<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('appsettings', function (Blueprint $table) {
            $table->id();
            $table->string('api_key',300)->nullable();
            $table->string('redirect_url',300)->nullable();
            $table->text('permissions');
            $table->string('shared_secret',300);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('appsettings', function (Blueprint $table) {
            //
        });
    }
}
