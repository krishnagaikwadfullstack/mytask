import React, { Component,useEffect, useState, useRef } from 'react';
import ReactDOM from 'react-dom';
import createApp from '@shopify/app-bridge';
import {ContextualSaveBar,Loading,Toast,Redirect} from '@shopify/app-bridge/actions'
import axios from 'axios';
import {Provider, ResourcePicker} from '@shopify/app-bridge-react';
import DatePickerComp from './Datepicker';

export default class EditLocation extends Component {
    constructor(props){
        super(props);
        this.state = {
            shop: props.shop,
            shop_detail: props.shopdetail,
            loader: Loading.create(app),
            save_location_success_notice : Toast.create(app,{message: 'Location updated successfully!'}),
            save_location_error_notice : Toast.create(app,{message: 'Error occurrred while adding location.', isError:true}),
            validation_error_notice : Toast.create(app,{message: 'Please enetr all required fields.', isError:true}),
            error_notice : Toast.create(app,{message: 'Something went wrong!', isError:true}),
            isChecked : false,
            checkbox_value : 2,
            current_id : JSON.parse(props.shopdetail).fn_locations[0].id,
            enable_pickup_date_checked : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup && JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup.enable_pickup_date == 1) ? true : false,
            enable_pickup_date_checkbox_value : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup.enable_pickup_date : 2,
            enable_pickup_time_checked : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup && JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup.enable_pickup_time == 1) ? true : false,
            enable_pickup_time_checkbox_value : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup.enable_pickup_time : 2,
            block_days_interval_checked : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup && JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup.block_days_interval == 1) ? true : false,
            block_days_interval_checkbox_value : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup.block_days_interval : 2,
            cuttoff_status_checked : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup && JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup.cuttoff_status == 1) ? true : false,
            cuttoff_status_checkbox_value : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup.cuttoff_status : 2,
            local_delivery_status_checked : (JSON.parse(props.shopdetail).fn_locations[0] && JSON.parse(props.shopdetail).fn_locations[0].local_delivery_status == 1) ? true : false,
            local_delivery_status_checkbox_value : (JSON.parse(props.shopdetail).fn_locations[0]) ? JSON.parse(props.shopdetail).fn_locations[0].local_delivery_status : 2,
            enable_local_delivery_date_checked : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery && JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery.enable_local_delivery_date == 1) ? true : false,
            enable_local_delivery_date_checkbox_value : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery.enable_local_delivery_date : 2,
            enable_local_delivery_time_checked : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery && JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery.enable_local_delivery_time == 1) ? true : false,
            enable_local_delivery_time_checkbox_value : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery.enable_local_delivery_time : 2,
            local_delivery_block_days_interval_checked : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery && JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_block_days_interval == 1) ? true : false,
            local_delivery_block_days_interval_checkbox_value : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_block_days_interval : 2,
            local_delivery_cuttoff_status_checked : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery && JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_cuttoff_status == 1) ? true : false,
            local_delivery_cuttoff_status_checkbox_value : (JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_cuttoff_status : 2,
            show_local_delivery : (JSON.parse(props.shopdetail).fn_locations[0].local_delivery_status == 1)? true : false,
            store_pickup_checkbox_value : JSON.parse(props.shopdetail).fn_locations[0].store_pickup_status,
            show_store_pickup : (JSON.parse(props.shopdetail).fn_locations[0].store_pickup_status == 1)? true : false,
            date_format : JSON.parse(props.shopdetail).block_config.date_format,
            date_values: [],
            default_date_value: (JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup.block_dates :[],
            default_local_delivery_date_values: (JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_block_date :[],
            local_delivery_date_values: [],
            block_days: (JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_store_pickup.block_days :[],
            local_delivery_block_days: (JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_block_days :[],
            value: '',
            startDate: '',
            company_nameError: '',
            addressError: '',
            cityError: '',
            stateError: '',
            countryError: '',
            zipcodeError: '',
        };
        this.handleSubmit = this.handleSubmit.bind(this);
    }
    toggleChange = (e) => {
        this.state.loader.dispatch(Loading.Action.START);
        this.setState({
            isChecked : (this.state.enable_location == '1') ? true : false,
            enable_location : (this.state.enable_location == '1') ? '2' : '1',
            checkbox_value : (this.state.checkbox_value == '1') ? '2' : '1',
        });
        if(e.target.name == 'enable_pickup_date'){
            this.setState({
                enable_pickup_date_checked : (this.state.enable_pickup_time_checkbox_value == '1') ? true : false,
                enable_pickup_date_checkbox_value : (this.state.enable_pickup_date_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'enable_pickup_time'){
            this.setState({
                enable_pickup_time_checked : (this.state.enable_pickup_time_checkbox_value == '1') ? true : false,
                enable_pickup_time_checkbox_value : (this.state.enable_pickup_time_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'block_days_interval'){
            this.setState({
                block_days_interval_checked : (this.state.block_days_interval_checkbox_value == '1') ? true : false,
                block_days_interval_checkbox_value : (this.state.block_days_interval_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'cuttoff_status'){
            this.setState({
                cuttoff_status_checked : (this.state.cuttoff_status_checkbox_value == '1') ? true : false,
                cuttoff_status_checkbox_value : (this.state.cuttoff_status_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'local_delivery_status'){
            this.setState({
                local_delivery_status_checked : (this.state.local_delivery_status_checkbox_value == '1') ? true : false,
                local_delivery_status_checkbox_value : (this.state.local_delivery_status_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'enable_local_delivery_date'){
            this.setState({
                enable_local_delivery_date_checked : (this.state.enable_local_delivery_date_checkbox_value == '1') ? true : false,
                enable_local_delivery_date_checkbox_value : (this.state.enable_local_delivery_date_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'enable_local_delivery_time'){
            this.setState({
                enable_local_delivery_time_checked : (this.state.enable_local_delivery_time_checkbox_value == '1') ? true : false,
                enable_local_delivery_time_checkbox_value : (this.state.enable_local_delivery_time_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'local_delivery_block_days_interval'){
            this.setState({
                local_delivery_block_days_interval_checked : (this.state.local_delivery_block_days_interval_checkbox_value == '1') ? true : false,
                local_delivery_block_days_interval_checkbox_value : (this.state.local_delivery_block_days_interval_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'local_delivery_cuttoff_status'){
            this.setState({
                local_delivery_cuttoff_status_checked : (this.state.local_delivery_cuttoff_status_checkbox_value == '1') ? true : false,
                local_delivery_cuttoff_status_checkbox_value : (this.state.local_delivery_cuttoff_status_checkbox_value == '1') ? '2' : '1',
            });
        }
        this.state.loader.dispatch(Loading.Action.STOP);
    }
    toggleStorePickupChange = (e) => {
        this.state.loader.dispatch(Loading.Action.START);
        this.setState({
            store_pickup_checkbox_value : (this.state.store_pickup_checkbox_value == 1) ? 2 : 1,
        });
        if(e.target.value == 2){
            this.setState({
                show_store_pickup : true,
            });
        }else{
            this.setState({
                show_store_pickup : false,
            });
        }
        this.state.loader.dispatch(Loading.Action.STOP);
    }
    toggleLocalDeliveryChange = (e) => {
        this.state.loader.dispatch(Loading.Action.START);
        this.setState({
            local_delivery_status_checkbox_value : (this.state.local_delivery_status_checkbox_value == 1) ? 2 : 1,
        });
        if(e.target.value == 2){
            this.setState({
                show_local_delivery : true,
            });
        }else{
            this.setState({
                show_local_delivery : false,
            });
        }
        this.state.loader.dispatch(Loading.Action.STOP);
    }
    handleSubmit(e) {
        e.preventDefault();
        const formData = {};
        const date_array = [];
        const local_date_arrry = [];
        if(this.state.date_values.length > 0){
            this.state.date_values.map((e,i) => {
                if(typeof e === 'string' && e.includes("/")){
                    date_array.push(e);
                }else{
                    if (this.state.date_format == 'mm/dd/yy') {
                        date_array.push(e.month.number+'/'+e.day+'/'+e.year);
                    }
                    if (this.state.date_format == 'dd/mm/yy') {
                        date_array.push(e.day+'/'+e.month.number+'/'+e.year);
                    }
                    if (this.state.date_format == 'yy/mm/dd') {
                        date_array.push(e.year+'/'+e.month.number+'/'+e.day);
                    }
                }
            });
            formData['block_dates'] = date_array;
        }
        if(this.state.local_delivery_date_values.length > 0){
            this.state.local_delivery_date_values.map((e,i) => {                
                if(typeof e === 'string' && e.includes("/")){
                    local_date_arrry.push(e);
                }else{
                    if (this.state.date_format == 'mm/dd/yy') {
                        local_date_arrry.push(e.month.number+'/'+e.day+'/'+e.year);
                    }
                    if (this.state.date_format == 'dd/mm/yy') {
                        local_date_arrry.push(e.day+'/'+e.month.number+'/'+e.year);
                    }
                    if (this.state.date_format == 'yy/mm/dd') {
                        local_date_arrry.push(e.year+'/'+e.month.number+'/'+e.day);
                    }
                }
            });
            formData['local_delivery_block_date'] = local_date_arrry;
        }
        for (const field in this.refs) {
            var field_name = `${field}Error`;
            formData[field] = this.refs[field].value;
            if(field == 'block_days'){
                formData[field] = this.state.block_days;
            }
            if(field == 'local_delivery_block_days'){
                formData[field] = this.state.local_delivery_block_days;
            }
            this.setState({
                [field_name]: false
            });
            if(this.refs[field].value==='undefined' || this.refs[field].value==='' || this.refs[field].value===null){
                if(field_name == 'pickup_timeError' && this.refs['enable_pickup_time'].value == 2){
                    this.setState({
                        [field_name]:false
                    })
                }else{
                    this.setState({
                        [field_name]:true
                    })
                    // this.state.validation_error_notice.dispatch(Toast.Action.SHOW);
                }
            }else{
                this.setState({
                    [field_name]:false
                })
            }
        }
        console.log('formData',formData,(this.state.company_nameError , this.state.addressError , this.state.cityError , this.state.stateError , this.state.countryError ,this.state.zipcodeError))
        if(this.state.company_nameError == false && this.state.addressError == false && this.state.cityError == false && this.state.stateError == false && this.state.countryError == false && this.state.zipcodeError == false){
            this.state.loader.dispatch(Loading.Action.START);
            axios({
                url:'locations/'+this.state.current_id,
                method:"PUT",
                data: formData,
            }).then((response)=>{
                if(response.data.status == 'success'){
                    this.setState({
                       save_location_success_notice: Toast.create(app,{message: response.data.message}), 
                    });
                    this.state.save_location_success_notice.dispatch(Toast.Action.SHOW);
                    // history.push(location_url);
                    window.location.href = location_url;
                    // navigate(location_url);
                    // redirect.dispatch(Redirect.Action.APP, location_url);
                }
                if(response.data.status == 'error'){
                    this.setState({
                       save_location_error_notice: Toast.create(app,{message: response.data.message, isError:true}),
                    });
                    this.state.save_location_error_notice.dispatch(Toast.Action.SHOW);
                }
                this.state.loader.dispatch(Loading.Action.STOP);
            },(error)=>{
                this.state.error_notice.dispatch(Toast.Action.SHOW);
                this.state.loader.dispatch(Loading.Action.STOP);
            });
        }
    }
    handleChange(e){
        const target = e.target;
        const value = target.type === 'checkbox' ? target.checked : target.value;
        const name = target.name;
        this.setState({
            [name]: value
        });
        var field_name = `${name}Error`;
        if(e.target.value==='' || e.target.value===null ){
          this.setState({
            [field_name]:true
          })
        } else {
          this.setState({
            [field_name]:false,
          })
        }
    }
    generalSettingPage = () => {
        redirect.dispatch(Redirect.Action.APP,dashboard_url)
    }
    cancelLocationClick = () => {
        redirect.dispatch(Redirect.Action.APP,location_url)
    }
    togglePicker = () => {
            this.setState(({ resourcePickerOpen }) => {
            return { resourcePickerOpen: false };
        });
    }
    handleSelection = (resources) => {
        const formData = [];
        for (const item in resources.selection) {
            formData[item] = {'id': resources.selection[item].id};
        }
        this.setState({ selected_product: formData })
        this.setState({ resourcePickerOpen: false })
    }
    radioHandler = (status) => {
        this.setState({ status:status });
        if(status == 2){
            this.setState({ show_product_selection:true });
        }
    };
    handleDateChange = (event) => {
        this.setState({date_values:event});
    }
    handleLocalDeliveryDateChange = (event) => {
        this.setState({local_delivery_date_values:event});
    }
    handleSelectChange = (e) => {
        let target = e.target
        let name = target.name
        //here get selected value
        let value = Array.from(target.selectedOptions, option => option.value);
        this.setState({
          [name]: value
        });
    }
    render() {
        var hours = ['00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
        const listhourItems = hours.map((number) =>
            <option key={number.toString()} value={number}>{number}</option>
        );
        const listminuteItems = [...Array(60)].map((e, i) =>
            <option key={i} value={i}>{i}</option>
        );
        //
        return(
            <div className="location-wraper">
                <div className="row">
                    <div className="col-md-6">
                        <h2 className="heading">Update Locations</h2>
                    </div>
                    <div className="col-md-6 cancel-location-btn">
                        <a href={location_url} onClick={this.cancelLocationClick} className="btn btn-primary button">Cancel</a>
                    </div>
                </div>
                <form onSubmit={this.handleSubmit}>
                    <input ref="shop" type="hidden" name="shop" defaultValue={this.state.shop} />
                    <div className="row formcolor_row">
                        <div className="company_label">
                            <div><strong>Company Name *</strong></div>
                            <div><input ref="company_name" type="text" id="company_name" name="company_name" className="form-control" defaultValue={JSON.parse(this.props.shopdetail).fn_locations[0].company_name} onChange={(e)=>{this.handleChange(e)}}/></div>
                            {this.state.company_nameError ? <span style={{color: "red"}}>Please Enter Company Name</span> : ''} 
                        </div>
                        <div className="address">
                            <div><strong>Address *</strong></div>
                            <div><input ref="address" type="text" id="address" name="address" className="form-control" onChange={(e)=>{this.handleChange(e)}} defaultValue={JSON.parse(this.props.shopdetail).fn_locations[0].address}/></div>
                            {this.state.addressError ? <span style={{color: "red"}}>Please Enter Address</span> : ''}
                        </div>
                        <div className="city_label">
                            <div><strong>City *</strong></div>
                            <div><input ref="city" type="text" id="city" name="city" className="form-control" onChange={(e)=>{this.handleChange(e)}} defaultValue={JSON.parse(this.props.shopdetail).fn_locations[0].city}/></div>
                            {this.state.cityError ? <span style={{color: "red"}}>Please Enter City Name</span> : ''}
                        </div>
                        <div className="state_label">
                            <div><strong>State *</strong></div>
                            <div><input ref="state" type="text" id="state" name="state" className="form-control" onChange={(e)=>{this.handleChange(e)}} defaultValue={JSON.parse(this.props.shopdetail).fn_locations[0].state}/></div>
                            {this.state.stateError ? <span style={{color: "red"}}>Please Enter State Name</span> : ''}
                        </div>
                        <div className="country_label">
                            <div><strong>Country *</strong></div>
                            <div><input ref="country" type="text" id="country" name="country" className="form-control" onChange={(e)=>{this.handleChange(e)}} defaultValue={JSON.parse(this.props.shopdetail).fn_locations[0].country}/></div>
                            {this.state.countryError ? <span style={{color: "red"}}>Please Enter Country Name</span> : ''}
                        </div>
                        <div className="zipcode_label">
                            <div><strong>Zipcode *</strong></div>
                            <div><input ref="zipcode" type="text" id="zipcode" name="zipcode" className="form-control" onChange={(e)=>{this.handleChange(e)}} defaultValue={JSON.parse(this.props.shopdetail).fn_locations[0].zipcode}/></div>
                            {this.state.zipcodeError ? <span style={{color: "red"}}>Please Enter Zipcode</span> : ''}
                        </div>
                        <div className="additional_info_label">
                            <div><strong>Additional Info</strong></div>
                            <div><input ref="additional_info" type="text" id="additional_info" name="additional_info" className="form-control" defaultValue={JSON.parse(this.props.shopdetail).fn_locations[0].additional_info}/></div>
                        </div>
                        <div className="enable-disable-app">
                            <div className="col-sm-12" title="Option to Enable/Disable Location">                      
                                <strong>Enable or Disable Store Pickup? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                <label className="switch">
                                  <input ref="store_pickup_status" name="store_pickup_status" type="checkbox" onClick={this.toggleStorePickupChange} defaultValue={this.state.store_pickup_checkbox_value} defaultChecked={(this.state.store_pickup_checkbox_value == 1) ? true : false}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                            {this.state.show_store_pickup && <div className="col-sm-12 store_pickup_div">
                                <div>
                                    <div className="col-sm-12"><strong>Blocked Date(s)</strong></div>
                                    <div className="main-date" id="main-date">
                                        <DatePickerComp shopdetail={this.state.shop_detail} handleDateChange={this.handleDateChange.bind(this)} default_date_value={this.state.default_date_value} fieldname="block_date"/>
                                    </div>
                                    <div className="note">
                                        <strong>Note:</strong>List of dates that will be blocked for delivery so user won't be able to select it for the order delivery.
                                    </div>

                                    <div className="col-sm-12" title="Option to Enable/Disable Date">
                                        <strong>Enable or Disable Pickup Date? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                        <label className="switch">
                                          <input ref="enable_pickup_date" name="enable_pickup_date" type="checkbox" onClick={this.toggleChange} defaultChecked={(this.state.enable_pickup_date_checkbox_value == 1) ? true :false} defaultValue={this.state.enable_pickup_date_checkbox_value}/>
                                          <span className="slider round"></span>
                                        </label>
                                    </div>
                                    <div className="col-sm-12" title="Option to Enable/Disable Time">
                                        <strong>Enable or Disable Pickup Time? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                        <label className="switch">
                                          <input ref="enable_pickup_time" name="enable_pickup_time" type="checkbox" onClick={this.toggleChange} defaultChecked={(this.state.enable_pickup_time_checkbox_value == 1) ? true : false} defaultValue={this.state.enable_pickup_time_checkbox_value}/>
                                          <span className="slider round"></span>
                                        </label>
                                    </div>
                                    <div className="order_note">
                                        <div><span className="note"><strong>Pickup Time</strong> (Add <b>","</b>(comma) separated values)</span></div>
                                        <div>
                                            <textarea ref="pickup_time" id="pickup_time" name="pickup_time" className="form-control" rows="5" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_store_pickup.pickup_time : ''}></textarea>
                                        </div>
                                        {this.state.pickup_timeError ? <span style={{color: "red"}}>Please Enter Pickup Time</span> : ''}
                                    </div>
                                    <div>  
                                        <div className="col-sm-12">
                                            <strong>Add Block Days Interval? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                            <label className="switch">
                                              <input ref="block_days_interval" name="block_days_interval" type="checkbox" onClick={this.toggleChange} defaultChecked={this.state.block_days_interval_checked} defaultValue={this.state.block_days_interval_checkbox_value}/>
                                              <span className="slider round"></span>
                                            </label>
                                        </div>   
                                        <div className="note">
                                            <strong>Note:</strong> Use "Add Block Days", if you wish to add extra days for interval due to Block Days.
                                        </div>
                                    </div>
                                    <br/>
                                    <br/>
                                    <div>
                                        <strong>Block Day(s)</strong>
                                        <div className="form-group block_days">
                                            <select ref="block_days" size="8" className="form-control" name="block_days" multiple={true} onChange={this.handleSelectChange}  value={this.state.block_days}>
                                                <option value="all_allow">All Allows</option>
                                                <option value="Sunday">Sunday</option>
                                                <option value="Monday">Monday</option>
                                                <option value="Tuesday">Tuesday</option>
                                                <option value="Wednesday">Wednesday</option>
                                                <option value="Thursday">Thursday</option>
                                                <option value="Friday">Friday</option>
                                                <option value="Saturday">Saturday</option>
                                            </select>
                                        </div>
                                        <div className="note">
                                            <strong>Note:</strong> Selected day will be blocked and user won't be able to select it as a delivery date.
                                        </div>
                                    </div>
                                    <br/>
                                    <br/>
                                    <div>
                                        <div><strong>Allowed Pre-order Time</strong></div>
                                        <div className="form-group margin_bottom_0">
                                            <input ref="allowed_preorder_time" className="form-control" type="number" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_store_pickup.allowed_preorder_time : 1} min="1" name="allowed_preorder_time" min="1" id="example-number-input" />
                                        </div>
                                        <div className="note">
                                            <strong>Note:</strong> This option will allow user to book order before "X" number of Months on the Website.
                                        </div>
                                    </div>
                                    <br/>
                                    <br/>
                                    <div>
                                        <div><strong>Minimum Date Interval</strong></div>
                                        <div className="form-group margin_bottom_0">
                                            <input ref="minimum_date_intervel" className="form-control" type="number" min="0" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_store_pickup.minimum_date_intervel : 0} name="minimum_date_intervel" id="example-number-input"/>
                                        </div>
                                        <div className="note">
                                            <strong>Note:</strong> For "Today Delivery" it should be "0" otherwise it should be the interval of days from the current day to allow user to select delivery date.
                                        </div>
                                    </div>
                                    <br/>
                                    <br/>
                                    <div className="col-sm-12">
                                        <strong>Cut Off Time? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                        <label className="switch">
                                          <input ref="cuttoff_status" name="cuttoff_status" type="checkbox" onClick={this.toggleChange} defaultChecked={this.state.cuttoff_status_checked} defaultValue={this.state.cuttoff_status_checkbox_value}/>
                                          <span className="slider round"></span>
                                        </label>
                                    </div>
                                    <div className="cuttofftime_box">
                                        <div className="display_block">
                                            <label>Hour</label>
                                            <select ref="hours" name="hours" className="form-control" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_store_pickup.hours : ''}>
                                                {listhourItems}
                                            </select>
                                        </div>
                                        <div className="display_block">
                                            <label>Minute</label>
                                            <select ref="minute" name="minute" className="form-control" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_store_pickup) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_store_pickup.minute : ''}>
                                                {listminuteItems}
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>}
                            <div className="col-sm-12" title="Option to Enable/Disable Location">
                                <strong>Enable or Disable Local Delivery? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                <label className="switch">
                                  <input ref="local_delivery_status" name="local_delivery_status" type="checkbox" onClick={this.toggleLocalDeliveryChange} defaultChecked={this.state.local_delivery_status_checked} defaultValue={this.state.local_delivery_status_checkbox_value}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                            {this.state.show_local_delivery && <div className="col-sm-12 store_pickup_div">
                                <div>
                                    <div className="col-sm-12"><strong>Blocked Date(s)</strong></div>
                                    <div className="main-date" id="main-date">
                                        <DatePickerComp shopdetail={this.state.shop_detail} handleDateChange={this.handleLocalDeliveryDateChange.bind(this)} default_date_value={this.state.default_local_delivery_date_values} fieldname="local_delivery_block_date"/>
                                    </div>
                                    <div className="note">
                                        <strong>Note:</strong>List of dates that will be blocked for delivery so user won't be able to select it for the order delivery.
                                    </div>

                                    <div className="col-sm-12" title="Option to Enable/Disable Date">
                                        <strong>Enable or Disable Local Delivery Date? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                        <label className="switch">
                                          <input ref="enable_local_delivery_date" name="enable_local_delivery_date" type="checkbox" onClick={this.toggleChange} defaultChecked={this.state.enable_local_delivery_date_checked} defaultValue={this.state.enable_local_delivery_date_checkbox_value}/>
                                          <span className="slider round"></span>
                                        </label>
                                    </div>
                                    <div className="col-sm-12" title="Option to Enable/Disable Time">
                                        <strong>Enable or Disable Local Delivery Time? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                        <label className="switch">
                                          <input ref="enable_local_delivery_time" name="enable_local_delivery_time" type="checkbox" onClick={this.toggleChange} defaultChecked={this.state.enable_local_delivery_time_checked} defaultValue={this.state.enable_local_delivery_time_checkbox_value}/>
                                          <span className="slider round"></span>
                                        </label>
                                    </div>
                                    <div className="order_note">
                                        <div><span className="note"><strong>Local Delivery Time</strong> (Add <b>","</b>(comma) separated values)</span></div>
                                        <div>
                                            <textarea ref="local_delivery_time" id="local_delivery_time" name="local_delivery_time" className="form-control" rows="5" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_time : ''}></textarea>
                                        </div>
                                        {this.state.local_delivery_timeError ? <span style={{color: "red"}}>Please Enter Pickup Time</span> : ''}
                                    </div>
                                    <div>  
                                        <div className="col-sm-12">
                                            <strong>Add Block Days Interval? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                            <label className="switch">
                                              <input ref="local_delivery_block_days_interval" name="local_delivery_block_days_interval" type="checkbox" onClick={this.toggleChange} defaultChecked={this.state.local_delivery_block_days_interval_checked} defaultValue={this.state.local_delivery_block_days_interval_checkbox_value} />
                                              <span className="slider round"></span>
                                            </label>
                                        </div>   
                                        <div className="note">
                                            <strong>Note:</strong> Use "Add Block Days", if you wish to add extra days for interval due to Block Days.
                                        </div>
                                    </div>
                                    <br/>
                                    <br/>
                                    <div>
                                        <strong>Block Day(s)</strong>
                                        <div className="form-group local_delivery_block_days">
                                            <select ref="local_delivery_block_days" size="8" className="form-control" name="local_delivery_block_days" multiple={true} onChange={this.handleSelectChange}  value={this.state.local_delivery_block_days}>
                                                <option value="all_allow">All Allows</option>
                                                <option value="Sunday">Sunday</option>
                                                <option value="Monday">Monday</option>
                                                <option value="Tuesday">Tuesday</option>
                                                <option value="Wednesday">Wednesday</option>
                                                <option value="Thursday">Thursday</option>
                                                <option value="Friday">Friday</option>
                                                <option value="Saturday">Saturday</option>
                                            </select>
                                        </div>
                                        <div className="note">
                                            <strong>Note:</strong> Selected day will be blocked and user won't be able to select it as a delivery date.
                                        </div>
                                    </div>
                                    <br/>
                                    <br/>
                                    <div>
                                        <div><strong>Distance Validation</strong></div>
                                        <div className="form-group margin_bottom_0">
                                            <input ref="distance" className="form-control" type="number" defaultValue="1" name="distance" min="1" id="example-distance-input" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery.distance : 1}/>
                                        </div>
                                        <div className="note">
                                            <strong>Note:</strong> To define the radius for checking eligibility for local delivery.
                                        </div>
                                    </div>
                                    <br/>
                                    <br/>
                                    <div>
                                        <div><strong>Postal Code Validation</strong></div>
                                        <div className="form-group margin_bottom_0">
                                            <textarea ref="postal_code" name="postal_code" placeholder="e.g. 10001,10002" type="text" rows="1" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery.postal_code : ''}></textarea>
                                        </div>
                                        <div className="note">
                                            <strong>Note:</strong> Eligible postal codes with a comma separated for local delivery.
                                        </div>
                                    </div>
                                    <br/>
                                    <br/>
                                    <div>
                                        <div><strong>Allowed Pre-order Time</strong></div>
                                        <div className="form-group margin_bottom_0">
                                            <input ref="local_delivery_allowed_preorder_time" className="form-control" type="number" defaultValue="1" name="local_delivery_allowed_preorder_time" min="1" id="example-number-input" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_allowed_preorder_time : 1}/>
                                        </div>
                                        <div className="note">
                                            <strong>Note:</strong> This option will allow user to book order before "X" number of Months on the Website.
                                        </div>
                                    </div>
                                    <br/>
                                    <br/>
                                    <div>
                                        <div><strong>Minimum Date Interval</strong></div>
                                        <div className="form-group margin_bottom_0">
                                            <input ref="local_delivery_minimum_date_intervel" className="form-control" type="number" min="0" defaultValue="0" name="local_delivery_minimum_date_intervel" id="example-number-input" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_minimum_date_intervel : 0}/>
                                        </div>
                                        <div className="note">
                                            <strong>Note:</strong> For "Today Delivery" it should be "0" otherwise it should be the interval of days from the current day to allow user to select delivery date.
                                        </div>
                                    </div>
                                    <br/>
                                    <br/>
                                    <div className="col-sm-12">
                                        <strong>Cut Off Time? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                        <label className="switch">
                                          <input ref="local_delivery_cuttoff_status" name="local_delivery_cuttoff_status" type="checkbox" onClick={this.toggleChange} defaultChecked={this.state.local_delivery_cuttoff_status_checked} defaultValue={this.state.local_delivery_cuttoff_status_checkbox_value}/>
                                          <span className="slider round"></span>
                                        </label>
                                    </div>
                                    <div className="cuttofftime_box">
                                        <div className="display_block">
                                            <label>Hour</label>
                                            <select ref="local_delivery_hours" name="local_delivery_hours" className="form-control" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_hours : ''}>
                                                {listhourItems}
                                            </select>
                                        </div>
                                        <div className="display_block">
                                            <label>Minute</label>
                                            <select ref="local_delivery_minute" name="local_delivery_minute" className="form-control" defaultValue={(JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery) ? JSON.parse(this.props.shopdetail).fn_locations[0].fn_location_local_delivery.local_delivery_minute : ''}>
                                                {listminuteItems}
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>}
                        </div>
                        <div className="submit-button">
                            <button className="button btn-primary" type="submit">Update</button>
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}
if (document.getElementById('editlocation')) {
    var shopdetail = document.getElementById('editlocation').getAttribute('shopdetail');
    var shop = document.getElementById('editlocation').getAttribute('shop');
    ReactDOM.render(<EditLocation shopdetail={shopdetail} shop={shop} />, document.getElementById('editlocation'));
}