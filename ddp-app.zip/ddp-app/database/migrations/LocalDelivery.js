import React, { Component,useEffect, useState, useRef } from 'react';
import ReactDOM from 'react-dom';
import createApp from '@shopify/app-bridge';
import {ContextualSaveBar,Loading,Toast,Redirect} from '@shopify/app-bridge/actions'
import axios from 'axios';

export default class LocalDelivery extends Component {
    constructor(props){
        super(props);
        this.state = {
            shop: props.shop,
            shop_detail: props.shopdetail,
            loader: Loading.create(app),
            save_localdelivery_success_notice : Toast.create(app,{message: 'Local Delievery Setting Saved successfully!'}),
            save_localdelivery_error_notice : Toast.create(app,{message: 'Error occurrred while adding location.', isError:true}),
            validation_error_notice : Toast.create(app,{message: 'Please enetr all required fields.', isError:true}),
            error_notice : Toast.create(app,{message: 'Something went wrong!', isError:true}),
            tag_list: (JSON.parse(props.shopdetail).fn_local_delivery.local_delivery_order_tags) ? JSON.parse(props.shopdetail).fn_local_delivery.local_delivery_order_tags : [],
            tag_text: '',
            enable_local_delivery_checkbox_value: JSON.parse(props.shopdetail).fn_local_delivery.enable_local_delivery,
            enable_local_delivery_checked: (JSON.parse(props.shopdetail).fn_local_delivery.enable_local_delivery == 1) ? true : false,
            enable_local_delivery_date_checkbox_value: JSON.parse(props.shopdetail).fn_local_delivery.enable_local_delivery_date,
            enable_local_delivery_date_checked: (JSON.parse(props.shopdetail).fn_local_delivery.enable_local_delivery_date == 1) ? true : false,
            enable_local_delivery_time_checkbox_value: JSON.parse(props.shopdetail).fn_local_delivery.enable_local_delivery_time,
            enable_local_delivery_time_checked: (JSON.parse(props.shopdetail).fn_local_delivery.enable_local_delivery_time == 1) ? true : false,
            enable_distance_validation_radio_value: JSON.parse(props.shopdetail).fn_local_delivery.enable_distance_validation
        };
        this.handleSubmit = this.handleSubmit.bind(this);        
        this.addOrderTag = this.addOrderTag.bind(this);
        this.removeOrderTag = this.removeOrderTag.bind(this);
    }
    toggleChange = (e) => {
        this.state.loader.dispatch(Loading.Action.START);
        if(e.target.name == 'enable_local_delivery'){
            this.setState({
                enable_local_delivery_checked : (this.state.enable_local_delivery_checkbox_value == '1') ? true : false,
                enable_local_delivery_checkbox_value : (this.state.enable_local_delivery_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'enable_local_delivery_date'){
            this.setState({
                enable_local_delivery_date_checked : (this.state.enable_local_delivery_date_checkbox_value == '1') ? true : false,
                enable_local_delivery_date_checkbox_value : (this.state.enable_local_delivery_date_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'enable_local_delivery_time'){
            this.setState({
                enable_local_delivery_time_checked : (this.state.enable_local_delivery_time_checkbox_value == '1') ? true : false,
                enable_local_delivery_time_checkbox_value : (this.state.enable_local_delivery_time_checkbox_value == '1') ? '2' : '1',
            });
        }
        this.state.loader.dispatch(Loading.Action.STOP);
    }
    handleSubmit(e) {
        e.preventDefault();
        const formData = {};
        for (const field in this.refs) {
            var field_name = `${field}Error`;
            formData[field] = this.refs[field].value;
        }
        formData['local_delivery_order_tags'] = this.state.tag_list;
        formData['enable_distance_validation'] = this.state.enable_distance_validation_radio_value;
        console.log('formData',formData,this.state.enable_distance_validation_radio_value)
        if(formData){
            this.state.loader.dispatch(Loading.Action.START);
            axios({
                url:'localdelivery',
                method:"post",
                data: formData,
            }).then((response)=>{
                if(response.data.status == 'success'){
                    this.setState({
                       save_localdelivery_success_notice: Toast.create(app,{message: response.data.message}), 
                    });
                    this.state.save_localdelivery_success_notice.dispatch(Toast.Action.SHOW);
                    // window.location.href = location_url;
                }
                if(response.data.status == 'error'){
                    this.setState({
                       save_localdelivery_error_notice: Toast.create(app,{message: response.data.message, isError:true}),
                    });
                    this.state.save_localdelivery_error_notice.dispatch(Toast.Action.SHOW);
                }
                this.state.loader.dispatch(Loading.Action.STOP);
            },(error)=>{
                this.state.error_notice.dispatch(Toast.Action.SHOW);
                this.state.loader.dispatch(Loading.Action.STOP);
            });
        }
    }
    addOrderTag = (e) => {
        var input_value = this.refs['local_delivery_order_tags'].value;
        if(input_value != '' && input_value != null){
            this.setState(prevState => ({
              tag_list: prevState.tag_list.concat(input_value),
              tag_text: ''
            }))
        }
        this.refs['local_delivery_order_tags'].value = '';
    }
    removeOrderTag = (index) => {        
        this.state.tag_list.splice(index, 1);
        this.setState({
           tag_list: this.state.tag_list.filter(i => i !== index)
        });
    }
    cancelLocationClick = () => {
        redirect.dispatch(Redirect.Action.APP,dashboard_new_url)
    }
    handleRadioChange = (e) => {
        this.setState({
            enable_distance_validation_radio_value : e.target.value
        });
    }
    render() {
        return(
            <div className="local-dev-main">
                <div className="row">
                    <div className="col-md-6">
                        <h2 className="heading">Local Delivery</h2>
                    </div>
                    <div className="col-md-6 cancel-location-btn">
                        <a onClick={this.cancelLocationClick} className="btn btn-primary button">Cancel</a>
                    </div>
                </div>
                <br/><br/><br/>
                <form onSubmit={this.handleSubmit}>
                    <input ref="shop" type="hidden" name="shop" defaultValue={this.state.shop} />
                    <br/>
                    <div className="row formcolor_row">
                        <div className="enable-disable-app">
                            <div className="col-sm-12" title="Option to Enable/Disable Local Delivery">                      
                                <strong>Enable or Disable Local Delivery? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                <label className="switch">
                                  <input ref="enable_local_delivery" name="enable_local_delivery" type="checkbox" onClick={this.toggleChange} defaultValue={this.state.enable_local_delivery_checkbox_value} defaultChecked={this.state.enable_local_delivery_checked}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div className="distance-validation-setting">
                            <strong>Distance Validation Setting</strong>
                            <ul className="">
                                <li className="">
                                    <label className="">            
                                        <span className="">
                                            <input ref="enable_distance_validation" id="enable_distance_validation1" name="enable_distance_validation" type="radio" defaultValue="1" onClick={this.handleRadioChange} defaultChecked={(this.state.enable_distance_validation_radio_value == 1) ? true : false} />
                                        </span>
                                        <span className="">Enable Postal Code</span>
                                    </label>
                                </li>
                                <li className="">
                                    <label className="">
                                        <span className="">
                                            <span className="">
                                                <input ref="enable_distance_validation" id="enable_distance_validation2" name="enable_distance_validation" type="radio" defaultValue="2" onClick={this.handleRadioChange} defaultChecked={(this.state.enable_distance_validation_radio_value == 2) ? true : false}/>
                                            </span>
                                        </span>
                                        <span className="">Enable Customer within specified radius</span>
                                    </label>
                                </li>
                            </ul>
                        </div>
                        <div className="enable-disable-app">
                            <div className="col-sm-12" title="Option to Enable/Disable Delievery Date">
                                <strong>Enable or Disable Delievery Date? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                <label className="switch">
                                  <input ref="enable_local_delivery_date" name="enable_local_delivery_date" type="checkbox" onClick={this.toggleChange} defaultValue={this.state.enable_local_delivery_date_checkbox_value} defaultChecked={this.state.enable_local_delivery_date_checked}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div className="enable-disable-app">
                            <div className="col-sm-12" title="Option to Enable/Disable Delievery Time">
                                <strong>Enable or Disable Delievery Time? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                <label className="switch">
                                  <input ref="enable_local_delivery_time" name="enable_local_delivery_time" type="checkbox" onClick={this.toggleChange} defaultValue={this.state.enable_local_delivery_time_checkbox_value} defaultChecked={this.state.enable_local_delivery_time_checked}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div className="localdelivery-order-tags">
                            <div className="">
                                <label className="order-tag-lable">Order tags</label>
                            </div>
                            <div className="add-tags-wrap">
                                <input ref="local_delivery_order_tags" type="text" name="local_delivery_order_tags" id="localdelivery_order_tag"/>
                                <div>{this.state.tag_list.length > 0 && this.state.tag_list.map((x,y) => {
                                  return <span key={y}>{x}
                                  <button className="remove-tag" onClick={this.removeOrderTag.bind(this,y)}>X</button>
                                  </span>})}
                                </div>
                                <div>
                                    <button type="button" id="local_delivery_order_tag_btn" onClick={this.addOrderTag}>
                                        <span className="">Add tag</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div className="submit-button">
                            <button className="button btn-primary" type="submit">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}
if (document.getElementById('localdelivery')) {
    var shopdetail = document.getElementById('localdelivery').getAttribute('shopdetail');
    var shop = document.getElementById('localdelivery').getAttribute('shop');
    ReactDOM.render(<LocalDelivery shopdetail={shopdetail} shop={shop} />, document.getElementById('localdelivery'));
}