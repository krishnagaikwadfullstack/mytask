<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStorePickupLocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('store_pickup_locations', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('store_pickup_id')->unsigned(); 
            $table->foreign('store_pickup_id')->references('id')->on('store_pickups');
            $table->integer('location_id')->unsigned(); 
            $table->foreign('location_id')->references('id')->on('locations');
            $table->enum('enable_pickup_date',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->enum('enable_pickup_time',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->text('pickup_time')->nullable();
            $table->enum('block_days_interval',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->text('block_days')->nullable();
            $table->integer('allowed_preorder_time'); 
            $table->integer('minimum_date_intervel'); 
            $table->enum('cuttoff_status',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->integer('hours'); 
            $table->integer('minute'); 
            $table->text('block_dates')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('store_pickup_locations');
    }
}
