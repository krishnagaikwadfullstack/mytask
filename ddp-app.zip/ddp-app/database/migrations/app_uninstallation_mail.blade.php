<html>

    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            @import url("https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i");
            @media only screen and (max-width:599px) {
                table {
                    width: 100% !important;
                }
            }
            
            @media only screen and (max-width:412px) {
                h2 {
                    font-size: 20px;
                }
                p {
                    font-size: 13px;
                }
                .easy-donation-icon img {
                    width: 120px;
                }
            }
        </style>

    </head>
    <body style="background: #f4f4f4; padding-top: 57px; padding-bottom: 57px;">
        <table class="main" border="0" cellspacing="0" cellpadding="0" width="600px" align="center" style="border: 1px solid #e6e6e6; background:#fff; ">
            <tbody>
                <tr>
                    <td style="padding: 30px 30px 10px 30px;" class="review-content">
                        <p class="text-align:left;"><img src="{{$logo}}" alt=""></p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px; line-height: 25px; margin-top: 0px;"><b>Hi  {{$shopInfo->shop_owner ?? ''}}</b>,</p>
                        
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">You have Un-installed Shopify Application - "{{ $app_name }}" from your store.</p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">If you have faced any issue with the application in terms of functional part or design related issues, we can assist you to resolve it for you.</p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">Some of the important features are Delivery Date for order, Delivery Time, Block Days, Block Dates, Cut Off time, Cut Off time for individual weekdays, Limit number of delivery for day or delivery time, order export based on delivery
                            date, Add information to customer order email, admin order notification, language support & Custom Design etc.</p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">Please have a look at below Live Stores to understand how you can use it for your website:</p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">==========================================================</p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">1)Integrated <b>Calendar</b>  on the cart page on the <b>pickup option</b> <a href="https://studiofullbloom.com/cart" target="_blank">https://studiofullbloom.com/cart</a></p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">2)Integrated <b>Calendar</b>  on the <b>product page</b> <a href="https://www.flowers24.com/collections/spring-flowers/products/mellow-yellow?variant=32729653084291" target="_blank">https://www.flowers24.com/collections/spring-flowers/products/mellow-yellow?variant=32729653084291</a></p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">3)Integarted <b>Calendar</b>  on <b>cart page</b> <a href="https://copperhousebakery.com/cart" target="_blank">https://copperhousebakery.com/cart</a></p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">4) Integrated <b>Delivery date and Delivery Time</b> on the cart page  <a href="https://clamandoyster.com/cart" target="_blank">https://clamandoyster.com/cart</a></p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">5)Integrated <b>Calendar</b>  on the <b>cart page</b>  <a href="https://cupcakesweeties.co.nz/cart" target="_blank">https://cupcakesweeties.co.nz/cart</a></p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px; line-height: 25px; margin-top: 0px;">Also, do not forget to read the reviews of happy customers. We have 1000s active stores with the application.</p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px; line-height: 25px; margin-top: 0px;">Please let us know if you have any query.</p>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px; line-height: 25px; margin-top: 0px;">PS: Don\'t forget to check our new App:: Shopify Product Matrix.</p>
    
                    </td>
                </tr>
                <tr>
                    <td style="padding: 20px 30px 30px 30px;">
                        <br>
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 26px; margin-bottom:0px;">Thanks,<br>Zestard Support</p>
                    </td>
                </tr>
    
            </tbody>
        </table>
    </body>
</html>