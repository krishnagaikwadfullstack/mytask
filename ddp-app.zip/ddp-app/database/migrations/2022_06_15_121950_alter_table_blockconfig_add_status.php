<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterTableBlockconfigAddStatus extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('block_config', function (Blueprint $table) {
           $table->enum('enable_store_pickup', ['1', '2'])->comment('1-Yes, 2-No')->default('2');
           $table->enum('enable_local_delivery', ['1', '2'])->comment('1-Yes, 2-No')->default('2');
           $table->enum('enable_external_delivery', ['1', '2'])->comment('1-Yes, 2-No')->default('2');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('block_config', function (Blueprint $table) {
            //
        });
    }
}
