<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLocalDeliveryLocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('local_delivery_locations', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('local_delivery_id')->unsigned(); 
            $table->foreign('local_delivery_id')->references('id')->on('local_deliveries');
            $table->integer('location_id')->unsigned(); 
            $table->foreign('location_id')->references('id')->on('locations');
            $table->enum('enable_local_delivery_date',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->enum('enable_local_delivery_time',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->text('local_delivery_time')->nullable();
            $table->enum('local_delivery_block_days_interval',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->text('local_delivery_block_days')->nullable();
            $table->integer('local_delivery_allowed_preorder_time'); 
            $table->integer('local_delivery_minimum_date_intervel'); 
            $table->enum('local_delivery_cuttoff_status',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->integer('local_delivery_hours'); 
            $table->integer('local_delivery_minute'); 
            $table->text('local_delivery_block_date')->nullable();
            $table->float('distance', 8, 2);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('local_delivery_locations');
    }
}
