<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterTableUsersettingsAddChargeUpdateFlag extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('usersettings', function (Blueprint $table) {
            $table->enum('charge_update_flag', ['1', '2', '3'])->comment('1-Default, 2-Charge Updated, 3- Charge Approved')->default('1');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('usersettings', function (Blueprint $table) {
            //
        });
    }
}
