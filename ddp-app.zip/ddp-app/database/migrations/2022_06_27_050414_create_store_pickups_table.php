<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStorePickupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('store_pickups', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('shop_id')->unsigned(); 
            $table->foreign('shop_id')->references('id')->on('usersettings');
            $table->enum('enable_store_pickup',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->enum('enable_storepickup_delivery_date',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->enum('enable_storepickup_delivery_time',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->enum('location_filter',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->string('storepickup_order_tags',255)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('store_pickups');
    }
}
