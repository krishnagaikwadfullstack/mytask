<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLocationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('locations', function (Blueprint $table) {
            $table->id();
            $table->integer('shop_id')->unsigned(); 
            $table->foreign('shop_id')->references('id')->on('usersettings'); 
            $table->string('company_name',255);
            $table->text('address');
            $table->string('city',255);
            $table->string('country',255);
            $table->string('state',255);
            $table->integer('zipcode');
            $table->text('additional_info')->nullable();
            $table->enum('store_pickup_status',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->enum('local_delivery_status',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('locations');
    }
}
