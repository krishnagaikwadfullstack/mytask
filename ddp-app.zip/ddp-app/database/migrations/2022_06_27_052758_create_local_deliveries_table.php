<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLocalDeliveriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('local_deliveries', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('shop_id')->unsigned(); 
            $table->foreign('shop_id')->references('id')->on('usersettings');
            $table->enum('enable_local_delivery',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->enum('enable_distance_validation',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->enum('enable_local_delivery_date',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->enum('enable_local_delivery_time',['1','2'])->comment('1-Yes, 2-No')->default('2');
            $table->string('local_delivery_order_tags',255)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('local_deliveries');
    }
}
