<?php

/*
  |--------------------------------------------------------------------------
  | Web Routes
  |--------------------------------------------------------------------------
  |
  | Here is where you can register web routes for your application. These
  | routes are loaded by the RouteServiceProvider within a group which
  | contains the "web" middleware group. Now create something great!
  |
 */
// header('Set-Cookie: cross-site-cookie=name; SameSite=None; Secure');
Route::get('/', function () {
    return view('welcome');
});
Route::any('getlat', 'App\Http\Controllers\orderController@getLat');
## webhook routes
Route::any('/uninstallappwebhook', 'WebHookController@index');
Route::any('/checkoutwebhook', 'CheckoutWebHookController@index');
Route::any('/shopupdatewebhook', 'ShopUpdateWebHookController@index');


#Routes AuthenticateController
Route::get('callback', 'AuthenticateController@authenticate')->name('authenticate');
Route::get('redirect', 'AuthenticateController@fn_install_app')->name('redirect');
Route::get('select-plans', 'AuthenticateController@fn_select_plan')->name('select-plans');
Route::post('plan/{plan_id}', 'AuthenticateController@fn_change_plan')->name('plan');
Route::get('uninstall', 'AuthenticateController@uninstall')->name('uninstall');
Route::get('payment_process', 'AuthenticateController@fn_payment_process')->name('payment_process');
Route::get('payment_success', 'AuthenticateController@fn_payment_success')->name('payment_success');
Route::get('help', 'AuthenticateController@help')->name('help');

#Upgrade
# Routes orderController
Route::any('order', 'orderController@index')->name('order');
Route::any('orders', 'orderController@orders')->name('orders');
Route::any('order-demo', 'orderController@order_export')->name('order-demo');
Route::any('update-order', 'orderController@updateDeliveryDate')->middleware('cors')->name('update_details');
Route::any('update_thankyou_page', 'orderController@updateDeliveryDate')->middleware('cors')->name('update_thankyou_page');
Route::any('get_delivery_update', 'orderController@getDeliveryUpdate')->middleware('cors')->name('get_delivery_update'); 

# Routes cutoffController
Route::any('cut-off', 'cutoffController@cut_off')->middleware('check_permission')->name('cut-off');
Route::any('save-cut-off', 'cutoffController@save_cut_off')->middleware('check_permission')->name('save-cut-off');
# Routes deliverytimeController
Route::any('delivery-time', 'deliverytimeController@delivery_time')->middleware('check_permission')->name('delivery-time');
Route::any('save-delivery-times', 'deliverytimeController@save_delivery_times')->middleware('check_permission')->name('save-delivery-times');
# Routes testing_controller
Route::any('demomail','testing_controller@demo_mail');
#Routes Product Settings 
Route::any('check-data', 'DashboardController@check_data')->name('check-data');
Route::any('get-product-data', 'DashboardController@get_product_data')->name('get-product-data');
Route::any('product-settings', 'Product_Controller@product_settings')->middleware('check_permission_product')->name('product-settings');
Route::any('save-product-settings', 'Product_Controller@save_product_settings')->middleware('check_permission_product')->name('save-product-settings');
Route::any('save-product-data', 'Product_Controller@check_data')->middleware('check_permission_product')->name('save-product-data');
Route::any('product-data', 'Product_Controller@product_data')->name('product-data');
Route::any('get-product-settings', 'Product_Controller@get_product_settings')->middleware('cors')->name('get-product-settings');
# Routes DashboardController
Route::get('dashboard', 'DashboardController@index')->name('dashboard');
Route::get('settings', 'DashboardController@fn_setting')->name('settings');
Route::any('get-delivery-times', 'DashboardController@get_delivery_times')->middleware('cors')->name('get-delivery-times');
Route::any('get-cutoff-time', 'DashboardController@get_cutoff_time')->middleware('cors')->name('get-cutoff-time');
Route::any('check-cuttoff', 'DashboardController@check_cutoff_time')->middleware('cors')->name('check-cuttoff');
Route::any('check-blocked-day', 'DashboardController@check_blocked_day')->middleware('cors')->name('check-blocked-day');
Route::any('check-blocked-date', 'DashboardController@check_blocked_date')->middleware('cors')->name('check-blocked-date');
Route::any('check-delivery-time', 'DashboardController@check_delivery_time')->middleware('cors')->name('check-delivery-time');
Route::any('get-plan-info', 'DashboardController@get_type_and_version')->middleware('cors')->name('get-plan-info');
Route::any('update-modal-status', 'DashboardController@update_modal_status')->middleware('cors')->name('update-modal-status');
Route::any('upgrade-modal-status', 'DashboardController@update_upgrade_modal_status')->middleware('cors')->name('upgrade-modal-status');
Route::any('denied', 'DashboardController@permission_denied')->name('denied');
Route::any('acknowledge', 'DashboardController@acknowledge')->middleware('cors')->name('acknowledge');
Route::any('save-delivery-info', 'DashboardController@save_delivery_info')->middleware('cors')->name('save-delivery-info');
Route::any('check-delivery-info', 'DashboardController@check_delivery_info')->middleware('cors')->name('check-delivery-info');

Route::post('saveconfig', 'DashboardController@store')->name('saveconfig');
Route::get('appconfiguration', 'DashboardController@selectdate')->middleware('cors')->name('appconfiguration');
Route::get('getconfigandtype', 'DashboardController@getconfigandtype')->middleware('cors')->name('getconfigandtype');
Route::any('delivery-date-pro', 'DashboardController@delivery_date_pro')->middleware('cors')->name('delivery-date-pro');
Route::any('edit/{id}', 'DashboardController@update')->name('edit');
Route::any('check-cart', 'DashboardController@check_cart')->middleware('cors')->name('check-cart');

Route::any('check-delivery-info', 'DashboardController@check_delivery_info')->middleware('cors')->name('check-delivery-info');
Route::any('thank-you-page', 'DashboardController@thank_you_page')->middleware('cors')->name('thank-you-page');

Route::any('new-features', function() {
    return view('features');
})->name('new-features');
Route::any('snippet', function() {
    return view('snippets');
});
Route::get('/clear-cache', function() {
    Artisan::call('cache:clear');
    return "Cache is cleared";
});
Route::get('plan-verification', function() {
    \Artisan::call('plan:verification');
    dd("Plan verification cron run successfully");
});
# Routes Store Information
Route::any('store-info-csv', 'orderController@getStoreInfo')->name('store-info-csv');
Route::get('unauthorised', function() {
    return view('unauthorised');
});