@extends('header')
@section('content')
<?php
	$shop = session('shop') ?? request()->get('shop');
?>
<script type="text/javascript">
    const navigationMenu = NavigationMenu.create(app, {
      items: [dashboardNewLink,dashboardLink, ordersLink, versionLink,helpLink],
    });
    const titleBarOptions = {
        title: 'Location'+ "{{Config::get('constants.arr_version_name')[$shop_detail->app_version]}}"
    }; 
    const myTitleBar = TitleBar.create(app, titleBarOptions);
    function generalSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, dashboard_url);
    }
</script>
<div class="container" id="location" shopdetail="{{json_encode($shop_detail,true)}}" shop="{{$shop}}">
</div>
<script type="text/javascript" src="./js/app.js"></script>
@endsection
