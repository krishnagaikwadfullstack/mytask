<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use Exception;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Events\WebhookProcessedEvent;
use App\ShopModel;
use App\StoreInformation;
class ShopUpdateWebHookController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        try {
            $data = file_get_contents('php://input');
            $this->shop_info = json_decode($data);
            $store_name = $this->shop_info->myshopify_domain ?? 'N/A';
            $store_email = $this->shop_info->email;
            $objShopDetails = ShopModel::whereStoreName($store_name)->first();
            ## check all table has data then delete it.
            if(!is_null($objShopDetails)){
                $shop_address = "";
                if($this->shop_info->address1 != '')
                    $shop_address .= $this->shop_info->address1.', ';

                if($this->shop_info->city != '')
                    $shop_address .= $this->shop_info->city.', ';

                if($this->shop_info->province != '')
                    $shop_address .= $this->shop_info->province.' - ';
                
                if($this->shop_info->zip != '')
                    $shop_address .= $this->shop_info->zip;
                
                
                ## Update Shop Meta information
                $objShopDetails->store_information()->updateOrCreate(['shop_id'=>$objShopDetails->id],[
                        'store_information_id' => $this->shop_info->id, 
                        'store_name' => $this->shop_info->name, 
                        'store_email' => $this->shop_info->email, 
                        'store_domain' => $this->shop_info->domain ?? $objShopDetails->domain, 
                        'store_address'=> $shop_address, 
                        'store_phone'=> $this->shop_info->phone,
                        'store_updated'=> date('Y-m-d H:i:s', strtotime($this->shop_info->updated_at)), 
                        'store_country_name'=> $this->shop_info->country_name, 
                        'store_currency'=> $this->shop_info->currency, 
                        'store_owner' => $this->shop_info->shop_owner, 
                        'store_plan_name'=> $this->shop_info->plan_name 
                    ]);
                // Plans = ["affiliate","staff","professional","custom","shopify_plus","unlimited","basic","cancelled","staff_business","trial","dormant","frozen","singtel_unlimited","npo_lite","singtel_professional","singtel_trial","npo_full","business","singtel_basic","uafrica_professional","sales_training","singtel_starter","uafrica_basic","fraudulent","enterprise","starter","comped","shopify_alumni","partner_test"]
                $arr_live_plan_name = ["professional","shopify_plus","unlimited","basic","enterprise"];
                if(in_array($this->shop_info->plan_name, $arr_live_plan_name)){
                    if(!in_array($objShopDetails->plan_name, $arr_live_plan_name)){
                        $objShopDetails->update([
                                'plan_update_date' => date('Y-m-d H:i:s')
                            ]);
                    }
                }
                ## Update Shop information
                $objShopDetails->update([
                        'email' => $this->shop_info->email,
                        'shop_name' => $this->shop_info->name,
                        'owner_name' => $this->shop_info->shop_owner,
                        'plan_name'=> $this->shop_info->plan_name,
                        'phone'=> $this->shop_info->phone,
                        'address'=> $shop_address,
                        'country_name'=> $this->shop_info->country_name
                    ]);
            }
            // event(new WebhookProcessedEvent(['message'=>'Shopify shop update webhook run successfully']));
        } catch (Exception $e) {
            event(new WebhookProcessedEvent(['message'=>'Error occured when update shop data using webhook in store- '.$store_name.'. File Path-'.$e->getFile().' Error-'.$e->getMessage().' At line-'.$e->getLine()]));
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        echo "done";
    }
}
