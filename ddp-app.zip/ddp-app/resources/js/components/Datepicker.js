import React, { useState, useRef, useEffect } from "react";
import DatePicker, { DateObject } from "react-multi-date-picker";
import DatePanel from "react-multi-date-picker/plugins/date_panel";
import moment from 'moment';

export default function App(props) {
  const [dates, setDates] = (props.default_date_value) ? useState(props.default_date_value) : useState([]);
  const selected_date = (props.default_date_value) ? props.default_date_value : '';
  const blockdate = useRef(null);
  const format = (JSON.parse(props.store_detail).fn_store_config.date_format == 'mm/dd/yy') ? "MM/DD/YYYY" : (JSON.parse(props.store_detail).fn_store_config.date_format == 'yy/mm/dd' ? "YYYY/MM/DD" :(JSON.parse(props.store_detail).fn_store_config.date_format == 'dd/mm/yy' ? "DD/MM/YYYY" :"DD/MM/YYYY"));
  const date = new Date();
  var startDate = moment(date).format(format);
  useEffect(() => {
        props.handleDateChange(dates);
    }, [dates]);
  return (
    <div className="App">
      <div style={{ textAlign: "left" }}>
        <DatePicker
          value={dates}
          onChange={setDates}
          multiple
          sort
          format={format}
          calendarPosition="bottom-left"
          plugins={[<DatePanel />]}
          name={props.fieldname}
          startDate={startDate}
          minDate={startDate}
          selected={selected_date}
        />
      </div>
    </div>
  );
}
