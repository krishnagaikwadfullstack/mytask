import React, { Component,useEffect, useState, useRef } from 'react';
import ReactDOM from 'react-dom';
import createApp from '@shopify/app-bridge';
import {ContextualSaveBar,Loading,Toast,Redirect} from '@shopify/app-bridge/actions'
import axios from 'axios';

export default class StorePickup extends Component {
    constructor(props){
        super(props);
        console.log(JSON.parse(props.shopdetail).fn_store_pickup.storepickup_order_tags)
        this.state = {
            shop: props.shop,
            shop_detail: props.shopdetail,
            loader: Loading.create(app),
            save_storepickup_success_notice : Toast.create(app,{message: 'Location added successfully!'}),
            save_storepickup_error_notice : Toast.create(app,{message: 'Error occurrred while adding location.', isError:true}),
            validation_error_notice : Toast.create(app,{message: 'Please enetr all required fields.', isError:true}),
            error_notice : Toast.create(app,{message: 'Something went wrong!', isError:true}),
            tag_list: (JSON.parse(props.shopdetail).fn_store_pickup.storepickup_order_tags) ? JSON.parse(props.shopdetail).fn_store_pickup.storepickup_order_tags : [],
            tag_text: '',
            enable_store_pickup_checkbox_value: JSON.parse(props.shopdetail).fn_store_pickup.enable_store_pickup,
            enable_store_pickup_checked: (JSON.parse(props.shopdetail).fn_store_pickup.enable_store_pickup == 1) ? true : false,
            enable_storepickup_delivery_date_checkbox_value: JSON.parse(props.shopdetail).fn_store_pickup.enable_storepickup_delivery_date,
            enable_storepickup_delivery_date_checked: (JSON.parse(props.shopdetail).fn_store_pickup.enable_storepickup_delivery_date == 1) ? true : false,
            enable_storepickup_delivery_time_checkbox_value: JSON.parse(props.shopdetail).fn_store_pickup.enable_storepickup_delivery_time,
            enable_storepickup_delivery_time_checked: (JSON.parse(props.shopdetail).fn_store_pickup.enable_storepickup_delivery_time == 1) ? true : false,
            enable_filter_by_region_checkbox_value: JSON.parse(props.shopdetail).fn_store_pickup.enable_filter_by_region,
            enable_filter_by_region_checked: (JSON.parse(props.shopdetail).fn_store_pickup.enable_filter_by_region == 1) ? true : false
        };
        this.handleSubmit = this.handleSubmit.bind(this);        
        this.addOrderTag = this.addOrderTag.bind(this);
        this.removeOrderTag = this.removeOrderTag.bind(this);
    }
    toggleChange = (e) => {
        this.state.loader.dispatch(Loading.Action.START);
        if(e.target.name == 'enable_store_pickup'){
            this.setState({
                enable_store_pickup_checked : (this.state.enable_store_pickup_checkbox_value == '1') ? true : false,
                enable_store_pickup_checkbox_value : (this.state.enable_store_pickup_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'enable_storepickup_delivery_date'){
            this.setState({
                enable_storepickup_delivery_date_checked : (this.state.enable_storepickup_delivery_date_checkbox_value == '1') ? true : false,
                enable_storepickup_delivery_date_checkbox_value : (this.state.enable_storepickup_delivery_date_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'enable_storepickup_delivery_time'){
            this.setState({
                enable_storepickup_delivery_time_checked : (this.state.enable_storepickup_delivery_time_checkbox_value == '1') ? true : false,
                enable_storepickup_delivery_time_checkbox_value : (this.state.enable_storepickup_delivery_time_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'enable_filter_by_region'){
            this.setState({
                enable_filter_by_region_checked : (this.state.enable_filter_by_region_checkbox_value == '1') ? true : false,
                enable_filter_by_region_checkbox_value : (this.state.enable_filter_by_region_checkbox_value == '1') ? '2' : '1',
            });
        }
        this.state.loader.dispatch(Loading.Action.STOP);
    }
    handleSubmit(e) {
        e.preventDefault();
        const formData = {};
        for (const field in this.refs) {
            var field_name = `${field}Error`;
            formData[field] = this.refs[field].value;
        }
        formData['storepickup_order_tags'] = this.state.tag_list;
        console.log('formData',formData)
        if(formData){
            this.state.loader.dispatch(Loading.Action.START);
            axios({
                url:'storepickup',
                method:"post",
                data: formData,
            }).then((response)=>{
                if(response.data.status == 'success'){
                    this.setState({
                       save_storepickup_success_notice: Toast.create(app,{message: response.data.message}), 
                    });
                    this.state.save_storepickup_success_notice.dispatch(Toast.Action.SHOW);
                    // window.location.href = location_url;
                }
                if(response.data.status == 'error'){
                    this.setState({
                       save_storepickup_error_notice: Toast.create(app,{message: response.data.message, isError:true}),
                    });
                    this.state.save_storepickup_error_notice.dispatch(Toast.Action.SHOW);
                }
                this.state.loader.dispatch(Loading.Action.STOP);
            },(error)=>{
                this.state.error_notice.dispatch(Toast.Action.SHOW);
                this.state.loader.dispatch(Loading.Action.STOP);
            });
        }
    }
    addOrderTag = (e) => {
        var input_value = this.refs['storepickup_order_tags'].value;
        if(input_value != '' && input_value != null){
            this.setState(prevState => ({
              tag_list: prevState.tag_list.concat(input_value),
              tag_text: ''
            }))
        }
        this.refs['storepickup_order_tags'].value = '';
    }
    removeOrderTag = (index) => {        
        this.state.tag_list.splice(index, 1);
        this.setState({
           tag_list: this.state.tag_list.filter(i => i !== index)
        });
    }
    cancelLocationClick = () => {
        redirect.dispatch(Redirect.Action.APP,dashboard_new_url)
    }
    render() {
        return(
            <div className="store-pic-main">
                <div className="row">
                    <div className="col-md-6">
                        <h2 className="heading">Store Pickup</h2>
                    </div>
                    <div className="col-md-6 cancel-location-btn">
                        <a onClick={this.cancelLocationClick} className="btn btn-primary button">Cancel</a>
                    </div>
                </div>
                <form onSubmit={this.handleSubmit}>
                    <input ref="shop" type="hidden" name="shop" defaultValue={this.state.shop} />
                    <br/>
                    <div className="row formcolor_row">
                        <div className="enable-disable-app">
                            <div className="col-sm-12" title="Option to Enable/Disable Store Pickup">                      
                                <strong>Enable or Disable Store Pickup? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                <label className="switch">
                                  <input ref="enable_store_pickup" name="enable_store_pickup" type="checkbox" onClick={this.toggleChange} defaultValue={this.state.enable_store_pickup_checkbox_value} defaultChecked={this.state.enable_store_pickup_checked}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div className="enable-disable-app">
                            <div className="col-sm-12" title="Option to Enable/Disable Location Filter">                      
                                <strong>Location Filter</strong>
                            </div>
                            <div className="col-sm-12">
                                <strong>Enable or Disable Filter by region? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                <label className="switch">
                                  <input ref="enable_filter_by_region" name="enable_filter_by_region" type="checkbox" onClick={this.toggleChange} defaultValue={this.state.enable_filter_by_region_checkbox_value} defaultChecked={this.state.enable_filter_by_region_checked}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div className="enable-disable-app">
                            <div className="col-sm-12" title="Option to Enable/Disable Delivery Date">
                                <strong>Enable or Disable Delivery Date? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                <label className="switch">
                                  <input ref="enable_storepickup_delivery_date" name="enable_storepickup_delivery_date" type="checkbox" onClick={this.toggleChange} defaultValue={this.state.enable_storepickup_delivery_date_checkbox_value} defaultChecked={this.state.enable_storepickup_delivery_date_checked}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div className="enable-disable-app">
                            <div className="col-sm-12" title="Option to Enable/Disable Delivery Time">
                                <strong>Enable or Disable Delivery Time? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                                <label className="switch">
                                  <input ref="enable_storepickup_delivery_time" name="enable_storepickup_delivery_time" type="checkbox" onClick={this.toggleChange} defaultValue={this.state.enable_storepickup_delivery_time_checkbox_value} defaultChecked={this.state.enable_storepickup_delivery_time_checked}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div className="storepickup-order-tags">
                            <div className="">
                                <label className="order-tag-lable">Order tags</label>
                            </div>
                            <div className="add-tags-wrap">
                                <input ref="storepickup_order_tags" type="text" name="storepickup_order_tags" id="storepickup_order_tag"/>
                                <div>{this.state.tag_list.length > 0 && this.state.tag_list.map((x,y) => {
                                  return <span key={y}>{x}
                                  <button className="remove-tag" onClick={this.removeOrderTag.bind(this,y)}>X</button>
                                  </span>})}
                                </div>
                                <div>
                                    <button type="button" id="storepickup_order_tag_btn" onClick={this.addOrderTag}>
                                        <span className="">Add tag</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div className="submit-button">
                            <button className="button btn-primary" type="submit">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}
if (document.getElementById('storepickup')) {
    var shopdetail = document.getElementById('storepickup').getAttribute('shopdetail');
    var shop = document.getElementById('storepickup').getAttribute('shop');
    ReactDOM.render(<StorePickup shopdetail={shopdetail} shop={shop} />, document.getElementById('storepickup'));
}