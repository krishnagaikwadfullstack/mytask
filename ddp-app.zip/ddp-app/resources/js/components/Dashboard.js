import React, { Component,useEffect, useState, useRef } from 'react';
import ReactDOM from 'react-dom';
import createApp from '@shopify/app-bridge';
import {ContextualSaveBar,Loading,Toast,Redirect} from '@shopify/app-bridge/actions'
import axios from 'axios';

export default class Dashboard extends Component {
    constructor(props){
        super(props);
        console.log(props)
        this.state = {
            shop: props.shop,
            shop_detail: props.shop,
            isChecked : (JSON.parse(props.shopdetail).block_config.app_status == 'Active') ? true : false,
            app_status : JSON.parse(props.shopdetail).block_config.app_status,
            appenabletext : (JSON.parse(props.shopdetail).block_config.app_status == 'Active' ? 'Enabled' : 'Disabled'),
            loader: Loading.create(app),
            status_enable_notice : Toast.create(app,{message: 'Your app is enabled'}),
            status_disable_notice : Toast.create(app,{message: 'Your app is disabled'}),
            short_added_success_notice : Toast.create(app,{message: 'Shortcode added successfully!'}),
            short_added_error_notice : Toast.create(app,{message: 'Error occurrred while adding shortcode.', isError:true}),
            error_notice : Toast.create(app,{message: 'Something went wrong!', isError:true}),
            copy_success : '',
            selectValue: '',
        };
        this.textAreaRef = React.createRef(null);
        this.textAreaRefProduct = React.createRef(null);
    }
    toggleChange = () => {
        console.log('before',this.state.app_status)
        this.setState({
            isChecked : (this.state.app_status == 'Active') ? true : false,
            app_status : (this.state.app_status == 'Active') ? 'Inactive' : 'Active',
            appenabletext : (this.state.app_status == 'Active') ? 'Disabled' : 'Enabled',
        });
        this.state.loader.dispatch(Loading.Action.START);
        axios({
            url:'save-dashboard-config',
            method:"post",
            data: {
                shop: this.state.shop,
                status: (this.state.app_status == 'Active') ? 'Inactive' : 'Active'
            },
        }).then((response)=>{
            console.log('response',response)
            if(response.data == 'Enabled'){
                this.state.status_enable_notice.dispatch(Toast.Action.SHOW);
            }
            if(response.data == 'Disabled'){
                this.state.status_disable_notice.dispatch(Toast.Action.SHOW);
            }
            this.state.loader.dispatch(Loading.Action.STOP);
        },(error)=>{
            this.state.error_notice.dispatch(Toast.Action.SHOW);
            this.state.loader.dispatch(Loading.Action.STOP);
        });
    }
    putShortCode = (e) => {
        this.state.loader.dispatch(Loading.Action.START);
        axios({
            url:(this.state.selectValue == 2 ? 'snippet-create-product' : 'snippet-create-cart'),
            method:"post",
            data: {
                shop: this.state.shop,
                template_id: this.state.selectValue
            },
        }).then((response)=>{
            console.log('response',response)
            if(response.data.status == 'success'){
                this.setState({
                   short_added_success_notice: Toast.create(app,{message: response.data.message}), 
                });
                this.state.short_added_success_notice.dispatch(Toast.Action.SHOW);
            }
            if(response.data.status == 'error'){
                this.setState({
                   short_added_error_notice: Toast.create(app,{message: response.data.message, isError:true}),
                });
                this.state.short_added_error_notice.dispatch(Toast.Action.SHOW);
            }
            this.state.loader.dispatch(Loading.Action.STOP);
        },(error)=>{
            this.state.error_notice.dispatch(Toast.Action.SHOW);
            this.state.loader.dispatch(Loading.Action.STOP);
        });
    }
    generalSettingPage = () => {
        redirect.dispatch(Redirect.Action.APP,dashboard_url)
    }
    locationSettingPage = () => {
        redirect.dispatch(Redirect.Action.APP,location_url)
    }
    storePickupSettingPage = () => {
        redirect.dispatch(Redirect.Action.APP,store_pickup_url)
    }
    localDeliverySettingPage = () => {
        redirect.dispatch(Redirect.Action.APP,local_delivery_url)
    }
    externalDeliverySettingPage = () => {
        redirect.dispatch(Redirect.Action.APP,external_delivery_url)
    }
    copyToClipboard = (event) => {
        this.textAreaRef.current.value = this.textAreaRef.current.defaultValue;
        this.textAreaRef.current.select();
        document.execCommand('copy');
        this.setState({
            copy_success : 'Copied!',
        });       
    }
    copyToClipboardProduct = (event) => {
        this.textAreaRefProduct.current.value = this.textAreaRefProduct.current.defaultValue;
        this.textAreaRefProduct.current.select();
        document.execCommand('copy');
        this.setState({
            copy_success : 'Copied!',
        });
    }
    handleDropdownChange = (e) => {
        this.setState({ selectValue: e.target.value });
    }
    render() {
        const style = {
          marginLeft: '12px'
        };
        const style1 = {
          display: 'block'
        };
        const style2 = {
          display: 'none'
        };
        const style3 = {
          color: 'red',
          display: 'none'
        };
        const shortcode = "{% include 'delivery-date' %}";
        const shortcodeproduct = "{% include 'product-delivery-date' %}";
        return(
            <form id="delivery_date_form" name="config" method="post">
                <input type="hidden" name="shop" defaultValue={this.state.shop} />
                <br/>
                <h2 className="heading">Dashboard</h2>
                <div className="row formcolor_row">
                    <div className="enable-disable-app">
                        <div className="col-sm-12" title="Option to Enable/Disable App">                      
                            <strong>Enable or Disable App? <i className="fa fa-question-circle" aria-hidden="true"></i></strong>
                            <label className="switch">
                              <input type="checkbox" onClick={this.toggleChange} defaultValue={this.state.appenabletext}/>
                              <span className="slider round"></span>
                            </label>
                        </div>
                    </div>
                    <div className="columns has-sections card">
                        <h3>Configuration Steps for OS 1.0 & 2.0 Themes</h3>
                        <ul className="tabs">
                            <li className="tab-link active" data-tab="tab-1"><a>Theme 2.0</a></li>
                            <li className="tab-link" data-tab="tab-2"><a>Theme 1.0</a></li>
                        </ul>
                        <div className="card-section">
                            <div id="tab-1" className="tab-content first-section active">
                                <div className="panel">
                                <h3>New Update for Theme 2.0:</h3>
                                <div className="row">
                                    <ul className="dashboard-shortcode">
                                        <li>We have updated the app to be compatible with OS 2.0 themes, if you are using 2.0 themes you don’t need to add any Short code, you can directly configure the app by ‘Theme Customization’ option from the Themes Section.</li>
                                    </ul>
                                    <p><b>How can you identify whether it's 1.0 or 2.0 Theme?</b></p> 
                                    <ul className="dashboard-shortcode">
                                        <li><b>Step 1:</b> Go to Themes -> Actions -> <a href="https://prnt.sc/0Y47mDtzZilN" target="_blank">Edit Code</a></li>
                                        <li><b>Step 2:</b> Check whether the file type is .liquid or .json, EX: product.liquid or product.json.</li>
                                        <span style={style}>Theme 1.0: <a href="https://prnt.sc/azXZ0scLstH_" target="_blank">product.liquid</a></span>
                                        <br/>
                                        <span style={style}>Theme 2.0: <a href="https://prnt.sc/9AYlhgQSDFBl" target="_blank">product.json</a></span>
                                    </ul>
                                    <p><b>Configuration Steps For Cart Page:</b></p>
                                    <ul className="dashboard-shortcode">
                                        <li><b>Step 1:</b> Click on Customize -> Select cart page <a href="image/cartpage_theme_two_config_step1.png" target="_blank">Example</a> and Add the widget through <a href="https://prnt.sc/r1SeN9omIZGO" target="_blank">Add Block</a></li>
                                        <li><b>Step 2:</b> Try <a href="https://prnt.sc/CBXKGrS1rT2V" target="_blank">Drag & Drop</a> wherever you would like to place the widget</li>
                                        <li><b>Step 3:</b> Preview the theme to check how it’s appearing</li>
                                    </ul>
                                    <p><b>Configuration Steps For Product Page:</b></p>
                                    <ul className="dashboard-shortcode">
                                        <li><b>Step 1:</b> Click on Customize -> Select product page <a href="image/productpage_theme_two_config_step1.png" target="_blank">Example</a> and Add the widget through <a href="image/productpage_theme_two_config.png" target="_blank">Add Block</a></li>
                                        <li><b>Step 2:</b> Try <a href="https://prnt.sc/C22GfdbQkreK" target="_blank">Drag & Drop</a> wherever you would like to place the widget</li>
                                        <li><b>Step 3:</b> Preview the theme to check how it’s appearing</li>
                                    </ul>
                                </div>
                                </div>
                            </div>
                            <div id="tab-2" className="tab-content second-section">
                                <div className="panel">
                                <h3>Theme 1.0</h3>
                                    <div className="row">
                                        <p><b>Configuration Steps:</b></p><br/>
                                        <p><b>Cart Page</b></p>
                                        <ul className="dashboard-shortcode">
                                            <li>Copy and paste the shortcode in your <b>Cart Template</b> see <a className="" href="image/info_delivery date.png" target="_blank"><b>Example</b></a>
                                            </li>
                                            <li>If you dont find form tag in your cart page so you have to paste the short code in the <b>cart page</b> see <a className="" href="image/Delivery date short code.png" target="_blank"><b>Example</b></a>
                                            </li>
                                            <li>
                                                If your cart page is not opening as url https://your-store-name/cart, Then Please contact support team (<a href="mailto:support@zestard.com">support@zestard.com</a>) or live chat at bottom right
                                            </li>
                                        </ul>
                                        <p><b>Product Page</b></p>
                                        <ul className="dashboard-shortcode">
                                            <li>Copy and paste the shortcode in your <b>Product Template</b> see <a className="" href="image/product_template.png" target="_blank"><b>Example</b></a></li>
                                            <li>If you dont find form tag in your product template page so you have to paste the short code in the <b>Product Page</b> see <a className="" href="image/Product.png" target="_blank"><b>Example</b></a>
                                            </li>
                                        </ul>
                                        <div className="alert notice">
                                            <dl>
                                                <dt><b>Note</b> : </dt>
                                                <dd>Do not paste the above code multiple times in the same liquid file.</dd>
                                            </dl>
                                        </div>
                                        <h2 className="heading-text">Do you want us to paste the Shortcode?</h2>
                                        <div className="adjust-margin hide">
                                            <div className="alert success alertHide" id="scrolltobottom">
                                                <a className="close btnClose"></a>
                                                <dl>
                                                    <dt>Success</dt>
                                                    <dd></dd>
                                                </dl>
                                            </div>
                                            <div className="alert error alertHide" id="scrolltobottom" style={style1}>
                                                <a className="close btnClose"></a>
                                                <dl>
                                                    <dt>Error</dt>
                                                    <dd></dd>
                                                </dl>
                                            </div>
                                        </div>

                                        <div className="has-sections  fields-group parent-automatic-shortcode row">
                                            <div className="automatic-shortcode col-sm-8">
                                                <select className="validation form-control select_page cur_point select_template_page" onChange={this.handleDropdownChange}> name="template_id" id="template_id">
                                                    <option value="">Select Template Page</option>
                                                    <option value="1">Cart Page</option>
                                                    <option value="2">Product Page</option>
                                                </select>
                                                <input type="hidden" name="shop" defaultValue={this.state.shop} />
                                                <div id="errors_select_template_page" style={style3}>Please select template page</div>
                                                <p><strong>Note : </strong>Select the page from the option where you want to paste the code then click 'Put Shortcode' and will get your job done.</p>
                                            </div>
                                            <div className="col-sm-2">
                                                <input type="button" className="btn btn-primary submit-loader" id="shortcode_pase_template" name="BtnPutShortcode" value="Put Shortcode" onClick={this.putShortCode}/>
                                            </div>
                                        </div>


                                        <div style={style2}>
                                            <p><b>Paste Shortcode in Cart Template</b></p>
                                        <div className="">
                                            <button className="btn btn-primary" type="submit" name="snippet_cart">Paste Shortcode in Cart</button>
                                        </div>

                                        <p><b>Paste Shortcode in Product Template</b></p>
                                        <div className="">
                                            <button className="btn btn-primary" type="submit" name="snippet_product">Paste Shortcode in Product</button>
                                        </div>
                                        <br/>
                                        </div>
                                        <p className="delivery-date-pro-note note_delete"><b></b></p>
                                        <div className="success-copied">{this.state.copy_success}</div>
                                        <h2 className="heading-text">Shortcode for Cart Page</h2>
                                        <div className="cus-row">
                                            <div className="c-7">
                                                <textarea ref={this.textAreaRef} id="ticker-shortcode" rows="1" className="form-control short-code"  readOnly={true} defaultValue={shortcode}></textarea>
                                            </div>
                                            <div className="c-5">
                                                <button type="button" onClick={this.copyToClipboard} className="btn tooltipped tooltipped-s copyMe copyclippro"><i className="fa fa-check"></i> &nbsp; Copy to clipboard</button>
                                            </div>
                                        </div>
                                        <h2 className="heading-text">Shortcode for Product Page(only for Ultimate Version)</h2>
                                        <div className="cus-row">
                                            <div className="c-7">
                                                <textarea ref={this.textAreaRefProduct} id="ticker-shortcode" rows="1" className="form-control short-code"  readOnly={true} defaultValue={shortcodeproduct}></textarea>
                                            </div>
                                            <div className="c-5">
                                                <button type="button" onClick={this.copyToClipboardProduct} className="btn tooltipped tooltipped-s copyMe copyclippro"><i className="fa fa-check"></i> &nbsp; Copy to clipboard</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="dashboard-bottom">
                        <div className="col-sm-12">
                            <div className="genral-setting-dashbaord">
                               <div className="genral-setting-heading">
                                  <h2 >Settings</h2>
                               </div>
                               <div className="row">
                                  <div className="col-md-6">
                                     <div className="button-link">
                                          <a className=""  href="" onClick={generalSettingPage}>Go to general settings page</a>
                                     </div>
                                  </div>
                                  <div className="col-md-6">
                                     <div className="button-link">
                                          <a className=""  href="" onClick={this.locationSettingPage}>Locations</a>
                                     </div>
                                  </div>
                                  <div className="col-md-6">
                                     <div className="button-link">
                                          <a className="" onClick={this.storePickupSettingPage}>Store Pickup Settings</a>
                                     </div>
                                  </div>
                                  <div className="col-md-6">
                                     <div className="button-link">
                                          <a className="" onClick={this.localDeliverySettingPage}>Local Delivery Settings</a>
                                     </div>
                                  </div>
                                  <div className="col-md-6">
                                     <div className="button-link">
                                          <a className="" onClick={this.externalDeliverySettingPage}>External Delivery Settings</a>
                                     </div>
                                  </div>
                               </div>
                            </div>
                        </div>
                        <div className="col-sm-12">
                            <h3>Advanced configuration :</h3>
                            <ul>
                              <li>Show Delivery Information on Order Confirmation Email for customers see <a className="" href="image/order_email_config.png" target="_blank"><b>Example</b></a></li>
                              <li>Show Delivery Information on Checkout/Thank You Page see <a className="" href="image/thankyou_config.png" target="_blank"><b>Example</b></a></li>
                              <li>Translate Delivery-Date Label for the Orders as well as everywhere else.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </form>
        );
    }
}
if (document.getElementById('dashboard')) {
    var shopdetail = document.getElementById('dashboard').getAttribute('shopdetail');
    var shop = document.getElementById('dashboard').getAttribute('shop');
    ReactDOM.render(<Dashboard shopdetail={shopdetail} shop={shop} />, document.getElementById('dashboard'));
}