import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import createApp from '@shopify/app-bridge';
import { Redirect } from '@shopify/app-bridge/actions';

export default class AppConfiguration extends Component {
    constructor(props){
        super(props);
        this.state = {
            apiKey: props.apikey,
            host: props.host,
            shop_domain: props.shop,
            read_all_orders: props.read_all_orders,
            loader: (window.top == window.self) ? true : false
        };
    }

    render() {
        // var shop_name = document.getElementById('dashboard').getAttribute('shop');
		const redirectUri = `https://shopifydev.anujdalal.com/DeliveryDateProAppBridge/public/redirect`;
		const permissionUrl = `https://${this.state.shop_domain}/admin/oauth/authorize?client_id=${this.state.apiKey}&scope=read_content,read_script_tags,write_script_tags,read_themes,write_content,write_themes,read_products,write_products,read_orders,${this.state.read_all_orders}write_orders,read_locations&redirect_uri=${redirectUri}`;
		// If the current window is the 'parent', change the URL by setting location.href
		if (window.top == window.self) {
		  window.location.assign(permissionUrl);
		  // If the current window is the 'child', change the parent's URL with Shopify App Bridge's Redirect action
		} else {
		const app = createApp({
			apiKey: this.state.apiKey,
			host: this.state.host
		});
		Redirect.create(app).dispatch(Redirect.Action.REMOTE, permissionUrl);
		}
        
        return(
            <div className="modal payment-process-model show" tabIndex="-1" role="dialog" id="payment-model">
                
            </div>
        );
    }
}
if (document.getElementById('appconfiguration')) {
    var host = document.getElementById('appconfiguration').getAttribute('host');
    var apikey = document.getElementById('appconfiguration').getAttribute('apikey');
    var shop = document.getElementById('appconfiguration').getAttribute('shop');
    var read_all_orders = document.getElementById('appconfiguration').getAttribute('read_all_orders');
    ReactDOM.render(<AppConfiguration host={host} apikey={apikey} shop={shop} read_all_orders={read_all_orders} />, document.getElementById('appconfiguration'));
}