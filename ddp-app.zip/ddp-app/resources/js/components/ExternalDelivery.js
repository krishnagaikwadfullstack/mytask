import React, { Component,useEffect, useState, useRef } from 'react';
import ReactDOM from 'react-dom';
import createApp from '@shopify/app-bridge';
import {ContextualSaveBar,Loading,Toast,Redirect} from '@shopify/app-bridge/actions'
import axios from 'axios';
import DatePickerComp from './Datepicker';

export default class GeneralDelivery extends Component {
    constructor(props){
        super(props);
        this.state = {
            shop: props.shop,
            shop_detail: props.store_detail,
            loader: Loading.create(app),
            save_generaldelivery_success_notice : Toast.create(app,{message: 'Setting saved successfully!'}),
            save_generaldelivery_error_notice : Toast.create(app,{message: 'Error occurrred while adding location.', isError:true}),
            validation_error_notice : Toast.create(app,{message: 'Please enetr all required fields.', isError:true}),
            error_notice : Toast.create(app,{message: 'Something went wrong!', isError:true}),
            tag_text: '',
            enable_external_delivery_checkbox_value: JSON.parse(props.store_detail).fn_store_config.enable_external_delivery,
            enable_external_delivery_checked: (JSON.parse(props.store_detail).fn_store_config.enable_external_delivery == 1) ? true : false,
            enable_external_delivery_date_checkbox_value: JSON.parse(props.store_detail).fn_store_config.enable_external_delivery_date,
            enable_external_delivery_date_checked: (JSON.parse(props.store_detail).fn_store_config.enable_external_delivery_date == 1) ? true : false,
            enable_external_delivery_time_checkbox_value: JSON.parse(props.store_detail).fn_store_config.enable_external_delivery_time,
            enable_external_delivery_time_checked: (JSON.parse(props.store_detail).fn_store_config.enable_external_delivery_time == 1) ? true : false,
            default_date_value:(JSON.parse(props.store_detail).fn_store_config) ? JSON.parse(JSON.parse(props.store_detail).fn_store_config.block_date) :[],
            date_values: [],
            date_format : JSON.parse(props.store_detail).fn_store_config.date_format,
            block_days_interval_checkbox_value : (JSON.parse(props.store_detail).fn_store_config) ? JSON.parse(props.store_detail).fn_store_config.exclude_block_date_status : 1,
            block_days_interval_checked: (JSON.parse(props.store_detail).fn_store_config.exclude_block_date_status == 0) ? false : true,
            cuttoff_status_checkbox_value : (JSON.parse(props.store_detail).fn_store_config) ? JSON.parse(props.store_detail).fn_store_config.cuttoff_status : 1,
            cuttoff_status_checked: (JSON.parse(props.store_detail).fn_store_config.cuttoff_status == 0) ? false : true,
            days : (JSON.parse(props.store_detail).fn_store_config) ? JSON.parse(JSON.parse(props.store_detail).fn_store_config.days) :[],
            date_interval : (JSON.parse(props.store_detail).fn_store_config) ? JSON.parse(props.store_detail).fn_store_config.date_interval : 0,
            alloved_month : (JSON.parse(props.store_detail).fn_store_config) ? (JSON.parse(props.store_detail).fn_store_config.alloved_month != 0 ? JSON.parse(props.store_detail).fn_store_config.alloved_month : 1) : 1,
            hours : (JSON.parse(this.props.store_detail).fn_store_config) ? JSON.parse(this.props.store_detail).fn_store_config.hours : '',
            minute : (JSON.parse(this.props.store_detail).fn_store_config) ? JSON.parse(this.props.store_detail).fn_store_config.minute : '',
        };
        console.log(JSON.parse(props.store_detail).fn_store_config)
        this.handleSubmit = this.handleSubmit.bind(this);        
        this.addOrderTag = this.addOrderTag.bind(this);
        this.removeOrderTag = this.removeOrderTag.bind(this);
    }
    toggleChange = (e) => {
        this.state.loader.dispatch(Loading.Action.START);
        if(e.target.name == 'enable_external_delivery'){
            this.setState({
                enable_external_delivery_checked : (this.state.enable_external_delivery_checkbox_value == '1') ? true : false,
                enable_external_delivery_checkbox_value : (this.state.enable_external_delivery_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'enable_external_delivery_date'){
            this.setState({
                enable_external_delivery_date_checked : (this.state.enable_external_delivery_date_checkbox_value == '1') ? true : false,
                enable_external_delivery_date_checkbox_value : (this.state.enable_external_delivery_date_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'enable_external_delivery_time'){
            this.setState({
                enable_external_delivery_time_checked : (this.state.enable_external_delivery_time_checkbox_value == '1') ? true : false,
                enable_external_delivery_time_checkbox_value : (this.state.enable_external_delivery_time_checkbox_value == '1') ? '2' : '1',
            });
        }
        if(e.target.name == 'exclude_block_date_status'){
            this.setState({
                block_days_interval_checked : (this.state.block_days_interval_checkbox_value == '0') ? true : false,
                block_days_interval_checkbox_value : (this.state.block_days_interval_checkbox_value == '0') ? '1' : '0',
            });
        }
        if(e.target.name == 'cuttoff_status'){
            this.setState({
                cuttoff_status_checked : (this.state.cuttoff_status_checkbox_value == '0') ? true : false,
                cuttoff_status_checkbox_value : (this.state.cuttoff_status_checkbox_value == '0') ? '1' : '0',
            });
        }
        this.state.loader.dispatch(Loading.Action.STOP);
    }
    handleSubmit(e) {
        e.preventDefault();
        const formData = {};
        const date_array = [];
        if(this.state.date_values.length > 0){
            this.state.date_values.map((e,i) => {
                console.log(e)
                if(typeof e === 'string' && e.includes("-")){
                    date_array.push(e);
                }else{
                    if (this.state.date_format == 'mm/dd/yy') {
                        date_array.push(e.month.number+'/'+e.day+'/'+e.year);
                    }
                    if (this.state.date_format == 'dd/mm/yy') {
                        date_array.push(e.day+'/'+e.month.number+'/'+e.year);
                    }
                    if (this.state.date_format == 'yy/mm/dd') {
                        date_array.push(e.year+'/'+e.month.number+'/'+e.day);
                    }
                }
            });
            formData['block_date'] = date_array;
        }
        for (const field in this.refs) {
            var field_name = `${field}Error`;
            formData[field] = this.refs[field].value;
            if(field == 'days'){
                formData[field] = this.state.days;
            }
            if(this.refs[field].value==='undefined' || this.refs[field].value==='' || this.refs[field].value===null){
                if(field_name == 'delivery_timeError' && this.refs['enable_external_delivery_time'].value == '0'){
                    this.setState({
                        [field_name]:false
                    })
                    this.refs[field].focus();
                }else{
                    this.setState({
                        [field_name]:true
                    })
                    // this.state.validation_error_notice.dispatch(Toast.Action.SHOW);
                }
            }else{
                this.setState({
                    [field_name]:false
                })
            }
        }
        formData['external_delivery_order_tags'] = this.state.tag_list;
        console.log('formData',formData)
        if(formData && this.state.delivery_timeError == false){
            this.state.loader.dispatch(Loading.Action.START);
            axios({
                url:'generaldelivery',
                method:"post",
                data: formData,
            }).then((response)=>{
                if(response.data.status == 'success'){
                    this.setState({
                       save_generaldelivery_success_notice: Toast.create(app,{message: response.data.message}), 
                    });
                    this.state.save_generaldelivery_success_notice.dispatch(Toast.Action.SHOW);
                }
                if(response.data.status == 'error'){
                    this.setState({
                       save_generaldelivery_error_notice: Toast.create(app,{message: response.data.message, isError:true}),
                    });
                    this.state.save_generaldelivery_error_notice.dispatch(Toast.Action.SHOW);
                }
                this.state.loader.dispatch(Loading.Action.STOP);
            },(error)=>{
                this.state.error_notice.dispatch(Toast.Action.SHOW);
                this.state.loader.dispatch(Loading.Action.STOP);
            });
        }
    }
    addOrderTag = (e) => {
        var input_value = this.refs['external_delivery_order_tags'].value;
        if(input_value != '' && input_value != null){
            this.setState(prevState => ({
              tag_list: prevState.tag_list.concat(input_value),
              tag_text: ''
            }))
        }
        this.refs['external_delivery_order_tags'].value = '';
    }
    removeOrderTag = (index) => {        
        this.state.tag_list.splice(index, 1);
        this.setState({
           tag_list: this.state.tag_list.filter(i => i !== index)
        });
    }
    cancelBtnClick = () => {
        redirect.dispatch(Redirect.Action.APP,dashboard_new_url)
    }
    handleRadioChange = (e) => {
        this.setState({
            enable_distance_validation_radio_value : e.target.value
        });
    }
    handleDateChange = (event) => {
        this.setState({date_values:event});
    }
    handleSelectChange = (e) => {
        let target = e.target
        let name = target.name
        //here get selected value
        let value = Array.from(target.selectedOptions, option => option.value);
        this.setState({
          [name]: value
        });
    }
    render() {
        var hours = ['00','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
        const listhourItems = hours.map((number) =>
            <option key={number.toString()} value={number}>{number}</option>
        );
        const listminuteItems = [...Array(60)].map((e, i) =>
            <option key={i} value={i}>{i}</option>
        );
        //
        return(
            <div className="local-dev-main">
                <div className="row">
                    <div className="col-md-6">
                        <h2 className="heading">General Settings</h2>
                    </div>
                    <div className="col-md-6 cancel-location-btn">
                        <a onClick={this.cancelBtnClick} className="btn btn-primary button">Cancel</a>
                    </div>
                </div>
                <form onSubmit={this.handleSubmit}>
                    <input ref="shop" type="hidden" name="shop" defaultValue={this.state.shop} />
                    <div className="row formcolor_row">
                        <div className="enable-disable-app">
                            <div className="dateformat_option" title="Option to Select the Language of the Calendar">
                                <div><strong>Delivery Datepicker Language</strong></div>
                                <div>                            
                                    <select name="language_locale" className="form-control">       
                                        <option value="sq" >Albanian (Gjuha shqipe)</option>
                                        <option value="ar" >Arabic (&#8235;(&#1604;&#1593;&#1585;&#1576;&#1610;</option>
                                        <option value="hy" >Armenian (&#1344;&#1377;&#1397;&#1381;&#1408;&#1381;&#1398;)</option>
                                        <option value="bg" >Bulgarian (&#1073;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080; &#1077;&#1079;&#1080;&#1082;)</option>
                                        <option value="ca" >Catalan (Catal&agrave;)</option>
                                        <option value="zh-CN" >Chinese Simplified (&#31616;&#20307;&#20013;&#25991;)</option>
                                        <option value="zh-TW" >Chinese Traditional (&#32321;&#39636;&#20013;&#25991;)</option>
                                        <option value="hr" >Croatian (Hrvatski jezik)</option>
                                        <option value="cs" >Czech (Ce&ouml;tina)</option>
                                        <option value="da" >Danish (Dansk)</option>
                                        <option value="nl" >Dutch (Nederlands)</option>
                                        <option value="eo" >Esperanto</option>
                                        <option value="en" >English</option>
                                        <option value="fa" >Farsi/Persian (&#8235;(&#1601;&#1575;&#1585;&#1587;&#1740;</option>
                                        <option value="fi" >Finnish (suomi)</option>
                                        <option value="fr" >French (Fran&ccedil;ais)</option>
                                        <option value="de" >German (Deutsch)</option>
                                        <option value="el" >Greek (&#917;&#955;&#955;&#951;&#957;&#953;&#954;&#940;)</option>
                                        <option value="he" >Hebrew (&#8235;(&#1506;&#1489;&#1512;&#1497;&#1514;</option>
                                        <option value="hu" >Hungarian (Magyar)</option>
                                        <option value="is" >Icelandic (&Otilde;slenska)</option>
                                        <option value="id" >Indonesian (Bahasa Indonesia)</option>
                                        <option value="it" >Italian (Italiano)</option>
                                        <option value="ja" >Japanese (&#26085;&#26412;&#35486;)</option>
                                        <option value="ko" >Korean (&#54620;&#44397;&#50612;)</option>
                                        <option value="lv" >Latvian (Latvie&ouml;u Valoda)</option>
                                        <option value="lt" >Lithuanian (lietuviu kalba)</option>
                                        <option value="ms" >Malaysian (Bahasa Malaysia)</option>
                                        <option value="no" >Norwegian (Norsk)</option>
                                        <option value="pl" >Polish (Polski)</option>
                                        <option value="pt-BR" >Portuguese/Brazilian (Portugu&ecirc;s)</option>
                                        <option value="ro" >Romanian (Rom&acirc;n&#259;)</option>
                                        <option value="ru" >Russian (&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;)</option>
                                        <option value="sr" >Serbian (&#1089;&#1088;&#1087;&#1089;&#1082;&#1080; &#1112;&#1077;&#1079;&#1080;&#1082;)</option>
                                        <option value="sr-SR" >Serbian (srpski jezik)</option>
                                        <option value="sk" >Slovak (Slovencina)</option>
                                        <option value="sl" >Slovenian (Slovenski Jezik)</option>
                                        <option value="es" >Spanish (Espa&ntilde;ol)</option>
                                        <option value="sv" >Swedish (Svenska)</option>
                                        <option value="th" >Thai (&#3616;&#3634;&#3625;&#3634;&#3652;&#3607;&#3618;)</option>
                                        <option value="tr" >Turkish (T&uuml;rk&ccedil;e)</option>
                                        <option value="uk" >Ukranian (&#1059;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072;)</option>
                                    </select>       
                                </div>
                            </div>
                        </div>
                        <div className="enable-disable-app">
                            <div className="col-sm-12" title="Option to Enable/Disable Delievery Date">
                                <strong>Enable Delivery Date </strong>
                                <label className="switch">
                                  <input ref="enable_external_delivery_date" name="enable_external_delivery_date" type="checkbox" onClick={this.toggleChange} defaultValue={this.state.enable_external_delivery_date_checkbox_value} defaultChecked={this.state.enable_external_delivery_date_checked}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div className="enable-disable-app">
                            <div className="col-sm-12" title="Option to Enable/Disable Delievery Time">
                                <strong>Enable Delivery Time </strong>
                                <label className="switch">
                                  <input ref="enable_external_delivery_time" name="enable_external_delivery_time" type="checkbox" onClick={this.toggleChange} defaultValue={this.state.enable_external_delivery_time_checkbox_value} defaultChecked={this.state.enable_external_delivery_time_checked}/>
                                  <span className="slider round"></span>
                                </label>
                            </div>
                        </div>
                        <div className="col-sm-12 store_pickup_div">
                            <div className="datepicker_validate" title="Option to show/hide available Delivery-Dates by default (without clicking on the input-box)">
                                <div>
                                    <strong>Calendar display type</strong>
                                    <div className="radio">
                                      <label>
                                        <input name="datepicker_display_on" type="radio" value="1" checked={true} />
                                        Show default Visible
                                      </label>
                                    </div>
                                    <div className="radio">
                                      <label>
                                        <input name="datepicker_display_on" type="radio" value="2" />
                                        Show input box
                                      </label>
                                    </div>
                                </div>
                            </div>
                            <div className="datepicker_validate" title="Option to show/hide available Delivery-Dates by default (without clicking on the input-box)">
                                <div>
                                   <div className="col-sm-4 padding_right">
                                        <strong>Cut Off Time&nbsp;&nbsp;&nbsp; - &nbsp;&nbsp;&nbsp; Active</strong>
                                        <span className="onoff" >
                                            <input name="cuttoff_time" type="checkbox" value="cuttoff_on" id="checkboxID11" name="cuttoff_time"/>
                                                   <label for="checkboxID11"></label>
                                        </span>
                                    </div>
                                   <div>
                                    <div>
                                     <div className="radio">
                                       <label>
                                         <input name="global_cutoff_time" type="radio" value="1" checked={true} />
                                         Same for each day
                                       </label>
                                     </div>
                                     <div className="radio">
                                       <label>
                                         <input name="global_cutoff_time" type="radio" value="2" />
                                         Different for each day
                                       </label>
                                     </div>
                                    </div>

                                    <div className="cuttofftime_box">
                                        <div className="display_block">
                                            <label>Hour</label>
                                            <select ref="hours" name="hours" className="form-control" defaultValue={this.state.hours}>
                                                {listhourItems}
                                            </select>
                                        </div>
                                        <div className="display_block">
                                            <label>Minute</label>
                                            <select ref="minute" name="minute" className="form-control" defaultValue={this.state.minute}>
                                                {listminuteItems}
                                            </select>
                                        </div>
                                    </div>
                                      <div className="cuttoffTime">
                                         <div>
                                            <div>Monday</div>
                                            <div className="">
                                               <div className="hours">
                                                  <label for="hours">Hour:   </label>
                                                  <select name="hour[]" className="form-control cutoff_hour">
                                                      {listhourItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                               <div className="minute">
                                                  <label for="minute">Minute:   </label>
                                                  <select name="minute[]" className="form-control cutoff_minute">
                                                      {listminuteItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                            </div>
                                         </div>
                                         <div>
                                            <div>Monday</div>
                                            <div className="">
                                               <div className="hours">
                                                  <label for="hours">Hour:   </label>
                                                  <select name="hour[]" className="form-control cutoff_hour">
                                                      {listhourItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                               <div className="minute">
                                                  <label for="minute">Minute:   </label>
                                                  <select name="minute[]" className="form-control cutoff_minute">
                                                      {listminuteItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                            </div>
                                         </div>
                                         <div>
                                            <div>Tuesday</div>
                                            <div className="">
                                               <div className="hours">
                                                  <label for="hours">Hour:   </label>
                                                  <select name="hour[]" className="form-control cutoff_hour">
                                                      {listhourItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                               <div className="minute">
                                                  <label for="minute">Minute:   </label>
                                                  <select name="minute[]" className="form-control cutoff_minute">
                                                      {listminuteItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                            </div>
                                         </div>
                                         <div>
                                            <div>Wednesday</div>
                                            <div className="">
                                               <div className="hours">
                                                  <label for="hours">Hour:   </label>
                                                  <select name="hour[]" className="form-control cutoff_hour">
                                                      {listhourItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                               <div className="minute">
                                                  <label for="minute">Minute:   </label>
                                                  <select name="minute[]" className="form-control cutoff_minute">
                                                      {listminuteItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                            </div>
                                         </div>
                                         <div>
                                            <div>Thursday</div>
                                            <div className="">
                                               <div className="hours">
                                                  <label for="hours">Hour:   </label>
                                                  <select name="hour[]" className="form-control cutoff_hour">
                                                      {listhourItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                               <div className="minute">
                                                  <label for="minute">Minute:   </label>
                                                  <select name="minute[]" className="form-control cutoff_minute">
                                                      {listminuteItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                            </div>
                                         </div>
                                         <div>
                                            <div>Friday</div>
                                            <div className="">
                                               <div className="hours">
                                                  <label for="hours">Hour:   </label>
                                                  <select name="hour[]" className="form-control cutoff_hour">
                                                      {listhourItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                               <div className="minute">
                                                  <label for="minute">Minute:   </label>
                                                  <select name="minute[]" className="form-control cutoff_minute">
                                                      {listminuteItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                            </div>
                                         </div>
                                         <div>
                                            <div>Saturday</div>
                                            <div className="">
                                               <div className="hours">
                                                  <label for="hours">Hour:   </label>
                                                  <select name="hour[]" className="form-control cutoff_hour">
                                                      {listhourItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                               <div className="minute">
                                                  <label for="minute">Minute:   </label>
                                                  <select name="minute[]" className="form-control cutoff_minute">
                                                      {listminuteItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                            </div>
                                         </div>
                                         <div>
                                            <div>Sunday</div>
                                            <div className="">
                                               <div className="hours">
                                                  <label for="hours">Hour:   </label>
                                                  <select name="hour[]" className="form-control cutoff_hour">
                                                      {listhourItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                               <div className="minute">
                                                  <label for="minute">Minute:   </label>
                                                  <select name="minute[]" className="form-control cutoff_minute">
                                                      {listminuteItems}
                                                  </select>
                                                  <small className="text-danger hide">This field is required.</small>
                                               </div>
                                            </div>
                                         </div>
                                      </div>
                                   </div>
                                </div>
                            </div>
                            <div>
                                <div className="col-sm-12"><strong>Block Dates</strong></div>
                                <div className="main-date" id="main-date">
                                    <DatePickerComp store_detail={this.state.shop_detail} handleDateChange={this.handleDateChange.bind(this)} default_date_value={this.state.default_date_value} fieldname="block_date"/>
                                </div>
                                <div className="note">
                                    <strong>Note: Customers can select can't select it as a delivery date.</strong>
                                </div>
                                <div>
                                 <div className="radio">
                                   <label>
                                     <input name="global_delivery_time" type="radio" value="1" checked={true} />
                                      Same for each day
                                   </label>
                                 </div>
                                 <div className="radio">
                                   <label>
                                     <input name="global_delivery_time" type="radio" value="2" />
                                     Different for each day
                                   </label>
                                 </div>
                                </div>
                                <div className="order_note">
                                    <div><span className="note"><strong>Delivery Time</strong> (Add comma(<b>","</b>) separated delivery time values)</span></div>
                                    <div>
                                        <textarea ref="delivery_time" id="delivery_time" name="delivery_time" className="form-control" rows="5" defaultValue={(JSON.parse(this.props.store_detail).fn_store_config) ? JSON.parse(this.props.store_detail).fn_store_config.delivery_time : ''}></textarea>
                                    </div>
                                    {this.state.delivery_timeError ? <span style={{color: "red"}}>Please Delivery Time</span> : ''}
                                </div>
                                <div className="datepicker_validate">
                                    <strong>Enable Block Days Interval</strong>
                                    <span className="onoff"><input ref="exclude_block_date_status" name="exclude_block_date_status" type="checkbox" onClick={this.toggleChange} defaultChecked={this.state.block_days_interval_checked} defaultValue={this.state.block_days_interval_checkbox_value}/><label for="checkboxID2"></label></span>
                                    <div className="note">
                                        <strong>Note:</strong> Use "Block Days", if you wish to add extra days for interval due to Block Days.
                                    </div>
                                </div>
                                <br/>
                                <br/>
                                <div>
                                    <strong>Block Days</strong>
                                    <div className="form-group days">
                                        <input type="checkbox" name="days[]" value="Sunday" />Sunday
                                        <input type="checkbox" name="days[]" value="Monday" />Monday
                                        <input type="checkbox" name="days[]" value="Tuesday" />Tuesday
                                        <input type="checkbox" name="days[]" value="Wednesday" />Wednesday
                                        <input type="checkbox" name="days[]" value="Thursday" />Thursday
                                        <input type="checkbox" name="days[]" value="Friday" />Friday
                                        <input type="checkbox" name="days[]" value="Saturday" />Saturday
                                    </div>
                                    <div className="note">
                                        <strong>Note: Customers can select can't select it as a delivery date.</strong>
                                    </div>
                                </div>
                                <br/>
                                <br/>
                                <div>
                                    <div><strong>Pre-order Time(In Months)</strong></div>
                                    <div className="form-group margin_bottom_0">
                                        <input ref="alloved_month" className="form-control" type="number" defaultValue={this.state.alloved_month} min="1" name="alloved_month" min="1" id="example-number-input" />
                                    </div>
                                    <div className="note">
                                        <strong>Note:</strong> This option will allow user to book order before "X" number of Months on the Website.
                                    </div>
                                </div>
                                <br/>
                                <br/>
                                <div>
                                    <div><strong>Date Interval</strong></div>
                                    <div className="form-group margin_bottom_0">
                                        <input ref="date_interval" className="form-control" type="number" min="0" defaultValue={this.state.date_interval} name="date_interval" id="example-number-input"/>
                                    </div>
                                    <div className="note">
                                        <strong>Note:</strong> For "Today Delivery" it should be "0" otherwise it should be the interval of days from the current day to allow user to select delivery date.
                                    </div>
                                </div>
                                <br/>
                                <br/>
                            </div>
                            <div className="datepicker_label" title="Option to set Label/Title for Calendar">
                                <div><strong>Delivery Datepicker Title </strong></div>
                                <div><input type="text" id="datepicker_label" name="datepicker_label" value="" className="form-control" />
                                <span className='text-danger hide'>Make sure the Datepicker Label is less than 200 characters.</span></div>
                            </div>
                            <div className="datepicker_label">
                                <div><strong>Error Message for Delivery Date</strong></div>
                                <div><input type="text" id="date_error_message" name="date_error_message" value="" className="form-control"/>
                                <span className='text-danger hide'>Make sure the Validation Message is less than 200 characters.</span></div>
                            </div>
                            <div className="datepicker_label" title="Option to set Label/Title for Delivery-Time">
                                <div><strong>Delivery Time Title </strong></div>
                                <div><input type="text" name="time_label" value="" className="form-control"/>
                                <span className='text-danger hide'>Make sure the Delivery Time Title is less than 200 characters.</span></div>
                            </div>
                            <div className="datepicker_label" title="Option to set validation-message for customers if Delivery-Time is required">
                                <div><strong>Error Message for Delivery Time</strong></div>
                                <div><input type="text" id="time_error_message" name="time_error_message" value="" className="form-control"/>
                                <span className='text-danger hide'>Make sure the Validation Message is less than 200 characters.</span></div>
                            </div>
                            <div className="dateformat_option">
                                <div><strong>Delivery Date Format</strong></div>
                                <div>
                                    <select name="date_format" className="form-control">
                                        <option value="mm/dd/yy">mm/dd/yyyy</option>
                                        <option value="yy/mm/dd">yyyy/mm/dd</option>
                                        <option value="dd/mm/yy">dd/mm/yyyy</option>
                                    </select> 
                                </div>
                            </div>
                        </div>
                        <div className="submit-button">
                            <button className="button btn-primary" type="submit">Save</button>
                        </div>
                    </div>
                </form>
            </div>
        );
    }
}
if (document.getElementById('generaldelivery')) {
    var store_detail = document.getElementById('generaldelivery').getAttribute('store_detail');
    var shop = document.getElementById('generaldelivery').getAttribute('shop');
    ReactDOM.render(<GeneralDelivery store_detail={store_detail} shop={shop} />, document.getElementById('generaldelivery'));
}