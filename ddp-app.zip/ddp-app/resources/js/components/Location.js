import React, { Component,useEffect, useState, useRef } from 'react';
import ReactDOM from 'react-dom';
import createApp from '@shopify/app-bridge';
import {ContextualSaveBar,Loading,Toast,Redirect} from '@shopify/app-bridge/actions'
import axios from 'axios';

export default class Location extends Component {
    constructor(props){
        super(props);
        this.state = {
            shop: props.shop,
            shop_detail: props.shop,
            locations: JSON.parse(props.shopdetail).fn_locations,
            loader: Loading.create(app),
        };
    }
    generalSettingPage = () => {
        redirect.dispatch(Redirect.Action.APP,dashboard_url)
    }
    addLocationClick = () => {
        redirect.dispatch(Redirect.Action.APP,add_location_url)
    }

    render() {
        return(
            <div className="location-wraper">
                <div className="row">
                    <div className="col-md-6 add-location-btn">
                        <h2 className="heading">Locations</h2>
                    </div>
                    <div className="col-md-6 add-location-btn">
                        <a href={add_location_url} onClick={this.addLocationClick} className="btn btn-primary button">Add Location</a>
                    </div>
                </div>
                <table className="table">
                    <thead>
                        <tr>
                            <th>Company Name</th>
                            <th>Address</th>
                            <th>City</th>
                            <th>State</th>
                            <th>Country</th>
                            <th>Zipcode</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    {
                        this.state.locations.map((data, index)=>{
                            return(
                                <tr key={index}>
                                    <td>{data.company_name}</td>
                                    <td>{data.address}</td>
                                    <td>{data.city}</td>
                                    <td>{data.state}</td>
                                    <td>{data.country}</td>
                                    <td>{data.zipcode}</td>
                                    <td>
                                        <a href={"locationsedit?shop="+this.state.shop+"&id="+data.id} className="edit-location">
                                            <i className="fa fa-pencil" aria-hidden="true"></i>                                            
                                        </a>
                                    </td>
                                </tr>
                            )
                        })
                    }
                    </tbody>
                </table>
                {!this.state.locations && <h1 className="text-center m-5">Your location is not created yet. Please create location first.</h1>}
            </div>
        );
    }
}
if (document.getElementById('location')) {
    var shopdetail = document.getElementById('location').getAttribute('shopdetail');
    var shop = document.getElementById('location').getAttribute('shop');
    ReactDOM.render(<Location shopdetail={shopdetail} shop={shop} />, document.getElementById('location'));
}