<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        @import url("https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i");
        @media only screen and (max-width:599px) {
            table {
                width: 100% !important;
            }
        }
        
        @media only screen and (max-width:412px) {
            h2 {
                font-size: 20px;
            }
            p {
                font-size: 13px;
            }
            .easy-donation-icon img {
                width: 120px;
            }
        }
    </style>
</head>

<body style="background: #f4f4f4; padding-top: 57px; padding-bottom: 57px;">
    <table class="main" border="0" cellspacing="0" cellpadding="0" width="600px" align="center" style="border: 1px solid #e6e6e6; background:#fff; ">
        <tbody>
            <tr>
                <td style="padding: 30px 30px 10px 30px;" class="review-content">
                    <p class="text-align:left;"><img src="{{$logo}}" alt=""></p>
                    <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px; line-height: 25px; margin-top: 0px;"><b>Hello {{ $shopInfo->store_owner ?? '' }}</b>,</p>
                    <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">I noticed that your Shopify store, {{$shopInfo->store_name ?? ''}}, has gone live. Congratulations!</p>
                    <p style="font-family: \'Helvetica\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">I wanted to touch base and remind you that while your store was in development, the Delivery Date Pro app was free to use. However, now that the store is live you will need to authorize billing on your app, Delivery Date Pro, in order for it to run.</p>
                    <a href="{{$shopInfo->fn_shop_information->confirmation_url ?? ''}}" target="_blank" style="background-color:#ce2525;border-radius:6px;color:#fff;display:inline-block;font-family:sans-serif;font-size:16px;font-weight:bold;line-height:40px;text-align:center;text-decoration:none;padding:5px 20px">Authorize Billing Now</a><br><br>
                    <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">Any questions? Hit reply and I can help you out! <br><br>
                    </p>
                </td>
            </tr>
            <tr>
                <td style="padding: 20px 30px 30px 30px;">
                    <br>
                    <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 26px; margin-bottom:0px;">Thanks & Regards,<br>
                        Shilpi Sethi<br>
                        <b>Tel No:</b> +91 79 40320305<br>
                        <b>Email Id:</b> <a href="mailto:shilpi@zestard.com" style="text-decoration: none;color: #1f98ea;font-weight: 600;">shilpi@zestard.com</a><br>
                        <b>Skype:</b> biz.zestard <br>
                        <b>Website:</b> https://www.zestard.com
                    </p>
                </td>
            </tr>
        </tbody>
    </table>
</body>
</html>