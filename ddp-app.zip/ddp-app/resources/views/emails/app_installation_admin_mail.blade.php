<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        @import url("https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i");
        @media only screen and (max-width:599px) {
            table {
                width: 100% !important;
            }
        }
        
        @media only screen and (max-width:412px) {
            h2 {
                font-size: 20px;
            }
            p {
                font-size: 13px;
            }
            .easy-donation-icon img {
                width: 120px;
            }
        }
    </style>

</head>

<body style="background: #f4f4f4; padding-top: 57px; padding-bottom: 57px;">
    <table>
        <tr>
            <th>Shop Name</th>
            <td>{{$shopInfo->shop->name ?? 'N/A'}}</td>
        </tr>
        <tr>
            <th>Email</th>
            <td>{{$shopInfo->shop->email ?? 'N/A'}}</td>
        </tr>
        <tr>
            <th>Domain</th>
            <td>{{$shopInfo->shop->domain ?? 'N/A'}}</td>
        </tr>
        <tr>
            <th>Phone</th>
            <td>{{$shopInfo->shop->phone ?? 'N/A'}}</td>
        </tr>
        <tr>
            <th>Shop Owner</th>
            <td>{{$shopInfo->shop->shop_owner ?? 'N/A'}}</td>
        </tr>
        <tr>
            <th>Country</th>
            <td>{{$shopInfo->shop->country_name ?? 'N/A'}}</td>
        </tr>
        <tr>
            <th>Plan</th>
            <td>{{$shopInfo->shop->plan_name ?? 'N/A'}}</td>
        </tr>
    </table>
</body>
</html>