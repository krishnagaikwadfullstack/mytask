<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        @import url("https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i");
        @media only screen and (max-width:599px) {
            table {
                width: 100% !important;
            }
        }
        
        @media only screen and (max-width:412px) {
            h2 {
                font-size: 20px;
            }
            p {
                font-size: 13px;
            }
            .easy-donation-icon img {
                width: 120px;
            }
        }
    </style>
</head>
<body style="background: #f4f4f4; padding-top: 57px; padding-bottom: 57px;">
    <table class="main" border="0" cellspacing="0" cellpadding="0" width="600px" align="center" style="border: 1px solid #e6e6e6; background:#fff; ">
        <tbody>
            <tr>
                <td style="padding: 30px 30px 10px 30px;" class="review-content">
                    <p class="text-align:left;"><img src="{{$logo}}" alt=""></p>
                    <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px; line-height: 25px; margin-top: 0px;"><b>Hello Admin</b>,</p>
                    <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;"> Please find the below list for the stores with Development/Partner Test/Affiliate and moved to live.</p>
                    @if(isset($shopInfo->arrTestPlanStores))
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px; line-height: 25px; margin-top: 0px;"><b>Development/Partner Test/Affiliate(Test plan stores)</b></p>
                        <ul>
                            @foreach($shopInfo->arrTestPlanStores as $shop)
                                <li>{{$shop->store_name}} - {{$shop->plan_name}}</li>
                            @endforeach
                        </ul>
                    @endif
                    @if(isset($shopInfo->arrTestToLiveStores))
                        <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px; line-height: 25px; margin-top: 0px;"><b>Moved to live</b></p>
                        <ul>
                            @foreach($shopInfo->arrTestToLiveStores as $shop)
                                <li>{{$shop->store_name}} - {{$shop->plan_name}}</li>
                            @endforeach
                        </ul>
                    @endif
                </td>
            </tr>           
            <tr>
                <td style="padding: 20px 30px 30px 30px;">
                    <br>
                    <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 26px; margin-bottom:0px;"> Thanks & Regards,<br>
                        Zestard Notification!
                    </p>
                </td>
            </tr>
        </tbody>
    </table>
</body>
</html>