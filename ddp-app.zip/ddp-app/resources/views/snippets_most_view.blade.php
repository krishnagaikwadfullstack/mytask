<?php
echo "{% assign product_page =  1  %}
		{% assign product_id   = ""  %}
	{% if template contains 'product' %}
		{% assign product_id = product.id %}		
	{% else %}
        {% assign product_page = 0 %}
    {% endif %}";

echo "<script>
	var product_ids, product_id, product_page=1;
 	{% if template contains 'product' %}
  		
  		product_id = {{ product.id }};   
        
    {% else %}    
        
        product_page=0;
  
	{% endif %}
	</script>";	
	
<div id="jquery_box"></div>

{{ 'https://zestardshop.com/shopifyapp/quick_buy/public/js/most_view.js' | script_tag }}