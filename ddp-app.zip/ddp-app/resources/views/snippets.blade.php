<?php

echo "{% assign flag = 0 %}
{% for item in cart.items %}
	{% if item.product.tags contains 'no-delivery-date' %}   
		
	{% else %}
        {% assign flag = 1 %}
    {% endif %}              	
{% endfor %}";
?>
<input type="hidden" id="kanaoddp-current-date" value="<?php echo "{{ 'now' | date: '%d' }}";?>" />
<input type="hidden" id="kanaoddp-store-hour" value="<?php echo "{{ 'now' | date: '%H' }}";?>" />
<input type="hidden" id="kanaoddp-store-minute" value="<?php echo "{{ 'now' | date: '%M' }}";?>" />
<input type="hidden" id="kanaoddp-date-format-ddmmyy" value="<?php echo "{{ 'now' | date: '%d-%m-%Y' }}";?>" />
<input type="hidden" id="kanaoddp-date-format-yymmdd" value="<?php echo "{{ 'now' | date: '%Y-%m-%d' }}";?>" />
<?php echo "{{ '".getenv('APP_URL')."public/css/jquery-ui.css' | stylesheet_tag }}";?>
<?php echo "{% if flag == 1 %}";?>
<div id="datepicker_box" class="additional-css">	
	<p class="date-box">
		<label for="kanaoddp-delivery-date"></label>
		<input id="kanaoddp-delivery-date" type="text" name="attributes[Delivery-Date]" value="<?php echo "{{ cart.attributes.Delivery-Date }}";?>" readonly="readonly" disabled />
	</p>
	<span id="selected_format"></span>
	<label id="kanaoddp-time-label" style="display:none" ></label>
	<select id="kanaoddp-time" name="attributes[Delivery-Time]" style="display:none" readonly="readonly">
	<option id="kanaoddp_time_option_label" value=""></option>
	</select>
	<span id="kanaoddp_admin_notes"></span>
</div>
<?php echo "{% endif %}";?>
<script>
var store_timezone_offset = "<?php echo "{{ 'now' | date: '%Z' }}";?>";

</script>
<?php echo "{{ '".getenv('APP_URL')."public/js/snippets.js' | script_tag }}";?>
<?php echo "{{ '".getenv('APP_URL')."public/css/kanaoddp-snippet.css' | stylesheet_tag }}";?>