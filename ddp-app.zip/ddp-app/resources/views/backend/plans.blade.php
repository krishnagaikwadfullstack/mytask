@extends('layouts.header_new') 
@section('content')
<script type="text/javascript">
    const cancelButton = Button.create(app, {label: 'Cancel'});
    cancelButton.subscribe(Button.Action.CLICK, (data) => {
         redirect.dispatch(Redirect.Action.APP, dashboard_url);
    });
    console.log('titleBarOptions')
    @if($data['obj_shop_detail']->app_version > 0)
    const titleBarOptions = {
        title: 'CHOOSE PLAN',
        buttons: {
            primary: cancelButton
        }
    };
    const myTitleBar = TitleBar.create(app, titleBarOptions);
    console.log(myTitleBar)
    @endif
</script>
<div class="container formcolor"> 
    <div class="pricing_table_block">
        <div class="pricing_table_div">
            <div class="pricing_table_item margin_right">
                <h1 class="pricing_table_title">Basic</h1>
                <div class="pricing_table_price_div">
                    <span class="doller_icon">$</span><h2>8.99</h2><span class="month_text"> / M</span>
                </div>
                <div class="pricing_table_list">
                    <ul>
                        <li>Delivery Date & Time Selection</li>
                        <li>Cut Off Time (Same for Everyday)</li>
                        <li>Same Day & Next Day Delivery</li>
                        <li>Blocking Specific Days and Dates</li>
                        <li>Admin Order Manage & Export Based on Delivery Date</li>
                        <li>All Basic Features</li>             
                        <li>Auto Select for Next Available Delivery Date</li>
                        <li>Auto Tag Delivery Details to all the Orders Within Interval of 1 hour from Order Placed Time</li>
                        <li>Add Delivery Date & Time Information Under Customer Order Confirmation Email<br><br><br></li>
                    </ul>
                </div>
                <div class="select_btn">                
                    <form action="{{ url('plan/1') }}" method="post">                                            
                        {{ csrf_field() }}
                        <input name="one" type="hidden" value="1">
                        <input name="shop" type="hidden" class="shop" value="{{ $data['shop'] }}">
                        <button type="submit" class="plan_select1" @if($data['obj_shop_detail']->app_version == 1) disabled @endif>{{ ($data['obj_shop_detail']->app_version == 1)?'Current Plan':'Select' }}</button>
                    </form>
                </div>
            </div>
            <div class="pricing_table_item popup-with-zoom-anim">
                <h1 class="pricing_table_title">Advance</h1>
                <div class="pricing_table_price_div">
                    <span class="doller_icon">$</span><h2>13.99</h2><span class="month_text"> / M</span>
                </div>
                <div class="pricing_table_list">
                    <ul>
                        <li>All Basic Features</li>
                        <li>Set Cut Off Time for Each Individual Weekday</li>
                        <li>Set Different Delivery Time Options for Each Weekday</li>
                        <li>Set Limit for Customer Order Delivery Based on Delivery Time</li>
                        <li>Add-on Options of Cut-off time & Block Dates</li>
                        <li>Minimum Date Interval</li>
                    </ul>                   
                </div>
                <div class="select_btn">
                    <form action="{{ url('plan/2') }}" method="post">
                        {{ csrf_field() }}
                        <input name="three" type="hidden" value="2">    
                        <input name="shop" type="hidden" class="shop" value="{{ $data['shop'] }}">
                        @if($data['obj_shop_detail']->app_version != 2)
                        <button data-version="three" type="button" class="plan_select" @if($data['obj_shop_detail']->app_version == 2) disabled @endif>{{ ($data['obj_shop_detail']->app_version == 2)?'Current Plan':'Select' }}</button>
                        @else
                        <button type="submit" class="plan_select1" @if($data['obj_shop_detail']->app_version == 2) disabled @endif>{{ ($data['obj_shop_detail']->app_version == 2)?'Current Plan':'Select' }}</button>
                        @endif
                    </form>
                </div>
            </div>  
        </div>
    </div>
</div>
<script>
    var trial_days = "{{$data['obj_shop_detail']->trial_days}}";
</script>
@endsection