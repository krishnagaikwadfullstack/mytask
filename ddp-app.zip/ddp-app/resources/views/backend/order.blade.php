@extends('layouts.header_new')	
@section('pageCss')
<link rel="stylesheet" href="https://shopifydev.anujdalal.com/ddp_new/public/css/custom.css">
<link rel="stylesheet" href="{{ asset('css/uptown/style.css') }}">  
@endsection
@section('content')
@php 
$date_format = $settings['date_format']; 
@endphp
<div class="container formcolor" style="margin-top:1%;">
    <div id="manage-order-div">
        <form action='order-demo' id="exportValidate" method='post'><input type='hidden' name='_token' value='{{ csrf_token() }}'/>	
            <input type='hidden' value='{{ $store_format }}' name='current_format' />	
            <input type="hidden" name="shop" value="{{ $shop }}"/>	
            <section>
                <div class="columns six card">
                    <h2>Today's Delivery:- {{ $today_delivery_count }}</h2>			
                </div>
                <div class="columns six card">
                    <h2>This Week's Delivery:- {{ $week_delivery_count }}</h2>  
                    <p>This card is slightly dimmed to give the primary card more visual importance</p>
                </div>
            </section>
            <section>
                <div class="columns twelve card">
                    <div class="filterParentDiv">
                        <label class="filterChildDiv">Start Delivery Date</label>
                        <input type="text" name="min" id="min" class="start_delivery filterChildDiv"/>
                        <label class="filterChildDiv">End Delivery Date</label>
                        <input type="text" name="max" id="max" class="end_delivery filterChildDiv"/>
                    </div>
                    <div id="show_product_checkbox">
                        <label>
                            <input type="checkbox" name="repeat" id="repeat_details"  value="1" checked="checked">Show Product Data for all Products
                        </label>
                    </div>
                    <div>						
                        <button type='reset' name='clear' value='' id='reset_button' onclick='reload()'>Reset</button>
                        <button type='submit' id='export-csv'>Export to CSV</button>
                    </div>
                </div>
            </section>
        </form>
        <section>
            <div class="has-sections card">
                <ul class="tabs">
                    <li class="active"><a href="#"><h2>Orders</h2></a></li>
                </ul>
                <div class="manage_table card-section">
                    <table id="example" class="table table-striped table-bordered">
                        <thead> 
                            <tr>
                                <th>Order</th>
                                <th>Customer Name</th>
                                @if($shop == "the-bunched-co.myshopify.com")	
                                <th>Product Name (Qty, Delivery Date, Delivery Time)</th>
                                @else
                                @if($app_version == 4)
                                <th>Product Name (Qty, Delivery Date, Delivery Time)</th>
                                @else
                                <th>Product Name (Qty)</th>
                                @endif
                                @endif				  
                                <th>Payment Status</th>
                                <th>Total</th>
                                <th>Delivery Date</th>
                                <th>Delivery Time</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($orderlist->orders as $order_details)
                            @php
                            $products_array = array();
                            @endphp
                            <tr>
                                <td>
                                    <a href="https://{{session('shop') ?? $shop}}/admin/orders/{{ $order_details->id }}" target="_blank">
                                        {{$order_details->name}}	
                                    </a>
                                </td>
                                <td>
                                    {{$order_details->customer->first_name." ".$order_details->customer->last_name}}	
                                </td>
                                <td>
                                    @foreach ($order_details->line_items as $product_details)
                                    @php	
                                    array_push($products_array," ".$product_details->title ."<b> (".$product_details->quantity .")</b>") ;
                                    @endphp
                                    @endforeach
                                    {!! implode("<br>",$products_array) !!} 
                                </td>
                                <td>
                                    <span class="tag @if($order_details->financial_status == 'paid') green @else orange @endif">
                                        {{ $order_details->financial_status }}
                                    </span>
                                </td>
                                <td>
                                    {{ $order_details->currency.' '.$order_details->total_price }}
                                </td>
                                <td>
                                    @php
                                    $atributes="";	
                                    $time_attribute="";							
                                    @endphp
                                    @foreach($order_details->note_attributes as $attribute)
                                    @if($attribute->name == "Delivery-Date" || $attribute->name == "Delivery-Date-Pro")
                                    @php $atributes = $attribute; @endphp
                                    @endif
                                    @if($attribute->name == "Delivery-Time" || $attribute->name == "Delivery-Time-Pro")
                                    @php $time_attribute = $attribute; @endphp
                                    @endif
                                    @endforeach
                                    @if(!empty($atributes))										
                                    @php										
                                    $date_final = (string)$atributes->value;																	
                                    @endphp									
                                    {{ date('d F, Y',strtotime($date_final)) }}														
                                    @else
                                    {{ "-" }}
                                    @endif
                                </td>
                                <td>
                                    @if(!empty($time_attribute))															
                                    @if($time_attribute->value != "" or !(empty($time_attribute->value)))
                                    {{ $time_attribute->value }}													
                                    @else												
                                    {{ "-" }}
                                    @endif
                                    @else
                                    {{ "-" }}
                                    @endif
                                </td>
                                <td>
                                    @if($order_details->fulfillment_status == 'fulfilled')
                                    <button type="button" class="secondary order_complete" data-value="{{ $order_details->fulfillment_status }}" data-id="{{ $order_details->id }}" style="pointer-events:none;">Fulfilled</button>
                                    @else								
                                    <button type="button" class="secondary order_complete" data-value="{{ $order_details->fulfillment_status }}" style="pointer-events:none;" data-id="{{ $order_details->id }}" data-toggle="tooltip" title="Mark as fulfilled" title="Mark as fulfiiled" data-hover="Mark Order Complete">Unfulfilled</button>
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>	
                </div>	

            </div>
        </section> 
    </div>
</div>
@endsection 
@section('pageScript')
<script type="text/javascript">
    const navigationMenu = NavigationMenu.create(app, {
      items: [helpLink, ordersLink, dashboardLink],
      // active: settingsLink,
    });
    console.log(navigationMenu,'navigationMenu','----',NavigationMenu,app)
    const titleBarOptions = {
        title: 'ORDERS'
    }; 
    const myTitleBar = TitleBar.create(app, titleBarOptions);
</script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.js"></script>
<script type="text/javascript">
    function reload() {
        $("#min").val("");
        $("#max").val("");
        var table = $('#example').DataTable();
        table.search('').columns().search('').draw();
    }
    function convertdate(date)
    {
        var current_format = $('#date_format').val();
        var blank = "";
        if (current_format == "dd/mm/yy") {
            var day = date.substring(0, 2);
            var month = date.substring(3, 5);
            var year = date.substring(6, 10);
            return date.value = year + ',' + month + ',' + day;
        } else if (current_format == "mm/dd/yy")
        {
            var month = date.substring(0, 2);
            var day = date.substring(3, 5);
            var year = date.substring(6, 10);
            return date.value = year + ',' + month + ',' + day;
        } else if (current_format == "yy/mm/dd") {
            return date.split('/').join(',');
        } else {
            return blank;
        }
    }
//data table with custom filter and feature   
    $(document).ready(function () {
        //for data table
        var todays_date = "{{ $todays_date }}";
        var start_of_week = "{{ $start_of_week }}";
        var end_of_week = "{{ $end_of_week }}";
        var store_format = '<?php echo $store_format ?>';
        if (store_format == "d/m/Y")
        {
            var day = todays_date.substring(0, 2);
            var month = todays_date.substring(3, 5);
            var year = todays_date.substring(6, 10);
            todays_date = day + '/' + month + '/' + year;
        }
        if (store_format == "m/d/Y")
        {
            var month = todays_date.substring(3, 5);
            var day = todays_date.substring(0, 2);
            var year = todays_date.substring(6, 10);
            todays_date = month + '/' + day + '/' + year;
        }
        if (store_format == "Y/m/d")
        {
            var month = todays_date.substring(5, 7);
            var day = todays_date.substring(8, 10);
            var year = todays_date.substring(0, 4);
            //todays_date = year + '/' + month + '/' + day;
            parts_date = todays_date.split('-');
            todays_date = parts_date[2] + '/' + parts_date[1] + '/' + parts_date[0];
        }
        $("#min").datepicker({onSelect: function () {
                table.draw();
            }, changeMonth: false, changeYear: false, dateFormat: '<?php echo $date_format; ?>'
        });
        $("#max").datepicker({onSelect: function () {
                table.draw();
            }, changeMonth: false, changeYear: false, dateFormat: '<?php echo $date_format; ?>'});
        var table = $('#example').DataTable({
            "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
            "language": {
                paginate: {
                    next: '<button class="secondary"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></button>',
                    previous: '<button class="secondary"><i class="fa fa-long-arrow-left" aria-hidden="true"></i></button>'
                },
                processing: "<img src='{{ asset('/image/loadingthin.svg') }}' height='40px;' width='40px;'>"
            },
            "dom": '<<"pull-right" l><"pull-left" f>ti<"pull-right" p>>',
            "order": [0, "desc"],
            "pageLength": 5,
            "bPaginate": true,
        });
        $('#min, #max').change(function () {
            table.draw();
        });
        $('.todays_delivery').click(function () {
            $("#min").val(todays_date);
            $("#max").val(todays_date);
            table.draw();
        });
        // validate export to csv
        $("#exportValidate").submit(function (event) {
            var start_date = $('.start_delivery').val();
            var end_date = $('.end_delivery').val();
            if (start_date == "") {
                alert("Please select start delivery date.");
                return false;
            }
            if (end_date == "") {
                alert("Please select end delivery date.");
                return false;
            }
        });
    });
</script>
@endsection 