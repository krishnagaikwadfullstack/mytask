<script src="{{ asset('vendor/unisharp/laravel-ckeditor/ckeditor.js') }}"></script>
<script src="{{ asset('vendor/unisharp/laravel-ckeditor/adapters/jquery.js') }}"></script>
<script>
    CKEDITOR.replace('textarea.ckeditor');
//    $('textarea.ckeditor').ckeditor();
</script>