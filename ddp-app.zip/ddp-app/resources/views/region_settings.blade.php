@extends('header')
@section('content')
<?php
if(!empty(session('shop'))) {
  $shop = session('shop');
} else {
  $shop = $_REQUEST['shop'] ?? request()->get('shop');
}
	
?>
<script type="text/javascript">
    const navigationMenu = NavigationMenu.create(app, {
      items: [helpLink, ordersLink, dashboardLink],
      // active: settingsLink,
    });
    const titleBarOptions = {
        title: 'Region Settings'
    };
    const myTitleBar = TitleBar.create(app, titleBarOptions);
    const myTitleBar = TitleBar.create(app, titleBarOptions);
     function generalSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, dashboard_url);
    }
    function regionSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, region_url);
    }
    function cutoffSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, cutoff_setting_url);
    }
</script>
<script type="text/javascript">

</script>
<div class="container formcolor cutoff_block">      
	<ul class="nav nav-tabs dashboard_tabs">
        <li><a href="{{ url('dashboard?shop='.$shop) }}" onclick="generalSettingPage()">General Settings</a></li>
        <li class="active"><a href="{{ url('region?shop='.$shop) }}" onclick="regionSettingPage()">Regions</a></li>
		<li><a href="{{ url('cut-off?shop='.$shop) }}" onclick="cutoffSettingPage()">Cutoff & Time Settings</a></li>		
	</ul>				
	
	<div class="row formcolor_row">	
	<h2 class="sub-heading">Region Settings</h2>		
    <form method="post" action="{{ url('save-region?shop='.$shop) }}" data-shopify-app-submit="form_submit" class="cutoff_div1">
    <input type="hidden" name="shop_id" value="{{ $shop_id }}">
	{{ csrf_field() }}
    <table id="cut_off" class="table table-bordered delivery_time_table cutoff_table" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th class="col-md-4"><span class="col-md-12">Add Region</span></th>							                						          
            </tr>
        </thead>
        <tbody><tr>
            <td>
           <div class="col-md-4"><input type="text" name="region" class="form-control" /></div>
           <div class="col-md-4"><input type="submit" value="Add" class="add_btn" /></td></tr></div>
        </tbody>        					
        </table>
    </form>
        @if(!empty($regions))
        <table id="cut_off" class="table table-bordered delivery_time_table cutoff_table" cellspacing="0" width="100%">
                <thead>
                    <tr>
                        <th class="col-md-4" colspan="4"><span class="col-md-12">Region List</span></th>							                						          
                    </tr>
                </thead>
                <tbody>
                   @foreach($regions as $region)
                       <tr>
                       <td class="region_text" id="region_text_{{ $region->id }}"><span>{{ $region->region }}</span> <form action="{{ url('save-region?id='.$region->id) }}" method="POST">	{{ csrf_field() }}<input type="text"  class="form-control" value="{{ $region->region }}" name="region" id="region_{{ $region->id }}" style="display:none;"/></form></td>
                            <td><a href="javascript:;" class="edit_btn" data-value="{{ $region->id }}">Edit</a></td>
                            <td><a href="{{ url('delete-region/'.$region->id) }}?shop={{$shop}}">Delete</a></td>
                       </tr>
                   @endforeach
                </tbody>        					
                </table>
        @endif
	
</div>
<script>
    $(".edit_btn").click(function(e){
        var current = $(this).attr('data-value');
        $('#region_text_'+current + ' span').hide();
        $('#region_'+current).show();
    });
</script>
@endsection