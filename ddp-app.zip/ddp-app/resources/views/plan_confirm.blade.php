@extends('layouts.header_new') 
@section('content')
<style type="text/css">
    .formcolor_plan h4 {
        font-size: 19px;
        line-height: 25px;
        margin-bottom: 20px;
    }

    .formcolor_plan h5 {
        margin-bottom: 15px;
        visibility: top;
        font-weight: 800;
    }

    .formcolor_plan h5 input[type=checkbox]{
        visibility: visible;
        position: relative;
        display: inline-block;
        height: 1.6rem;
        width: 1.6rem;
        border: .1rem solid #c4cdd5;
        background: -webkit-linear-gradient(top, #fff, #f9fafb);
        background: linear-gradient(180deg, #fff, #f9fafb);
        box-shadow: 0 0 0 1px transparent, 0 1px 0 0 rgba(22, 29, 37, 0.05);
        margin: 0 1rem 0 0;
        padding: 0;
        box-sizing: border-box;
        vertical-align: text-bottom;
    }

</style>
<script>
    $(document).ready(function () {
        // Handler for .ready() called.
        $('html, body').animate({
            scrollTop: $('.pricing_table_div').offset().top
        }, 'slow');
    });
</script>
<link rel="stylesheet" href="{{ asset('css/custom.css') }}"/>

<form method="get" action="{{route('plan',['plan_id' => $plan])}}" id="planForm">
    <input type="hidden" name="shop" value="{{$shop}}">
    @if($plan == 1)
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 formcolor_plan">
                <h3>{{ "Dear Customer, You Have Selected Basic Plan. Total Payable Amount is $7.99 (Basic Plan)" }}</h3><br>
                <h4>User charges will get apply for Basic version during trial period according to the shopify terms and structure of charges. Develpement Merchants do not have any rights or hold on this Methodology.</h4>
                <h5><input type="checkbox" name="confirm_usage_charge"> I agree to the Terms and Conditions.</h5>
                <a href="{{ url('plan/1') }}?shop={{$shop}}"><button  type="submit" class="btn btn-info">Click Here to Pay</button></a>
                <a href="{{url('select-plans')}}?shop={{$shop}}"><button type="button" class="btn btn-info">Go Back</button></a>
            </div></div></div>
    @endif
    @if($plan == 2)
    <br> 
    <div class="container">
        <div class="row">
            <div class="col-lg-12 formcolor_plan">
                <h3>{{ "Dear Customer, You Have Selected Professional Plan. Total Payable Amount is $10.99 (Basic - $7.99 + Professional - $3.00)" }}</h3><br>
                <h4>User charges will get apply for Professional version during trial period according to the shopify terms and structure of charges. Develpement Merchants do not have any rights or hold on this Methodology.</h4>
                <h5><input type="checkbox" name="confirm_usage_charge"> I agree to the Terms and Conditions.</h5>
                <a href="{{ url('plan/2') }}?shop={{$shop}}"><button  type="submit" class="btn btn-info">Click Here to Pay</button></a>
                <a href="{{url('select-plans')}}?shop={{$shop}}"><button type="button" class="btn btn-info">Go Back</button></a>
            </div></div></div>
    @endif	
    @if($plan == 3)
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 formcolor_plan">
                <h3>{{ "Dear Customer, You Have Selected Enterprise Plan. Total Payable Amount is $14.99(Basic - $7.99 + Enterprise - $7.00)" }}</h3><br>
                <h4>User charges will get apply for Enterprise version during trial period according to the shopify terms and structure of charges. Develpement Merchants do not have any rights or hold on this Methodology.</h4>
                <h5><input type="checkbox" name="confirm_usage_charge"> I agree to the Terms and Conditions.</h5>
                <a href="{{ url('plan/3') }}?shop={{$shop}}"><button  type="submit" class="btn btn-info">Click Here to Pay</button></a>
                <a href="{{url('select-plans')}}?shop={{$shop}}"><button type="button" class="btn btn-info">Go Back</button></a>	
            </div>
        </div>
    </div>
    @endif
    @if($plan == 4)
    <br>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 formcolor_plan">
                <h3>{{ "Dear Customer, You Have Selected Ultimate Plan. Total Payable Amount is $15.99(Basic - $7.99 + Ultimate - $8.00)" }}</h3><br>
                <h4>User charges will get apply for Ultimate version during trial period according to the shopify terms and structure of charges. Develpement Merchants do not have any rights or hold on this Methodology.</h4>
                <h5><input type="checkbox" name="confirm_usage_charge"> I agree to the Terms and Conditions.</h5>
                <a href="{{url('plan/4')}}?shop={{$shop}}"><button type="submit"  class="btn btn-info">Click Here to Pay</button></a>
                <a href="{{url('select-plans')}}?shop={{$shop}}"><button type="button" class="btn btn-info">Go Back</button></a>	
            </div>
        </div>
    </div>
    @endif
</form>
<script>

    $("#planForm").on('submit', function () {
        var getChecked = $("input[name='confirm_usage_charge']").prop("checked");
        if (!getChecked) {
            alert("Please select I Agree checkbox");
            return false;
        }
    });
</script>
@endsection