@extends('header')
@section('content')
<style>
	.cutoff_block {
		float: left;
		width: 100%;
		padding: 10px 0;
	}
	i.add_icon{
		font-size:18px;
		margin-top: 10px;
		float: left;
	}
	input.delivery_time.form-control {
		float: left;
		margin-right: 5px;
	}
	a.removecurrent {
		margin-top: 10px;
		float: left;
	}
</style>
<?php
	if(!empty(session('shop'))) {
		$shop = session('shop');
	} else {
		$shop = $_REQUEST['shop'] ?? request()->get('shop');
	}
	$days = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
?>
<script type="text/javascript">
	const navigationMenu = NavigationMenu.create(app, {
		items: [helpLink, ordersLink, dashboardLink],
      // active: settingsLink,
  });
	const titleBarOptions = {
		title: 'Region CutOff & Time Settings'
	}; 
	const myTitleBar = TitleBar.create(app, titleBarOptions);
	function generalSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, dashboard_url);
    }
    function regionSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, region_url);
    }
    function deliveryTimeSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, delivery_time_url);
    }
</script>
<div class="container formcolor">      
	<ul class="nav nav-tabs dashboard_tabs">
		<li><a href="{{ url('dashboard?shop='.$shop) }}" onclick="generalSettingPage()">General Settings</a></li>
		<li><a href="{{ url('region?shop='.$shop) }}" onclick="regionSettingPage()">Regions</a></li>
		<li class="active"><a href="{{ url('cut-off?shop='.$shop) }}" onclick="cutoffSettingPage()">Cutoff & Time Settings</a></li>		
	</ul>
	<div class="row formcolor_row">	
		<h2 class="sub-heading">Region CutOff & Time Settings</h2>		
		<form method="post" action="{{ url('save-region_setting?shop='.$shop) }}" data-shopify-app-submit="form_submit" class="cutoff_div">
			<input type="hidden" value="{{ $shop }}" name="shop">
			{{ csrf_field() }}
			<div class="text-right">
				<div class=" cutoff_time_checkbox">
					<span class="onoff">
						<input type="checkbox" @if($global_flag==1) checked @endif name="global_cutoff_time" id="global_cutoff_time" value="1"/>
						<label for="global_cutoff_time"></label>
					</span>
					<strong>Use Global Cut Off Time</strong>
					<div class="note">
						<strong>Note:</strong> If You Enable Global Cut Off Time, Then Cut Off Time(In General Settings) Will Be Global For All Days
					</div>
				</div>
				<span style="font-weight:0;font-size:13px;"></span>
			</div>	
			<table id="cut_off" class="table table-bordered delivery_time_table cutoff_table" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th class="col-md-2"><span class="col-md-12">Region</span></th>				
						<th class="col-md-8"><span class="col-md-12">Region time Settings</span></th>
						<th class="col-md-2"><span class="col-md-12">Add Region</span></th>
					</tr>
				</thead>
				<tbody>	
					<tr>
						<td>						
							<select name="region" class="form-control">						
								@foreach($region as $r)						
								<option value="{{ $r->id }}">{{ $r->region }}</option>
								@endforeach
							</select>
						</td>
						<td>
							<div class="cutoff_box">
								<div class="cutoff_block">								
									<div class="col-md-2">
										<label for="days">Days</label>
										<select name="time[0][days][day]" class="form-control">
											<option value="">Select Day</option>
											@foreach($days as $key => $delivery_day)
											<option value="{{ $key }}">{{ $delivery_day }}</option>
											@endforeach
										</select>
									</div>
									<div class="col-md-2" >	
										<label for="hours">Hours</label>
										<select name="time[0][days][hour]" class="form-control cutoff_hour">								
										<option selected value="">Select Hour</option>
										<?php for ($h = 00; $h < 24; $h++) { ?>
											<option value="{{str_pad($h, 2, '0', STR_PAD_LEFT)}}">{{ str_pad($h, 2, '0', STR_PAD_LEFT)}}</option>
											<?php} ?>
										</select>
									</div>
									<div class="col-md-2" >	
										<label for="minute">Minute</label>
										<select name="time[0][days][minute]" class="form-control cutoff_minute">
											<option selected value="">Select Minute</option>
											<?php for ($m = 00; $m <= 59; $m++) { ?>	
												<option value="{{ str_pad($m, 2, '0', STR_PAD_LEFT) }}">{{ str_pad($m, 2, "0", STR_PAD_LEFT) }}</option>
											<?php}?>
										</select>
									</div>

									<div class="col-md-2">
										<label for="interval">Interval</label>
										<input type="text" name="time[0][days][date_interval]" class="delivery_time form-control "  />
									</div>											
									<div class="col-md-4">
										<label for="timeslot">Time Slot</label>
										<div class="delivery_block">
											<div class="delivery_time_box">
												<div class="row col-xs-6 col-md-6 col-sm-6">
													<input type="text" name="time[0][days][delivery_time][0]" class="delivery_time form-control " value="" />
												</div>
												<div class="row col-xs-3 col-md-3 col-sm-3">
													<a data-id="1" data-value="0" class="add_delvierytime_slot"><i class="fa fa-plus-circle add_icon"></i></a>
												</div>
											</div>
										</div>
									</div>
								</div>	
							</div>
						</td>
						<td>
							<div class="col-xs-12 col-md-12 col-sm-12"><a data-id="" class="add_row"><i class="fa fa-plus"></i>Add more</a></div>
						</td>
					</tr>
				</tbody>
			</table>
		</form>
	</div>
</div>
<style>
	.datepicker_validate{
		margin-top: 10px;
		margin-bottom: 10px;
	}  
	.validate_text{
		margin-top: 10px;
	}
	#cut_off{
		width:100%;

	}
	#cut_off tr{
		height:10%;

	}
	.display_block{
		display:inline-block;
	}
</style>
<script text="text/javascript">
	var c_row = '';
	/* add delivery time slot */
	runremoverow();
	$(document).on('click','.add_delvierytime_slot', function () {	
		var row = $(this).attr('data-value');
		var id = $(this).attr('data-id');		
		var new_add = '<div class="delivery_block"><div class="delivery_time_box"><div class="row col-xs-6 col-md-6 col-sm-6"><input required type="text" class="delivery_time form-control" name="time['+row+'][days][delivery_time]['+id+']" ></input></div></div><div class="col-xs-3"><a class="removerow"><img src="{{ asset("/image/close-icon.png") }}"/></a></div></div>';
		$(new_add).insertBefore($(this).parent());
		id++;    
		$(this).attr('data-id',id);    
		runremoverow();
	}); 
	function runremoverow() {
		$(".removerow").on('click', function() {
			$(this).parent('div').parent('div').remove();
		});
		$(".times_count").keydown(function(e) {
			if (e.shiftKey || e.ctrlKey || e.altKey) {
				e.preventDefault();
			} else {
				var key = e.keyCode;
				if (!((key == 8) || (key == 9) || (key == 46) || (key >= 35 && key <= 40) || (key >= 48 && key <= 57) || (key >= 96 && key <= 105))) {
					e.preventDefault();
				}
			}
		});
	}
	/* end */

	/* add row */
	var k;
	var day = '';
	var days = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
	for (k = 0; k < days.length; k++) {
		day += '<option value="'+k+'">'+days[k]+'</option>';
	}


	var i;
	var hour_option = '';	
	var hours = 00;
	for(i = hours; i < 24; i++) {			
		var h_string = String(i);
		hour_option += '<option value="'+h_string.padStart(2,'0')+'">'+ h_string.padStart(2,'0') +'</option>';
	}

	var j;
	var minute_option = '';
	var minute = 00;
	for(j = minute; j <= 59; j++) {			
		var m_string = String(j);
		minute_option += '<option value="'+m_string.padStart(2,'0')+'">'+ m_string.padStart(2,'0') +'</option>';
	}
	removeMainrow();
	$(".add_row").on('click', function () {
		var count = $('.cutoff_block').length;
		if(c_row == '') {
			c_row = count;
		} else {
			c_row++;
		}

		var new_add_row = '<div class="cutoff_block"><div class="col-md-2"><select name="time['+c_row+'][days][day]" class="form-control">"'+day+'"</select></div><div class="col-md-2"><select name="time['+c_row+'][days][hour]" class="form-control cutoff_hour"><option selected="" value="">Select Hour</option>"'+hour_option+'"</select></div><div class="col-md-2"><select name="time['+c_row+'][days][minute]" class="form-control cutoff_minute"><option selected="" value="">Select Minute</option>"'+minute_option+'"</select></div><div class="col-md-2"><input type="text" name="time['+c_row+'][days][date_interval]" class="delivery_time form-control "></div><div class="col-md-4"><div class="delivery_block"><div class="delivery_time_box"><div class="row col-xs-6 col-md-6 col-sm-6"><input type="text" name="time['+c_row+'][days][delivery_time][0]" class="delivery_time form-control " value="" /></div><div class="row col-xs-3 col-md-3 col-sm-3"><a data-id="1" data-value="'+c_row+'" class="add_delvierytime_slot"><i class="fa fa-plus-circle add_icon"></i></a></div><div class="col-md-1 col-sm-1 col-xs-1"><a class="removemainrow"><i class="fa fa-minus-circle add_icon"></i></a></div></div></div></div></div>';
		$('.cutoff_box').append(new_add_row);        
		removeMainrow();
	}); 

	function removeMainrow() {
		$(".removemainrow").on('click', function() {			
			$(this).closest('.cutoff_block').remove();
		});
		$(".times_count").keydown(function(e) {
			if (e.shiftKey || e.ctrlKey || e.altKey) {
				e.preventDefault();
			} else {
				var key = e.keyCode;
				if (!((key == 8) || (key == 9) || (key == 46) || (key >= 35 && key <= 40) || (key >= 48 && key <= 57) || (key >= 96 && key <= 105))) {
					e.preventDefault();
				}
			}
		});
	}
	/* end */
</script>
@endsection