@yield('header')
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <title>{{ session('shop') }}</title>

        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">   

        <!--Import materialize.css-->
        <!--<link type="text/css" rel="stylesheet" href="{{ asset('css/materialize.min.css') }}"  media="screen,projection"/>-->

        <!-- Datepicker CSS -->
        <link rel="stylesheet" href="{{ asset('css/jquery-ui.css') }}">

        <!-- Select2 CSS -->
        <link rel="stylesheet" href="{{ asset('css/select2.min.css') }}">

        <!-- Notification -->
        <link rel="stylesheet" type="text/css" href="{{ asset('css/toastr.css') }}">

        <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css"> 

        <!-- magnificent popup CSS -->
        <link rel="stylesheet" href="{{ asset('css/magnific-popup.css') }}">

        <link rel="stylesheet" href="{{ asset('css/style.css') }}">   
    <link rel="stylesheet" href="{{ asset('css/admin/custom.css') }}"/>
        @yield('pageCss')
        <!-- jquery script -->
        <script src="{{ asset('js/kanaoddp_custom_jquery_3.3.1.js') }}"></script>

        <!-- Latest compiled JavaScript -->
        <script src="{{ asset('js/bootstrap.min.js') }}"></script>    

        <!-- JavaScript for datepicker -->
        <script src="{{ asset('js/jquery-ui.js') }}"></script>

        <!-- jquery datatable script -->
        <script src="{{ asset('js/datatable/jquery.dataTables.min.js') }}"></script>
        <script src="{{ asset('js/datatable/dataTables.bootstrap.min.js') }}"></script>
        <script src="{{ asset('js/datatable/buttons.html5.min.js') }}"></script>
        <script src="{{ asset('js/datatable/dataTables.buttons.min.js') }}"></script>
        <!--script src="{{ asset('js/datatable/date_range_plugin.js') }}"></script-->

        <!-- Select2 js -->
        <script src="{{ asset('js/select2.min.js') }}"></script>

        <!-- Notification -->
        <script src="{{ asset('js/toastr.min.js') }}"></script>

        <!-- Custom js -->
        <script src="{{ asset('js/javascript.js') }}"></script>
        <script src="{{ asset('js/app-bridge.js')}}"></script>
        <?php
            if(!empty(session('shop'))) {
              $shop = session('shop');
            } else {
              $shop = request()->get('shop');
            }
            
            $host = base64_encode($shop.'/admin');
            $apikey =  getenv('SHOPIFY_APP_API_KEY');
        ?>
        <script type="text/javascript">
            var appKey = "{{ env('SHOPIFY_APP_API_KEY') }}";
            var AppBridge = window['app-bridge'];
            var createApp = AppBridge.createApp;
            var actions = AppBridge.actions;
            let TitleBar = actions.TitleBar; 
            let Redirect = actions.Redirect;
            let Button = actions.Button;
            let AppLink = actions.AppLink;
            let Loading = actions.Loading;
            let NavigationMenu = actions.NavigationMenu;
            var host = '<?php echo $host ?>';
            var app = createApp({
                apiKey: appKey,
                host: host
            });
            console.log(appKey,host,app)

            var dashboard_url = '/koddpapp/public/dashboard?shop={{$shop}}';
            const dashboardLink = AppLink.create(app, {
              label: 'SETTINGS',
              destination: dashboard_url,
            });
            console.log(dashboardLink,'dashboardLink')
            manage_order_url = '/koddpapp/public/order?shop={{$shop}}';
            const ordersLink = AppLink.create(app, {
              label: 'MANAGE ORDER',
              destination: manage_order_url,
            });

            help_url = '/koddpapp/public/help?shop={{$shop}}';
            const helpLink = AppLink.create(app, {
              label: 'HELP',
              destination: help_url,
            });

            version_url = '/koddpapp/public/select-plans?shop={{$shop}}';
            const versionLink = AppLink.create(app, {
              label: 'CHANGE VERSION',
              destination: version_url,
            });

            region_add_url = '/koddpapp/public/region-add?shop={{$shop}}';
            const regionAddLink = AppLink.create(app, {
              label: 'Add',
              destination: region_add_url,
            });
            const region_url = '/koddpapp/public/region?shop={{$shop}}';
            const delivery_time_url = '/koddpapp/public/delivery-time?shop={{$shop}}';
            const product_setting_url = '/koddpapp/public/product-settings?shop={{$shop}}';
            const cutoff_setting_url = '/koddpapp/public/cut-off?shop={{$shop}}';
            const saveButton = Button.create(app, {label: 'Save'});
            const redirect = Redirect.create(app);
        </script>

        <!-- Js add by dipal (add general setting js in custom.js) -->
        <script src="{{ asset('js/custom.js') }}"></script>

    </head>

    <body>

        

        @yield('navigation')
        <?
        if (!isset($active)) {
            $active = "";
        }
        ?>
        <div class="header clearfix">

        </div>
<!--        <div class="text-right change_plans">
            <a href="select-plans" class="btn btn-success">Change Version</a>
        </div>-->
    <!-- <marquee class="marquee_code" onMouseOver="this.stop()" onMouseOut="this.start()">
        We have updated our app with a new feature called as <b>Delivery Date Pro on Thank You Page(i.e. Order Confirmation Page)</b>.In case, if Delivery information is not captured due to some reason, then this feature will help customers to select Delivery information again from Thank You Page. <b><a href="thank-you-page" target="_blank">Click here</a></b> to refer how you can implement this feature on your store.
    </marquee> -->
    @yield('content')

    <div class="modal fade" id="new_note">
        <div class="modal-dialog">          
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><b>Note</b></h4>
                </div>
                <div class="modal-body">
                    <p>Dear Customer, As this is a paid app and hundreds of customers are using it, So if you face any issue(s) on your store before uninstalling, Please contact support team (<a href="mailto:info@test.com">info@test.com</a>) or live chat at bottom right to resolve it ASAP.</p>
                </div>        
                <div class="modal-footer">          
                    <div class="datepicker_validate" id="modal_div">
                        <div>
                            <strong>Show me this again</strong>
                            <span class="onoff"><input name="modal_status" type="checkbox" checked id="dont_show_again"/>                           
                                <label for="dont_show_again"></label></span>
                        </div>      
                    </div>      
                </div>      
            </div>
        </div>
    </div>
    <div class="modal fade" id="notification">
        <div class="modal-dialog">          
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><b>Note</b></h4>
                </div>
                <div class="modal-body">
                    <p>Dear Customer, We have upgraded our app with new features, minor changes & bug resolution so if you face any issue(s) on your store , Please contact support team (<a href="mailto:info@test.com">info@test.com</a>) or live chat at bottom right to resolve it ASAP or Staff account access along with issue notes will help us to resolve your query soon.</p>
                </div>                       
            </div>
        </div>
    </div>
    <script>

        //For showing modal for those who are using app for the first time
        var one = new Date().getTime();
        var two = new Date('2018-05-05').getTime();
        /* @if(isset($new_install))
         { */
        var new_install = "{{ $new_install }}";
        if (new_install == "Y")
        {
        $('#new_note').modal('show');
        }
        else
        {
        if (one <= two)
        {
        $('#notification').modal('show');
        }
        }
        /* }
         @endif */
        /* For Pagination */
        $('#page_number').change(function() {
        this.form.submit();
        });
        $('#records_length').change(function() {
        this.form.submit();
        });
        @if (isset($page_number))

                var page_number = {{ $page_number }}
        var order_count = {{ $order_count }}
        var last_page = Math.ceil(order_count / {{ $records_per_page }});
        if (page_number >= last_page)
        {
        $(".next").hide();
        $(".last").hide();
        }
        else
        {
        $(".next").show();
        $(".last").show();
        }
        if (page_number <= 1)
        {
        $(".previous").hide();
        $(".first").hide();
        }
        else
        {
        $(".first").show();
        $(".previous").show();
        }
        $("input." + page_number).css('background', '#337ab7');
        $("input." + page_number).css('color', 'white');
        $(".next").click(function(){
        $(this).val(parseInt(page_number) + 1);
        });
        $(".previous").click(function(){
        if (page_number <= 1)
                $(this).val("1");
        else
                $(this).val(parseInt(page_number) - 1);
        });
        @endif
        /* For Pagination */

        //For showing success or error notification
        @if (Session::has('notification') || request()->has('notification'))
            var type = @if(request()->has('notification')) "{{ request()->get('notification')['alert-type'] }}"; @else "{{ Session::get('notification.alert-type', 'info') }}"; @endif
            toastr.options = {
            "closeButton": true,
                    "debug": false,
                    "newestOnTop": false,
                    "progressBar": false,
                    "positionClass": "toast-top-right",
                    "preventDuplicates": false,
                    "onclick": null,
                    "showDuration": "300",
                    "hideDuration": "1000",
                    "timeOut": "5000",
                    "extendedTimeOut": "1000",
                    "showEasing": "swing",
                    "hideEasing": "linear",
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
            }
            switch (type)
            {
            case 'info':
                    toastr.info("{{ Session::get('notification.message') ?? request()->get('notification')['message'] }}");
            break;
            case 'warning':
                    toastr.warning("{{ Session::get('notification.message') ?? request()->get('notification')['message'] }}");
            break;
            case 'success':
                    toastr.success("{{ Session::get('notification.message') ?? request()->get('notification')['message'] }}");
            break;
            case 'error':
                    toastr.error("{{ Session::get('notification.message') ?? request()->get('notification')['message'] }}");
            break;
            case 'options':
                    toastr.warning("{{ Session::get('notification.message') ?? request()->get('notification')['message'] }}");
            break;
            }
        @else

            @if (!empty($notification))
                var type = "{{ $notification['alert-type'] }}";
                toastr.options = {
                "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": false,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                }
                switch (type)
                {
                case 'info':
                        toastr.info("{{ $notification['message'] }}");
                break;
                case 'warning':
                        toastr.warning("{{ $notification['message'] }}");
                break;
                case 'success':
                        toastr.success("{{ $notification['message'] }}");
                break;
                case 'error':
                        toastr.error("{{ $notification['message'] }}");
                break;
                case 'options':
                        toastr.warning("{{ $notification['message'] }}");
                break;
                }
            @endif
        @endif
    </script>
   
</body>
<style>
    marquee.marquee_code {
        background: yellow;
        padding: 15px;
    }
</style>
@yield('pageScript')
</html>