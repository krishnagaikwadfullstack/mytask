<footer>
  <article class="help">
    <span></span>
    <p>Learn more about <a href="#">%screen%</a> at the <a href="#">%company%</a> Help Center.</p>
  </article>
</footer>