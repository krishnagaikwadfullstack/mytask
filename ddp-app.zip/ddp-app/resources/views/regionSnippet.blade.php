<?php
echo "<script src='https://use.fontawesome.com/releases/v5.11.2/js/all.js' data-auto-replace-svg='nest'></script>
{% assign flag = 0 %}
{% for item in cart.items %}
	{% if item.product.tags contains 'no-delivery-date' %}   
		
	{% else %}
        {% assign flag = 1 %}
    {% endif %}              	
{% endfor %}";
?>
<input type="hidden" id="ztpl-current-date" value="<?php echo "{{ 'now' | date: '%d' }}";?>" />
<input type="hidden" id="ztpl-store-hour" value="<?php echo "{{ 'now' | date: '%H' }}";?>" />
<input type="hidden" id="ztpl-store-minute" value="<?php echo "{{ 'now' | date: '%M' }}";?>" />
<input type="hidden" id="ztpl-date-format-ddmmyy" value="<?php echo "{{ 'now' | date: '%d-%m-%Y' }}";?>" />
<input type="hidden" id="ztpl-date-format-yymmdd" value="<?php echo "{{ 'now' | date: '%Y-%m-%d' }}";?>" />
<?php echo "{{ '".getenv('APP_URL')."public/css/jquery-ui.css' | stylesheet_tag }}";?>
<?php echo "{% if flag == 1 %}";?>
<div id="datepicker_box" class="additional-css">
        <div class="regions" style="display:none">
                <label>Select Region</label>
                    <select id="region_id" name="attributes[Region]" readonly="readonly"></select><br/>
              </div>	
	<p class="date-box">
        
        <div class="main-box" style="display:none;">  <label class="title-label" style="float: left;padding-right:10px;"></label><div class="delivery-date-pro" style="font-weight:bold;"></div>
		<input class="delivery-date-pro-date" type="hidden" name="attributes[Delivery-Date]" />
	</p>
	<span id="selected_format"></span>
    <label id="delivery-time-label" style="display:none" ></label>
    <div class="custom_delivery"></div>
    <input type="hidden" name="attributes[Delivery-Time]" class="checked_time"/><div class='error_note' style='color:#f00;'></div>	</div>

	<span id="admin_notes"></span>
</div>
<?php echo "{% endif %}";?>
<?php echo "{{ '".getenv('APP_URL')."public/js/region_snippets.js' | script_tag }}";?>
<?php echo "{{ '".getenv('APP_URL')."public/css/kanaoddp-snippet.css' | stylesheet_tag }}";?>