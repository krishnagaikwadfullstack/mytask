<?php
use Carbon\Carbon;
$shop = session('shop') ?? request()->get('shop');
?>
@extends('header')
@section('content')
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
    const navigationMenu = NavigationMenu.create(app, {
      items: [regionAddLink, dashboardLink, ordersLink, helpLink],
      // active: settingsLink,
  });
    const titleBarOptions = {
        title: 'Region CutOff & Time Settings'
    }; 
    const myTitleBar = TitleBar.create(app, titleBarOptions);
    function generalSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, dashboard_url);
    }
    function regionSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, region_url);
    }
    function deliveryTimeSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, delivery_time_url);
    }
</script>
<div class="container formcolor">
	<ul class="nav nav-tabs dashboard_tabs">
        <li><a href="{{url('dashboard')}}?shop={{$shop}}" onclick="generalSettingPage()">General Settings</a></li>
        <li><a href="{{ url('region?shop='.$shop) }}" onclick="regionSettingPage()">Regions</a></li>
        <li class="active"><a href="{{ url('cut-off?shop='.$shop) }}" onclick="deliveryTimeSettingPage()">Cutoff & Time Settings</a></li>
    </ul>
    <h2 class="sub-heading">Region cutoff & time Settings</h2>    
    <div class="row">				
        <div class="col-md-12">			
            <input type="hidden" name="shop" value="{{ $shop }}" />
            <table id="region_settings" class="table table-striped table-bordered" cellspacing="0">
                 <thead>
                    <tr>
                        <th>No</th>
                        <th>Region</th>
                        <th>Edit</th>
                        <th>Delete</th>							
                    </tr>
                </thead>					                               
            </table>
        </div>
    </div>
</div>
<script>    
//data table with custom filter and feature   
$(document).ready(function(){          	 
	var table = $('#region_settings').DataTable({
		"processing": true,
        "serverSide": true,        
        "ajax": {
           "url"	 	: "region-data",
           "dataSrc"	: "data",
           'data': {
             shop: "{{ $shop }}",           		
            }
        }
    });
});
</script>
@endsection