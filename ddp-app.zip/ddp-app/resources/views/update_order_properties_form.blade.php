<div class="modal fade" id="ddt-update" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal-title">Update Delivery Date and Time for <span id="display_order_id"></span></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <form id="update-orders-details">
        {{ csrf_field() }}
        <input type="hidden" name="order_id" id="details_order_id">
        @if($shop != env('SHOW_REGIONS'))
        <input type="hidden" name="delivery_region_name" id="delivery_region_name" value="">
        @else
         <div class="form-group">
          <label for="new_delivery_date">Region</label>
          <select name="delivery_region_name" id="delivery_region_name" class="form-control"> 
            @foreach($regions as $region)
            @if($region->region != '')
            <option value="{{$region->region}}">{{$region->region}}</option>
            @endif
            @endforeach
          </select>
        </div> 
        @endif
        <input type="hidden" name="shop" value="{{$shop}}">
        <div class="form-group">
          <label for="new_delivery_date">Delivery Date</label>
          <input type="email" class="form-control" id="new_delivery_date"  name="new_delivery_date" placeholder="please select the delivery date">
          
        </div>
        <div class="form-group">
          <label for="new_delivery_time">Delivery Time</label>
          @php
          $settings_delivery_time = explode(",",$settings->delivery_time);
          @endphp

          <select class="form-control" id="new_delivery_time" placeholder="Enter the delivery time" name="new_delivery_time">
              <option value="">select time</option>
              @foreach($settings_delivery_time as $time)
                <option value="{{$time}}"> {{$time}} </option>
              @endforeach
          </select>
        </div>
      </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="update-details">update</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>