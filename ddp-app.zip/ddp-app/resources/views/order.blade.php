<?php
use Carbon\Carbon;
?>
@extends('header')
@section('content')
<?php
	$product_delivery_date = "";
	$product_delivery_time = "";
	$shop = session('shop') ?? request()->get('shop');
?>
<style type="text/css">
	button[disabled] {
    	cursor: no-drop;
	}
	#example_wrapper tr td .btn-primary{
		color: #fff;
	    border-color: #3f4eae;
	    background: #3f4eae;
	    max-height: 26px;
	    line-height: 10px;
	}
	#ddt-update .modal-header button{
		position: absolute;
	    right: 15px;
	    top: 15px;
	}
	#display_order_id{
		color: #3f4eae;
    	font-weight: 600;
	}
</style>
<script type="text/javascript">
    const navigationMenu = NavigationMenu.create(app, {
      items: [dashboardNewLink, helpLink, dashboardLink],
      // active: settingsLink,
    });
    const titleBarOptions = {
        title: 'MANAGE ORDER'+ "{{Config::get('constants.arr_version_name')[$app_version]}}"
    }; 
    const myTitleBar = TitleBar.create(app, titleBarOptions);
    function generalSettingPage() {
    	console.log(22)
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, dashboard_url);
    }
    function cutoffSettingPage() {
    	console.log(333)
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, cutoff_setting_url);
    }
    function deliveryTimeSettingPage() {
    	console.log(2298)
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, delivery_time_url);
    }
    function productPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, product_setting_url);
    }
    function helpPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, help_url);
    }
</script>
<?php	

$id = $shop_id;
$date_format = $settings['date_format'];

if($date_format == "mm/dd/yy")
{
    $arrange_format = "m/d/Y";
}
else if($date_format == "yy/mm/dd")
{
    $arrange_format = "Y/m/d";
}
else if($date_format == "dd/mm/yy")
{
    $arrange_format = "d/m/Y";
}
?>
@include('update_order_properties_form')
<div class="container formcolor">
<ul class="nav nav-tabs dashboard_tabs">
	<li><a href="{{url('dashboard')}}?shop={{$shop}}" onclick="generalSettingPage()">General Settings</a></li>
	@if($app_version == 3)
		<li><a href="{{url('cut-off')}}?shop={{$shop}}" onclick="cutoffSettingPage()">Cut Off Settings</a></li>
		<li><a href="{{url('delivery-time')}}?shop={{$shop}}" onclick="deliveryTimeSettingPage()">Delivery Time Settings</a></li>
	@endif
	@if($app_version == 4)
		<li><a href="{{url('product-settings')}}?shop={{$shop}}" onclick="productPage()">Product Settings</a></li>
	@endif
	<li><a href="{{url('help')}}?shop={{$shop}}" onclick="helpPage()">Help</a></li>	
</ul>
<h2 class="sub-heading">Manage Order</h2><div class="text-right fixed-top" style='padding-right:20px'><a class="todays_delivery" href="javascript:;" ><b>Today's Delivery:</b></a> {{ $todays_orders }} <a class="weeks_delivery" href="javascript:;"><b>This Week's Delivery:</b></a> {{ $weeks_orders }}</div>
    <form action="{{url('update_order')}}" name="update_order" method="post">
        {{ csrf_field() }}
        <input type="submit" name="updateorder" value="Run" class="btn btn-info margin_zero" style="display:none;"/>
    </form>   
    <div class="row">
		<div class="col-md-12">				
			<form action="{{url('order-demo')}}" method='post' id="exportValidate"><input type='hidden' name='_token' value='{{ csrf_token() }}'/>	
				<input type='hidden' value='{{ $arrange_format }}' name='current_format' />	
				<input type="hidden" name="shop" value="{{ $shop }}"/>			
				<table width="100%" class="inputs table table-striped table-bordered">
					<tbody>				
						<tr style="font-weight:900">						
							<td class="col-md-6">Start Delivery Date:<input style="width:50%" class='form-control start_delivery' name="min" id="min" type="text" autocomplete="off"/></td>
							<td class="col-md-6"><span class="onoff"><input type='checkbox' name='repeat' id="repeat_details" value='1'></input><label for="repeat_details"></label></span>Show order data for all products (Export Sheet)</td>	
						</tr>
						<tr>
							<td  style="font-weight:900" class="col-md-6">End Delivery Date:<input style="width:50%" class='form-control end_delivery' name="max" id="max" type="text" autocomplete="off"/></td>		
							<td><button type='reset' name='clear' value='' id='reset_button' class='btn btn-primary' onclick='reload()'>Reset</button>
							<button type='submit' id='export-csv' class='btn btn-primary'>Export to CSV</button><br><label style="font-size:13px; font-weight:normal">(Export Sheet will contain at max 250 orders)</label>
							</td>						
						</tr>
						<tr style="font-weight:400">
							<td colspan="2">
							<div class="row">
								<div class="col-sm-4"></div>
								<div class="col-sm-5">
									<select name="status" class="form-control status_filter">
										<option value="" Placeholder="">Select Status
										</option>
										<option value="paid">Paid
										</option>				
										<option value="partially_paid">Partially Paid
										</option>				
										<option value="partially_refunded">Partially Refunded
										</option>
										<option value="refunded">Refunded
										</option>
										<option value="pending">Pending
										</option>
										<option value="expired">Expired
										</option>
										<option value="voided">Voided
										</option>
										<option value="authorized">Authorized
										</option>
										<option value="Unfulfilled">Unfulfilled
										</option>
										<option value="fulfilled">Fulfilled
										</option>
										<option value="partial">Partially Fulfilled
										</option>
									</select>
								</div>				
							</div> 
							</td>
						</tr>
					</tbody>
				</table>
				<br>
			</form>	
			<table id="example" class="table table-bordered table-striped">
				<thead>
					<tr>
						<th>Order Number</th>
						<th>Name</th>
						@if($shop == "the-bunched-co.myshopify.com")	
							<th>Product Name (Qty, Delivery Date, Delivery Time)</th>
						@else
							@if($app_version == 4)
								<th>Product Name (Qty, Delivery Date, Delivery Time)</th>
							@else
								<th>Product Name (Qty)</th>
							@endif
						@endif
						@if($shop == "casinetto.myshopify.com" && $app_version == 3)
							<th>Region</th>
						@endif
	                    <th>Delivery Date</th> 
	                    <th>Delivery Time</th> 
						<th>Status</th>
						<th>Order Status</th>
						<th>Actions</th>      	
						@if($shop == "the-bunched-co.myshopify.com")
							<th>Delivery Address</th>
						@endif
					</tr>
			  	</thead>
			</table>
		</div>
	</div>
<script>
	var dateFormat = @json($settings);
	var filter_start_date = filter_end_date = '';
	$('#ddt-update').modal({backdrop: 'static'}).modal('hide')
	$("#new_delivery_date").datepicker({ dateFormat: dateFormat.date_format})
	// Update delivery date and time using ajax call
	$("#update-details").on('click',function(){
		$.ajax({
			method:'post',
			url:"{{route('update_details')}}",
			data:$("#update-orders-details").serialize(),
			dataType:'json',
			success:function(data){
				$('#modal').modal('toggle');
				location.reload();
			}
		})
	})
	$(".pagination-button").on('click',function(){
		$("#page_info").val($(this).val());
		$("#order_form").submit();
	})
	// Submit export data form
  	$("#exportValidate").submit(function( event ) {
	    var start_date = $('.start_delivery').val();
	    var end_date = $('.end_delivery').val();
	    if(start_date == ""){ 
	        alert("Please select start delivery date.");
	        return false;
	    }
	    if(end_date == "") {
	        alert("Please select end delivery date.");
	        return false;
	    }
	});

    function reload(){
        $("#min").val("");
        $("#max").val("");
        var table = $('#example').DataTable();
        table.search('').columns().search('').draw();      
    }

    function convertdate(date) {
        var current_format = $('#date_format').val();
        var blank = "";
        if(current_format == "dd/mm/yy"){
            var day = date.substring(0, 2);
            var month = date.substring(3, 5);
            var year = date.substring(6, 10);
            return date.value = year + ',' + month + ',' + day;
        } else if(current_format == "mm/dd/yy") {
            var month = date.substring(0, 2);
            var day = date.substring(3, 5);
            var year = date.substring(6, 10);
            return date.value = year + ',' + month + ',' + day;
        } else if(current_format == "yy/mm/dd"){
            return date.split('/').join(',');
        } else{
            return blank;
        }
    }

    //data table with custom filter and feature   
    $(document).ready(function() {
    	$("body").on('click','.edit-delivery-details',function(){
    		alert(44);
    		var id = $(this).attr('data-id');
    		var order_name = $(this).attr('data-order-number');
    		var previous_delivery_date = $(this).attr('data-delivery-date');
    		var previous_delivery_time = $.trim($(this).attr('data-delivery-time'));
    		var previous_delivery_region = $.trim($(this).closest('tr').find('td.td_delivery_region').text())
    		$("#new_delivery_date").val(previous_delivery_date)
    		$("#new_delivery_time").val(previous_delivery_time)
    		$("#delivery_region_name").val(previous_delivery_region)
    		$("#display_order_id").html("#"+order_name);
    		$('#details_order_id').val(id);
    	});
	    //for data table
		var todays_date = "{{ $todays_date }}";
		var start_of_week = "{{ $start_of_week }}";
		var end_of_week = "{{ $end_of_week }}";	
		var arrange_format	='<?php echo $arrange_format ?>';
		if(arrange_format == "d/m/Y") {
			var day = todays_date.substring(0, 2);
			var month = todays_date.substring(3, 5);
			var year = todays_date.substring(6, 10);		
			todays_date=day + '/' + month + '/' + year;	
		}
		if(arrange_format == "m/d/Y") {
			var month = todays_date.substring(3, 5);
			var day = todays_date.substring(0, 2);
			var year = todays_date.substring(6, 10);		
			todays_date= month + '/' + day + '/' + year;	
		}
		if(arrange_format == "Y/m/d") {
			var month = todays_date.substring(5, 7);
			var day = todays_date.substring(8, 10);
			var year = todays_date.substring(0, 4);		
			//todays_date = year + '/' + month + '/' + day;
			parts_date=todays_date.split('-');
			todays_date=parts_date[2] + '/' + parts_date[1] + '/' + parts_date[0];
		}
		
		$.fn.dataTable.ext.search.push(
			function (settings, data, dataIndex) {
			console.log('draw search run');
				var min = $('#min').datepicker("getDate");
				var max = $('#max').datepicker("getDate");
				var arrange_format	='<?php echo $arrange_format ?>';
				console.log(min,max,arrange_format)
				var parts,new_date;	
				if(arrange_format == "d/m/Y") {
					parts_date=data[16].split('/');
					new_date=parts_date[2] + '/' + parts_date[1] + '/' + parts_date[0];	
				}
				if(arrange_format == "m/d/Y") {
					parts_date=data[16].split('/');
					new_date=parts_date[2] + '/' + parts_date[0] + '/' + parts_date[1];	
				}
				if(arrange_format == "Y/m/d") {
					parts_date=data[16].split('/');
					new_date=parts_date[0] + '/' + parts_date[1] + '/' + parts_date[2];	
				}
				var startDate = new Date(new_date);
				if (min == null && max == null) { return true; }
				if (min == null && startDate <= max) { return true;}
				if(max == null && startDate >= min) {return true;}
				console.log('condition',(startDate <= max && startDate >= min),data)
				if (startDate <= max && startDate >= min) { return true; }
				return false;
			}
		);

		var table = $('#example').DataTable({		
			info:false,
			order: [ 0, "desc" ],
			pageLength: "{{$records_per_page}}",
			paging:   true,
		    processing: true,
		    serverSide: true,
		    ajax: {
		        url: "{{ url('order') }}",
		        type: 'GET',
		        data: function ( d ) {
			        d.status_filter = $('select.status_filter option:selected').val();
			        d.shop = "{{$shop}}";
			        d.csrf_token = "{{csrf_token()}}";
			        d.start_date = $('.start_delivery').val();
		            d.end_date = $('.end_delivery').val();
			    }
		    },
		    columns: [
		        { data: 'order_number', name: 'order_number' },
		        { data: 'name', name: 'name' },
		        { data: 'product_name', name: 'product_name' },
		        { data: 'delivery_date', name: 'delivery_date' },
		        { data: 'delivery_time', name: 'delivery_time' },
		        { data: 'status', name: 'status' },
		        { data: 'order_status', name: 'order_status' },
		        { data: 'action', name: 'action' },
		    ]
		});

		$("#min").datepicker({ onSelect: function () { 
			table.draw();
			filter_start_date = $('.start_delivery').val();
			console.log('min select')
			}, changeMonth: true, changeYear: true,dateFormat: '<?php echo $date_format; ?>'
		});
		$("#max").datepicker({ onSelect: function (e) {
			filter_end_date = $('.end_delivery').val();
			console.log('max select')
			var start_date = $('.start_delivery').val();
	    	var end_date = $('.end_delivery').val();
	    	var date1 = new Date(start_date);
			var date2 = new Date(end_date);
			var Difference_In_Time = date2.getTime() - date1.getTime();
			var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
			if(parseInt(Difference_In_Days) < 0){
				$("#max").val("");
				alert("Select date higher than start date");
				return false;
			}else{
		 		table.draw(); 
				console.log('draw max else')
			}
		}, changeMonth: true, changeYear: true,dateFormat: '<?php echo $date_format; ?>' });
		
		$('body').on('change','#min, #max' ,function () {
			console.log('min max')
			table.draw();
		});

		$('.todays_delivery').click(function () {
			$("#min").val(todays_date);
			$("#max").val(todays_date);
			table.draw();
		});	
		$('.weeks_delivery').click(function () {
			$("#min").val(start_of_week);
			$("#max").val(end_of_week);
			table.draw();
		});
	        
	    var custom_div = "";
	    $("#example_filter").append(custom_div);
		$("#example_filter").css("float","right");
	         	
		$("#display_field").select2({
	        placeholder: "Select a Field"
	    });

		// Status Filter search functionality
		$("select.status_filter").on('change', function(){
			if(this.value){
				// var searchTerm = this.value.toLowerCase(),
				// regex = searchTerm;
				// table.search(regex, true, false).draw();
				table.draw();
			}else{
				table.search('').draw();
				table.draw();
			}
		});
	});
</script>
@endsection