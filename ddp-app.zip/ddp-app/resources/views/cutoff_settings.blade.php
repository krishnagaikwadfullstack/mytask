@extends('header')
@section('content')
@php
	if(!empty(session('shop'))) {
		$shop = session('shop');
	} else {
		$shop = $_REQUEST['shop'] ?? request()->get('shop');
	}

	$cutoff_status = $config['cuttoff_status'];
	$disabled_status = ($cutoff_status == 0) ? "disabled" : "";
	$i = 0;
	$days = array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
@endphp

<script type="text/javascript">
    const navigationMenu = NavigationMenu.create(app, {
      items: [helpLink, ordersLink, dashboardLink],
      // active: settingsLink,
    });
    //Do something with the click action of save button
    saveButton.subscribe(Button.Action.CLICK, (data) => {
        var checked_global_cutoff_time = $("#global_cutoff_time").prop("checked");
		var flag = 0;

		$(".cutoff_hour").each(function(){
			if($(this).val() == "") {	
				flag= 1;
			}
		});

		$(".cutoff_minute").each(function(){
			if($(this).val() == "") {	
				flag= 1;
			}
		});

		if(checked_global_cutoff_time == false && flag == 1) {
			alert('Since you have not checked "Use Global Cut Off Time" to manage deliveries based on different cutoff time, Please make sure cutoff time value should not be empty for any day.');	
			event.preventDefault();
		} else {
			$("#cutoff_time_form").attr("data-shopify-app-submit","form_submit");
			$("#cutoff_time_form").submit();
		}
     });
  
    //Do something with the click action of preview button
    previewButton.subscribe(Button.Action.CLICK, (data) => {
		var checked_global_cutoff_time = $("#global_cutoff_time").prop("checked");
		var flag = 0;

		$(".cutoff_hour").each(function(){
			if($(this).val() == "") {	
				flag= 1;
			}
		});

		$(".cutoff_minute").each(function(){
			if($(this).val() == "") {	
				flag= 1;
			}
		});

		if(checked_global_cutoff_time == false && flag == 1) {
				alert('Since you have not checked "Use Global Cut Off Time" to manage deliveries based on different cutoff time, Please make sure cutoff time value should not be empty for any day.');	
				event.preventDefault();
		} else {
			deliveryDatePro();
		    setTimeout(function() {
		    	$('#exampleModal').modal('show')
			}, 2000);
		}
    });

    const moreActions = ButtonGroup.create(app, {
      label: 'Save Or Preview',
      buttons: [saveButton, previewButton],
    });

    const titleBarOptions = {
        title: 'CUT OFF SETTINGS',
        buttons: {
            secondary: [moreActions],
        },
    };
    const myTitleBar = TitleBar.create(app, titleBarOptions);

    function generalSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, dashboard_url);
    }
    function cutoffSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, cutoff_setting_url);
    }
    function deliveryTimeSettingPage() {
        // Go to {appOrigin}/url
        redirect.dispatch(Redirect.Action.APP, delivery_time_url);
    }
    function validate(event) {
		var checked_global_cutoff_time = $("#global_cutoff_time").prop("checked");
		var flag = 0;

		$(".cutoff_hour").each(function(){
			if($(this).val() == "") {
				flag= 1;
			}
		});
		$(".cutoff_minute").each(function(){
			if($(this).val() == "") {
				flag= 1;
			}
		});
		if(checked_global_cutoff_time == false && flag == 1) {
			alert('Since you have not checked "Use Global Cut Off Time" to manage deliveries based on different cutoff time, Please make sure cutoff time value should not be empty for any day.');	
			event.preventDefault();
		} else {
			$("#cutoff_time_form").attr("data-shopify-app-submit","form_submit");	
		}
	}
</script>
<div class="container formcolor cutoff_block">      
	<ul class="nav nav-tabs dashboard_tabs">
		<li><a href="{{ url('dashboard?shop='.$shop) }}" onclick="generalSettingPage()">General Settings</a></li>
		<li class="active"><a href="{{ url('cut-off?shop='.$shop) }}" onclick="cutoffSettingPage()">Cut Off Settings</a></li>
		<li><a href="{{ url('delivery-time?shop='.$shop) }}" onclick="deliveryTimeSettingPage()">Delivery Time Settings</a></li>
	</ul>
	<div class="row formcolor_row">	
		<h2 class="sub-heading">Cut Off Settings</h2>		
		<form method="post" id="cutoff_time_form" action="{{ url('save-cut-off') }}" data-shopify-app-submit="form_submit" class="cutoff_div">
			<input type="hidden" name="shop" value="{{$shop}}">
			{{ csrf_field() }}
			<div class="text-right">
				<div class=" cutoff_time_checkbox">
					<span class="onoff">
						<input type="checkbox" @if($global_flag==1) checked @endif name="global_cutoff_time" id="global_cutoff_time" value="1"/>
						<label for="global_cutoff_time"></label>
					</span>
					<strong>Use Global Cut Off Time</strong>
					<div class="note">
						<strong>Note:</strong> If You Enable Global Cut Off Time, Then Cut Off Time(In General Settings) Will Be Global For All Days
					</div>
				</div>
				<span class="note">
					@if($cutoff_status == 0)
						<div class="note"><b>{{ "Cut Off is Inactive, If you want to Edit, Please Go to General Settings and Active Cut Off." }} </b></div>
					@endif
				</span>
			</div>
			<table id="cut_off" class="table table-bordered delivery_time_table cutoff_table" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th class="col-md-4"><span class="col-md-12">Day</span></th>	
						<th class="col-md-8"><span class="col-md-12">Cut Off Time</span></th>
					</tr>
				</thead>
				<tbody>					
					@foreach($days as $delivery_day)
						@if(!empty($settings[$i]))
							@php
								$day = $settings[$i];
								$hour = $day->cutoff_hour;
								$minute = $day->cutoff_minute;
							@endphp
						@endif
						<tr>
							<td class="col-md-4">
								<span class="col-md-12">{{ $delivery_day }}</span>
							</td>
							<td class="col-md-8">
							<div class="" >
								<div class="display_block col-md-3" >
									<label for="hours">Hour:   </label>
									<select {{ $disabled_status }} name="hour[]" class="form-control cutoff_hour" data-day="{{$i}}">
									<option selected value="">Select Hour</option>
										<?php for ($h = 00; $h < 24; $h++) { ?>
											<option @if(isset($hour) && str_pad($h, 2, "0", STR_PAD_LEFT) == $hour) {{ "selected" }} @endif value="<?php echo str_pad($h, 2, "0", STR_PAD_LEFT); ?>"><?php echo str_pad($h, 2, "0", STR_PAD_LEFT); ?></option>
										<?php } ?>
									</select>
									<small class="text-danger hide">This field is required.</small>
								</div>
								<div class="display_block col-md-3" >
									<label for="minute">Minute:   </label>
									<select {{ $disabled_status }} name="minute[]" class="form-control cutoff_minute" data-day="{{$i}}">
									<option selected value="">Select Minute</option>
										<?php for ($m = 00; $m <= 59; $m++) { ?>
										<option @if(isset($minute) && str_pad($m, 2, "0", STR_PAD_LEFT) == $minute) {{ "selected" }} @endif value="<?php echo str_pad($m, 2, "0", STR_PAD_LEFT); ?>"><?php echo str_pad($m, 2, "0", STR_PAD_LEFT); ?></option>
										<?php } ?>
									</select>
									<small class="text-danger hide">This field is required.</small>
								</div>
							</div>
							</td>
						</tr>
						<?php $i++; ?>
					@endforeach
				</tbody>					
			</table>
		</form>
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Preview</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="datepicker_box" class="additional-css">    
            <p class="date-box">
                <label for="delivery-date-pro"></label>
                <input id="delivery-date-pro" type="text" name="attributes[Delivery-Date]" value="" readonly="readonly" disabled />
            </p>
            <span id="selected_format"></span>
            <label id="delivery-time-label" style="display:none" ></label>
            <select id="delivery-time" name="attributes[Delivery-Time]" style="display:none" readonly="readonly">
            <option id="time_option_label" value=""></option>
            </select>
            <span id="admin_notes"></span>
        </div>
        <script type="text/javascript">
        var shop_name = "{{ $shop }}";
        </script>
        <script src="{{ asset('js/admin_snippets.js') }}"></script>
        <link rel="stylesheet" href="{{ asset('css/kanaoddp-snippet.css') }}">
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        // Remove and Add required alert message
        $('select[name="hour[]"]').change(function(){
		    if ($(this).val() != "" && $(this).parent().next("div").find('.cutoff_minute option:selected').val() == ""){
		    	$(this).parent().next("div").find('.text-danger').removeClass('hide');
		    }else{
		    	$(this).next(".text-danger").addClass('hide');
                $(this).parent().next("div").find('.text-danger').addClass('hide');
            }
		});
		// Remove and Add required alert message
		$('select[name="minute[]"]').change(function(){
		    if ($(this).val() != "" && $(this).parent().prev("div").find('.cutoff_hour option:selected').val() == ""){
		    	$(this).parent().prev("div").find('.text-danger').removeClass('hide');
		    }else{
		    	$(this).next(".text-danger").addClass('hide');
                $(this).parent().prev("div").find('.text-danger').addClass('hide');
            }
		});
		// add datepicker css
        $('body').on('click', '#delivery-date-pro', function(event) {
            $('.ui-datepicker').css({'z-index': 99999999999999, 'position': 'absolute'});
        });
	});
</script>
@endsection