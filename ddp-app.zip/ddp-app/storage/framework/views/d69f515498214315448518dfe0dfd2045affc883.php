<script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/unisharp/laravel-ckeditor/adapters/jquery.js')); ?>"></script>
<script>
    CKEDITOR.replace('textarea.ckeditor');
//    $('textarea.ckeditor').ckeditor();
</script><?php /**PATH E:\xampp\htdocs\ddp-app\resources\views/ck_editor.blade.php ENDPATH**/ ?>