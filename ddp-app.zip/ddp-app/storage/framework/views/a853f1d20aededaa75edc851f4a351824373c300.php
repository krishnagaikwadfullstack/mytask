<?php echo $__env->yieldContent('header'); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <meta name="description" content="">
        <meta name="author" content="">
        <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE" />
        <link rel="icon" href="../../favicon.ico">

        <title><?php echo e(session('shop')); ?></title>

        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">   

        <!--Import materialize.css-->
        <!--<link type="text/css" rel="stylesheet" href="<?php echo e(asset('css/materialize.min.css')); ?>"  media="screen,projection"/>-->

        <!-- Datepicker CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">

        <!-- Select2 CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/select2.min.css')); ?>">

        <!-- Notification -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/toastr.css')); ?>">

        <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css"> 

        <!-- magnificent popup CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">

        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">   
         <?php echo $__env->yieldContent('pageCss'); ?>
        <!-- jquery script -->
        <script src="<?php echo e(asset('js/kanaoddp_custom_jquery_3.3.1.js')); ?>"></script>

        <!-- Latest compiled JavaScript -->
        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>    

        <!-- JavaScript for datepicker -->
        <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>

        <!-- jquery datatable script -->
        <script src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/datatable/dataTables.bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/datatable/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/datatable/dataTables.buttons.min.js')); ?>"></script>
        <!--script src="<?php echo e(asset('js/datatable/date_range_plugin.js')); ?>"></script-->

        <!-- Select2 js -->
        <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>

        <!-- Notification -->
        <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>

        <!-- Magnificent popup js -->
        <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>    

        <!-- Custom js -->
        <script src="<?php echo e(asset('js/javascript.js')); ?>"></script>
        <script src="<?php echo e(asset('js/app-bridge.js')); ?>"></script>
        <!-- HumCommerce Tracking code for Shopify Apps -->
        <script type="text/javascript">
          var _ha = window._ha || [];
            _ha.push(['trackPageView']);
          _ha.push(['enableLinkTracking']);
          (function() {
            var u="https://app.humcommerce.com/";
            _ha.push(['setTrackerUrl', u+'humdash.php']);
            _ha.push(['setSiteId', '2049']);
            var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
            g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'sites/h-2049.js'; s.parentNode.insertBefore(g,s);
          })();
        </script>
        <!-- End of HumCommerce Code -->

        <!-- Js add by dipal (add general setting js in custom.js) -->
        <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
        <?php
            if(!empty(session('shop'))) {
              $shop = session('shop');
            } else {
              $shop = request()->get('shop');
            }
            
            $host = base64_encode($shop.'/admin');
            $apikey =  getenv('SHOPIFY_APP_API_KEY');
        ?>
        <script type="text/javascript">
            var appKey = "<?php echo e(env('SHOPIFY_APP_API_KEY')); ?>";
            var AppBridge = window['app-bridge'];
            var createApp = AppBridge.createApp;
            var actions = AppBridge.actions;
            let TitleBar = actions.TitleBar; 
            let Redirect = actions.Redirect;
            let Button = actions.Button;
            let ButtonGroup = actions.ButtonGroup;
            let AppLink = actions.AppLink;
            let Loading = actions.Loading;
            let NavigationMenu = actions.NavigationMenu;

            var host = '<?php echo $host ?>';
            var app = createApp({
                apiKey: appKey,
                host: host
            });
            const dashboard_url = '/DeliveryDateProAppBridge/public/dashboard?shop=<?php echo e($shop); ?>';
            const dashboardLink = AppLink.create(app, {
              label: 'SETTINGS',
              destination: dashboard_url,
            });

            const manage_order_url = '/DeliveryDateProAppBridge/public/order?shop=<?php echo e($shop); ?>';
            const ordersLink = AppLink.create(app, {
              label: 'MANAGE ORDER',
              destination: manage_order_url,
            });

            const help_url = '/DeliveryDateProAppBridge/public/help?shop=<?php echo e($shop); ?>';
            const helpLink = AppLink.create(app, {
              label: 'HELP',
              destination: help_url,
            });

            const version_url = '/DeliveryDateProAppBridge/public/select-plans?shop=<?php echo e($shop); ?>';
            const versionLink = AppLink.create(app, {
              label: 'CHANGE VERSION',
              destination: version_url,
            });

            const region_add_url = '/DeliveryDateProAppBridge/public/region-add?shop=<?php echo e($shop); ?>';
            const regionAddLink = AppLink.create(app, {
              label: 'Add',
              destination: region_add_url,
            });
            const region_url = '/DeliveryDateProAppBridge/public/region?shop=<?php echo e($shop); ?>';
            const delivery_time_url = '/DeliveryDateProAppBridge/public/delivery-time?shop=<?php echo e($shop); ?>';
            const product_setting_url = '/DeliveryDateProAppBridge/public/product-settings?shop=<?php echo e($shop); ?>';
            const cutoff_setting_url = '/DeliveryDateProAppBridge/public/cut-off?shop=<?php echo e($shop); ?>';
            const saveButton = Button.create(app, {label: 'Save'});
            const previewButton = Button.create(app, {label: 'Preview'});
            const createCharge = Button.create(app, {label: 'Create New Charge'});
            const redirect = Redirect.create(app);
        </script>
    </head>

    <body>

        <!-- <div class="review-div" 
            style="font-size: 15px;color: #000;
            font-weight: 500;
            background-color: #ffeb00;
            padding: 5px;
            margin: 0px;  width: 100%;
            margin: 10px auto;text-align: center;">
            Support Note: Due to Indian Diwali Festival, Our support team will be not be available untill 7th November, 2021. We will resume our support assistance from 8th November, 2021.
        </div>
 -->
        <?php echo $__env->yieldContent('navigation'); ?>
        <?
        if (!isset($active)) {
            $active = "";
        }
        ?>
        <div class="header clearfix">

        </div>
<!--        <div class="text-right change_plans">
            <a href="select-plans" class="btn btn-success">Change Version</a>
        </div>-->
    <!-- <marquee class="marquee_code" onMouseOver="this.stop()" onMouseOut="this.start()">
        We have updated our app with a new feature called as <b>Delivery Date Pro on Thank You Page(i.e. Order Confirmation Page)</b>.In case, if Delivery information is not captured due to some reason, then this feature will help customers to select Delivery information again from Thank You Page. <b><a href="thank-you-page" target="_blank">Click here</a></b> to refer how you can implement this feature on your store.
    </marquee> -->
     
    <?php echo $__env->yieldContent('content'); ?>

    <div class="modal fade" id="new_note">
        <div class="modal-dialog">          
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><b>Note</b></h4>
                </div>
                <div class="modal-body">
                    <p>Dear Customer, As this is a paid app and hundreds of customers are using it, So if you face any issue(s) on your store before uninstalling, Please contact support team <a href="mailto:info@test.com" target="_top"><button class="btn btn-info">info@test.com</button></a> or live chat at bottom right to resolve it ASAP.</p>
                </div>        
                <div class="modal-footer">			
                    <div class="datepicker_validate" id="modal_div">
                        <div>
                            <strong>Don't show me this again</strong>
                            <span class="onoff"><input name="modal_status" type="checkbox" checked id="dont_show_again"/>							
                                <label for="dont_show_again"></label></span>
                        </div>      
                    </div>      
                </div>      
            </div>
        </div>
    </div>
    <div class="modal fade" id="notification">
        <div class="modal-dialog">          
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><b>Note</b></h4>
                </div>
                <div class="modal-body">
                    <p>Dear Customer, We have upgraded our app with new features, minor changes & bug resolution so if you face any issue(s) on your store , Please contact support team (<a href="mailto:info@test.com">info@test.com</a>) or live chat at bottom right to resolve it ASAP or Staff account access along with issue notes will help us to resolve your query soon.</p>
                </div>        			     
            </div>
        </div>
    </div>
    <script>

        //For showing modal for those who are using app for the first time
        var one = new Date().getTime();
        var two = new Date('2018-05-05').getTime();
        /* <?php if(isset($new_install)): ?>
         { */
        var new_install = "<?php echo e($new_install); ?>";
        if (new_install == "Y")
        {
        $('#new_note').modal('show');
        }
        else
        {
        if (one <= two)
        {
        $('#notification').modal('show');
        }
        }
        /* }
         <?php endif; ?> */
        /* For Pagination */
        $('#page_number').change(function() {
        this.form.submit();
        });
        $('#records_length').change(function() {
        this.form.submit();
        });
        <?php if(isset($page_number)): ?>

                var page_number = <?php echo e($page_number); ?>

        var order_count = <?php echo e($order_count); ?>

        var last_page = Math.ceil(order_count / <?php echo e($records_per_page); ?>);
        if (page_number >= last_page)
        {
        $(".next").hide();
        $(".last").hide();
        }
        else
        {
        $(".next").show();
        $(".last").show();
        }
        if (page_number <= 1)
        {
        $(".previous").hide();
        $(".first").hide();
        }
        else
        {
        $(".first").show();
        $(".previous").show();
        }
        $("input." + page_number).css('background', '#337ab7');
        $("input." + page_number).css('color', 'white');
        $(".next").click(function(){
        $(this).val(parseInt(page_number) + 1);
        });
        $(".previous").click(function(){
        if (page_number <= 1)
                $(this).val("1");
        else
                $(this).val(parseInt(page_number) - 1);
        });
        <?php endif; ?>
        /* For Pagination */

        //For showing success or error notification
        <?php if(Session::has('notification') || request()->has('notification')): ?>
            var type = <?php if(request()->has('notification')): ?> "<?php echo e(request()->get('notification')['alert-type']); ?>"; <?php else: ?> "<?php echo e(Session::get('notification.alert-type', 'info')); ?>"; <?php endif; ?>
            toastr.options = {
            "closeButton": true,
                    "debug": false,
                    "newestOnTop": false,
                    "progressBar": false,
                    "positionClass": "toast-top-right",
                    "preventDuplicates": false,
                    "onclick": null,
                    "showDuration": "300",
                    "hideDuration": "1000",
                    "timeOut": "5000",
                    "extendedTimeOut": "1000",
                    "showEasing": "swing",
                    "hideEasing": "linear",
                    "showMethod": "fadeIn",
                    "hideMethod": "fadeOut"
            }
            switch (type)
            {
            case 'info':
                    toastr.info("<?php echo e(Session::get('notification.message') ?? request()->get('notification')['message']); ?>");
            break;
            case 'warning':
                    toastr.warning("<?php echo e(Session::get('notification.message') ?? request()->get('notification')['message']); ?>");
            break;
            case 'success':
                    toastr.success("<?php echo e(Session::get('notification.message') ?? request()->get('notification')['message']); ?>");
            break;
            case 'error':
                    toastr.error("<?php echo e(Session::get('notification.message') ?? request()->get('notification')['message']); ?>");
            break;
            case 'options':
                    toastr.warning("<?php echo e(Session::get('notification.message') ?? request()->get('notification')['message']); ?>");
            break;
            }
        <?php else: ?>
            <?php if(!empty($notification)): ?>
                var type = "<?php echo e($notification['alert-type']); ?>";
                toastr.options = {
                "closeButton": true,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": false,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                }
                switch (type)
                {
                case 'info':
                        toastr.info("<?php echo e($notification['message']); ?>");
                break;
                case 'warning':
                        toastr.warning("<?php echo e($notification['message']); ?>");
                break;
                case 'success':
                        toastr.success("<?php echo e($notification['message']); ?>");
                break;
                case 'error':
                        toastr.error("<?php echo e($notification['message']); ?>");
                break;
                case 'options':
                        toastr.warning("<?php echo e($notification['message']); ?>");
                break;
                }
            <?php endif; ?>
        <?php endif; ?>
    </script>
    <script>
                $('.info_css').magnificPopup({
        type: 'image'
        });</script>

    <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API = Tawk_API || {}, Tawk_LoadStart = new Date();
        (function(){
        var s1 = document.createElement("script"), s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/5a2e20e35d3202175d9b7782/default';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
        })();
    </script>
    <!--End of Tawk.to Script-->
</body>
<style>
    marquee.marquee_code {
        background: yellow;
        padding: 15px;
    }
</style>
<script>
 $(document).ready(function () {
$("#dont_show_again").change(function () {
    var checked = $(this).prop("checked");
    var shop_name = "<?php echo e($shop); ?>";
    if (!checked)
    {
        $.ajax({
            url: 'update-modal-status',
            data: {shop_name: shop_name},
            async: false,
            type: 'POST',
            success: function (result)
            {

            }
        });
    }
});
});
</script>
<?php echo $__env->yieldContent('pageScript'); ?>
</html><?php /**PATH E:\xampp\htdocs\ddp-app\resources\views/header.blade.php ENDPATH**/ ?>