<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Config;

class JavaScriptErrorOccurredMail extends Mailable
{
    use Queueable, SerializesModels;
    protected $arrEmailData;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($arrEmailData)
    {
        $this->arrEmailData = $arrEmailData;        
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $strSubject = "Zestard Technologies | Type ".$this->arrEmailData['type']." Error in Store ".$this->arrEmailData['store'];
        $logo = config('app.url') . 'public/image/zestard-logo.png';
        $blade_name = 'emails.jquery_error_occurred_mail';
        $text = '';
        ## Get error type wise msg.
        if ($this->arrEmailData['type'] == 1)
            $text = "jQuery Not Loaded in Store ".$this->arrEmailData['store'];
        if ($this->arrEmailData['type'] == 2)
            $text = "jQuery UI Not Loaded in Store ".$this->arrEmailData['store'];
        if ($this->arrEmailData['type'] == 3)
            $text = "Datepicker Object Not Created in Store ".$this->arrEmailData['store'];

        return $this->subject($strSubject)
                    ->with([
                            'shopInfo' => $this->arrEmailData,
                            'logo' => $logo,
                            'text' => $text,
                        ])
                    ->view($blade_name);
    }
}
