<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class OrderProcessedAdminMail extends Mailable
{
    use Queueable, SerializesModels;
    protected $arrEmailData;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($arrEmailData)
    {
        $this->arrEmailData = $arrEmailData;        
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $strSubject = "Delivery Date Pro | Regarding Order #" .$this->arrEmailData['order_number'];
        $logo = config('app.url') . 'public/image/zestard-logo.png';
        $blade_name = 'emails.order_update_admin_mail';
        $text = 'Following is the Delivery information which was missed by customer on order confirmation page.';

        return $this->subject($strSubject)
                    ->with([
                            'orderInfo' => $this->arrEmailData,
                            'logo' => $logo,
                            'text' => $text,
                        ])
                    ->view($blade_name);
    }
}
