<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App;
use Exception;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\ShopModel;
use App\settings_log;
use App\BlockConfig;
use App\AppSettings;
use App\ProductSettings;
use App\DeliveryTimeSettings;
use App\CutoffSettings;
use App\VisitorsLog;
use App\Regions;
use App\RegionSettings;
use App\OrderDetails;
use App\Events\JavaScriptErrorOccurredEvent;
use App\Events\OrderProcessedEvent;

class dateController extends Controller {

    public function __construct() {
        $this->api_version = getenv('API_VERSION');
    }
    public function index(Request $request) {
        try {
            $shop = session('shop') ?? request()->get('shop');
            $notification = array();
            if (isset($_GET['notification']))
                $notification = $_GET['notification'];

            $app_settings = AppSettings::where('id', 1)->first();
            $shop_find = ShopModel::where('store_name', $shop)->first();
            $shop_id = $shop_find->id;
            $type_of_app = $shop_find->type_of_app;
            $app_version = $shop_find->app_version;
            $new_install = $shop_find->new_install;
            $upgrade_status = $shop_find->upgrade_status;
            $upgrade_modal_status = $shop_find->upgrade_modal_status;
            $install_date = $shop_find->payment_created_at;
            $date_time = explode("T", $install_date);
            $date = strtotime($date_time[0]);
            $date = strtotime("+7 day", $date);
            $modal_date = date('Y-m-d', $date);
            $todays_date = date('Y-m-d');

            if (strtotime($todays_date) > strtotime($modal_date)) {
                $new_install = 'N';
                $shop_find->new_install = 'N';
                $shop_find->save();
            }

            $config = [];
            $config = $shop_find->block_config;
            //For Basic Version, Return to Basic Dashboard
            if (($type_of_app == 1 ) && ($app_version == 1)) {
                return view('dashboard_basic', ['config' => $config, 'active' => 'date', 'new_install' => $new_install, 'notification' => $notification, 'shop' => $shop, 'upgrade_status' => $upgrade_status, 'upgrade_modal_status' => $upgrade_modal_status]);
            }

            //For Professional Version, Return to Professional Dashboard=
            if (($type_of_app == 2 ) && ($app_version == 2)) {
                return view('dashboard_pro', ['config' => $config, 'active' => 'date', 'new_install' => $new_install, 'notification' => $notification, 'shop' => $shop, 'upgrade_status' => $upgrade_status, 'upgrade_modal_status' => $upgrade_modal_status]);
            }

            //For EnterPrise Version, Return to EnterPrise Dashboard
            if ($type_of_app == 3 && $app_version == 3) {
                $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);
                $theme = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/', 'METHOD' => 'GET']); //'DATA' => ['role' => 'main']
                if ($shop == "casinetto.myshopify.com") {
                    foreach ($theme->themes as $themeData) {
                        if ($themeData->role == 'main') {
                            $theme_id = $themeData->id;
                            $content = ($config->region_settings == 1) ? View('regionSnippet')->render() : View('snippets')->render();
                            $view = (string) $content;
                            $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'snippets/delivery-date.liquid', 'value' => $view]]]);
                        }
                    }
                }
                return view('dashboard', ['config' => $config, 'active' => 'date', 'new_install' => $new_install, 'notification' => $notification, 'shop' => $shop, 'upgrade_status' => $upgrade_status, 'upgrade_modal_status' => $upgrade_modal_status]);
            }

            //For Ultimate Version, Return to Ultimate Dashboard
            if ($type_of_app == 4 && $app_version == 4) {
                return view('dashboard_product', ['config' => $config, 'active' => 'date', 'new_install' => $new_install, 'shop' => $shop, 'upgrade_status' => $upgrade_status, 'upgrade_modal_status' => $upgrade_modal_status]);
            }
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    public function check_data(Request $request) {
        try {
            $product_data = array();
            parse_str($request->input('data'), $product_data);
            if (isset($product_data['selected_product'])) {
                $selected_products_count = count($product_data['selected_product']);
                $selected_products = $product_data['selected_product'];
                $shop = session('shop') ?? request()->get('shop');
                $data = array();
                $data['global_product_delivery_time'] = isset($product_data['global_product_delivery_time']) ? 1 : 0;
                $data['global_product_blocked_dates'] = isset($product_data['global_product_blocked_dates']) ? 1 : 0;
                $data['global_product_blocked_days'] = isset($product_data['global_product_blocked_days']) ? 1 : 0;
                $data['global_product_pre_order'] = isset($product_data['global_product_pre_order']) ? 1 : 0;
                $data['global_product_date_interval'] = isset($product_data['global_product_date_interval']) ? 1 : 0;
                $data['global_product_cut_off'] = isset($product_data['global_product_cut_off']) ? 1 : 0;
                $user_settings = ShopModel::where('store_name', $shop)->first();
                if(!empty($user_settings)){
                    $user_settings->block_config()->update($data);
                }
                ## Product for loop
                for ($i = 0; $i < $selected_products_count; $i++) {
                    $data = array();
                    $product_id = $selected_products[$i];
                    $product_settings = ProductSettings::where(['shop_id' => $user_settings->id, 'product_id' => $product_id])->first();
                    if (isset($product_data['delivery_time_' . $product_id])) {
                        $data['delivery_times'] = $product_data['delivery_time_' . $product_id];
                    } else {
                        $data['delivery_times'] = $product_settings->delivery_times;
                    }

                    if (isset($product_data['blockeddate_' . $product_id]))
                        $data['blocked_dates'] = str_replace("/", "-", implode(",", $product_data['blockeddate_' . $product_id]));

                    if (isset($product_data['days_' . $product_id])) {
                        if (count($product_data['days_' . $product_id]) > 0) {
                            $data['blocked_days'] = implode(",", $product_data['days_' . $product_id]);
                        }
                    }

                    if (isset($product_data['allowed_month_' . $product_id]))
                        $data['pre_order_time'] = $product_data['allowed_month_' . $product_id];

                    if (isset($product_data['intervel_' . $product_id]))
                        $data['date_interval'] = $product_data['intervel_' . $product_id];

                    $data['cut_off_hours'] = empty($product_data['hour_' . $product_id]) ? 0 : $product_data['hour_' . $product_id];
                    $data['cut_off_minutes'] = empty($product_data['minute_' . $product_id]) ? 0 : $product_data['minute_' . $product_id];
                    $data['shop'] = $shop;
                    $data['product_id'] = $product_id;
                    $data = ProductSettings::updateOrCreate(['shop' => $shop, 'product_id' => $product_id],$data);
                }
            }   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    public function get_product_data(Request $request) {
        try {
            $product_settings = ProductSettings::select('product_id')->get();
            $product_settings_array = array();
            foreach ($product_settings as $product) {
                $product_id = $product->product_id;
                $product_settings_array[$product_id] = ProductSettings::where('product_id', $product_id)->first();
            }
            return json_encode($product_settings_array);   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    //For Updating General Settings
    public function update(Request $recuestdata, $id) {
        $shop = session('shop') ?? request()->get('shop');
        try {
            $shop_find = ShopModel::where('id', $id)->first();
            $data = $shop_find->block_config;
            $old_data = new settings_log;
            $old_format = $recuestdata['date_format'] ?? $data->date_format;
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {   //check ip from share internet
                $ip = $_SERVER['HTTP_CLIENT_IP'];
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {   //to check ip is pass from proxy
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            } else {
                $ip = $_SERVER['REMOTE_ADDR'];
            }

            //For Logging Old Data Before Storing New Changes
            $old_data->shop_id = $data->shop_id;
            $old_data->app_status = $data->app_status;
            $old_data->block_date = $data->block_date;
            $old_data->alloved_month = $data->alloved_month;
            $old_data->date_interval = $data->date_interval;
            $old_data->datepicker_display_on = $data->datepicker_display_on;
            $old_data->default_date_option = $data->default_date_option;
            $old_data->days = $data->days;
            $old_data->hours = $data->hours;
            $old_data->minute = $data->minute;
            $old_data->cuttoff_status = $data->cuttoff_status;
            $old_data->date_format = $data->date_format;
            $old_data->show_date_format = $data->show_date_format;
            $old_data->datepicker_label = $data->datepicker_label;
            $old_data->admin_order_note = $data->admin_order_note;
            $old_data->additional_css = $data->additional_css;
            $old_data->admin_note_status = $data->admin_note_status;
            $old_data->require_option = $data->require_option;
            $old_data->admin_time_status = $data->admin_time_status;
            $old_data->time_require_option = $data->time_require_option;
            $old_data->add_delivery_information = $data->add_delivery_information;
            $old_data->time_label = $data->time_label;
            $old_data->time_default_option_label = $data->time_default_option_label;
            $old_data->delivery_time = $data->delivery_time;
            $old_data->type_of_app = $shop_find->type_of_app;
            $old_data->app_version = $shop_find->app_version;
            $old_data->ip_address = $ip;
            $old_data->region_settings = $recuestdata->region_settings;
            $old_data->save();

            $dateConverted = array();
            if ($recuestdata['blockdate']) {
                if ($recuestdata['blockdate'][0] != "") {
                    foreach ($recuestdata['blockdate'] as $dateConvert) {
                        $dateConvert = trim($dateConvert);
                        if ($dateConvert != '') {
                            if ($old_format == "dd/mm/yy")
                                $dateConverted[] = str_replace("/", "-", $dateConvert);

                            if ($old_format == "mm/dd/yy") {
                                $date_array = explode("/", $dateConvert);
                                $dateConverted[] = $date_array[1] . "-" . $date_array[0] . "-" . $date_array[2];
                            }

                            if ($old_format == "yy/mm/dd") {
                                $date_array = explode("/", $dateConvert);
                                $dateConverted[] = $date_array[2] . "-" . $date_array[1] . "-" . $date_array[0];
                            }
                        }
                    }
                }
            }

            $data->block_date = json_encode($dateConverted);
            $data->alloved_month = $recuestdata['allowed_month'] ?? 0;
            $data->date_interval = $recuestdata['intervel'] ?? 0;
            $data->datepicker_display_on = $recuestdata['datepicker_display_on'] ?? 0;
            $data->default_date_option = $recuestdata['default_date'] ?? 0;
            
            $data->days = null;
            if ($recuestdata['days']) {
                $data->days = json_encode($recuestdata['days']);
                if (in_array("all_allow", $recuestdata['days'])) {
                    $data->days = null;
                }
            }
            $data->hours = $recuestdata['hours'];
            $data->minute = $recuestdata['minute'];
            $data->cuttoff_status = ($recuestdata['cuttoff_time'] == "cuttoff_on") ? 1 : 0 ;
            $data->app_status = $recuestdata['app_status'] ?? 'Deactive';
            $data->require_option = $recuestdata['require_option'] ?? 0;
            $data->show_datepicker_label = $recuestdata['show_datepicker_label'] ?? 0;
            $data->datepicker_label = $recuestdata['datepicker_label'];
            $data->show_date_format = $recuestdata['show_date_format'] ?? 0;
            $data->admin_time_status = $recuestdata['admin_time_status'] ?? 0;
            $data->date_format = $recuestdata['date_format'];
            $data->admin_order_note = $recuestdata['admin_order_note'];
            $data->additional_css = $recuestdata['additional_css'];
            $data->admin_note_status = $recuestdata['admin_note_status'] ?? 0;
            $data->time_require_option = $recuestdata['time_require_option'] ?? 0;
            $data->add_delivery_information = $recuestdata['add_delivery_information'] ?? 0;
            $data->region_settings = $recuestdata['region_settings'] ?? 0;
            $data->time_label = $recuestdata['time_label'];
            $data->time_default_option_label = $recuestdata['time_default_option_label'];
            $data->delivery_time = $recuestdata['delivery_time'];
            $data->datepicker_display_on = $recuestdata['datepicker_display_on'] ?? 0;
            $data->language_locale = $recuestdata['language_locale'];
            $data->date_error_message = $recuestdata['date_error_message'];
            $data->time_error_message = $recuestdata['time_error_message']; 
            $data->exclude_block_date_status = $recuestdata['exclude_block_date_status'] ?? 0;
            $data->save();

            $current_setting = ShopModel::where('id', $id)->first();
            if ($current_setting->new_install == 'Y')
                $current_setting->update(['new_install' => 'N']);

            $notification = array(
                'message' => 'Settings Saved Successfully.',
                'alert-type' => 'success'
            );
            return redirect()->route('dashboard', ['shop' => $shop_find->store_name, 'notification' => $notification])->with(['notification'=> $notification,'shop'=>$shop]);
        } catch (Exception $e) {
            $notification = array(
                'message' => 'Something went wrong.',
                'alert-type' => 'error'
            );
            return redirect()->route('dashboard', ['shop' => $shop, 'notification' => $notification])->with(['notification'=> $notification,'shop'=>$shop]);
        }
    }

    public function selectdate(Request $recuestdata) {
        try {
            $config = [];
            $shop = session('shop') ?? request()->get('shop');
            $shop_find = ShopModel::where('store_name', $shop)->first();
            ## Return zero if value shop not found
            if(is_null($shop_find))
                return 0;
            $shop_id = $shop_find->id;
            $global_cutoff_flag = $shop_find->global_cutoff_time_status;
            $global_deliverytime_flag = $shop_find->global_delivery_time_status;
            /*if($shop_find->app_version  == 4 && $shop_find->type_of_app == 4){
                $global_cutoff_flag = $shop_find->block_config->global_product_cut_off;
                $global_deliverytime_flag = $shop_find->block_config->global_product_delivery_time;
            }*/
            $config = BlockConfig::where('shop_id', $shop_id)->get();
            $config[0]['cutoff_global_status'] = $global_cutoff_flag;
            $config[0]['deliverytime_global_status'] = $global_deliverytime_flag;
            // code added by venkatesh in order to remove the previous dates from the blocked dates
            $block_date = json_decode($config[0]->block_date);
            if ($block_date != null) {
                foreach ($block_date as $index => $date) {
                    if (strtotime($date) < strtotime(date('Y-m-d')))
                        unset($block_date[$index]);
                }
                $config[0]->block_date = '["' . implode('","', $block_date) . '"]';
            }
            //code ended
            return $config;
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return $config;
        }
    }

    // For PetalJet
    public function getconfigandtype(Request $recuestdata) {
        try {
            $config = [];
            $shop = $recuestdata['shop'];
            $shop_find = ShopModel::where('store_name', $shop)->first();
            ## Return zero if value shop not found
            if(is_null($shop_find))
                return 0;

            $shop_id = $shop_find->id;
            $global_cutoff_flag = $shop_find->global_cutoff_time_status;
            $global_deliverytime_flag = $shop_find->global_delivery_time_status;
            $config = BlockConfig::where('shop_id', $shop_id)->get();
            $config[0]['cutoff_global_status'] = $global_cutoff_flag;
            $config[0]['deliverytime_global_status'] = $global_deliverytime_flag;
            $config[0]['app_version'] = $shop_find->app_version;
            $config[0]['type_of_app'] = $shop_find->type_of_app;
            return $config;   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return $config;
        }
    }

    // Get Delivery Time Dynamically Based on Day
    public function get_delivery_times(Request $request) {
        try {
            //For Getting Delivery Time Each Time Date is Changed
            $todays_date = "";
            if ($request->input('todays_date')) {
                if ($request->input('date_format') == "mm/dd/yy") {
                    $date = date("d-m-Y", strtotime($request->input('todays_date')));
                    $todays_date = str_replace("/", "-", $date);
                    $day = date("w", strtotime($todays_date));
                } else {
                    $todays_date = str_replace("/", "-", $request->input('todays_date'));
                    $day = date("w", strtotime($todays_date));
                }
            } else {
                //For Getting Delivery Time on Page Load
                $start_from = $request->input('start_from');
                $date = date("d-m-Y");
                $next_date = date('d-m-Y H:i:s', strtotime($date . $start_from . ' day'));
                $day = date("w", strtotime($next_date));
            }
            $options = "";
            $shop = $request->input('shop_name');
            $temp = ShopModel::where('store_name', $shop)->first();
            $flag = $temp->delivery_time_count_status;
            $app_version = $temp->app_version;
            $current_time = date("Y-m-d", time());
            $options_array = array();
            /* Code by dipal product global setting off for ultimate version */
            if ($app_version == 4 && $request->input('product_id') != '' && $request->input('global_time') == 0) {
                $product_id = $request->input('product_id');
                $result = ProductSettings::where(['shop' => $shop, 'status' => 1, 'product_id' => $product_id])->get();
                $count = $result->count();
                if ($count > 0) {
                    $options_array = array();
                    $delivery_times = $result[0]->delivery_times;
                    $delivery_times = explode(',', $delivery_times);
                    for ($i = 0; $i < count($delivery_times); $i++) {
                        array_push($options_array, $delivery_times[$i]);
                    }
                } else {
                    $options_array = 0;
                }
            } else if ($app_version == 4) {
                /* product global setting on for ultimate version */
                $result = $temp->block_config;
                if (!empty($result)) {
                    $delivery_times = $result->delivery_time;
                    $delivery_times = explode(',', $delivery_times);
                    for ($i = 0; $i < count($delivery_times); $i++) {
                        array_push($options_array, $delivery_times[$i]);
                    }
                } else {
                    $options_array = 0;
                }
            } else {
                $result =  DeliveryTimeSettings::where(['store' => $shop, 'day' => $day])->get();
                $count = $result->count();
                //If Delivery Time exists for selected day then Return Array of Delivery Time
                if ($count > 0) {
                    $counts = explode(",", $result[0]->count);
                    $delivery_times = json_decode($result[0]->delivery_times, true);
                    if ($flag == 1) {
                        for ($i = 0; $i < count($counts); $i++) {
                            if (intval($counts[$i]) > 0) {
                                if ($shop == "the-bunched-co.myshopify.com") {
                                    $order_count = 0;
                                    $orders = OrderDetails::where(['details' => $shop])->where('product_delivery_info', '!=', '')->get();
                                    $flag = 1;
                                    foreach ($orders as $order) {
                                        $temp = json_decode($order->product_delivery_info, true);
                                        if (empty($temp))
                                            $temp = array();

                                        if (count($temp) > 0) {
                                            foreach ($temp as $info) {
                                                if ($info[0] == str_replace("-", "/", $todays_date) && $info[1] == $delivery_times[$i]) {
                                                    $order_count++;
                                                }
                                            }
                                        }
                                    }
                                    if ($order_count >= intval($counts[$i])) {
                                        $flag = 0;
                                    }
                                    if ($flag == 1) {
                                        array_push($options_array, $delivery_times[$i]);
                                    }
                                } else {
                                    array_push($options_array, $delivery_times[$i]);
                                }
                            }
                        }
                    } else {
                        for ($i = 0; $i < count($counts); $i++) {
                            array_push($options_array, $delivery_times[$i]);
                        }
                    }
                } else {
                    //If there are no Delivery Time For Selected Day Return 0
                    $options_array = 0;
                }
            }
            return $options_array;   
        } catch (Exception $e) {
            return $e->getMessage();
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return [];
        }
    }

    // Get Cutoff Time Dynamically Based on Day
    public function get_cutoff_time(Request $request) {
        try {
            $day = $request->input('day');
            $shop = $request->input('shop_name');
            $result = CutoffSettings::where(['store' => $shop, 'cutoff_day' => $day])->first();
            return json_encode($result);   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return [];
        }
    }

    // Validating Cut Off Time
    public function check_cutoff_time(Request $request) {
        try {
            $start_from = $request->input('start_from') - 1;
            $date = $request->input('store_date');
            if($request->date_format == 'mm/dd/yy'){
                $res = explode("/", $request->input('delivery_date'));
                $cutoff_date = $res[1]."-".$res[0]."-".$res[2];
            }else{
                $cutoff_date = str_replace("/", "-", $request->input('delivery_date'));
                $cutoff_date = date('d-m-Y', strtotime($cutoff_date)); 
            }

            $date = strtotime("$start_from day", strtotime($date));
            $min_date = date('d-m-Y', $date);
            // Compare Next Available Date With Selected Date and Set Cut Off Flag
            $cutoff_timestamp = strtotime($cutoff_date);
            $mindate_timestamp = strtotime($min_date);
            $cutoff_flag = ($cutoff_timestamp == $mindate_timestamp) ? 1 : 0;
            $invalid_date = ($cutoff_timestamp < $mindate_timestamp) ? 1 : 0;
            $shop = $request->input('shop_name');
            $shop_find = ShopModel::where('store_name', $shop)->first();
            $shop_id = $shop_find->id;
            $day = date('w');
            ## Get cutoff settings data
            $cutoff_time_settings = CutoffSettings::where(['store' => $shop, 'cutoff_day' => $day])->get();
            $delivery_time_status = $shop_find->global_delivery_time_status;
            $cutoff_global_status = $shop_find->global_cutoff_time_status;
            $config = [];
            ## Get block config data
            $config = $shop_find->block_config;
            $cutoff_status = $config->cuttoff_status;
            $cutoff_hours = $config->hours;
            $cutoff_minute = $config->minute;
            $store_hour = $request->input('store_hour');
            $store_minute = $request->input('store_minute');
            //Check Cut Off Status
            if ($cutoff_status == 0)
                return 1;
            //Check Global Cut Off Status is Active, Then Compare with Global Cut Off time
            if ($invalid_date == 1)
                return 2;

            if ($cutoff_global_status == 1) {
                if (($store_hour) <= ($cutoff_hours)) {
                    if (($store_hour) < ($cutoff_hours)){
                        return 1;
                    }
                    if (($store_hour) == ($cutoff_hours) && ($store_minute) <= ($cutoff_minute)){
                        return 1;
                    }
                    // If User Selected Next Available Date After Cut Off Time Return 0 Else 1
                    $response_data = ($cutoff_flag == 1) ? 0 : 1;
                    return $response_data;
                }
                $response_data = ($cutoff_flag == 1) ? 0 : 1;
                return $response_data;
            }

            //If Global Cut Off Status if Inactive, Then Compare with Current Day's Cut Off time
            $cutoff_hours = $cutoff_time_settings[0]->cutoff_hour;
            $cutoff_minute = $cutoff_time_settings[0]->cutoff_minute;
            if (($store_hour) <= ($cutoff_hours)) {
                if (($store_hour) < ($cutoff_hours)) {
                    return 1;
                } 
                if (($store_hour) == ($cutoff_hours) && ($store_minute) <= ($cutoff_minute)) {
                    return 1;
                } 
                // If User Selected Next Available Date After Cut Off Time Return 0 Else 1
                $response_data = ($cutoff_flag == 1) ? 0 : 1;
                return $response_data;
            } 
            // If User Selected Next Available Date After Cut Off Time Return 0 Else 1
            $response_data = ($cutoff_flag == 1) ? 0 : 1;
            return $response_data;
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * function check_delivery_time
     * Validating Delivery Time Time
     */
    public function check_delivery_time(Request $request) {
        try {
            $shop = $request->input('shop_name');
            $shop_find = ShopModel::where('store_name', $shop)->first();
            $app_settings = AppSettings::where('id', 1)->first();
            $shop_id = $shop_find->id;
            ## Make ShopifyAPI object
            $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);
            $delivery_date = $request->input('delivery_date');
            $delivery_time = $request->input('delivery_time');
            $format = $request->input('date_format');
            //Converting Date According to Store's Date Format
            $date = str_replace("/", "-", $delivery_date);
            if ($format == "dd/mm/yy")
                $date = date("Y-m-d", strtotime($date));
            
            if ($format == "mm/dd/yy")
                $date = date("Y-m-d", strtotime($delivery_date));

            if ($format == "yy/mm/dd")
                $date = date("Y-m-d", strtotime($date));

            $day = date('w', strtotime($date));
            $result = DeliveryTimeSettings::where(['store' => $shop, 'day' => $day])->get();
            $delivery_times = json_decode($result[0]->delivery_times, true);
            $delivery_time_count = explode(",", $result[0]->count);
            $date_atrributes = '';
            $time_attributes = '';
            $index = array_search("$delivery_time", $delivery_times);
            if (isset($index)) {
                $count = $delivery_time_count[$index];
            }
            $counts = 0;
            $flag = 0;
            $delivery_time_settings = DeliveryTimeSettings::where(['store' => $shop, 'day' => $day])->get();
            $global_delivery_time_status = $shop_find->global_delivery_time_status;
            $delivery_time_count_status = $shop_find->delivery_time_count_status;
            $config = [];
            $config = $shop_find->block_config;
            //If Global Delivery Time Status Is Active Then No Need to Check Count Just Return 1
            if ($global_delivery_time_status == 1)
                return 1;
            //If Global Delivery Time Status is Inactive Then Check Count & If Count is Inactive Return 1
            if ($delivery_time_count_status == 0)
                return 1;
            //If Count is Active Check Count & If Order's Have Reached Count Limit, Then Return 0 Else 1
            if ($shop == "the-bunched-co.myshopify.com") {
                $counts = 0;
                $orders = OrderDetails::where(['details' => $shop])->where('product_delivery_info', '!=', '')->get();
                $flag = 1;
                foreach ($orders as $order) {
                    $temp = json_decode($order->product_delivery_info, true);
                    $temp = empty($temp) ? array() : $temp;
                    if (count($temp) > 0) {
                        foreach ($temp as $info) {
                            if ($info[0] == $delivery_date && $info[1] == $delivery_time) {
                                $counts++;
                            }
                        }
                    }
                }
                if ($counts >= intval($count)) {
                    $flag = 0;
                }
                return $flag;
            } else {
                if ($shop == "chill-and-shop.myshopify.com") {
                    $new_date = date("Y-d-m", strtotime($date));
                    $counts = OrderDetails::where(['delivery_date' => $new_date, 'delivery_time' => $delivery_time, 'details' => $shop])->count();
                    if ($count > 0) {
                        $response_data = (intval($counts) < intval($count)) ? 1 : 0;
                        return $response_data;
                    } 
                    return 1;
                } else {
                    $counts = OrderDetails::where(['delivery_date' => $date, 'delivery_time' => $delivery_time, 'details' => $shop])->count();
                    if (!empty($count)) {
                         $response_data = (intval($counts) < intval($count)) ? 1 : 0;
                        return $response_data;
                    }
                    return 1;
                }
            }   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * Function check_cart
     */
    public function check_cart(Request $request) {
        try {
            $shop = $request->input('shop_name');
            $shop_find = ShopModel::where('store_name', $shop)->first();
            $app_settings = AppSettings::where('id', 1)->first();
            $shop_id = $shop_find->id;

            ## Make ShopifyAPI object
            $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);
            
            $delivery_count = 0;
            $delivery_date = $request->input('delivery_date');
            $delivery_time = $request->input('delivery_time');
            $format = $request->input('date_format');
            $delivery_info_array = json_decode($request->input('delivery_info'), true);

            foreach ($delivery_info_array as $info) {
                if ($info[0] == $delivery_date && $info[1] == $delivery_time) {
                    $delivery_count++;
                }
            }
            //Converting Date According to Store's Date Format
            $date = str_replace("/", "-", $delivery_date);
            if ($format == "dd/mm/yy")
                $date = date("Y-m-d", strtotime($date));

            if ($format == "mm/dd/yy")
                $date = date("Y-m-d", strtotime($delivery_date));

            $day = date('w', strtotime($date));
            $result = DeliveryTimeSettings::where(['store' => $shop, 'day' => $day])->get();
            $delivery_times = json_decode($result[0]->delivery_times, true);
            $delivery_time_count = $result[0]->count;
            $date_atrributes = $time_attributes = '';
            $delivery_time_count = explode(",", $result[0]->count);
            $index = array_search("$delivery_time", $delivery_times);

            $count = 0;
            if (isset($index))
                $count = $delivery_time_count[$index];
            $flag = 1;
            $global_delivery_time_status = $shop_find->global_delivery_time_status;
            $delivery_time_count_status = $shop_find->delivery_time_count_status;
            $config = [];
            $config = $shop_find->block_config;
            //If Global Delivery Time Status Is Active Then No Need to Check Count Just Return 1
            if ($global_delivery_time_status == 1)
                return 1;
            //If Global Delivery Time Status is Inactive Then Check Count & If Count is Inactive Return 1
            if ($delivery_time_count_status == 0)
                return 1;
            //If Count is Active Check Count
            $response_data = ($delivery_count < $count) ? 1 : 0;
            return $response_data;
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * Function check_blocked_date
     * Check Blocked Dates
     */
    public function check_blocked_date(Request $request) {
        try {
            //Converting Date According to Store's Date Format
            if ($request->input('date_format') == "mm/dd/yy" || $request->input('date_format') == "yy/mm/dd")
                $date = date("d-m-Y", strtotime($request->input('delivery_date')));

            if ($request->input('date_format') == "dd/mm/yy")
                $date = str_replace("/", "-", $request->input('delivery_date'));

            $delivery_date = strtotime($date);
            $shop = $request->input('shop_name');
            $shop_find = ShopModel::where('store_name', $shop)->first();
            $shop_id = $shop_find->id;
            $config = $shop_find->block_config;
            $blocked_dates = json_decode($config->block_date, true);

            //If there are No Blocked Dates Simply Return 1 else Check in Blocked Dates
            if (count($blocked_dates) > 0) {
                $blocked_dates_timestamp = array();
                foreach ($blocked_dates as $date) {
                    array_push($blocked_dates_timestamp, strtotime($date));
                }
                $delivery_time_stamp = strtotime($delivery_date);
                // If Selected Delivery Date Exists in Blocked Dates Then Return False
                $response_data = (in_array($delivery_date, $blocked_dates_timestamp)) ? 0 : 1;
                return $response_data;
            }
            return 1;
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * Fundtion check_blocked_day
     * Check Blocked Days
     */
    public function check_blocked_day(Request $request) {
        try {
            $days = array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
            $json_response = array();
            $shop = $request->input('shop_name');
            $shop_find = ShopModel::where('store_name', $shop)->first();
            $shop_id = $shop_find->id;
            $config = $shop_find->block_config;

            //Converting Date According to Store's Date Format
            $todays_date = str_replace("/", "-", $request->input('todays_date'));
            if ($request->input('date_format') == "mm/dd/yy") {
                $date = date("d-m-Y", strtotime($request->input('todays_date')));
                $today = date("w", strtotime($date));
            }

            if ($request->input('date_format') == "dd/mm/yy" || $request->input('date_format') == "yy/mm/dd")
                $today = date("w", strtotime($todays_date));

            ## Check days available then set result
            if (empty($config->days)) {
                $json_response['result'] = 1;
            } else {
                $blocked_days = json_decode($config->days, true);
                $json_response['today'] = $days[$today];
                $json_response['result'] = (in_array($days[$today], $blocked_days)) ? 0 : 1;
            }
            return json_encode($json_response);   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return [];
        }
    }
    /**
     * Fundtion permission_denied
     * For Redirecting To Permission Denied Page if App Version is Less Than 3
     */
    public function permission_denied() {
        return view('permission_denied');
    }

    /**
     * Function get_type_and_version
     * For getting app type and version
     */
    public function get_type_and_version(Request $request) {
        try {
            $shop = $request->input('shop_name') ?? session('shop');
            $data = array();
            if ($shop == 'davidaustinroses-dev.myshopify.com') {
                $data_info = ShopModel::where('store_name', $shop)->first();
                $shop_id = $data_info->id;
                $data = ShopModel::with('block_config')->where('store_name', $shop)->whereHas('block_config', function($query) use ($shop_id) {
                            $query->where('shop_id', '=', $shop_id);
                        })->first();
            } else {
                $data = ShopModel::where('store_name', $shop)->get();
            }
            $response_data = (count($data) > 0) ? $data : 0; 
            return $response_data;   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * Function update_modal_status
     * For update modal status
     */
    public function update_modal_status(Request $request) {
        try {
            $shop = $request->input('shop_name');
            $shop_find = ShopModel::where('store_name', $shop)->update(['new_install'=>'N']);
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * Function update_upgrade_modal_status
     * For update upgrade modal status
     */
    public function update_upgrade_modal_status(Request $request) {
        try {
            $shop = $request->input('shop_name');
            $shop_find = ShopModel::where('store_name', $shop)->update(['upgrade_modal_status'=>'N']); 
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * Function acknowledge
     * For sending email according to issue(jQuery or Datepicker Object or jQuery UI Undefined)
     */
    public function acknowledge(Request $request) {
        try {
            $email_info_array['type'] = $request->input('type');
            $email_info_array['store'] = $request->input('shop_name');
            ## send email to admin
            event(new JavaScriptErrorOccurredEvent($email_info_array));
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * Function delivery_date_pro
     */
    public function delivery_date_pro(Request $request) {
        try {
            $order_number = $request->input('order_number');
            $customer_id = $request->input('customer_id');
            $delivery_date = $request->input('delivery_date');
            $delivery_time = $request->input('delivery_time');
            $shop = $request->input('shop_name');
            $shop_find = ShopModel::where('store_name', $shop)->first();
            $shop_id = $shop_find->id;
            $app_settings = AppSettings::where('id', 1)->first();
            $config_settings = $shop_find->block_config;
            ## Make ShopifyAPI instance $sh
            $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);

            ## Get store data
            $email_address = $shop_find->email;
            if ($delivery_date == "" || empty($delivery_date) || $delivery_date == "0000-00-00" || $delivery_date == "1969-12-31") {
                if ($config_settings->require_option == "1") {
                    //OrderDetails::where(['shop_id' => $shop_id , 'order_id' => $order_number ])->update(['delivery_info_status' => 1]);
                } else {

                }
            } else {
                $delivery_array = array();
                $delivery_array['Delivery-Date'] = $delivery_date;
                if (!empty($delivery_time)) {
                    $delivery_array['Delivery-Time'] = $delivery_time;
                }
                $order_data = [
                    "order" => [
                        "id" => $order_number,
                        "note_attributes" => $delivery_array
                    ]
                ];
                $delivery_date = date('Y-m-d', strtotime($delivery_date));
                ## Call api for update specific order data
                $sh->call(['URL' => '/admin/api/'.$this->api_version.'/orders/$order_number.json', 'METHOD' => 'PUT', 'DATA' => $order_data]);

                ## Send mail regarding order update
                $email_info_array['shop'] = $shop;
                $email_info_array['email'] = $email_address;
                $email_info_array['order_number'] = $order_number;
                $email_info_array['delivery_date'] = $delivery_date;
                $email_info_array['delivery_time'] = $delivery_time;
                $email_info_array['checkout_flag'] = 1;
                event(new OrderProcessedEvent($email_info_array));
                OrderDetails::where(['shop_id' => $shop_id, 'order_id' => $order_number])->update(['delivery_info_status' => 1, 'delivery_date' => $delivery_date, 'delivery_time' => $delivery_time]);
                return $shop_id;
            }   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return 0;
        }
    }

    /**
     * Function check_delivery_info
     */
    public function check_delivery_info(Request $request) {
        try {
            $order_number = $request->input('order_number');
            $order_detail = OrderDetails::where(['order_id' => $order_number])->first();
            $response_data = ($order_detail->delivery_info_status == 1) ? 1 : 0;
            return $response_data;   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * Function thank_you_page
     */
    public function thank_you_page(Request $request) {
        return view('thank_you_page');
    }

    /**
     * Function save_delivery_info
     */
    public function save_delivery_info(Request $request) {
        try {
            $shop = $request->input('shop_name');
            $order_number = $request->input('order_number');
            $shop_find = ShopModel::where('store_name', $shop)->first();
            $shop_id = $shop_find->id;
            $app_settings = AppSettings::where('id', 1)->first();
            ## Make ShopifyAPI instance and get shop info using api.
            $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);

            $email_address = $shop_find->email;
            $delivery_date = $request->input('delivery_date');
            $delivery_time = $request->input('delivery_time');
            $delivery_array = array();
            $delivery_array['Delivery-Date'] = $delivery_date;
            if (isset($delivery_time))
                $delivery_array['Delivery-Time'] = $delivery_time;

            ## Update order data using api
            $order_data = [
                "order" => [
                    "id" => $order_number,
                    "note_attributes" => $delivery_array
                ]
            ];
            $sh->call(['URL' => '/admin/api/'.$this->api_version.'/orders/$order_number.json', 'METHOD' => 'PUT', 'DATA' => $order_data]);

            ## Send mail to admin and client
            $email_info_array['shop'] = $shop;
            $email_info_array['email'] = $email_address;
            $email_info_array['order_number'] = $order_number;
            $email_info_array['delivery_date'] = $delivery_date;
            $email_info_array['delivery_time'] = $delivery_time;
            $email_info_array['admin_mail_status'] = 1;
            event(new OrderProcessedEvent($email_info_array));

            $updated_data['delivery_info_status'] = 1;
            $updated_data['delivery_date'] = date("Y-m-d", strtotime(str_replace("/", "-", $delivery_date)));
            ## Update order details data
            if (isset($delivery_time))
                $updated_data['delivery_time'] = $delivery_time;

           OrderDetails::where(['shop_id' => $shop_id, 'order_id' => $order_number])->update($updated_data);
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    /**
     * Function regionList
     */
    public function regionList(Request $request) {
        try {
            if (session('shop')) {
                $shop = session('shop');
            } else if (isset($_REQUEST['shop_name']) && $_REQUEST['shop_name'] != NULL) {
                $shop = $_REQUEST['shop_name'];
            } else if (isset($_REQUEST['shop']) && $_REQUEST['shop'] != NULL) {
                $shop = $_REQUEST['shop'];
            } else {
                $shop = $request->input('shop');
            }

            ## Store specific condition
            if ($shop == "www.casinetto.com" || $shop == "casinetto.com" || $shop == "casinetto.myshopify.com") {
                $shop = 'casinetto.myshopify.com';
            }
            $user_settings = ShopModel::where('store_name', $shop)->first();
            $shop_id = $user_settings->id;
            $regions = Regions::where('shop_id', $shop_id)->get();
            if ($request->shop_name != '')
                return $regions;
            else
                return view('region_settings', compact('shop_id', 'regions'));   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
        }
    }

    /**
     * Function save_regions
     */
    public function save_region(Request $request) {
        try {
            ## Store region data
            $data['region'] = $request->region;
            $data['shop_id'] = $request->shop_id;
            Regions::updateOrCreate(['shop_id'=>$request->shop_id],$data)->update($data);
            return redirect('region');
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return redirect('region');
        }
    }

    /**
     * Function delete_region
     */
    public function delete_region(Request $request) {
        try {
            $id = $request->id;
            $region = Regions::find($id);
            $region->delete();
            return redirect('region');   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return redirect('region');
        }
    }

    /**
     * Function addRegionData
     */
    public function addRegionData(Request $request) {
        try {
            $shop = session('shop') ?? request()->get('shop');
            $shop_find = ShopModel::where('store_name', $shop)->first();
            $shop_id = $shop_find->id;
            $config = [];
            $config = $shop_find->block_config;
            $data['config'] = $config;
            $data['active'] = 'date';
            $settings = CutoffSettings::where('shop_id', $shop_id)->get();
            $region = Regions::where('shop_id', $shop_id)->get();
            $data['region'] = $region;
            $data['settings'] = $settings;
            $data['global_flag'] = $shop_find->global_cutoff_time_status;
            return view('cutoff_settings_region', $data);   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
        }
    }

    /**
     * Function save_region_setting
     */
    public function save_region_setting(Request $request) {
        try {
            $shop = $request->shop;
            $user_settings = ShopModel::where('store_name', $shop)->first();
            $shop_id = $user_settings->id;
            $region_id = $request->region;
            $date_interval = $request->date_interval;
            $global_cutoff_time = $request->global_cutoff_time ?? 0;
            ## update global cufoof time
            $user_settings = $user_settings->update(['global_cutoff_time_status' => $global_cutoff_time]);
            ## Get region setting and delete.
            $region_settings = RegionSettings::where(['shop_id' => $shop_id, 'region_id' => $region_id])->get();
            if (count($region_settings) > 0) {
                foreach ($region_settings as $r) {
                    $r->delete();
                }
            }

            $time_setting = $request->time;
            foreach ($time_setting as $time) {
                $data = array();
                $data['shop_id'] = $shop_id;
                $data['region_id'] = $region_id;
                $time_array = $time['days'];
                $data['day'] = $time_array['day'];
                $data['date_interval'] = $time_array['date_interval'];
                $data['cutoff_hour'] = $time_array['hour'];
                $data['cutoff_minute'] = $time_array['minute'];
                $data['region_delivery_time'] = json_encode(array_values($time_array['delivery_time']), true);
                $data = RegionSettings::create($data);
            }
            return view('cutoff_settings_view', compact('region', 'region_settings'));   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
        }
    }


    /**
     * Function region_view
     */
    public function region_view(Request $request) {
        return view('cutoff_settings_view');
    }

    /**
     * Function getRegionData
     */
    public function getRegionData(Request $request) {
        try {
            $shop = $request->shop;
            $user_settings = ShopModel::where('store_name', $shop)->first();
            $offset = $request->start;
            $limit = $request->length;
            $shop_id = $user_settings->id;
            $obj_region_settings = RegionSettings::with('regions')->where('shop_id', $shop_id)->groupBy('region_id');
            $row_count = $obj_region_settings->count();
            $region_settings = $obj_region_settings->offset($offset)->limit($limit)->get();
            $total_regions['data'] = array();
            $count = 1;
            $action = '';
            $action_delete = '';
            foreach ($region_settings as $regions) {
                $action = '<a href="' . url('region-edit', $regions->id) . '">Edit</a>';
                $action_delete = '<a href="' . url('region-delete', $regions->id) . '">Delete</a>';
                $total_regions['data'][] = array($count, $regions->regions->region, $action, $action_delete);
                $count++;
            }
            if ($total_regions['data'] == null) {
                $total_regions['data'] = [];
            }
            $total_regions['draw'] = (int) $request->draw;
            $total_regions['recordsTotal'] = $row_count;
            $total_regions['recordsFiltered'] = $row_count;
            return $total_regions;   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * Function region_edit
     */
    public function region_edit(Request $request) {
        try {
            $id = $request->id;
            $regiondata = RegionSettings::where(['id' => $id])->first();
            $region_id = $regiondata->region_id;
            $shop_id = $regiondata->shop_id;
            $region_settings = RegionSettings::where(['shop_id' => $shop_id, 'region_id' => $region_id])->get();
            $region = Regions::where('shop_id', $shop_id)->get();
            return view('region_edit', compact('region', 'region_settings', 'region_id'));   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
        }
    }

    /**
     * Function region_delete
     */
    public function region_delete(Request $request) {
        try {
            $id = $request->id;
            $regiondata = RegionSettings::where(['id' => $id])->first();
            $region_id = $regiondata->region_id;
            $shop_id = $regiondata->shop_id;
            $region_settings = RegionSettings::where(['shop_id' => $shop_id, 'region_id' => $region_id])->get();
            foreach ($region_settings as $r) {
                $r->delete();
            }
            return redirect('cut-off'); 
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return redirect('cut-off'); 
        }
    }

    /**
     * Function get_region_cutoff
     */
    public function get_region_cutoff(Request $request) {
        try {
            $day = $request->input('day');
            $shop = $request->input('shop_name');
            $region_id = $request->input('region_id');
            $user_settings = ShopModel::where('store_name', $shop)->first();
            $shop_id = $user_settings->id;
            $result = RegionSettings::with('regions')->where(['shop_id' => $shop_id, 'day' => $day, 'region_id' => $region_id])->get();
            return json_encode($result);   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return [];
        }
    }
}