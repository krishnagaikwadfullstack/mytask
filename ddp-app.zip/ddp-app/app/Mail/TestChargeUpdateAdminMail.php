<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class TestChargeUpdateAdminMail extends Mailable
{
    use Queueable, SerializesModels;
    protected $arrEmailData;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($arrEmailData)
    {
        $this->arrEmailData = $arrEmailData;        
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $strSubject = "Action Required: Need To Create New Recurring Application Charge For Delivery Date Pro";
        $app_name = "Delivery Date Pro";
        $logo = config('app.url') . 'public/image/zestard-logo.png';
        $blade_name = 'emails.test_plan_change_admin_mail';
        return $this->subject($strSubject)
                    ->with([
                            'shopInfo' => $this->arrEmailData,
                            'logo' => $logo,
                            'app_name' => $app_name,
                        ])
                    ->view($blade_name);
    }
}
