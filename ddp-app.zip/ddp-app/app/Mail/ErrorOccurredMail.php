<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use Config;

class ErrorOccurredMail extends Mailable
{
    use Queueable, SerializesModels;
    protected $arrEmailData;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($arrEmailData)
    {
        $this->arrEmailData = $arrEmailData;        
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $strSubject = "Zestard Technologies | Error Occurred While Installing Delivery Date Pro App";
        if($this->arrEmailData['error_type'] == 10){
            $strSubject = "Zestard Technologies | Error Occurred While Adding Product Page Short Code Dynamically in Delivery Date Pro App";
        }
        $app_name = "Delivery Date Pro";
        $logo = config('app.url') . 'image/zestard-logo.png';
        $blade_name = 'emails.error_occurred_mail';
        $arr_error_msg = Config::get('constants.arr_error_msg');
        $text = $arr_error_msg[$this->arrEmailData['error_type']] ?? '';

        return $this->subject($strSubject)
                    ->with([
                            'shopInfo' => $this->arrEmailData,
                            'logo' => $logo,
                            'app_name' => $app_name,
                            'text' => $text,
                            'error_msg' =>$this->arrEmailData['error_msg'] ?? '',
                            'error_line_no' => $this->arrEmailData['error_line_no'],
                        ])
                    ->view($blade_name);
    }
}
