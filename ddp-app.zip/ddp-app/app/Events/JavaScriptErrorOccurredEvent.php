<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class JavaScriptErrorOccurredEvent
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * The emailInfo instance.
     *
     */
    public $emailInfo;

   /**
     * Create a new event instance.
     *
     * @param  \App\ShopModel  $emailInfo
     * @return void
     */
    public function __construct($emailInfo)
    {
        $this->emailInfo = $emailInfo;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
