<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class FiveDayCronProcessedEvent
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    /**
     * The objShop instance.
     *
     * @var \App\ShopModel
     */
    public $objShop;

    /**
     * The client_flag instance.
     *
     */
    public $client_flag;

   /**
     * Create a new event instance.
     *
     * @param  \App\ShopModel  $objShop
     * @return void
     */
    public function __construct($objShop,$client_flag)
    {
        $this->objShop = $objShop;
        $this->client_flag = $client_flag;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
