<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LocalDelivery extends Model
{
    protected $table = 'local_deliveries';
    protected $fillable =[
    'enable_local_delivery', 'enable_distance_validation', 'enable_local_delivery_date', 'enable_local_delivery_time', 'local_delivery_order_tags'
    ];

    /**
    * Function to define the LocalDelivery & LocalDeliveryLocation relation
    */ 
    public function fn_local_delivery_locations() {
     return $this->hasMany('App\LocalDelivery','local_delivery_id','id');
    }
}
