<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LocalDeliveryLocation extends Model
{
    protected $table = 'local_delivery_locations';
    protected $fillable =[
    'local_delivery_id', 'location_id', 'enable_local_delivery_date', 'enable_local_delivery_time', 'local_delivery_time', 'local_delivery_block_days_interval', 'local_delivery_block_days', 'local_delivery_allowed_preorder_time', 'local_delivery_minimum_date_intervel', 'local_delivery_cuttoff_status', 'local_delivery_hours', 'local_delivery_minute', 'local_delivery_block_date', 'distance'
    ];
}
