<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderDetails extends Model
{
    protected $table = 'order_details';
    public $timestamps = false;
    protected $fillable =[
    'shop_id',
    'order_id',
    'order_name',
    'delivery_date',
    'delivery_time',
    'product_delivery_info',
    'ip_address',
    'browser_info',
    'date_and_time',
    'tag_flag',
    'delivery_info_status',
    'admin_email',
    'customer_email',
    'customer_name',
    'type_of_app',
    'app_version',
    'details'
  ];
}