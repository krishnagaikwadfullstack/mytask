<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShopModel extends Model {

    protected $table = 'usersettings';
    public $timestamps = false;    
    protected $fillable = [
        'access_token', 'store_name', 'store_encrypt', 'charge_id', 'api_client_id' ,'price', 'status', 'billing_on', 'payment_created_at', 'activated_on', 'trial_ends_on', 'cancelled_on', 'trial_days', 'decorated_return_url', 'confirmation_url', 'domain', 'write_orders_access', 'records_per_page', 'delivery_time_count_status', 'global_delivery_time_status' ,'global_cutoff_time_status', 'app_version', 'type_of_app', 'usage_charge_id', 'usage_price', 'new_install', 'upgrade_status', 'upgrade_modal_status', 'language_locale','email','shop_name','owner_name','plan_name','phone','address','country_name'
    ];

    public function block_config()
    {
        return $this->hasOne('App\Models\BlockConfig','shop_id','id');
    }

    /**
    * Function to define the ShopModel & TrialInfo relation
    */ 
    public function trial_info() {
        return $this->hasOne('App\Models\TrialInfo','shop_id','id');
    }

    /**
    * Function to define the ShopModel & ProductSettings relation
    */ 
    public function product_settings() {
        return $this->hasMany('App\Models\ProductSettings','shop_id','id');
    }

    /**
    * Function to define the ShopModel & DeliveryTimeSettings relation
    */ 
    public function delivery_time_settings() {
        return $this->hasMany('App\Models\DeliveryTimeSettings','shop_id','id');
    }

    /**
    * Function to define the ShopModel & CutoffSettings relation
    */ 
    public function cutoff_settings() {
        return $this->hasMany('App\Models\CutoffSettings','shop_id','id');
    }
    
    /**
    * Function to define the ShopModel & StoreInformation relation
    */ 
    public function store_information() {
        return $this->hasOne('App\Models\StoreInformation','shop_id','id');
    }
    
    /**
    * Function to define the ShopModel & OrderDetails relation
    */ 
    public function order_details() {
        return $this->hasMany('App\OrderDetails','shop_id','id');
    }

    /**
    * Function to define the ShopModel & Location relation
    */ 
    public function fn_locations() {
        return $this->hasMany('App\Models\Location','shop_id','id');
    }
}
