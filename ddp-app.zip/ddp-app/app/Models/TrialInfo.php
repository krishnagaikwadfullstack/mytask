<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TrialInfo extends Model
{
  protected $table = 'trial_info';
  public $timestamps = false;
  //protected $primaryKey = 'id';
  protected $fillable =[
    'store_name', 'shop_id', 'trial_days', 'activated_on', 'trial_ends_on', 'update_shopid_status'
  ];
  
  /**
  * Function to define the TrialInfo & ShopModel relation
  */ 
  public function shop_details() {
      return $this->belongsTo('App\Models\ShopModel','shop_id');
  }
}
