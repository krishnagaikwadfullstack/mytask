<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StorePickupLocation extends Model
{
    use HasFactory;
    protected $table = 'store_pickup_locations';
    protected $fillable =[
     'store_pickup_id', 'location_id', 'enable_pickup_date', 'enable_pickup_time', 'pickup_time', 'block_days_interval', 'block_days', 'allowed_preorder_time', 'minimum_date_intervel', 'cuttoff_status', 'hours', 'minute', 'block_dates'
    ];

    /**
    * Function to define the StorePickup & StorePickupLocation relation
    */ 
    public function fn_store_pickup_locations() {
      return $this->hasMany('App\StorePickupLocation','store_pickup_id','id');
    }
}
