<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StorePickup extends Model
{
    use HasFactory;
    protected $table = 'store_pickups';
    protected $fillable =[
     'enable_store_pickup', 'enable_storepickup_delivery_date', 'enable_storepickup_delivery_time', 'location_filter', 'storepickup_order_tags'
    ];

    /**
    * Function to define the StorePickup & StorePickupLocation relation
    */ 
    public function fn_store_pickup_locations() {
      return $this->hasMany('App\StorePickupLocation','store_pickup_id','id');
    }
}
