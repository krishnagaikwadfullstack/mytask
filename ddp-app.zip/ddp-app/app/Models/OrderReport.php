<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderReport extends Model
{
    protected $table = 'order_reports';
    protected $fillable = [
        'shop_id',
        'filter_data',
        'report_generate_status',
    ];

    protected $casts = [
        'filter_data' => 'array'
    ];

    protected $appends =['filtered_data'];

    /**
    * Function to get full address
    */ 
    public function getFilteredDataAttribute()
    {
        return json_decode($this->filtered_data);
    }

   /**
   * Function to define the ShopModel & OrderReport relation
   */ 
   public function fn_shop_detail() {
     return $this->belongsTo('App\ShopModel','shop_id','id');
   }
}
