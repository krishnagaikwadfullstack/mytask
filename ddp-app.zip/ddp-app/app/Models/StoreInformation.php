<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StoreInformation extends Model {

    protected $table = 'store_information';
   	protected $primaryKey = 'id';    
    protected $fillable = [
        'shop_id',
        'store_information_id',
        'store_name',
        'store_email',
        'store_domain',
        'store_address',
        'store_phone',
        'store_created',
        'store_updated',
        'store_country_name',
        'store_currency',
        'store_owner',
        'store_plan_name',
        'plan_update_date',
        'created_at',
        'updated_at',

    ];

    /**
    * Function to define the StoreInformation & ShopModel relation
    */ 
    public function fn_shop_information() {
        return $this->belongsTo('App\Models\ShopModel','shop_id');
    }
    
}
