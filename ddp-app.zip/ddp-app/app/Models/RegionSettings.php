<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RegionSettings extends Model
{
  protected $table = 'region_settings';
  public $timestamps = false;
  
  protected $fillable =[
    'shop_id', 'region_id', 'day', 'date_interval', 'cutoff_hour', 'cutoff_minute', 'region_delivery_time'
  ];
  
  public function regions()
  {
      return $this->hasOne(\App\Models\Regions::class,'id','region_id');
  }

}
