<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Regions extends Model
{
  protected $table = 'regions';
  public $timestamps = false;
  //protected $primaryKey = 'id';
  protected $fillable =[
    'shop_id', 'region'
  ];
 
}
