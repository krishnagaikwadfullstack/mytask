<?php

namespace App\Listeners;

use Mail;
use App\Events\ErrorOccurredEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\ErrorOccurredMail;

class SendErrorNotification
{
    /**
     * Handle the event.
     *
     * @param  ErrorOccurredEvent  $event
     * @return void
     */
    public function handle(ErrorOccurredEvent $event)
    {
        ## Send email to admin about the app installation error
        Mail::to(env('SUPPORT_EMAIL'))->send(new ErrorOccurredMail($event->shoInfo));
    }
}
