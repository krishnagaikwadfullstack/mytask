<?php

namespace App\Listeners;

use App\Events\TestPlanLiveStoreEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\TestPlanLiveStoreAdminMail;
use Mail;

class SendTestPlanLiveStoreNotification
{
    /**
     * Handle the event.
     *
     * @param  TestPlanLiveStoreEvent  $event
     * @return void
     */
    public function handle(TestPlanLiveStoreEvent $event)
    {
        $admin_email = env('SUPPORT_EMAIL');
        ## send mail to the admin about app test charges live stores.
        if(!is_null($admin_email))
            Mail::to($admin_email)->send(new TestPlanLiveStoreAdminMail($event));
    }
}
