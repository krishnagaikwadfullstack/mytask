<?php

namespace App\Listeners;

use App\Events\PlanVerificationCronProcessedEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\PlanVerificationCronAdminMail;
use Mail;

class SendPlanVerificationNotification
{

    /**
     * Handle the event.
     *
     * @param  PlanVerificationCronProcessedEvent  $event
     * @return void
     */
    public function handle(PlanVerificationCronProcessedEvent $event)
    {
        $admin_email = env('SUPPORT_EMAIL');
        ## send mail to the admin about app how many stores using test plan
        if(!is_null($admin_email))
            Mail::to($admin_email)->send(new PlanVerificationCronAdminMail($event));
    }
}
