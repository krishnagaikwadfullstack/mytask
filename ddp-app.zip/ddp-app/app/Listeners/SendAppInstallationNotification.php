<?php

namespace App\Listeners;

use Mail;
use App\Events\AppInstallationProcessed;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\AppInstallationProcessedMail;
use App\Mail\AppInstallationProcessedAdminMail;

class SendAppInstallationNotification
{
    
    /**
     * Handle the event.
     *
     * @param  AppInstallationProcessed  $event
     * @return void
     */
    public function handle(AppInstallationProcessed $event)
    {
        Mail::to($event->objShop->shop->email)->send(new AppInstallationProcessedMail($event->objShop));

        $admin_email = env('SUPPORT_EMAIL');
        ## send mail to the admin about app installation
        if(!is_null($admin_email))
            Mail::to($admin_email)->send(new AppInstallationProcessedAdminMail($event->objShop)); 
    }
}
