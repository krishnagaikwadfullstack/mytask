<?php

namespace App\Listeners;

use Mail;
use App\Events\WebhookProcessedEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\WebhookProcessedMail;

class SendWebhookNotification
{
    
    /**
     * Handle the event.
     *
     * @param  WebhookProcessedEvent  $event
     * @return void
     */
    public function handle(WebhookProcessedEvent $event)
    {
        Mail::to(env('SUPPORT_EMAIL'))->send(new WebhookProcessedMail($event->shopData));
        //$event->shopData->email
    }
}
