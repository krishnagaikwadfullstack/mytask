<?php

namespace App\Listeners;

use Mail;
use App\Events\AppUnInstallationProcessed;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\AppUnInstallationProcessedMail;
use App\Mail\AppUnInstallationProcessedAdminMail;

class SendAppUnInstallationNotification
{
    
    /**
     * Handle the event.
     *
     * @param  AppUnInstallationProcessed  $event
     * @return void
     */
    public function handle(AppUnInstallationProcessed $event)
    {
        Mail::to($event->shopData->email)->send(new AppUnInstallationProcessedMail($event->shopData));
        //$event->shopData->email
        $admin_email = env('SUPPORT_EMAIL');
        ## send mail to the admin about app installation
        if(!is_null($admin_email))
            Mail::to($admin_email)->send(new AppUnInstallationProcessedAdminMail($event->shopData)); 
    }
}
