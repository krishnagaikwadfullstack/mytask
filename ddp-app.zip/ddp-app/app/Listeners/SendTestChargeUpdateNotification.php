<?php

namespace App\Listeners;

use Mail;
use App\Events\TestChargeUpdateEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\TestChargeUpdateClientMail;
use App\Mail\TestChargeUpdateAdminMail;

class SendTestChargeUpdateNotification
{
    
    /**
     * Handle the event.
     *
     * @param  TestChargeUpdateEvent  $event
     * @return void
     */
    public function handle(TestChargeUpdateEvent $event)
    {
        Mail::to($event->objShop->email)->cc(['krishna.zestard@gmail.com'])->send(new TestChargeUpdateClientMail($event->objShop));

        $admin_email = env('SUPPORT_EMAIL');
        ## send mail to the admin about app charges confirmation
        if(!is_null($admin_email))
            Mail::to($admin_email)->send(new TestChargeUpdateAdminMail($event->objShop));
    }
}
