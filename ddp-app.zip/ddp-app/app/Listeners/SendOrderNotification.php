<?php

namespace App\Listeners;

use Mail;
use App\Events\OrderProcessedEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\OrderProcessedMail;
use App\Mail\OrderProcessedAdminMail;

class SendOrderNotification
{
    
    /**
     * Handle the event.
     *
     * @param  OrderProcessedEvent  $event
     * @return void
     */
    public function handle(OrderProcessedEvent $event)
    {
        Mail::to($event->orderInfo['email'])->send(new OrderProcessedMail($event->orderInfo));

        $admin_email = env('SUPPORT_EMAIL');
        ## send mail to the admin about the order update
        if(!is_null($admin_email) && isset($event->orderInfo['admin_mail_status']))
            Mail::to($admin_email)->send(new OrderProcessedAdminMail($event->orderInfo)); 
    }
}
