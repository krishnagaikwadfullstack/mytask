<?php

namespace App\Listeners;

use Mail;
use App\Events\JavaScriptErrorOccurredEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\JavaScriptErrorOccurredMail;

class SendJavaScriptErrorNotification
{
    /**
     * Handle the event.
     *
     * @param  JavaScriptErrorOccurredEvent  $event
     * @return void
     */
    public function handle(JavaScriptErrorOccurredEvent $event)
    {
        ## Send email to admin about the app jQuery error
        Mail::to(env('SUPPORT_EMAIL'))->send(new JavaScriptErrorOccurredMail($event->emailInfo));
    }
}
