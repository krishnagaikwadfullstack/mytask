<?php

namespace App\Listeners;

use Mail;
use App\Events\PlanChangeCronProcessedEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\PlanChangeCronProcessedMail;
use App\Mail\PlanChangeCronProcessedAdminMail;

class SendPlanChangeCronNotification
{
    
    /**
     * Handle the event.
     *
     * @param  PlanChangeCronProcessedEvent  $event
     * @return void
     */
    public function handle(PlanChangeCronProcessedEvent $event)
    {
        Mail::to($event->objShop->email)->cc(['support@zestard.com','krishna.zestard@gmail.com'])->send(new PlanChangeCronProcessedMail($event->objShop));

        $admin_email = env('SUPPORT_EMAIL');
        ## send mail to the admin about app charges confirmation
        if(!is_null($admin_email))
            Mail::to($admin_email)->send(new PlanChangeCronProcessedAdminMail($event->objShop));
    }
}
