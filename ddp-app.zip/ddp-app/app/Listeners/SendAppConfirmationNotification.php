<?php

namespace App\Listeners;

use App\Events\AppConfirmationProcessed;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\AppConfirmationProcessedMail;
use App\Mail\AppConfirmationProcessedAdminMail;
use Mail;

class SendAppConfirmationNotification
{
    /**
     * Handle the event.
     *
     * @param  AppConfirmationProcessed  $event
     * @return void
     */
    public function handle(AppConfirmationProcessed $event)
    {
        ## send mail to store owner about the app confirmation of usage charge during trial period
        Mail::to($event->objShop->email)->send(new AppConfirmationProcessedMail($event->objShop));

        $admin_email = env('SUPPORT_EMAIL');
        ## send mail to admin about the app confirmation of usage charge during trial period
        if(!is_null($admin_email))
            Mail::to($admin_email)->send(new AppConfirmationProcessedAdminMail($event->objShop)); 
    }
}
