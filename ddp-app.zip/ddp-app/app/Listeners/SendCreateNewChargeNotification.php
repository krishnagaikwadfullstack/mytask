<?php

namespace App\Listeners;

use App\Events\CreateNewChargeEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\CreateNewChargeProcessedClientMail;
use App\Mail\CreateNewChargeProcessedAdminMail;
use Mail;

class SendCreateNewChargeNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  CreateNewChargeEvent  $event
     * @return void
     */
    public function handle(CreateNewChargeEvent $event)
    {
        Mail::to($event->objShop->email)->cc(['krishna.zestard@gmail.com'])->send(new CreateNewChargeProcessedClientMail($event->objShop));

        $admin_email = env('SUPPORT_EMAIL');
        ## send mail to admin about created new app charges
        if(!is_null($admin_email))
            Mail::to($admin_email)->send(new CreateNewChargeProcessedAdminMail($event->objShop));
    }
}
