<?php

namespace App\Listeners;

use Mail;
use App\Events\FiveDayCronProcessedEvent;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Mail\FiveDayCronProcessedMail;
use App\Mail\FiveDayCronProcessedAdminMail;

class SendFiveDayCronNotification
{
    
    /**
     * Handle the event.
     *
     * @param  FiveDayCronProcessedEvent  $event
     * @return void
     */
    public function handle(FiveDayCronProcessedEvent $event)
    {
        if($event->client_flag == 1)
            Mail::to($event->objShop->store_email)->send(new FiveDayCronProcessedMail($event->objShop));
        $admin_email = env('SUPPORT_EMAIL');
        ## send mail to the admin about app charges confirmation
        if(!is_null($admin_email))
            Mail::to($admin_email)->send(new FiveDayCronProcessedAdminMail($event->objShop));
    }
}
