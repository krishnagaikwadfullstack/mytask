//Global Variable Declarations
var base_path_delivery_date = "https://shopifydev.anujdalal.com/DeliveryDateProAppBridge/public/";
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var cutoff_hours, cutoff_minute, store_hour, store_minute, datepicker_default_date, deliverytime_global_status, app_version, type_of_app, cutoff_global_status, cutoff_status, cutoff_global_hours, cutoff_global_minute, start_from, is_time_required, is_date_required, time_array, time_count, deliverytime_response, cutoff_response, date_formate, add_delivery_information, order_note, locale, date_error_message, store_date, delivery_date_array, formatted_delivery_date, selected_delivery_date, datepicker_on_default, textarea_variable, original_start_from, time_error_message, disable_checkout,enable_external_delivery_date,enable_local_delivery_date,enable_storepickup_delivery_date,enable_location_local_delivery_date,enable_storepickup_location_delivery_date,zindex_timeout,date_picker_timeout,date_main_timeout,button_timeout,note_timeout,default_date_timeout,checkout_click_timeout,storepickup_zindex_timeout,storepickup_date_picker_timeout,storepickup_date_main_timeout,storepickup_button_timeout,storepickup_note_timeout,storepickup_default_date_timeout,storepickup_checkout_click_timeout,location_timout,local_zindex_timeout,local_date_picker_timeout,local_date_main_timeout,local_button_timeout,local_note_timeout,local_default_date_timeout,local_checkout_click_timeout;
var xhttp, data_length, configdata;
var shop_name = Shopify.shop;
function calcTime(city, offset) {
    console.log(nd)
    console.log(nd.getHours());
    console.log(nd.getMinutes());
    // return time as a string
    return "The local time in " + city + " is " + nd.toLocaleString();
}
var store_timezone = 0;
var store_hour = ''
var store_minute = ''
if(typeof store_timezone_offset !== 'undefined'){
    d = new Date();
    utc = d.getTime() + (d.getTimezoneOffset() * 60000);
    nd = new Date(utc + (3600000*store_timezone_offset));
    store_timezone = 1;
    store_hour = nd.getHours();
    store_minute = nd.getMinutes();
}
//document.getElementsByName("checkout").disabled = true;
var $zestard_jq = "";
if (shop_name != "les-gastronomes.myshopify.com"  && shop_name != "enarxi.myshopify.com" && shop_name != "fisherscheese.myshopify.com" && shop_name != "alacena-de-monica-prueba-12345.myshopify.com"  && shop_name != "cheeseschool.myshopify.com" &&  shop_name != "maison-duffour.myshopify.com" && shop_name != "do-it-center-panama.myshopify.com" &&  shop_name != "altamarea-online-shop.myshopify.com") {
    //If Undefined or Not available, Then Load      
    (function() {
        console.log('load js')
        var jscript = document.createElement("script");
        jscript.src = base_path_delivery_date + "js/zestard_jquery_3.3.1.js";
        jscript.type = 'text/javascript';
        jscript.async = false;

        var el = document.getElementById('datepicker_box');
        if (el == '' || el == 'undefined' || el == null) {
            el = document.createElement('div');
            el.id = "datepicker_box";
            elChild = document.createElement('div');
            elChild.id = 'datepicker_box_jquery';
        } else {
            elChild = document.createElement('div');
            elChild.id = 'datepicker_box_jquery';
            el.insertBefore(elChild, el.firstChild);
            document.getElementById('datepicker_box_jquery').appendChild(jscript);
        }
        jscript.onload = function() {
            console.log('on load jquery')
            //Assigning Jquery Object to Zestard_jq
            $zestard_jq = window.jQuery;
            $zestard_jq.ajax({
                url: base_path_delivery_date + "getconfig",
                dataType: "json",
                async: false,
                data: {
                    shop: shop_name
                },
                success: function(data) {
                    configdata = data;
                    if (data == 0) {
                        data_length = data;
                    } else {
                        locale = data.language_locale;
                        if(data.local_delivery_details.enable_local_delivery == 2){
                            $zestard_jq(".ztpl-local-delivery").remove();
                            $zestard_jq("#ztpl-local-delivery").parent('.delivery-option-item').remove();
                            $zestard_jq("#ztpl-local-delivery").remove();
                        }
                        if(data.store_pickup_details.enable_store_pickup == 2){
                            $zestard_jq(".ztpl-store-pickup").remove();
                            $zestard_jq("#ztpl-store-pickup").parent('.delivery-option-item').remove()
                            $zestard_jq("#ztpl-store-pickup").remove();
                        }
                        if(data.enable_external_delivery == 2){
                            $zestard_jq(".ztpl-external-delivery").remove();
                            $zestard_jq("#ztpl-external-delivery").parent('.delivery-option-item').remove()
                            $zestard_jq("#ztpl-external-delivery").remove();
                            $zestard_jq("#External-Delivery").hide();
                        }
                    }
                }
            });
            if (data_length != 0) {
                //If Undefined or Not available, Then Load              
                script = document.createElement('script');
                script.type = "text/javascript";
                script.src = base_path_delivery_date + 'js/jquery-ui.js';
                document.getElementById('datepicker_box_jquery').appendChild(script);
                script.onload = function() {
                    console.log(jQuery.ui,'jQuery.ui',$zestard_jq.ui);
                    // Check If jQuery UI Object is Undefined
                    //Send Email that jQuery is Still not Working
                    if (typeof jQuery.ui == 'undefined') {
                    // if (typeof $zestard_jq.ui == 'undefined') {
                        //If undefined then send email
                        if (shop_name != "purpinkg.myshopify.com") {
                            xhttp = new XMLHttpRequest();
                            xhttp.onreadystatechange = function() {
                                if (this.readyState == 4 && this.status == 200) {

                                }
                            };
                            xhttp.open("GET", base_path_delivery_date + "acknowledge?shop_name=" + shop_name + "&type=2", true);
                            xhttp.send();
                        }
                    } else {
                        if (locale == "en") {
                            $zestard_jq = window.jQuery;
                            //Calling Delivery Date Function
                            console.log('alldetails',configdata)
                            if(configdata.enable_external_delivery == 1){
                                console.log('first call',configdata.enable_external_delivery)
                                deliveryDatePro();
                            } else if(configdata.store_pickup_details.enable_store_pickup == 1){
                                console.log('first call',configdata.store_pickup_details.enable_store_pickup)
                                $zestard_jq('#Store-Pickup').show();
                                $zestard_jq('#ztpl-delivery-option input[type="radio"][value="Store Pickup"]').prop('checked',true).addClass('active');
                                deliveryDateProStorePickup();
                            } else if(configdata.local_delivery_details.enable_local_delivery == 1){
                                console.log('first call',configdata.local_delivery_details.enable_local_delivery)
                                deliveryDateProLocalDelivery();
                                $zestard_jq('#Local-Delivery').show();
                                $zestard_jq('#ztpl-delivery-option input[type="radio"][value="Local Delivery"]').prop('checked',true).addClass('active');
                            }
                            
                            $zestard_jq("#ztpl-delivery-option input[type='radio']").on('click', function(e){
                                if($zestard_jq(this).val() == 'Store Pickup'){
                                    deliveryDateProStorePickup();
                                }else if($zestard_jq(this).val() == 'External Delivery'){
                                    deliveryDatePro();
                                }else if($zestard_jq(this).val() == 'Local Delivery'){
                                    deliveryDateProLocalDelivery();
                                }
                                console.log('in click')
                            });
                            console.log('firs ztpl-search-btn')
                            $zestard_jq("#ztpl-search-btn").on('click', function(e){
                                e.preventDefault();
                                console.log('search click',$zestard_jq('#ztpl-postal-code').val());
                                if($zestard_jq('#ztpl-postal-code').val()){
                                    deliveryDateProLocalDelivery($zestard_jq('#ztpl-postal-code').val());
                                }else{
                                    alert('Please enter valid zipcode.');
                                }
                            });
                            $zestard_jq("#ztpl-region-filter").on('change', function(e){
                                e.preventDefault();
                                deliveryDateProStorePickup('',$zestard_jq(this).val());
                            });
                        } else {
                            jscript = document.createElement("script");
                            jscript.src = base_path_delivery_date + "js/locale_js/datepicker-" + locale + ".js";
                            jscript.type = 'text/javascript';
                            jscript.async = false;
                            var el = document.getElementById('datepicker_box'),
                                elChild = document.createElement('div');
                            elChild.id = 'datepicker_locale_jquery';
                            el.insertBefore(elChild, el.firstChild);
                            el.appendChild(elChild);
                            document.getElementById('datepicker_box_jquery').appendChild(jscript);
                            jscript.onload = function() {
                                $zestard_jq = window.jQuery;
                                //Calling Delivery Date Function
                                console.log(configdata);
                                if(configdata.enable_external_delivery == 1){
                                    console.log('first call',configdata.enable_external_delivery)
                                    deliveryDatePro();
                                } else if(configdata.store_pickup_details.enable_store_pickup == 1){
                                    console.log('first call',configdata.store_pickup_details.enable_store_pickup)
                                    $zestard_jq('#Store-Pickup').show();
                                    $zestard_jq('#ztpl-delivery-option input[type="radio"][value="Store Pickup"]').prop('checked',true);
                                    deliveryDateProStorePickup();
                                } else if(configdata.local_delivery_details.enable_local_delivery == 1){
                                    console.log('first call',configdata.local_delivery_details.enable_local_delivery)
                                    deliveryDateProLocalDelivery();
                                    $zestard_jq('#Local-Delivery').show();
                                    $zestard_jq('#ztpl-delivery-option input[type="radio"][value="Local Delivery"]').prop('checked',true);
                                }
                                
                                $zestard_jq("#ztpl-delivery-option input[type='radio']").on('click', function(e){
                                    if($zestard_jq(this).val() == 'Store Pickup'){
                                        deliveryDateProStorePickup();
                                    }else if($zestard_jq(this).val() == 'External Delivery'){
                                        deliveryDatePro();
                                    }else if($zestard_jq(this).val() == 'Local Delivery'){
                                        deliveryDateProLocalDelivery();
                                    }
                                });
                                $zestard_jq("#ztpl-search-btn").on('click', function(e){
                                    e.preventDefault();
                                    console.log($zestard_jq('#ztpl-postal-code').val());
                                    if($zestard_jq('#ztpl-postal-code').val()){
                                        deliveryDateProLocalDelivery($zestard_jq('#ztpl-postal-code').val());
                                    }else{
                                        alert('Please enter valid zipcode.');
                                    }
                                });
                                $zestard_jq("#ztpl-region-filter").on('change', function(e){
                                    e.preventDefault();
                                    deliveryDateProStorePickup('',$zestard_jq(this).val());
                                });
                            }
                        }
                    }
                }
            } else {
                $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
                $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
                $zestard_jq("#datepicker_box").remove();

            }
        };
    })();
} else {
    if (shop_name == "alacena-de-monica-prueba-12345.myshopify.com") {
        $zestard_jq = window.jQuery;
        $zestard_jq.ajax({
            url: base_path_delivery_date + "getconfig",
            dataType: "json",
            async: false,
            data: {
                shop: shop_name
            },
            success: function(data) {
                configdata = data;
                locale = data.language_locale;
                if(data.local_delivery_details.enable_local_delivery == 2){
                    $zestard_jq(".ztpl-local-delivery").remove();
                    $zestard_jq("#ztpl-local-delivery").parent('.delivery-option-item').remove()
                    $zestard_jq("#ztpl-local-delivery").remove();
                }
                if(data.store_pickup_details.enable_store_pickup == 2){
                    $zestard_jq(".ztpl-store-pickup").remove();
                    $zestard_jq("#ztpl-store-pickup").parent('.delivery-option-item').remove()
                    $zestard_jq("#ztpl-store-pickup").remove();
                }
                if(data.enable_external_delivery == 2){
                    $zestard_jq(".ztpl-external-delivery").remove();
                    $zestard_jq("#ztpl-external-delivery").parent('.delivery-option-item').remove()
                    $zestard_jq("#ztpl-external-delivery").remove();
                    $zestard_jq("#External-Delivery").hide();
                }
            }
        });
        if (locale == "en") {} else {
            var el = document.getElementById('datepicker_box'),
                elChild = document.createElement('div');
            elChild.id = 'datepicker_box_jquery';
            el.insertBefore(elChild, el.firstChild);
            jscript = document.createElement("script");
            jscript.src = base_path_delivery_date + "js/locale_js/datepicker-" + locale + ".js";
            jscript.type = 'text/javascript';
            jscript.async = false;
            var el = document.getElementById('datepicker_box'),
                elChild = document.createElement('div');
            elChild.id = 'datepicker_locale_jquery';
            el.insertBefore(elChild, el.firstChild);
            el.appendChild(elChild);
            document.getElementById('datepicker_box_jquery').appendChild(jscript);
            jscript.onload = function() {
                $zestard_jq = window.jQuery;
                //Calling Delivery Date Function
                if(configdata.enable_external_delivery == 1){
                    console.log('first call',configdata.enable_external_delivery)
                    deliveryDatePro();
                } else if(configdata.store_pickup_details.enable_store_pickup == 1){
                    console.log('first call',configdata.store_pickup_details.enable_store_pickup)
                    $zestard_jq('#Store-Pickup').show();
                    $zestard_jq('#ztpl-delivery-option input[type="radio"][value="Store Pickup"]').prop('checked',true);
                    deliveryDateProStorePickup();
                } else if(configdata.local_delivery_details.enable_local_delivery == 1){
                    console.log('first call',configdata.local_delivery_details.enable_local_delivery)
                    deliveryDateProLocalDelivery();
                    $zestard_jq('#Local-Delivery').show();
                    $zestard_jq('#ztpl-delivery-option input[type="radio"][value="Local Delivery"]').prop('checked',true);
                }
                
                $zestard_jq("#ztpl-delivery-option input[type='radio']").on('click', function(e){
                    if($zestard_jq(this).val() == 'Store Pickup'){
                        deliveryDateProStorePickup();
                    }else if($zestard_jq(this).val() == 'External Delivery'){
                        deliveryDatePro();
                    }else if($zestard_jq(this).val() == 'Local Delivery'){
                        deliveryDateProLocalDelivery();
                    }
                });
                $zestard_jq("#ztpl-search-btn").on('click', function(e){
                    e.preventDefault();
                    console.log($zestard_jq('#ztpl-postal-code').val());
                    if($zestard_jq('#ztpl-postal-code').val()){
                        deliveryDateProLocalDelivery($zestard_jq('#ztpl-postal-code').val());
                    }else{
                        alert('Please enter valid zipcode.');
                    }
                });
                $zestard_jq("#ztpl-region-filter").on('change', function(e){
                    e.preventDefault();
                    deliveryDateProStorePickup('',$zestard_jq(this).val());
                });
            }
        }
    } else {
        //Calling Delivery Date Function
        $zestard_jq = window.jQuery;
        $zestard_jq('#ztpl-store-pickup').on('click', function(){
            console.log('store pickup')  
        });
        deliveryDatePro();
    }
}

function deliveryDatePro() {
    //Clear all timeout
    if (zindex_timeout){clearTimeout(zindex_timeout);}
    if (date_picker_timeout){clearTimeout(date_picker_timeout);}
    if (date_main_timeout){clearTimeout(date_main_timeout);}
    if (button_timeout){clearTimeout(button_timeout);}
    if (note_timeout){clearTimeout(note_timeout);}
    if (default_date_timeout){clearTimeout(default_date_timeout);}
    if (checkout_click_timeout){clearTimeout(checkout_click_timeout);}

    $zestard_jq('.ztpl-loader').removeClass('hide');
    $zestard_jq('input[name=checkout], button[name=checkout], .googlepay, .paypal-button, input#checkout').off('click');
    $zestard_jq('#delivery-time').off('change');
    $zestard_jq(".visible_datepicker").remove();
    store_date = $zestard_jq("#ztpl-date-format-ddmmyy").val();
    $zestard_jq("#delivery-date-pro").val("");
    $zestard_jq("#delivery-time-local-delivery").removeAttr('name');
    $zestard_jq("#delivery-time-store-pickup").removeAttr('name');
    $zestard_jq("#delivery-time").attr('name', 'attributes[Delivery-Time]');
    $zestard_jq.ajax({
        url: base_path_delivery_date + "get-type-and-version",
        async: false,
        data: { shop_name: shop_name },
        success: function(result) {
            data_length = result;
            if (data_length != 0) {
                app_version = result.app_version;
                type_of_app = result.type_of_app;
            } else {
                $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
                $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
                $zestard_jq("#datepicker_box").remove();
            }
        }
    });
    if (data_length != 0) {
        var unavailableDates = unavailableDays = [];
        var start_from = allowed_month = date_formate = tempdate ='';
        var check_out_form = $zestard_jq("#delivery-date-pro").closest("form").attr('class');
        if (check_out_form) {
            var check_out_class_array = check_out_form.split(' ');
            if ($zestard_jq.inArray("cart-form", check_out_class_array) < 0) {
                    $zestard_jq("#delivery-date-pro").closest("form").addClass("cart-form");
            }
        } else {
                $zestard_jq("#delivery-date-pro").closest("form").addClass("cart-form");
        }
        is_date_required = is_time_required = false;
        $zestard_jq.ajax({
            url: base_path_delivery_date + "getconfig",
            dataType: "json",
            async: false,
            data: {
                shop: shop_name
            },
            success: function(data) {
                app_status = data.app_status;
                locale = data.language_locale;
                datepicker_on_default = data.datepicker_display_on;
                datepicker_default_date = data.default_date_option;
                add_delivery_information = data.add_delivery_information;
                date_error_message = data.date_error_message;
                time_error_message = data.time_error_message;
                if (app_status == "Inactive") {
                    $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
                    $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
                    $zestard_jq("#datepicker_box").remove();
                    $zestard_jq("#ztpl-delivery-option").remove();
                }

                if (data.require_option == 1) {
                    is_date_required = true;
                    $zestard_jq("#delivery-date-pro").attr("required", "true");
                    $zestard_jq("#delivery-date-pro").closest("form").removeAttr('novalidate');
                }
                var date_label = data.datepicker_label;
                show_datepicker_label = data.show_datepicker_label;
                if (show_datepicker_label == 1) {
                    $zestard_jq('.date-box label').text(date_label);
                } else {
                    $zestard_jq('.date-box label').hide();
                }
                var dates = data.external_delivery_block_dates;
                var day = data.days;
                start_from = '+' + data.date_interval;
                allowed_month = '+' + data.alloved_month + 'M';
                unavailableDates = $zestard_jq.parseJSON(dates);
                unavailableDays = $zestard_jq.parseJSON(day);
                date_formate = data.date_format;
                cutoff_status = data.cuttoff_status;
                cutoff_global_status = data.cutoff_global_status;
                deliverytime_global_status = data.deliverytime_global_status;
                cutoff_global_hours = data.hours;
                cutoff_global_minute = data.minute;
                var current_date = $zestard_jq("#ztpl-current-date").val();
                if(store_hour == '' || isNaN(store_hour) ){
                    store_hour = $zestard_jq("#ztpl-store-hour").val();
                }
                if(store_minute == '' || isNaN(store_minute)){
                    store_minute = $zestard_jq("#ztpl-store-minute").val();
                }
                
                if (date_formate == "mm/dd/yy") {
                    var display_format = "(mm/dd/yyyy)";
                } else if (date_formate == "yy/mm/dd") {
                    var display_format = "(yyyy/mm/dd)";
                } else if (date_formate == "dd/mm/yy") {
                    var display_format = "(dd/mm/yyyy)";
                } else {
                    var display_format = "(mm/dd/yyyy)";
                }

                var show_date_format = data.show_date_format;
                if (show_date_format == 1) {
                    if (display_format != "") {
                        $zestard_jq("#selected_format").text(display_format);
                    } else {
                        $zestard_jq("#selected_format").text('mm/dd/yyyy');
                    }
                }
                var admin_note_status = data.admin_note_status;
                var notes_admin = data.admin_order_note;
                if (admin_note_status == 1) {
                    $zestard_jq("#admin_notes").html($zestard_jq.parseHTML(notes_admin));
                }

                var admin_time_status = data.admin_time_status;
                var enable_external_delivery_time = data.enable_external_delivery_time;
                enable_external_delivery_date = data.enable_external_delivery_date;
                var time_lable = data.time_label;
                var default_option_label = data.time_default_option_label;
                if (admin_time_status == 1 && enable_external_delivery_time == 1) {
                    var time_in_text = data.delivery_time;
                    time_array = new Array();
                    time_array = time_in_text.split(",");
                    time_count = 0;
                    $zestard_jq("#delivery-time").css('display', 'block');
                    $zestard_jq("#delivery-time").css('border', 'none');
                    $zestard_jq("#delivery-time").html("");
                    if(default_option_label){
                        $zestard_jq("#delivery-time").append("<option id='time_option_label' value='' readonly>"+default_option_label+"</option>");
                    }
                    $zestard_jq("#time_option_label").text(default_option_label);
                    if ((app_version <= 2 && type_of_app) <= 2 || (app_version == 4 && type_of_app == 4)) {
                        $zestard_jq(time_array).each(function() {
                            $zestard_jq('#delivery-time').append("<option value='" + time_array[time_count] + "'" + ">" + time_array[time_count] + "</option>");
                            time_count++;
                        });
                    }
                    $zestard_jq("#delivery-time-label").show();
                    $zestard_jq("#delivery-time-label").text(time_lable);
                    if (data.time_require_option == 1) {
                        is_time_required = true;
                        $zestard_jq("#delivery-time").attr("required", "true");
                        $zestard_jq("#delivery-date-pro").closest("form").removeAttr('novalidate');
                    }
                }
                var additional_css = data.additional_css;
                // if (shop_name == "balance80.myshopify.com") {
                //     $zestard_jq('.datepicker_wrapper_box').css("cssText", "display: inline-block;background: #f5f5f5;padding: 20px 30px;color:black !important;font-weight:700;");
                // } else {
                    $zestard_jq('#datepicker_box').after("<style>" + additional_css + "</style>");
                // }
                //Change Variable Name
                var str = parseInt(data.date_interval);
                if (parseInt(cutoff_status) == 0 || parseInt(cutoff_status) == 2) {} else {
                    //Check App Version if it is 3(i.e Enterprise) or more then it will Exceute Following Code For Multiple Cut Off and Delivery Time  
                    if (app_version == 3 && type_of_app == 3) {
                        if (cutoff_global_status == 1) {
                            cutoff_hours = cutoff_global_hours;
                            cutoff_minute = cutoff_global_minute;
                            if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                                if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                    str = parseInt(data.date_interval);
                                } else {
                                    if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                        str = parseInt(data.date_interval);
                                    } else {
                                        str = parseInt(data.date_interval) + 1;
                                    }
                                }
                            } else {
                                str = parseInt(data.date_interval) + 1;
                            }
                        } else {
                            var c_day = new Date().getDay();
                            $zestard_jq.ajax({
                                url: base_path_delivery_date + "get-cutoff-time",
                                data: { day: c_day, shop_name: shop_name },
                                async: false,
                                success: function(response) {
                                    var json_data = JSON.parse(response);
                                    cutoff_hours = json_data['cutoff_hour'];
                                    cutoff_minute = json_data['cutoff_minute'];
                                }
                            });
                            if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                                if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                    str = parseInt(data.date_interval);
                                } else {
                                    if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                        str = parseInt(data.date_interval);
                                    } else {
                                        str = parseInt(data.date_interval) + 1;
                                    }
                                }
                            } else {
                                str = parseInt(data.date_interval) + 1;
                            }
                        }
                    } else {
                        cutoff_hours = cutoff_global_hours;
                        cutoff_minute = cutoff_global_minute;
                        if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                            if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                str = parseInt(data.date_interval);
                            } else {
                                if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                    str = parseInt(data.date_interval);
                                } else {
                                    str = parseInt(data.date_interval) + 1;
                                }
                            }
                        } else {
                            str = parseInt(data.date_interval) + 1;
                        }
                    }
                }
                start_from = '+' + parseInt(str);
                original_start_from = start_from;

                function pad(n) {
                    return (n < 10) ? ("0" + n) : n;
                }
                var tempdate = new Date();
                tempdate.setDate(tempdate.getDate());
                var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                var block_date_array = JSON.parse(dates);
                var block_days_array = unavailableDays;
                var NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                var NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                var current_available_day = weekday[tempdate.getDay()];
                exit_flag = 0;
                temp_count = start_from;
                if (!block_days_array) {
                    block_days_array = new Array();
                }
                if (!block_date_array) {
                    block_date_array = new Array();
                }
                /* if (shop_name == "sunshine-milk-bread.myshopify.com" || shop_name == "greenox.myshopify.com" || shop_name == "petaljet.myshopify.com" || shop_name == "alacena-de-monica-prueba-12345.myshopify.com" || shop_name == "hello-cheese.myshopify.com" || shop_name == "sweetworthy.myshopify.com" || shop_name == "the-cornish-scone-company.myshopify.com" || shop_name == "the-cornish-scone-company.myshopify.com" || shop_name == "sgrocerie.myshopify.com" || shop_name == "maison-duffour.myshopify.com") //  */
                if (parseInt(data.exclude_block_date_status) == 0) {
                    tempdate.setDate(tempdate.getDate() + parseInt(start_from));
                    while (temp_count != -1) {
                        var date = tempdate.getDate();
                        var month = tempdate.getMonth() + 1;
                        var year = tempdate.getFullYear();
                        NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                        NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                        current_available_day = weekday[tempdate.getDay()];
                        if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                            index_of = block_date_array.indexOf(NextDayDMY);
                            block_date_array.splice(index_of, 1);
                            start_from = parseInt(start_from) + 1;
                            temp_count = start_from;
                        } else if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                            index_of = block_days_array.indexOf(current_available_day);
                            start_from = parseInt(start_from) + 1;
                            temp_count = start_from;
                        } else {
                            temp_count = -1;
                        }
                        tempdate.setDate(tempdate.getDate() + 1);
                    }
                } else {
                    if (temp_count == 0) {
                        if (block_date_array.length > 0 || block_days_array.length > 0) {
                            while ((block_date_array.length > 0 || block_days_array.length > 0) && temp_count > -1) {
                                var date = tempdate.getDate();
                                var month = tempdate.getMonth() + 1;
                                var year = tempdate.getFullYear();
                                NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                                NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                                current_available_day = weekday[tempdate.getDay()];

                                if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                                    index_of = block_date_array.indexOf(NextDayDMY);
                                    block_date_array.splice(index_of, 1);
                                    start_from = parseInt(start_from) + 1;
                                    temp_count = start_from;
                                } else if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                                    index_of = block_days_array.indexOf(current_available_day);
                                    //block_days_array.splice(index_of, 1);
                                    start_from = parseInt(start_from) + 1;
                                    temp_count = start_from;
                                } else {
                                    // if (block_date_array.length <= 0 || block_days_array.length <= 0) {
                                    //     temp_count = -1;
                                    // } else if (temp_count == 0) {
                                    //     temp_count = -1;
                                    // } else {
                                    //     temp_count--;
                                    // }
                                    var start_from_date = new Date();
                                    start_from_date.setDate(start_from_date.getDate() + parseInt(original_start_from));
                                    if (tempdate.getTime() >= start_from_date.getTime()) {
                                        temp_count = -1;
                                        block_days_array = [];
                                    }
                                }
                                tempdate.setDate(tempdate.getDate() + 1);
                            }
                        }
                    } else {
                        var original_block_dates_length = block_date_array.length;
                        while ((block_date_array.length > 0 || block_days_array.length > 0) && temp_count != -1) {
                            var date = tempdate.getDate();
                            var month = tempdate.getMonth() + 1;
                            var year = tempdate.getFullYear();
                            NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                            NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                            current_available_day = weekday[tempdate.getDay()];
                            if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                                // console.log('in if')
                                index_of = block_days_array.indexOf(current_available_day);
                                temp_count = 0;
                                var current_date = new Date();
                                var start_from_date = new Date();
                                // console.log('start_from inner',start_from_date,original_block_dates_length)
                                //block_days_array.splice(index_of, 1);
                                if(tempdate.getTime() > start_from_date.getTime() && original_block_dates_length == 0){
                                    start_from = ((parseInt(start_from) == 1 && weekday[current_date.getDay()] != current_available_day)) ? (parseInt(start_from) + 1) : parseInt(start_from);
                                }else{
                                    start_from = (parseInt(start_from) > 1 || (parseInt(start_from) == 1 && weekday[current_date.getDay()] == current_available_day)) ? (parseInt(start_from) + 1) : parseInt(start_from);
                                }
                                temp_count = start_from;
                                // console.log(weekday,weekday[current_date.getDay()],current_available_day,tempdate.getDay(),block_days_array,$zestard_jq.inArray(current_available_day, block_days_array),temp_count)

                            } else if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                                var start_from_date = new Date();
                                // console.log('in if else',(tempdate.getTime() > start_from_date.getTime()))
                                temp_count = 0;
                                index_of = block_date_array.indexOf(NextDayDMY);
                                block_date_array.splice(index_of, 1);
                                start_from = parseInt(start_from) + 1;
                                temp_count = start_from;
                            } else {

                                /* 1 Aug 2018 */
                                var start_from_date = new Date();
                                start_from_date.setDate(start_from_date.getDate() + parseInt(original_start_from));
                                if (tempdate.getTime() >= start_from_date.getTime()) {
                                    temp_count = -1;
                                    block_days_array = [];
                                }

                            }
                            tempdate.setDate(tempdate.getDate() + 1);

                        }
                    }
                }
            }
        });
        date_main_timeout = setTimeout(function() {
            var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            console.log('unavailableDates',unavailableDates);
            function unavailable(date) {
                ymd = date.getFullYear() + "/" + ("0" + (date.getMonth() + 1)).slice(-2) + "/" + ("0" + date.getDate()).slice(-2);
                ymd1 = ("0" + date.getDate()).slice(-2) + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + date.getFullYear();
                day = new Date(ymd).getDay();
                if ($zestard_jq.inArray(ymd1, unavailableDates) < 0 && $zestard_jq.inArray(days[day], unavailableDays) < 0) {
                    return [true, "enabled", "Book Now"];
                } else {
                    return [false, "disabled", "Booked Out"];
                }
            }
            date_picker_timeout = setTimeout(function() {
                datepicker_var = undefined;
                if(enable_external_delivery_date == 1){
                    //For keeping datepicker always open    
                    if (datepicker_on_default == 1) {
                        if (locale == "en") {
                            $zestard_jq("#datepicker_box .date-box").append("<div class='visible_datepicker'></div>");
                            $zestard_jq("#delivery-date-pro").attr("type", "hidden");
                            datepicker_var = $zestard_jq(".visible_datepicker").datepicker({
                                dateFormat: date_formate,
                                minDate: start_from,
                                maxDate: "'" + allowed_month + "'",
                                beforeShowDay: unavailable,
                                onSelect: function(dateText) {
                                    console.log(dateText)
                                    if($zestard_jq("[action='/cart']").length > 0){
                                        $zestard_jq(".delivery-date-hidden").remove();
                                        // $zestard_jq(".delivery-time-hidden").remove();
                                        $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                        order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                        delivery_time = $zestard_jq("#delivery-time").val();
                                        // $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-time-hidden" name="attributes[Delivery-Time]" value="'+ delivery_time +'">');
                                        console.log(order_type,dateText,delivery_time,1)
                                        var data = { attributes: {} };
                                        data.attributes['Order-Type'] = order_type;
                                        data.attributes['Delivery-Date'] = dateText;
                                        data.attributes['Store-Pickup-Location-Name'] = '';
                                        data.attributes['Store-Pickup-Address'] = '';
                                        data.attributes['Postal-Code'] = '';
                                        // data.attributes['Delivery-Time'] = delivery_time;

                                        $zestard_jq.ajax({
                                            type: 'POST',
                                            url: '/cart/update.js',
                                            data: data,
                                            dataType: 'json',
                                            success: function(responseData) { 
                                              console.log(responseData);
                                            }
                                        });
                                    }
                                    disable_today_highlight();
                                    if (deliverytime_global_status == 0  && app_version == 3) {
                                        delivery_date_pro_div(dateText);
                                    }
                                },
                                beforeShow: function() {
                                    zindex_timeout = setTimeout(function() {
                                        $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                    }, 0);
                                }
                            });
                            if (datepicker_default_date == 1) {
                                console.log(start_from,'start_from')
                                datepicker_var.datepicker("setDate", start_from);
                                // $zestard_jq(".visible_datepicker").trigger('onSelect');
                            }
                        } else {
                            $.getScript( base_path_delivery_date + "js/locale_js/datepicker-" + locale + ".js", function( data, textStatus, jqxhr ) {
                                //$zestard_jq.datepicker.setDefaults($zestard_jq.datepicker.regional[locale]); 
                                $zestard_jq("#datepicker_box .date-box").append("<div class='visible_datepicker'></div>");
                                $zestard_jq('.visible_datepicker').addClass('notranslate');
                                $zestard_jq("#delivery-date-pro").attr("type", "hidden");
                                datepicker_var = $zestard_jq(".visible_datepicker").datepicker({
                                    dateFormat: date_formate,
                                    minDate: start_from,
                                    maxDate: "'" + allowed_month + "'",
                                    beforeShowDay: unavailable,
                                    defaultDate: null,
                                    onSelect: function(dateText) {
                                        if($zestard_jq("[action='/cart']").length > 0){
                                            $zestard_jq(".delivery-date-hidden").remove();
                                            // $zestard_jq(".delivery-time-hidden").remove();
                                            $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                            order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                            delivery_time = $zestard_jq("#delivery-time").val();
                                            // $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-time-hidden" name="attributes[Delivery-Time]" value="'+ delivery_time +'">');console.log(order_type,dateText,delivery_time,1)
                                            var data = { attributes: {} };
                                            data.attributes['Order-Type'] = order_type;
                                            data.attributes['Delivery-Date'] = dateText;
                                            data.attributes['Store-Pickup-Location-Name'] = '';
                                            data.attributes['Store-Pickup-Address'] = '';
                                            data.attributes['Postal-Code'] = '';
                                            // data.attributes['Delivery-Time'] = delivery_time;

                                            $zestard_jq.ajax({
                                                type: 'POST',
                                                url: '/cart/update.js',
                                                data: data,
                                                dataType: 'json',
                                                success: function(responseData) { 
                                                  console.log(responseData);
                                                }
                                            });
                                        }
                                        $zestard_jq.getScript( base_path_delivery_date + "js/locale_js/datepicker-" + locale + ".js");
                                        if (deliverytime_global_status == 0  && app_version == 3) {
                                            delivery_date_pro_div(dateText);
                                        }
                                        $zestard_jq('.zAddToCart').prop('disabled', false);
                                        disable_today_highlight();
                                    },
                                    beforeShow: function() {
                                        zindex_timeout = setTimeout(function() {
                                            $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                        }, 0);
                                    }
                                });
                            });
                        }
                    } else {
                        if (locale == "en") {
                            $zestard_jq.datepicker.setDefaults($zestard_jq.datepicker.regional[locale]);
                            datepicker_var = $zestard_jq("#delivery-date-pro").datepicker({
                                dateFormat: date_formate,
                                minDate: start_from,
                                maxDate: "'" + allowed_month + "'",
                                onSelect: function(dateText) {
                                    if($zestard_jq("[action='/cart']").length > 0){
                                        $zestard_jq(".delivery-date-hidden").remove();
                                        // $zestard_jq(".delivery-time-hidden").remove();
                                        $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                        order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                        delivery_time = $zestard_jq("#delivery-time").val();
                                        // $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-time-hidden" name="attributes[Delivery-Time]" value="'+ delivery_time +'">');
                                        console.log(order_type,dateText,delivery_time,1)
                                        var data = { attributes: {} };
                                        data.attributes['Order-Type'] = order_type;
                                        data.attributes['Delivery-Date'] = dateText;
                                        data.attributes['Store-Pickup-Location-Name'] = '';
                                        data.attributes['Store-Pickup-Address'] = '';
                                        data.attributes['Postal-Code'] = '';
                                        // data.attributes['Delivery-Time'] = delivery_time;

                                        $zestard_jq.ajax({
                                            type: 'POST',
                                            url: '/cart/update.js',
                                            data: data,
                                            dataType: 'json',
                                            success: function(responseData) { 
                                              console.log(responseData);
                                            }
                                        });
                                    }
                                    $zestard_jq('.zAddToCart').prop('disabled', false);
                                    if (deliverytime_global_status == 0  && app_version == 3) {
                                        delivery_date_pro_div(dateText);
                                    }
                                    disable_today_highlight();
                                    //console.log($zestard_jq("#delivery-date-pro").val());
                                },
                                beforeShowDay: unavailable,
                                defaultDate: null,
                                beforeShow: function() {
                                    zindex_timeout = setTimeout(function() {
                                        $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                    }, 0);
                                }
                            });
                        } else {
                            //$zestard_jq.datepicker.setDefaults($zestard_jq.datepicker.regional[locale]);
                            datepicker_var = $zestard_jq("#delivery-date-pro").datepicker({
                                dateFormat: date_formate,
                                minDate: start_from,
                                maxDate: "'" + allowed_month + "'",
                                onSelect: function(dateText) {
                                    if($zestard_jq("[action='/cart']").length > 0){
                                        $zestard_jq(".delivery-date-hidden").remove();
                                        // $zestard_jq(".delivery-time-hidden").remove();
                                        $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                        order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                        delivery_time = $zestard_jq("#delivery-time").val();
                                        // $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-time-hidden" name="attributes[Delivery-Time]" value="'+ delivery_time +'">');                                    console.log(order_type,dateText,delivery_time,1)
                                        var data = { attributes: {} };
                                        data.attributes['Order-Type'] = order_type;
                                        data.attributes['Delivery-Date'] = dateText;
                                        data.attributes['Store-Pickup-Location-Name'] = '';
                                        data.attributes['Store-Pickup-Address'] = '';
                                        data.attributes['Postal-Code'] = '';
                                        // data.attributes['Delivery-Time'] = delivery_time;

                                        $zestard_jq.ajax({
                                            type: 'POST',
                                            url: '/cart/update.js',
                                            data: data,
                                            dataType: 'json',
                                            success: function(responseData) { 
                                              console.log(responseData);
                                            }
                                        });
                                    }
                                    //$zestard_jq('#AddToCart').prop('disabled', false);
                                    $zestard_jq('.zAddToCart').prop('disabled', false);
                                    if (deliverytime_global_status == 0  && app_version == 3) {
                                        delivery_date_pro_div(dateText);
                                    }

                                    var userLang = navigator.language || navigator.userLanguage;
                                    //console.log ("The language is: " + userLang);
                                    disable_today_highlight();

                                },
                                beforeShowDay: unavailable,
                                beforeShow: function() {
                                    zindex_timeout = setTimeout(function() {
                                        $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                    }, 0);
                                }
                            });
                        }
                    }

                    if (app_version == 1 && datepicker_on_default == 1) {
                        remove_default_date();
                    }
                    if (app_version > 1 && type_of_app > 1) {
                        if (datepicker_default_date == 1) {
                            $zestard_jq("#delivery-date-pro").datepicker("setDate", "today + start_from");
                        } else {
                            $zestard_jq('.visible_datepicker').datepicker('setDate', null);
                        }
                    }
                }else{
                    $zestard_jq('#External-Delivery').find('.date-box').remove();
                }
            }, 300)
            $zestard_jq("#delivery-date-pro").prop("disabled", false);
        }, 100);
        $zestard_jq("#delivery-date-pro").prop("disabled", false);
        //Check App Version if it is 3(i.e Enterprise) or more then it will Exceute Following Code For Multiple Cut Off and Delivery Time
        if (app_version > 2 && type_of_app > 2) {
            if (deliverytime_global_status == 0) {
                delivery_date_pro();
                var result = "";
                $zestard_jq.ajax({
                    url: base_path_delivery_date + "delivery-times",
                    data: { shop_name: shop_name, start_from: start_from, date_format: date_formate },
                    async: false,
                    success: function(response) {
                        if (response == 0) {
                            $zestard_jq("#delivery-time").html("");
                        } else {
                            $zestard_jq("#delivery-time").html("");
                            $zestard_jq("#delivery-time").append("<option value=''>Choose Time</option>");
                            for (var key in response) {
                                $zestard_jq("#delivery-time").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                            }
                        }
                    }
                });
            } else {
                $zestard_jq("#delivery-time").html("");
                $zestard_jq(time_array).each(function() {
                    $zestard_jq('#delivery-time').append("<option value='" + time_array[time_count] + "'" + ">" + time_array[time_count] + "</option>");
                    time_count++;
                });
            }
        }
        button_timeout = setTimeout(function() {
            $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
            $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
        }, 3000);

        note_timeout = setTimeout(function() {
            // if (shop_name == "cheeseschool.myshopify.com") {
            //     textarea_variable = $zestard_jq('.delivery_date_pro textarea[name=note]');
            // } else {
                textarea_variable = $zestard_jq('textarea[name=note]');
            // }
            old_order_note = textarea_variable.val();
            if (old_order_note) {
                open_index = old_order_note.indexOf("(Delivery Date:");
                if (open_index > -1) {
                    textarea_variable.html(old_order_note.substring(0, open_index - 1));
                }
            }
        }, 500);

        checkout_click_timeout = setTimeout(function() {
            $zestard_jq('input[name=checkout], button[name=checkout], .googlepay, .paypal-button, input#checkout').on('click', function(event) {
                var date = $zestard_jq('#date').val($zestard_jq('#delivery-date-pro').val());
                var time = $zestard_jq('#time').val($zestard_jq('#delivery-time').val());

                // if (shop_name == "bokis-florist-newbury-2.myshopify.com") {
                //     $zestard_jq("#delivery-date-pro").removeClass("error");
                // }
                if (datepicker_on_default == 1) {
                    var temp_date = $zestard_jq(".visible_datepicker").val();
                    $zestard_jq("#delivery-date-pro").val(temp_date);
                }

                var cart_date = $zestard_jq('#delivery-date-pro').val();
                var cart_time = $zestard_jq('#delivery-time').val();
                $zestard_jq('#cart_date').attr('value', cart_date);
                $zestard_jq('#cart_time').attr('value', cart_time);
                order_note = '';
                old_order_note = '';
                if (app_status == 'Active') {
                    if (is_date_required == true && ((typeof $zestard_jq('#delivery-date-pro').val() == 'undefined') || ($zestard_jq('#delivery-date-pro').val() == ''))) {
                        // if (shop_name == 'pastaldente.myshopify.com') {
                        //     $zestard_jq('.alert_mesg').text(date_error_message);
                        // } else {
                            alert(date_error_message);
                        // }
                        $zestard_jq('#delivery-date-pro').focus();
                        return false;
                        event.preventDefault();
                    }

                    if (is_time_required == true && ((typeof $zestard_jq('#delivery-time').val() == 'undefined') || ($zestard_jq('#delivery-time').val() == ''))) {
                        alert(time_error_message);
                        $zestard_jq('#delivery-time').focus();
                        return false;
                    }
                    console.log('add_delivery_information',add_delivery_information,textarea_variable)
                    if (add_delivery_information == 1) {
                        order_note = textarea_variable.val();
                        old_order_note = textarea_variable.val();
                    }
                    //Check Blocked Days and Dates  

                    if ($zestard_jq('#delivery-date-pro').val() != '') {
                        selected_delivery_date = $zestard_jq('#delivery-date-pro').val();
                        formatted_delivery_date = selected_delivery_date;
                        var blocked_status, json_response, blocked_date_status;
                        var todays_date = $zestard_jq('#delivery-date-pro').val();
                        var today = new Date(todays_date).getDay();
                        $zestard_jq.ajax({
                            url: base_path_delivery_date + "check-blocked-day",
                            data: { todays_date: todays_date, date_format: date_formate, shop_name: shop_name },
                            async: false,
                            success: function(result) {
                                console.log(result);
                                json_response = $zestard_jq.parseJSON(result);
                            }
                        });
                        blocked_status = json_response.result;

                        $zestard_jq.ajax({
                            url: base_path_delivery_date + "check-blocked-date",
                            data: { delivery_date: todays_date, date_format: date_formate, shop_name: shop_name },
                            async: false,
                            success: function(response) {
                                blocked_date_status = response;
                            }
                        });

                        if (blocked_status == 0) {
                            alert('Sorry Delivery is Not Possible for ' + json_response.today + ' . Please Select Other Day');
                            event.preventDefault();
                        }
                        if (blocked_date_status == 0) {
                            alert('Sorry, The Delivery Date You Selected is Blocked. Please Select Other Delivery Date');
                            event.preventDefault();
                        }
                        console.log('add_delivery_information',add_delivery_information)
                        if (blocked_date_status == 1 && blocked_status == 1) {
                            $zestard_jq.ajax({
                                url: base_path_delivery_date + "check-cuttoff",
                                data: { start_from: start_from, date_format: date_formate, delivery_date: formatted_delivery_date, store_hour: store_hour, store_minute: store_minute, shop_name: shop_name, store_date: store_date },
                                async: false,
                                success: function(result) {
                                    cutoff_response = result;
                                }
                            });

                            if (add_delivery_information == 1) {
                                old_order_note = textarea_variable.val();
                                if (old_order_note) {
                                    open_index = old_order_note.indexOf("(Delivery Date:");
                                    if (open_index > -1) {
                                        textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                    }
                                }
                                // if (shop_name == "virginiamaryflorist.myshopify.com") {
                                    if (order_note == "" || typeof order_note === "undefined") {
                                        order_note = ($zestard_jq('#delivery-time').val() != '') ? " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val() : " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val() + ")";
                                    } else {
                                        order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val();
                                        order_note = ($zestard_jq('#delivery-time').val() != '') ? order_note : order_note + ")";
                                    }
                                    if ($zestard_jq('#delivery-time').val() != '') {
                                        order_note = ($zestard_jq('#delivery-date-pro').val() != '') ? order_note + ", Delivery Time: " + $zestard_jq('#delivery-time').val() + ")" : order_note + "(Delivery Time: " + $zestard_jq('#delivery-time').val() + ")";
                                    }
                                // }
                            }
                            if (cutoff_response == 1) {
                                if ($zestard_jq("#delivery-time").val() == "" || typeof $zestard_jq('#delivery-date-pro').val() === 'undefined') {
                                    if (is_time_required == true) {
                                        // if (shop_name == "alacena-de-monica-prueba-12345.myshopify.com") {
                                        //     alert("Para continuar selecciona el horario de envío");
                                        //     $zestard_jq('#delivery-time').focus();
                                        //     event.preventDefault();
                                        // } else {
                                            alert(time_error_message);
                                            $zestard_jq('#delivery-time').focus();
                                            event.preventDefault();
                                        // }
                                    } else {
                                        if (add_delivery_information == 1) {
                                            old_order_note = textarea_variable.val();
                                            if (old_order_note) {
                                                open_index = old_order_note.indexOf("(Delivery Date:");
                                                if (open_index > -1) {
                                                    textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                                }
                                            }
                                            order_note = old_order_note;
                                            // if (shop_name == "virginiamaryflorist.myshopify.com") {
                                                if (order_note == "" || typeof order_note === "undefined") {
                                                    order_note = ($zestard_jq('#delivery-time').val() != '') ? " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val() : " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val() + ")";
                                                } else {
                                                    order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val();
                                                    order_note = ($zestard_jq('#delivery-time').val() != '') ? order_note : order_note + ")";
                                                }
                                                if ($zestard_jq('#delivery-time').val() != '') {
                                                    order_note = ($zestard_jq('#delivery-date-pro').val() != '') ? order_note + ", Delivery Time: " + $zestard_jq('#delivery-time').val() + ")" : order_note + "(Delivery Time: " + $zestard_jq('#delivery-time').val() + ")";
                                                }
                                            // }
                                            textarea_variable.val(order_note);
                                        }
                                    }
                                } else {
                                    if (add_delivery_information == 1) {
                                        old_order_note = textarea_variable.val();
                                        if (old_order_note) {
                                            open_index = old_order_note.indexOf("(Delivery Date:");
                                            if (open_index > -1) {
                                                textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                            }
                                        }
                                        order_note = old_order_note;
                                        // if (shop_name == "virginiamaryflorist.myshopify.com") {
                                            if (order_note == "" || typeof order_note === "undefined") {
                                                order_note = ($zestard_jq('#delivery-time').val() != '') ? " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val() : " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val() + ")";
                                            } else {
                                                order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val();
                                                order_note = ($zestard_jq('#delivery-time').val() != '') ? order_note : order_note + ")";
                                            }
                                            if ($zestard_jq('#delivery-time').val() != '') {
                                                order_note = ($zestard_jq('#delivery-date-pro').val() != '') ? order_note + ", Delivery Time: " + $zestard_jq('#delivery-time').val() + ")" : order_note + "(Delivery Time: " + $zestard_jq('#delivery-time').val() + ")";
                                            }
                                        // }
                                        textarea_variable.val(order_note);
                                    }
                                    if (deliverytime_global_status == 0) {
                                        $zestard_jq.ajax({
                                            url: base_path_delivery_date + "check-delivery-time",
                                            data: { delivery_time: $zestard_jq("#delivery-time").val(), date_format: date_formate, delivery_date: formatted_delivery_date, shop_name: shop_name },
                                            async: false,
                                            success: function(result) {
                                                deliverytime_response = result;
                                            }
                                        });
                                        if (deliverytime_response == 1 && $zestard_jq("#delivery-time").val() == null && is_time_required == true) {
                                            alert("Sorry No Time Slots Available For " + $zestard_jq("#delivery-date-pro").val() + " Please Select Other Date");
                                            event.preventDefault();
                                        }else if (deliverytime_response == 1) {

                                        } else {
                                            alert("Selected Delivery Time Slot is Full. Please Select Other Delivery Time");
                                            event.preventDefault();
                                        }
                                    }
                                }
                            }
                            if (cutoff_response == 0) {
                                alert("Cut Off Time is Over Please Select Other Delivery Date");
                                event.preventDefault();
                            }
                            if (cutoff_response == 2) {
                                alert("Sorry You Cannot Select " + $zestard_jq("#delivery-date-pro").val() + " As Delivery Date");
                                event.preventDefault();
                            }
                        }
                    }
                }
            });
            $zestard_jq('#delivery-time').on('change', function(){
                var data = { attributes: {} };
                // data.attributes['Order-Type'] = order_type;
                // data.attributes['Delivery-Date'] = dateText;
                data.attributes['Store-Pickup-Location-Name'] = '';
                data.attributes['Store-Pickup-Address'] = '';
                data.attributes['Postal-Code'] = '';
                data.attributes['Delivery-Time'] = $zestard_jq(this).val();

                $zestard_jq.ajax({
                    type: 'POST',
                    url: '/cart/update.js',
                    data: data,
                    dataType: 'json',
                    success: function(responseData) { 
                      console.log(responseData);
                    }
                });
            });
        });
        if(datepicker_default_date != 1){
            default_date_timeout = setTimeout(function () {
                $zestard_jq(".ui-state-highlight").removeClass('ui-state-highlight');
                $zestard_jq(".ui-state-hover").removeClass('ui-state-hover');
                remove_default_date();
            }, 2000);
        }else{
            default_date_timeout = setTimeout(function(){
                    $zestard_jq(".visible_datepicker").trigger('onSelect');
                    $zestard_jq('.visible_datepicker').find('.ui-state-active').trigger('click')
                    console.log('trigger123')
                    // $zestard_jq("#delivery-date-pro").trigger('onSelect');
            },3000);
        }
        
    }
    $zestard_jq('#CartSpecialInstructions').val(order_note);
    $zestard_jq('.ztpl-loader').addClass('hide');
}
function deliveryDateProStorePickup(location_id = '',region = '') {
    //Clear all timeout
    if (storepickup_zindex_timeout){clearTimeout(storepickup_zindex_timeout);}
    if (storepickup_date_picker_timeout){clearTimeout(storepickup_date_picker_timeout);}
    if (storepickup_date_main_timeout){clearTimeout(storepickup_date_main_timeout);}
    if (storepickup_button_timeout){clearTimeout(storepickup_button_timeout);}
    if (storepickup_note_timeout){clearTimeout(storepickup_note_timeout);}
    if (storepickup_default_date_timeout){clearTimeout(storepickup_default_date_timeout);}
    if (storepickup_checkout_click_timeout){clearTimeout(storepickup_checkout_click_timeout);}
    if (location_timout){clearTimeout(location_timout);}

    $zestard_jq('.ztpl-loader').removeClass('hide');
    $zestard_jq(".visible_datepicker").remove();
    $zestard_jq("#delivery-date-pro-store-pickup").datepicker('destroy');
    $zestard_jq('input[name=checkout], button[name=checkout], .googlepay, .paypal-button, input#checkout').off('click');
    $zestard_jq('#delivery-time-store-pickup').off('change');
    console.log('in pickup store',location_id,'region',region)
    store_date = $zestard_jq("#ztpl-date-format-ddmmyy").val();
    $zestard_jq("#delivery-date-pro-store-pickup").val("");
    $zestard_jq("#delivery-time-label").css('display', 'none');
    $zestard_jq("#delivery-time").removeAttr('name');
    $zestard_jq("#delivery-time-local-delivery").removeAttr('name');
    $zestard_jq("#delivery-time-store-pickup").attr('name', 'attributes[Delivery-Time]');
    if($zestard_jq('#ztpl-region-filter option:selected').val()){
        region = $zestard_jq('#ztpl-region-filter option:selected').val();
    }
    $zestard_jq.ajax({
        url: base_path_delivery_date + "get-type-and-version",
        async: false,
        data: { shop_name: shop_name },
        success: function(result) {
            data_length = result;
            if (data_length != 0) {
                app_version = result.app_version;
                type_of_app = result.type_of_app;
            } else {
                $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
                $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
                $zestard_jq("#datepicker_box_store_pickup").remove();
            }
        }
    });
    if (data_length != 0) {
        var unavailableDates = unavailableDays =[];
        var allowed_month = start_from = date_formate = '';
        var check_out_form = $zestard_jq("#delivery-date-pro-store-pickup").closest("form").attr('class');
        if (check_out_form) {
            var check_out_class_array = check_out_form.split(' ');
            if ($zestard_jq.inArray("cart-form", check_out_class_array) < 0) {
                $zestard_jq("#delivery-date-pro-store-pickup").closest("form").addClass("cart-form");
            }
        } else {
            $zestard_jq("#delivery-date-pro-store-pickup").closest("form").addClass("cart-form");
        }

        is_date_required = is_time_required = false;
        $zestard_jq.ajax({
            url: base_path_delivery_date + "getconfig?location_id="+location_id+"&state="+region,
            dataType: "json",
            async: false,
            data: {
                shop: shop_name
            },
            success: function(data) {
                app_status = data.app_status;
                locale = data.language_locale;
                datepicker_on_default = data.datepicker_display_on;
                datepicker_default_date = data.default_date_option;
                add_delivery_information = data.add_delivery_information;
                date_error_message = data.date_error_message;
                time_error_message = data.time_error_message;
                if (app_status == "Inactive") {
                    $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
                    $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
                    $zestard_jq("#datepicker_box_store_pickup").remove();
                    $zestard_jq("#ztpl-delivery-option").remove();
                }
                
                /*Show location list*/
                if(data.store_pickup_details.enable_store_pickup == 1){
                    locations = data.location_details;
                    if(data.location_details.length == 0){
                        alert('Store Pickup Location Not Available.');
                        $zestard_jq('#Store-Pickup').hide();
                        return false;
                    }
                    //Show filter
                    if(data.store_pickup_details.enable_filter_by_region == 1){
                        if(region == ''){
                            $zestard_jq('#ztpl-region-filter').html('');
                            $zestard_jq('<option>').val('').text('All').appendTo('#ztpl-region-filter');
                            var regionNames = {};
                            $zestard_jq.each(locations, function(index, value){
                                if (regionNames[value.state]) {} else {
                                    regionNames[value.state] = value.state;
                                    $zestard_jq('<option>').val(value.state).text(value.state).appendTo('#ztpl-region-filter');
                                }
                            });
                        }
                        $zestard_jq('.ztpl-region-filter').css('display','block');
                    }
                    if(location_id == ''){
                        $zestard_jq('#ztpl-locations-list').html('');
                        for (var key in locations) {
                            var first_active = first_checked = '';
                            if(key == 0){
                                first_checked = 'checked';
                                first_active = 'active';
                            }
                            $zestard_jq('#ztpl-locations-list').append("<div class='ztpl-store-location'><input type='radio' name='storepickup_location_id' class='ztpl-location-radio "+first_active+"' value='"+locations[key].id+"' "+first_checked+" data-address='"+locations[key].full_address+"' data-name='"+locations[key].company_name+"'><span class='ztpl-location-span'><strong>"+locations[key].company_name+"</strong><br><span>"+locations[key].full_address+"</span></span></div>");
                        }
                    }
                }

                var admin_time_status = data.admin_time_status;
                var store_pickup_time_status = data.store_pickup_details.enable_storepickup_delivery_time;
                enable_storepickup_delivery_date = data.store_pickup_details.enable_storepickup_delivery_date;
                enable_storepickup_location_delivery_date = data.store_pickup_details.fn_store_pickup_locations[0].enable_pickup_date;
                var store_pickup_location_time_status = data.store_pickup_details.fn_store_pickup_locations[0].enable_pickup_time;
                // Add time is required attribute
                if (data.require_option == 1 && store_pickup_time_status == 1 && store_pickup_location_time_status == 1) {
                    is_date_required = true;
                    $zestard_jq("#delivery-date-pro-store-pickup").attr("required", "true");
                    $zestard_jq("#delivery-date-pro-store-pickup").closest("form").removeAttr('novalidate');
                }

                var date_label = data.datepicker_label;
                show_datepicker_label = data.show_datepicker_label;
                if (show_datepicker_label == 1) {
                    $zestard_jq('.date-box label').text(date_label);
                } else {
                    $zestard_jq('.date-box label').hide();
                }
                console.log(data.store_pickup_details);
                // convert date as per date picker format
                // var dates = data.store_pickup_details.fn_store_pickup_locations[0].store_pickup_block_dates;
                var dates = (data.store_pickup_details.fn_store_pickup_locations[0].block_dates.length > 0) ? data.store_pickup_details.fn_store_pickup_locations[0].store_pickup_block_dates: data.store_pickup_details.fn_store_pickup_locations[0].block_dates;
                if(dates.length > 0){
                    $zestard_jq.each( dates, function( key, value ) {
                        dates[key] = value.replaceAll("/", "-");
                    });
                }
                var day = data.store_pickup_details.fn_store_pickup_locations[0].block_days;
                start_from = '+' + data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel;
                allowed_month = '+' + data.store_pickup_details.fn_store_pickup_locations[0].allowed_preorder_time + 'M';
                unavailableDates = dates;
                unavailableDays = day;
                date_formate = data.date_format;
                cutoff_status = data.store_pickup_details.fn_store_pickup_locations[0].cuttoff_status;
                cutoff_global_status = data.cutoff_global_status;
                deliverytime_global_status = data.deliverytime_global_status;
                cutoff_global_hours = data.store_pickup_details.fn_store_pickup_locations[0].hours;
                cutoff_global_minute = data.store_pickup_details.fn_store_pickup_locations[0].minute;
                var current_date = $zestard_jq("#ztpl-current-date").val();
                if(store_hour == '' || isNaN(store_hour) ){
                    store_hour = $zestard_jq("#ztpl-store-hour").val();
                }
                if(store_minute == '' || isNaN(store_minute)){
                    store_minute = $zestard_jq("#ztpl-store-minute").val();
                }
                
                if (date_formate == "mm/dd/yy") {
                    var display_format = "(mm/dd/yyyy)";
                } else if (date_formate == "yy/mm/dd") {
                    var display_format = "(yyyy/mm/dd)";
                } else if (date_formate == "dd/mm/yy") {
                    var display_format = "(dd/mm/yyyy)";
                } else {
                    var display_format = "(mm/dd/yyyy)";
                }

                var show_date_format = data.show_date_format;
                if (show_date_format == 1) {
                    if (display_format != "") {
                        $zestard_jq(".selected_format").text(display_format);
                    } else {
                        $zestard_jq(".selected_format").text('mm/dd/yyyy');
                    }
                }
                var admin_note_status = data.admin_note_status;
                var notes_admin = data.admin_order_note;
                if (admin_note_status == 1) {
                    $zestard_jq(".admin_notes").html($zestard_jq.parseHTML(notes_admin));
                }

                var time_lable = data.time_label;
                var default_option_label = data.time_default_option_label;
                if (admin_time_status == 1 && store_pickup_time_status == 1 && store_pickup_location_time_status == 1) {
                    var time_in_text = data.store_pickup_details.fn_store_pickup_locations[0].pickup_time;           time_array = new Array();
                    time_array = time_in_text.split(",");
                    time_count = 0;
                    $zestard_jq("#delivery-time-store-pickup").css('display', 'block');
                    $zestard_jq("#delivery-time-store-pickup").css('border', 'none');
                    $zestard_jq("#time_option_label").text(default_option_label);
                    $zestard_jq("#delivery-time-store-pickup").html("");
                    if(default_option_label){
                        $zestard_jq("#delivery-time-store-pickup").append("<option id='time_option_label' value='' readonly>"+default_option_label+"</option>");
                    }
                    //if (app_version <= 2 && type_of_app <= 2)
                    if ((app_version <= 2 && type_of_app <= 2) || (app_version == 4 && type_of_app == 4)) {
                        $zestard_jq(time_array).each(function() {
                            $zestard_jq('#delivery-time-store-pickup').append("<option value='" + time_array[time_count] + "'" + ">" + time_array[time_count] + "</option>");
                            time_count++;
                        });
                    }
                    $zestard_jq(".delivery-time-label").show();
                    $zestard_jq(".delivery-time-label").text(time_lable);
                    if (data.time_require_option == 1) {
                        is_time_required = true;
                        $zestard_jq("#delivery-time-store-pickup").attr("required", "true");
                        $zestard_jq("#delivery-date-pro-store-pickup").closest("form").removeAttr('novalidate');
                    }
                }else{
                    $zestard_jq("#delivery-time-store-pickup").css('display', 'none');
                    $zestard_jq("#Store-Pickup").find('#delivery-time-label').css('display', 'none');
                }
                var additional_css = data.additional_css;
                $zestard_jq('#datepicker_box_store_pickup').after("<style>" + additional_css + "</style>");
                //Change Variable Name
                var str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel);
                if (parseInt(cutoff_status) == 1) {
                    //Check App Version if it is 3(i.e Enterprise) or more then it will Exceute Following Code For Multiple Cut Off and Delivery Time  
                    if (app_version == 3 && type_of_app == 3) {
                        if (cutoff_global_status == 1) {
                            cutoff_hours = cutoff_global_hours;
                            cutoff_minute = cutoff_global_minute;
                            if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                                if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                    str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel);
                                } else {
                                    if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                        str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel);
                                    } else {
                                        str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel) + 1;
                                    }
                                }
                            } else {
                                str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel) + 1;
                            }
                        } else {
                            var c_day = new Date().getDay();
                            $zestard_jq.ajax({
                                url: base_path_delivery_date + "get-cutoff-time",
                                data: { day: c_day, shop_name: shop_name },
                                async: false,
                                success: function(response) {
                                    var json_data = JSON.parse(response);
                                    cutoff_hours = json_data['cutoff_hour'];
                                    cutoff_minute = json_data['cutoff_minute'];
                                }
                            });
                            if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                                if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                    str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel);
                                } else {
                                    if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                        str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel);
                                    } else {
                                        str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel) + 1;
                                    }
                                }
                            } else {
                                str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel) + 1;
                            }
                        }
                    } else {
                        cutoff_hours = cutoff_global_hours;
                        cutoff_minute = cutoff_global_minute;
                        if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                            if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel);
                            } else {
                                if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                    str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel);
                                } else {
                                    str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel) + 1;
                                }
                            }
                        } else {
                            str = parseInt(data.store_pickup_details.fn_store_pickup_locations[0].minimum_date_intervel) + 1;
                        }
                    }
                }
                start_from = '+' + parseInt(str);
                original_start_from = start_from;

                function pad(n) {
                    return (n < 10) ? ("0" + n) : n;
                }
                var tempdate = new Date();
                tempdate.setDate(tempdate.getDate());
                var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                var block_date_array = dates;
                var block_days_array = unavailableDays;
                var NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                var NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                var current_available_day = weekday[tempdate.getDay()];
                exit_flag = 0;
                temp_count = start_from;
                if (!block_days_array) {
                    block_days_array = new Array();
                }
                if (!block_date_array) {
                    block_date_array = new Array();
                }
                /* if (shop_name == "sunshine-milk-bread.myshopify.com" || shop_name == "greenox.myshopify.com" || shop_name == "petaljet.myshopify.com" || shop_name == "alacena-de-monica-prueba-12345.myshopify.com" || shop_name == "hello-cheese.myshopify.com" || shop_name == "sweetworthy.myshopify.com" || shop_name == "the-cornish-scone-company.myshopify.com" || shop_name == "the-cornish-scone-company.myshopify.com" || shop_name == "sgrocerie.myshopify.com" || shop_name == "maison-duffour.myshopify.com") //  */
                if (parseInt(data.store_pickup_details.fn_store_pickup_locations[0].block_days_interval) == 2) {
                    tempdate.setDate(tempdate.getDate() + parseInt(start_from));
                    while (temp_count != -1) {
                        var date = tempdate.getDate();
                        var month = tempdate.getMonth() + 1;
                        var year = tempdate.getFullYear();
                        NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                        NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                        current_available_day = weekday[tempdate.getDay()];
                        if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                            index_of = block_date_array.indexOf(NextDayDMY);
                            block_date_array.splice(index_of, 1);
                            start_from = parseInt(start_from) + 1;
                            temp_count = start_from;
                        } else if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                            index_of = block_days_array.indexOf(current_available_day);
                            start_from = parseInt(start_from) + 1;
                            temp_count = start_from;
                        } else {
                            temp_count = -1;
                        }
                        tempdate.setDate(tempdate.getDate() + 1);
                    }
                } else {
                    if (temp_count == 0) {
                        if (block_date_array.length > 0 || block_days_array.length > 0) {
                            while ((block_date_array.length > 0 || block_days_array.length > 0) && temp_count > -1) {
                                var date = tempdate.getDate();
                                var month = tempdate.getMonth() + 1;
                                var year = tempdate.getFullYear();
                                NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                                NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                                current_available_day = weekday[tempdate.getDay()];

                                if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                                    index_of = block_date_array.indexOf(NextDayDMY);
                                    block_date_array.splice(index_of, 1);
                                    start_from = parseInt(start_from) + 1;
                                    temp_count = start_from;
                                } else if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                                    index_of = block_days_array.indexOf(current_available_day);
                                    //block_days_array.splice(index_of, 1);
                                    start_from = parseInt(start_from) + 1;
                                    temp_count = start_from;
                                } else {
                                    // if (block_date_array.length <= 0 || block_days_array.length <= 0) {
                                    //     temp_count = -1;
                                    // } else if (temp_count == 0) {
                                    //     temp_count = -1;
                                    // } else {
                                    //     temp_count--;
                                    // }
                                    var start_from_date = new Date();
                                    start_from_date.setDate(start_from_date.getDate() + parseInt(original_start_from));
                                    if (tempdate.getTime() >= start_from_date.getTime()) {
                                        temp_count = -1;
                                        block_days_array = [];
                                    }
                                }
                                tempdate.setDate(tempdate.getDate() + 1);
                            }
                        }
                    } else {
                        var original_block_dates_length = block_date_array.length;
                        while ((block_date_array.length > 0 || block_days_array.length > 0) && temp_count != -1) {
                            var date = tempdate.getDate();
                            var month = tempdate.getMonth() + 1;
                            var year = tempdate.getFullYear();
                            NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                            NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                            current_available_day = weekday[tempdate.getDay()];
                            if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                                // console.log('in if')
                                index_of = block_days_array.indexOf(current_available_day);
                                temp_count = 0;
                                var current_date = new Date();
                                var start_from_date = new Date();
                                // console.log('start_from inner',start_from_date,original_block_dates_length)
                                //block_days_array.splice(index_of, 1);
                                if(tempdate.getTime() > start_from_date.getTime() && original_block_dates_length == 0){
                                    start_from = ((parseInt(start_from) == 1 && weekday[current_date.getDay()] != current_available_day)) ? (parseInt(start_from) + 1) : parseInt(start_from);
                                }else{
                                    start_from = (parseInt(start_from) > 1 || (parseInt(start_from) == 1 && weekday[current_date.getDay()] == current_available_day)) ? (parseInt(start_from) + 1) : parseInt(start_from);
                                }
                                temp_count = start_from;
                                // console.log(weekday,weekday[current_date.getDay()],current_available_day,tempdate.getDay(),block_days_array,$zestard_jq.inArray(current_available_day, block_days_array),temp_count)

                            } else if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                                var start_from_date = new Date();
                                // console.log('in if else',(tempdate.getTime() > start_from_date.getTime()))
                                temp_count = 0;
                                index_of = block_date_array.indexOf(NextDayDMY);
                                block_date_array.splice(index_of, 1);
                                start_from = parseInt(start_from) + 1;
                                temp_count = start_from;
                            } else {

                                /* 1 Aug 2018 */
                                var start_from_date = new Date();
                                start_from_date.setDate(start_from_date.getDate() + parseInt(original_start_from));
                                if (tempdate.getTime() >= start_from_date.getTime()) {
                                    temp_count = -1;
                                    block_days_array = [];
                                }

                            }
                            tempdate.setDate(tempdate.getDate() + 1);

                        }
                    }
                }
            }
        });
        storepickup_date_main_timeout = setTimeout(function() {
            var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
            function unavailable(date) {
                ymd = date.getFullYear() + "/" + ("0" + (date.getMonth() + 1)).slice(-2) + "/" + ("0" + date.getDate()).slice(-2);
                ymd1 = ("0" + date.getDate()).slice(-2) + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + date.getFullYear();
                day = new Date(ymd).getDay();
                if ($zestard_jq.inArray(ymd1, unavailableDates) < 0 && $zestard_jq.inArray(days[day], unavailableDays) < 0) {
                    return [true, "enabled", "Book Now"];
                } else {
                    return [false, "disabled", "Booked Out"];
                }
            }
            // Set datepicker default configuration
            storepickup_date_picker_timeout = setTimeout(function() {
                datepicker_var = undefined;
                $zestard_jq('#Store-Pickup').find('.date-box').removeClass('hide');
                if(enable_storepickup_delivery_date == 1 && enable_storepickup_location_delivery_date == 1){
                    //For keeping datepicker always open    
                    if (datepicker_on_default == 1) {
                        if (locale == "en") {
                            $zestard_jq("#datepicker_box_store_pickup .date-box").append("<div class='visible_datepicker'></div>");
                            $zestard_jq("#delivery-date-pro-store-pickup").attr("type", "hidden");
                            datepicker_var = $zestard_jq(".visible_datepicker").datepicker({
                                dateFormat: date_formate,
                                minDate: start_from,
                                maxDate: "'" + allowed_month + "'",
                                beforeShowDay: unavailable,
                                onSelect: function(dateText) {
                                    console.log('dateText',dateText)
                                    if($zestard_jq("[action='/cart']").length > 0){
                                        $zestard_jq(".delivery-date-hidden").remove();
                                        $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                        // Add store pickup information into cart attribute
                                        order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                        delivery_time = $zestard_jq("#delivery-time-store-pickup").val();
                                        store_pickup_address = $zestard_jq("input[name=storepickup_location_id]:checked").attr('data-address');
                                        store_pickup_company_name = $zestard_jq("input[name=storepickup_location_id]:checked").attr('data-name');
                                        console.log(order_type,$zestard_jq('#delivery-date-pro-store-pickup').val(),delivery_time,store_pickup_address,'checkout click')
                                        var data = { attributes: {} };
                                        data.attributes['Order-Type'] = order_type;
                                        data.attributes['Store-Pickup-Location-Name'] = store_pickup_company_name;
                                        data.attributes['Store-Pickup-Address'] = store_pickup_address;
                                        data.attributes['Delivery-Date'] = dateText;
                                        data.attributes['Delivery-Time'] = delivery_time;
                                        data.attributes['Postal-Code'] = '';

                                        $zestard_jq.ajax({
                                            type: 'POST',
                                            url: '/cart/update.js',
                                            data: data,
                                            async: false,
                                            dataType: 'json',
                                            success: function(responseData) { 
                                              console.log(responseData);
                                            }
                                        });
                                    }
                                    disable_today_highlight();
                                    // if (deliverytime_global_status == 0  && app_version == 3) {
                                    if (deliverytime_global_status == 0  && app_version == 3) {
                                        delivery_date_pro_div_store_pickup(dateText);
                                    }
                                },
                                beforeShow: function() {
                                    storepickup_zindex_timeout = setTimeout(function() {
                                        $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                    }, 0);
                                }
                            });
                            if (datepicker_default_date == 1) {
                                datepicker_var.datepicker("setDate", start_from);
                                // $zestard_jq(".visible_datepicker").trigger('onSelect');
                            }
                        } else {
                            $.getScript( base_path_delivery_date + "js/locale_js/datepicker-" + locale + ".js", function( data, textStatus, jqxhr ) {
                                //$zestard_jq.datepicker.setDefaults($zestard_jq.datepicker.regional[locale]); 
                                $zestard_jq("#datepicker_box_store_pickup .date-box").append("<div class='visible_datepicker'></div>");
                                $zestard_jq('.visible_datepicker').addClass('notranslate');
                                $zestard_jq("#delivery-date-pro-store-pickup").attr("type", "hidden");
                                datepicker_var = $zestard_jq(".visible_datepicker").datepicker({
                                    dateFormat: date_formate,
                                    minDate: start_from,
                                    maxDate: "'" + allowed_month + "'",
                                    beforeShowDay: unavailable,
                                    defaultDate: null,
                                    onSelect: function(dateText) {
                                        if($zestard_jq("[action='/cart']").length > 0){
                                            $zestard_jq(".delivery-date-hidden").remove();
                                            $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                            // Add store pickup information into cart attribute
                                            order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                            delivery_time = $zestard_jq("#delivery-time-store-pickup").val();
                                            store_pickup_address = $zestard_jq("input[name=storepickup_location_id]:checked").attr('data-address');
                                            store_pickup_company_name = $zestard_jq("input[name=storepickup_location_id]:checked").attr('data-name');
                                            console.log(order_type,$zestard_jq('#delivery-date-pro-store-pickup').val(),delivery_time,store_pickup_address,'checkout click')
                                            var data = { attributes: {} };
                                            data.attributes['Order-Type'] = order_type;
                                            data.attributes['Store-Pickup-Location-Name'] = store_pickup_company_name;
                                            data.attributes['Store-Pickup-Address'] = store_pickup_address;
                                            data.attributes['Delivery-Date'] = dateText;
                                            data.attributes['Delivery-Time'] = delivery_time;
                                            data.attributes['Postal-Code'] = '';
                                            $zestard_jq.ajax({
                                                type: 'POST',
                                                url: '/cart/update.js',
                                                data: data,
                                                async: false,
                                                dataType: 'json',
                                                success: function(responseData) { 
                                                  console.log(responseData);
                                                }
                                            });
                                        }
                                        $zestard_jq.getScript( base_path_delivery_date + "js/locale_js/datepicker-" + locale + ".js");
                                        // if (deliverytime_global_status == 0  && app_version == 3) {
                                        if (deliverytime_global_status == 0  && app_version == 3) {
                                            delivery_date_pro_div_store_pickup(dateText);
                                        }
                                        $zestard_jq('.zAddToCart').prop('disabled', false);
                                        disable_today_highlight();
                                    },
                                    beforeShow: function() {
                                        storepickup_zindex_timeout = setTimeout(function() {
                                            $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                        }, 0);
                                    }
                                });
                            });
                            // if (datepicker_default_date == 1) {
                            //     $zestard_jq(".visible_datepicker").trigger('onSelect');
                            // }
                        }
                    } else {
                        if (locale == "en") {
                            $zestard_jq.datepicker.setDefaults($zestard_jq.datepicker.regional[locale]);
                            datepicker_var = $zestard_jq("#delivery-date-pro-store-pickup").datepicker({
                                dateFormat: date_formate,
                                minDate: start_from,
                                maxDate: "'" + allowed_month + "'",
                                onSelect: function(dateText) {
                                    if($zestard_jq("[action='/cart']").length > 0){
                                        $zestard_jq(".delivery-date-hidden").remove();
                                        $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                        // Add store pickup information into cart attribute
                                        order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                        delivery_time = $zestard_jq("#delivery-time-store-pickup").val();
                                        store_pickup_address = $zestard_jq("input[name=storepickup_location_id]:checked").attr('data-address');
                                        store_pickup_company_name = $zestard_jq("input[name=storepickup_location_id]:checked").attr('data-name');
                                        console.log(order_type,$zestard_jq('#delivery-date-pro-store-pickup').val(),delivery_time,store_pickup_address,'checkout click')
                                        var data = { attributes: {} };
                                        data.attributes['Order-Type'] = order_type;
                                        data.attributes['Store-Pickup-Location-Name'] = store_pickup_company_name;
                                        data.attributes['Store-Pickup-Address'] = store_pickup_address;
                                        data.attributes['Delivery-Date'] = dateText;
                                        data.attributes['Delivery-Time'] = delivery_time;
                                        data.attributes['Postal-Code'] = '';
                                        $zestard_jq.ajax({
                                            type: 'POST',
                                            url: '/cart/update.js',
                                            data: data,
                                            async: false,
                                            dataType: 'json',
                                            success: function(responseData) { 
                                              console.log(responseData);
                                            }
                                        });
                                    }
                                    $zestard_jq('.zAddToCart').prop('disabled', false);
                                    // if (deliverytime_global_status == 0  && app_version == 3) {
                                    if (deliverytime_global_status == 0  && app_version == 3) {
                                        delivery_date_pro_div_store_pickup(dateText);
                                    }
                                    disable_today_highlight();
                                    //console.log($zestard_jq("#delivery-date-pro-store-pickup").val());
                                },
                                beforeShowDay: unavailable,
                                defaultDate: null,
                                beforeShow: function() {
                                    storepickup_zindex_timeout = setTimeout(function() {
                                        $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                    }, 0);
                                }
                            });
                        } else {
                            //$zestard_jq.datepicker.setDefaults($zestard_jq.datepicker.regional[locale]);
                            datepicker_var = $zestard_jq("#delivery-date-pro-store-pickup").datepicker({
                                dateFormat: date_formate,
                                minDate: start_from,
                                maxDate: "'" + allowed_month + "'",
                                onSelect: function(dateText) {
                                    if($zestard_jq("[action='/cart']").length > 0){
                                        $zestard_jq(".delivery-date-hidden").remove();
                                        $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                        // Add store pickup information into cart attribute
                                        order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                        delivery_time = $zestard_jq("#delivery-time-store-pickup").val();
                                        store_pickup_address = $zestard_jq("input[name=storepickup_location_id]:checked").attr('data-address');
                                        store_pickup_company_name = $zestard_jq("input[name=storepickup_location_id]:checked").attr('data-name');
                                        console.log(order_type,$zestard_jq('#delivery-date-pro-store-pickup').val(),delivery_time,store_pickup_address,'checkout click')
                                        var data = { attributes: {} };
                                        data.attributes['Order-Type'] = order_type;
                                        data.attributes['Store-Pickup-Location-Name'] = store_pickup_company_name;
                                        data.attributes['Store-Pickup-Address'] = store_pickup_address;
                                        data.attributes['Delivery-Date'] = dateText;
                                        data.attributes['Delivery-Time'] = delivery_time;
                                        data.attributes['Postal-Code'] = '';
                                        $zestard_jq.ajax({
                                            type: 'POST',
                                            url: '/cart/update.js',
                                            data: data,
                                            async: false,
                                            dataType: 'json',
                                            success: function(responseData) { 
                                              console.log(responseData);
                                            }
                                        });
                                    }
                                    //$zestard_jq('#AddToCart').prop('disabled', false);
                                    $zestard_jq('.zAddToCart').prop('disabled', false);
                                    // if (deliverytime_global_status == 0  && app_version == 3) {
                                    if (deliverytime_global_status == 0  && app_version == 3) {
                                        delivery_date_pro_div_store_pickup(dateText);
                                    }

                                    var userLang = navigator.language || navigator.userLanguage;
                                    //console.log ("The language is: " + userLang);
                                    disable_today_highlight();

                                },
                                beforeShowDay: unavailable,
                                beforeShow: function() {
                                    storepickup_zindex_timeout = setTimeout(function() {
                                        $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                    }, 0);
                                }
                            });
                        }
                    }

                    if (app_version == 1 && datepicker_on_default == 1) {
                        remove_default_date();
                    }
                    if (app_version > 1 && type_of_app > 1) {
                        if (datepicker_default_date == 1) {
                            $zestard_jq("#delivery-date-pro-store-pickup").datepicker("setDate", "today + start_from");
                            // $zestard_jq("#delivery-date-pro-store-pickup").trigger('onSelect');
                        } else {
                            $zestard_jq('.visible_datepicker').datepicker('setDate', null);
                        }
                    }
                }else{
                    $zestard_jq('#Store-Pickup').find('.date-box').addClass('hide');
                }
            }, 300)
            $zestard_jq("#delivery-date-pro-store-pickup").prop("disabled", false);
        }, 100);
        $zestard_jq("#delivery-date-pro-store-pickup").prop("disabled", false);
        //Check App Version if it is 3(i.e Enterprise) or more then it will Exceute Following Code For Multiple Cut Off and Delivery Time
        if (app_version == 3 && type_of_app == 3) {
            if (deliverytime_global_status == 0) {
                delivery_date_pro_store_pickup();
                var result = "";
                $zestard_jq.ajax({
                    url: base_path_delivery_date + "delivery-times",
                    data: { shop_name: shop_name, start_from: start_from, date_format: date_formate },
                    async: false,
                    success: function(response) {
                        if (response == 0) {
                            $zestard_jq("#delivery-time-store-pickup").html("");
                        } else {
                            $zestard_jq("#delivery-time-store-pickup").html("");
                            $zestard_jq("#delivery-time-store-pickup").append("<option value=''>Choose Time</option>");
                            for (var key in response) {
                                $zestard_jq("#delivery-time-store-pickup").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                            }
                        }
                    }
                });
            } else {
                $zestard_jq('#delivery-time-store-pickup').html('');
                $zestard_jq("#delivery-time-store-pickup").append("<option value=''>Choose Time</option>");
                $zestard_jq(time_array).each(function() {
                    $zestard_jq('#delivery-time-store-pickup').append("<option value='" + time_array[time_count] + "'" + ">" + time_array[time_count] + "</option>");
                    time_count++;
                });
            }
        }
        storepickup_button_timeout = setTimeout(function() {
            $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
            $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
        }, 3000);

        storepickup_note_timeout = setTimeout(function() {
            // if (shop_name == "cheeseschool.myshopify.com") {
            //     textarea_variable = $zestard_jq('.delivery_date_pro textarea[name=note]');
            // } else {
                textarea_variable = $zestard_jq('textarea[name=note]');
            // }
            old_order_note = textarea_variable.val();
            if (old_order_note) {
                open_index = old_order_note.indexOf("(Delivery Date:");
                if (open_index > -1) {
                    textarea_variable.html(old_order_note.substring(0, open_index - 1));
                }
            }
        }, 500);

        storepickup_checkout_click_timeout = setTimeout(function() {
            $zestard_jq('input[name=checkout], button[name=checkout], .googlepay, .paypal-button, input#checkout').on('click', function(event) {
                var date = $zestard_jq('#date').val($zestard_jq('#delivery-date-pro-store-pickup').val());
                var time = $zestard_jq('#time').val($zestard_jq('#delivery-time-store-pickup').val());
                if (datepicker_on_default == 1) {
                    var temp_date = $zestard_jq(".visible_datepicker").val();
                    $zestard_jq("#delivery-date-pro-store-pickup").val(temp_date);
                }

                var cart_date = $zestard_jq('#delivery-date-pro-store-pickup').val();
                var cart_time = $zestard_jq('#delivery-time-store-pickup').val();
                $zestard_jq('#cart_date').attr('value', cart_date);
                $zestard_jq('#cart_time').attr('value', cart_time);
                order_note = '';
                old_order_note = '';
                if (app_status == 'Active') {
                    if (is_date_required == true && ((typeof $zestard_jq('#delivery-date-pro-store-pickup').val() == 'undefined') || ($zestard_jq('#delivery-date-pro-store-pickup').val() == ''))) {
                        // if (shop_name == 'pastaldente.myshopify.com') {
                        //     $zestard_jq('.alert_mesg').text(date_error_message);
                        // } else {
                            alert(date_error_message);
                        // }
                        $zestard_jq('#delivery-date-pro-store-pickup').focus();
                        return false;
                        event.preventDefault();
                    }
                    if (is_time_required == true && ((typeof $zestard_jq('#delivery-time-store-pickup').val() == 'undefined') || ($zestard_jq('#delivery-time-store-pickup').val() == ''))) {
                        alert(time_error_message);
                        $zestard_jq('#delivery-time-store-pickup').focus();
                        return false;
                    }
                    // console.log(add_delivery_information,textarea_variable.val(),'textarea_variable')
                    if (add_delivery_information == 1) {
                        order_note = textarea_variable.val();
                        old_order_note = textarea_variable.val();
                    }
                    //Check Blocked Days and Dates  
                    if ($zestard_jq('#delivery-date-pro-store-pickup').val() != '') {
                        selected_delivery_date = $zestard_jq('#delivery-date-pro-store-pickup').val();
                        formatted_delivery_date = selected_delivery_date;
                        var blocked_status, json_response, blocked_date_status;
                        var todays_date = $zestard_jq('#delivery-date-pro-store-pickup').val();
                        var today = new Date(todays_date).getDay();
                        location_id = $zestard_jq("input[name=storepickup_location_id]:checked").val();
                        // console.log($zestard_jq("input[name=storepickup_location_id]:checked").val());
                        $zestard_jq.ajax({
                            url: base_path_delivery_date + "check-blocked-day?deliverytype=2&location_id="+location_id,
                            data: { todays_date: todays_date, date_format: date_formate, shop_name: shop_name },
                            async: false,
                            success: function(result) {
                                json_response = $zestard_jq.parseJSON(result);
                            }
                        });
                        blocked_status = json_response.result;

                        $zestard_jq.ajax({
                            url: base_path_delivery_date + "check-blocked-date?deliverytype=2&location_id="+location_id,
                            data: { delivery_date: todays_date, date_format: date_formate, shop_name: shop_name },
                            async: false,
                            success: function(response) {
                                blocked_date_status = response;
                            }
                        });

                        if (blocked_status == 0) {
                            alert('Sorry Delivery is Not Possible for ' + json_response.today + ' . Please Select Other Day');
                            event.preventDefault();
                        }
                        if (blocked_date_status == 0) {
                            alert('Sorry, The Delivery Date You Selected is Blocked. Please Select Other Delivery Date');
                            event.preventDefault();
                        }                        
                        if (blocked_date_status == 1 && blocked_status == 1) {
                            $zestard_jq.ajax({
                                url: base_path_delivery_date + "check-cuttoff?deliverytype=2&location_id="+location_id,
                                data: { start_from: start_from, date_format: date_formate, delivery_date: formatted_delivery_date, store_hour: store_hour, store_minute: store_minute, shop_name: shop_name, store_date: store_date },
                                async: false,
                                success: function(result) {
                                    cutoff_response = result;
                                }
                            });
                            //add delivery information under order note section
                            if (add_delivery_information == 1) {
                                old_order_note = textarea_variable.val();
                                if (old_order_note) {
                                    open_index = old_order_note.indexOf("(Delivery Date:");
                                    if (open_index > -1) {
                                        textarea_variable.val(old_order_note.substring(0, open_index - 1));
                                    }
                                }
                                if (order_note == "" || typeof order_note === "undefined") {
                                    order_note = ($zestard_jq('#delivery-time-store-pickup').val() != '') ? " (Delivery Date: " + $zestard_jq('#delivery-date-pro-store-pickup').val() : " (Delivery Date: " + $zestard_jq('#delivery-date-pro-store-pickup').val() + ")";
                                } else {
                                    order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro-store-pickup').val();
                                    order_note = ($zestard_jq('#delivery-time-store-pickup').val() != '') ? order_note : order_note + ")";
                                }
                                if ($zestard_jq('#delivery-time-store-pickup').val() != '') {
                                    order_note = ($zestard_jq('#delivery-date-pro-store-pickup').val() != '') ? order_note + ", Delivery Time: " + $zestard_jq('#delivery-time-store-pickup').val() + ")" : order_note + "(Delivery Time: " + $zestard_jq('#delivery-time-store-pickup').val() + ")";
                                }
                            }
                            if (cutoff_response == 1) {
                                if ($zestard_jq("#delivery-time-store-pickup").val() == "" || typeof $zestard_jq('#delivery-date-pro-store-pickup').val() === 'undefined') {
                                    if (is_time_required == true) {
                                        alert(time_error_message);
                                        $zestard_jq('#delivery-time-store-pickup').focus();
                                        event.preventDefault();
                                    } else {
                                        if (add_delivery_information == 1) {
                                            old_order_note = textarea_variable.val();
                                            if (old_order_note) {
                                                open_index = old_order_note.indexOf("(Delivery Date:");
                                                if (open_index > -1) {
                                                    textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                                }
                                            }
                                            order_note = old_order_note;
                                            if (order_note == "" || typeof order_note === "undefined") {
                                                order_note = ($zestard_jq('#delivery-time-store-pickup').val() != '') ? " (Delivery Date: " + $zestard_jq('#delivery-date-pro-store-pickup').val() : " (Delivery Date: " + $zestard_jq('#delivery-date-pro-store-pickup').val() + ")";
                                            } else {
                                                order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro-store-pickup').val();
                                                order_note = ($zestard_jq('#delivery-time-store-pickup').val() != '') ? order_note : order_note + ")";
                                            }
                                            if ($zestard_jq('#delivery-time-store-pickup').val() != '') {
                                                order_note = ($zestard_jq('#delivery-date-pro-store-pickup').val() != '') ? order_note + ", Delivery Time: " + $zestard_jq('#delivery-time-store-pickup').val() + ")" : order_note + "(Delivery Time: " + $zestard_jq('#delivery-time-store-pickup').val() + ")";
                                            }
                                            textarea_variable.val(order_note);
                                        }
                                    }
                                } else {
                                    if (add_delivery_information == 1) {
                                        old_order_note = textarea_variable.val();
                                        if (old_order_note) {
                                            open_index = old_order_note.indexOf("(Delivery Date:");
                                            if (open_index > -1) {
                                                textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                            }
                                        }
                                        order_note = old_order_note;
                                        if (order_note == "" || typeof order_note === "undefined") {
                                            order_note = ($zestard_jq('#delivery-time-store-pickup').val() != '') ? " (Delivery Date: " + $zestard_jq('#delivery-date-pro-store-pickup').val() : " (Delivery Date: " + $zestard_jq('#delivery-date-pro-store-pickup').val() + ")";
                                        } else {
                                            order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro-store-pickup').val();
                                            order_note = ($zestard_jq('#delivery-time-store-pickup').val() != '') ? order_note : order_note + ")";
                                        }
                                        if ($zestard_jq('#delivery-time-store-pickup').val() != '') {
                                            order_note = ($zestard_jq('#delivery-date-pro-store-pickup').val() != '') ? order_note + ", Delivery Time: " + $zestard_jq('#delivery-time-store-pickup').val() + ")" : order_note + "(Delivery Time: " + $zestard_jq('#delivery-time-store-pickup').val() + ")";
                                        }
                                        textarea_variable.val(order_note);                                    }
                                    if (deliverytime_global_status == 0) {
                                        $zestard_jq.ajax({
                                            url: base_path_delivery_date + "check-delivery-time?deliverytype=2&location_id="+location_id,
                                            data: { delivery_time: $zestard_jq("#delivery-time-store-pickup").val(), date_format: date_formate, delivery_date: formatted_delivery_date, shop_name: shop_name },
                                            async: false,
                                            success: function(result) {
                                                deliverytime_response = result;
                                            }
                                        });
                                        if (deliverytime_response == 1 && $zestard_jq("#delivery-time-store-pickup").val() == null && is_time_required == true) {
                                            alert("Sorry No Time Slots Available For " + $zestard_jq("#delivery-date-pro-store-pickup").val() + " Please Select Other Date");
                                            event.preventDefault();
                                        }else if (deliverytime_response == 1) {

                                        } else {
                                            alert("Selected Delivery Time Slot is Full. Please Select Other Delivery Time");
                                            event.preventDefault();
                                        }
                                    }
                                }
                            }
                            if (cutoff_response == 0) {
                                alert("Cut Off Time is Over Please Select Other Delivery Date");
                                event.preventDefault();
                            }
                            if (cutoff_response == 2) {
                                alert("Sorry You Cannot Select " + $zestard_jq("#delivery-date-pro-store-pickup").val() + " As Delivery Date");
                                event.preventDefault();
                            }
                        }
                        // Add store pickup information into cart attribute
                        order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                        delivery_time = $zestard_jq("#delivery-time-store-pickup").val();
                        store_pickup_address = $zestard_jq("input[name=storepickup_location_id]:checked").attr('data-address');
                        store_pickup_company_name = $zestard_jq("input[name=storepickup_location_id]:checked").attr('data-name');
                        console.log(order_type,$zestard_jq('#delivery-date-pro-store-pickup').val(),delivery_time,store_pickup_address,'checkout click')
                        var data = { attributes: {} };
                        data.attributes['Order-Type'] = order_type;
                        data.attributes['Store-Pickup-Location-Name'] = store_pickup_company_name;
                        data.attributes['Store-Pickup-Address'] = store_pickup_address;
                        data.attributes['Delivery-Time'] = delivery_time;
                        data.attributes['Postal-Code'] = '';

                        $zestard_jq.ajax({
                            type: 'POST',
                            url: '/cart/update.js',
                            data: data,
                            async: false,
                            dataType: 'json',
                            success: function(responseData) { 
                              console.log(responseData);
                            }
                        });
                    }
                }
            });
            $zestard_jq('#delivery-time-store-pickup').on('change', function(){
                var data = { attributes: {} };
                // data.attributes['Order-Type'] = order_type;
                // data.attributes['Delivery-Date'] = dateText;
                data.attributes['Postal-Code'] = '';
                data.attributes['Delivery-Time'] = $zestard_jq(this).val();

                $zestard_jq.ajax({
                    type: 'POST',
                    url: '/cart/update.js',
                    data: data,
                    dataType: 'json',
                    success: function(responseData) { 
                      console.log(responseData);
                    }
                });
            });
        });
        if(datepicker_default_date != 1){
            storepickup_default_date_timeout = setTimeout(function () {
                $zestard_jq(".ui-state-highlight").removeClass('ui-state-highlight');
                $zestard_jq(".ui-state-hover").removeClass('ui-state-hover');
                remove_default_date();
            }, 2000);
        }else{
            storepickup_default_date_timeout = setTimeout(function(){
                $zestard_jq(".visible_datepicker").trigger('onSelect');
                $zestard_jq('.visible_datepicker').find('.ui-state-active').trigger('click')
                console.log('trigger123')
                // $zestard_jq("#delivery-date-pro").trigger('onSelect');
            },3000);
        }
        if(location_id == ''){
            // timeout function for radio buttton selector
            location_timout = setTimeout(function() {
                $zestard_jq(".ztpl-store-location").on('click', function(e){
                    $zestard_jq('.ztpl-location-radio').removeClass('active');
                    $zestard_jq('.ztpl-location-radio').attr('checked',false);
                    $zestard_jq(this).find("input[type='radio']").attr('checked', true);
                    $zestard_jq(this).find("input[type='radio']").addClass('active');
                    deliveryDateProStorePickup($zestard_jq(this).find("input[type='radio']").val(),'');
                });
            }, 3000);
        }
    }
    $zestard_jq('#CartSpecialInstructions').val(order_note);
    $zestard_jq('.ztpl-loader').addClass('hide');
}
function deliveryDateProLocalDelivery(postal_code = null) {
    if (local_zindex_timeout){clearTimeout(local_zindex_timeout);}
    if (local_date_picker_timeout){clearTimeout(local_date_picker_timeout);}
    if (local_date_main_timeout){clearTimeout(local_date_main_timeout);}
    if (local_button_timeout){clearTimeout(local_button_timeout);}
    if (local_note_timeout){clearTimeout(local_note_timeout);}
    if (local_default_date_timeout){clearTimeout(local_default_date_timeout);}
    if (local_checkout_click_timeout){clearTimeout(local_checkout_click_timeout);}
    $zestard_jq('.ztpl-loader').removeClass('hide');
    $zestard_jq('input[name=checkout], button[name=checkout], .googlepay, .paypal-button, input#checkout').off('click');
    $zestard_jq('#delivery-time-local-delivery').off('change');
    $zestard_jq("#datepicker_box_local_delivery").find('.visible_datepicker').remove();
    console.log('in local delivery',postal_code)
    store_date = $zestard_jq("#ztpl-date-format-ddmmyy").val();
    $zestard_jq("#Local-Delivery").find('#datepicker_box_local_delivery').hide();
    $zestard_jq("#delivery-date-pro-local-delivery").val("");
    $zestard_jq("#delivery-time").removeAttr('name');
    $zestard_jq("#delivery-time-store-pickup").removeAttr('name');
    $zestard_jq("#delivery-time-local-delivery").attr('name', 'attributes[Delivery-Time]');
    $zestard_jq.ajax({
        url: base_path_delivery_date + "get-type-and-version",
        async: false,
        data: { shop_name: shop_name },
        success: function(result) {
            data_length = result;
            if (data_length != 0) {
                app_version = result.app_version;
                type_of_app = result.type_of_app;
            } else {
                $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
                $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
                $zestard_jq("#datepicker_box_local_delivery").remove();
            }
        }
    });
    if (data_length != 0 && postal_code != null) {
        var unavailableDates = [];
        var unavailableDays = arr_data = [];
        start_from = '';
        var allowed_month = '';
        date_formate = '';
        var check_out_form = $zestard_jq("#delivery-date-pro-local-delivery").closest("form").attr('class');
        if (check_out_form) {
            var check_out_class_array = check_out_form.split(' ');
            if ($zestard_jq.inArray("cart-form", check_out_class_array) < 0) {
                $zestard_jq("#delivery-date-pro-local-delivery").closest("form").addClass("cart-form");
            }
        } else {
            $zestard_jq("#delivery-date-pro-local-delivery").closest("form").addClass("cart-form");
        }
        is_date_required = false;
        is_time_required = false;
        $zestard_jq.ajax({
            url: base_path_delivery_date + "getconfig?postal_code="+postal_code,
            dataType: "json",
            async: false,
            data: {
                shop: shop_name
            },
            success: function(data) {
                arr_data = data;
                if(data.local_delivery_details.fn_local_delivery_locations.length <= 0){
                    $zestard_jq(".visible_datepicker").remove();
                    $zestard_jq("#Local-Delivery").find('#datepicker_box_local_delivery').hide();
                    $zestard_jq("#delivery-date-pro-local-delivery").val("");
                    alert('Sorry No Delivery Available For ' + postal_code + ' Please Select Other Zipcode');
                    return false;
                }
                console.log('log',data.local_delivery_details)
                app_status = data.app_status;
                locale = data.language_locale;
                datepicker_on_default = data.datepicker_display_on;
                datepicker_default_date = data.default_date_option;
                add_delivery_information = data.add_delivery_information;
                date_error_message = data.date_error_message;
                time_error_message = data.time_error_message;
                if (app_status == "Inactive") {
                    $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
                    $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
                    $zestard_jq("#datepicker_box_local_delivery").remove();
                    $zestard_jq("#ztpl-delivery-option").remove();
                }

                if (data.require_option == 1) {
                    is_date_required = true;
                    $zestard_jq("#delivery-date-pro-local-delivery").attr("required", "true");
                    $zestard_jq("#delivery-date-pro-local-delivery").closest("form").removeAttr('novalidate');
                }
                var date_label = data.datepicker_label;
                show_datepicker_label = data.show_datepicker_label;
                if (show_datepicker_label == 1) {
                    $zestard_jq('.date-box label').text(date_label);
                } else {
                    $zestard_jq('.date-box label').hide();
                }
                // convert date as per date picker standerd
                var dates = (data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_block_date.length > 0) ? data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_block_dates: data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_block_date;
                if(dates.length > 0){
                    $zestard_jq.each( dates, function( key, value ) {
                        dates[key] = value.replaceAll("/", "-");
                    });
                }
                var day = data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_block_days;
                start_from = '+' + data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel;
                allowed_month = '+' + data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_allowed_preorder_time + 'M';
                unavailableDates = dates;
                unavailableDays = day;
                date_formate = data.date_format;
                cutoff_status = data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_cuttoff_status;
                cutoff_global_status = data.cutoff_global_status;
                deliverytime_global_status = data.deliverytime_global_status;
                cutoff_global_hours = data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_hours;
                cutoff_global_minute = data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minute;
                var current_date = $zestard_jq("#ztpl-current-date").val();
                if(store_hour == '' || isNaN(store_hour) ){
                    store_hour = $zestard_jq("#ztpl-store-hour").val();
                }
                if(store_minute == '' || isNaN(store_minute)){
                    store_minute = $zestard_jq("#ztpl-store-minute").val();
                }
                
                if (date_formate == "mm/dd/yy") {
                    var display_format = "(mm/dd/yyyy)";
                } else if (date_formate == "yy/mm/dd") {
                    var display_format = "(yyyy/mm/dd)";
                } else if (date_formate == "dd/mm/yy") {
                    var display_format = "(dd/mm/yyyy)";
                } else {
                    var display_format = "(mm/dd/yyyy)";
                }

                var show_date_format = data.show_date_format;
                if (show_date_format == 1) {
                    if (display_format != "") {
                        $zestard_jq(".selected_format").text(display_format);
                    } else {
                        $zestard_jq(".selected_format").text('mm/dd/yyyy');
                    }
                }
                var admin_note_status = data.admin_note_status;
                var notes_admin = data.admin_order_note;
                if (admin_note_status == 1) {
                    $zestard_jq(".admin_notes").html($zestard_jq.parseHTML(notes_admin));
                }
                var admin_time_status = data.admin_time_status;
                var local_delivery_time_status = data.local_delivery_details.enable_local_delivery_time;
                enable_local_delivery_date = data.local_delivery_details.enable_local_delivery_date;
                enable_location_local_delivery_date = data.local_delivery_details.fn_local_delivery_locations[0].enable_local_delivery_date;
                var local_delivery_location_time_status = data.local_delivery_details.fn_local_delivery_locations[0].enable_local_delivery_time;
                var time_lable = data.time_label;
                var default_option_label = data.time_default_option_label;
                console.log('local_delivery_time_status',local_delivery_time_status,data)
                if (admin_time_status == 1 && local_delivery_time_status == 1 && local_delivery_location_time_status == 1) {
                    var time_in_text = data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_time; time_array = new Array();
                    time_array = time_in_text.split(",");
                    time_count = 0;
                    $zestard_jq("#delivery-time-local-delivery").css('display', 'block');
                    $zestard_jq("#delivery-time-local-delivery").css('border', 'none');
                    // $zestard_jq("#time_option_label").text(default_option_label);
                    $zestard_jq("#delivery-time-local-delivery").html("");
                    if(default_option_label){
                        $zestard_jq("#delivery-time-local-delivery").append("<option id='time_option_label' value='' readonly>"+default_option_label+"</option>");
                    }
                    if ((app_version <= 2 && type_of_app <= 2) || (app_version ==4 && type_of_app ==4)) {
                        // $zestard_jq('#delivery-time-local-delivery').html('');
                        $zestard_jq(time_array).each(function() {
                            $zestard_jq('#delivery-time-local-delivery').append("<option value='" + time_array[time_count] + "'" + ">" + time_array[time_count] + "</option>");
                            time_count++;
                        });
                    }
                    $zestard_jq(".delivery-time-label").show();
                    $zestard_jq(".delivery-time-label").text(time_lable);
                    if (data.time_require_option == 1) {
                        is_time_required = true;
                        $zestard_jq("#delivery-time-local-delivery").attr("required", "true");
                        $zestard_jq("#delivery-date-pro-local-delivery").closest("form").removeAttr('novalidate');
                    }
                }
                var additional_css = data.additional_css;
                $zestard_jq('#datepicker_box_local_delivery').after("<style>" + additional_css + "</style>");
                //Change Variable Name
                var str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel);
                if (parseInt(cutoff_status) == 0 || parseInt(cutoff_status) == 2) {} else {
                    //Check App Version if it is 3(i.e Enterprise) or more then it will Exceute Following Code For Multiple Cut Off and Delivery Time  
                    if (app_version == 3 && type_of_app == 3) {
                        if (cutoff_global_status == 1) {
                            cutoff_hours = cutoff_global_hours;
                            cutoff_minute = cutoff_global_minute;
                            if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                                if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                    str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel);
                                } else {
                                    if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                        str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel);
                                    } else {
                                        str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel) + 1;
                                    }
                                }
                            } else {
                                str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel) + 1;
                            }
                        } else {
                            var c_day = new Date().getDay();
                            $zestard_jq.ajax({
                                url: base_path_delivery_date + "get-cutoff-time",
                                data: { day: c_day, shop_name: shop_name },
                                async: false,
                                success: function(response) {
                                    var json_data = JSON.parse(response);
                                    cutoff_hours = json_data['cutoff_hour'];
                                    cutoff_minute = json_data['cutoff_minute'];
                                }
                            });
                            if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                                if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                    str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel);
                                } else {
                                    if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                        str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel);
                                    } else {
                                        str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel) + 1;
                                    }
                                }
                            } else {
                                str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel) + 1;
                            }
                        }
                    } else {
                        cutoff_hours = cutoff_global_hours;
                        cutoff_minute = cutoff_global_minute;
                        if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                            if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel);
                            } else {
                                if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                    str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel);
                                } else {
                                    str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel) + 1;
                                }
                            }
                        } else {
                            str = parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_minimum_date_intervel) + 1;
                        }
                    }
                }
                start_from = '+' + parseInt(str);
                original_start_from = start_from;

                function pad(n) {
                    return (n < 10) ? ("0" + n) : n;
                }
                var tempdate = new Date();
                tempdate.setDate(tempdate.getDate());
                var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                var block_date_array = dates;
                var block_days_array = unavailableDays;
                var NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                var NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                var current_available_day = weekday[tempdate.getDay()];
                exit_flag = 0;
                temp_count = start_from;
                if (!block_days_array) {
                    block_days_array = new Array();
                }
                if (!block_date_array) {
                    block_date_array = new Array();
                }
                /* if (shop_name == "sunshine-milk-bread.myshopify.com" || shop_name == "greenox.myshopify.com" || shop_name == "petaljet.myshopify.com" || shop_name == "alacena-de-monica-prueba-12345.myshopify.com" || shop_name == "hello-cheese.myshopify.com" || shop_name == "sweetworthy.myshopify.com" || shop_name == "the-cornish-scone-company.myshopify.com" || shop_name == "the-cornish-scone-company.myshopify.com" || shop_name == "sgrocerie.myshopify.com" || shop_name == "maison-duffour.myshopify.com") //  */
                if (parseInt(data.local_delivery_details.fn_local_delivery_locations[0].local_delivery_block_days_interval) == 2) {
                    tempdate.setDate(tempdate.getDate() + parseInt(start_from));
                    while (temp_count != -1) {
                        var date = tempdate.getDate();
                        var month = tempdate.getMonth() + 1;
                        var year = tempdate.getFullYear();
                        NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                        NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                        current_available_day = weekday[tempdate.getDay()];
                        if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                            index_of = block_date_array.indexOf(NextDayDMY);
                            block_date_array.splice(index_of, 1);
                            start_from = parseInt(start_from) + 1;
                            temp_count = start_from;
                        } else if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                            index_of = block_days_array.indexOf(current_available_day);
                            start_from = parseInt(start_from) + 1;
                            temp_count = start_from;
                        } else {
                            temp_count = -1;
                        }
                        tempdate.setDate(tempdate.getDate() + 1);
                    }
                } else {
                    if (temp_count == 0) {
                        if (block_date_array.length > 0 || block_days_array.length > 0) {
                            while ((block_date_array.length > 0 || block_days_array.length > 0) && temp_count > -1) {
                                var date = tempdate.getDate();
                                var month = tempdate.getMonth() + 1;
                                var year = tempdate.getFullYear();
                                NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                                NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                                current_available_day = weekday[tempdate.getDay()];

                                if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                                    index_of = block_date_array.indexOf(NextDayDMY);
                                    block_date_array.splice(index_of, 1);
                                    start_from = parseInt(start_from) + 1;
                                    temp_count = start_from;
                                } else if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                                    index_of = block_days_array.indexOf(current_available_day);
                                    //block_days_array.splice(index_of, 1);
                                    start_from = parseInt(start_from) + 1;
                                    temp_count = start_from;
                                } else {
                                    // if (block_date_array.length <= 0 || block_days_array.length <= 0) {
                                    //     temp_count = -1;
                                    // } else if (temp_count == 0) {
                                    //     temp_count = -1;
                                    // } else {
                                    //     temp_count--;
                                    // }
                                    var start_from_date = new Date();
                                    start_from_date.setDate(start_from_date.getDate() + parseInt(original_start_from));
                                    if (tempdate.getTime() >= start_from_date.getTime()) {
                                        temp_count = -1;
                                        block_days_array = [];
                                    }
                                }
                                tempdate.setDate(tempdate.getDate() + 1);
                            }
                        }
                    } else {
                        var original_block_dates_length = block_date_array.length;
                        while ((block_date_array.length > 0 || block_days_array.length > 0) && temp_count != -1) {
                            var date = tempdate.getDate();
                            var month = tempdate.getMonth() + 1;
                            var year = tempdate.getFullYear();
                            NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                            NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                            current_available_day = weekday[tempdate.getDay()];
                            if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                                // console.log('in if')
                                index_of = block_days_array.indexOf(current_available_day);
                                temp_count = 0;
                                var current_date = new Date();
                                var start_from_date = new Date();
                                // console.log('start_from inner',start_from_date,original_block_dates_length)
                                //block_days_array.splice(index_of, 1);
                                if(tempdate.getTime() > start_from_date.getTime() && original_block_dates_length == 0){
                                    start_from = ((parseInt(start_from) == 1 && weekday[current_date.getDay()] != current_available_day)) ? (parseInt(start_from) + 1) : parseInt(start_from);
                                }else{
                                    start_from = (parseInt(start_from) > 1 || (parseInt(start_from) == 1 && weekday[current_date.getDay()] == current_available_day)) ? (parseInt(start_from) + 1) : parseInt(start_from);
                                }
                                temp_count = start_from;
                                // console.log(weekday,weekday[current_date.getDay()],current_available_day,tempdate.getDay(),block_days_array,$zestard_jq.inArray(current_available_day, block_days_array),temp_count)

                            } else if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                                var start_from_date = new Date();
                                // console.log('in if else',(tempdate.getTime() > start_from_date.getTime()))
                                temp_count = 0;
                                index_of = block_date_array.indexOf(NextDayDMY);
                                block_date_array.splice(index_of, 1);
                                start_from = parseInt(start_from) + 1;
                                temp_count = start_from;
                            } else {

                                /* 1 Aug 2018 */
                                var start_from_date = new Date();
                                start_from_date.setDate(start_from_date.getDate() + parseInt(original_start_from));
                                if (tempdate.getTime() >= start_from_date.getTime()) {
                                    temp_count = -1;
                                    block_days_array = [];
                                }

                            }
                            tempdate.setDate(tempdate.getDate() + 1);

                        }
                    }
                }
            }
        });
        if(arr_data.local_delivery_details.fn_local_delivery_locations.length > 0){
            local_date_main_timeout = setTimeout(function() {
                var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                function unavailable(date) {
                    // if (shop_name == "purpinkg.myshopify.com") {}
                    ymd = date.getFullYear() + "/" + ("0" + (date.getMonth() + 1)).slice(-2) + "/" + ("0" + date.getDate()).slice(-2);
                    ymd1 = ("0" + date.getDate()).slice(-2) + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + date.getFullYear();
                    day = new Date(ymd).getDay();
                    if ($zestard_jq.inArray(ymd1, unavailableDates) < 0 && $zestard_jq.inArray(days[day], unavailableDays) < 0) {
                        return [true, "enabled", "Book Now"];
                    } else {
                        return [false, "disabled", "Booked Out"];
                    }
                }
                local_date_picker_timeout = setTimeout(function() {
                    datepicker_var = undefined;
                    if(enable_local_delivery_date == 1 && enable_location_local_delivery_date == 1){
                        //For keeping datepicker always open    
                        if (datepicker_on_default == 1) {
                            if (locale == "en") {
                                $zestard_jq("#datepicker_box_local_delivery .date-box").append("<div class='visible_datepicker'></div>");
                                $zestard_jq("#delivery-date-pro-local-delivery").attr("type", "hidden");
                                datepicker_var = $zestard_jq(".visible_datepicker").datepicker({
                                    dateFormat: date_formate,
                                    minDate: start_from,
                                    maxDate: "'" + allowed_month + "'",
                                    beforeShowDay: unavailable,
                                    onSelect: function(dateText) {
                                        if($zestard_jq("[action='/cart']").length > 0){
                                            $zestard_jq(".delivery-date-hidden").remove();
                                            $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                            // Add local delivery information into cart attribute
                                            order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                            delivery_time = $zestard_jq("#delivery-time-local-delivery").val();
                                            var data = { attributes: {} };
                                            data.attributes['Order-Type'] = order_type;
                                            data.attributes['Postal-Code'] = postal_code;
                                            data.attributes['Delivery-Date'] = delivery_time;
                                            data.attributes['Delivery-Time'] = delivery_time;
                                            data.attributes['Store-Pickup-Location-Name'] = '';
                                            data.attributes['Store-Pickup-Address'] = '';
                                            $zestard_jq.ajax({
                                                type: 'POST',
                                                url: '/cart/update.js',
                                                data: data,
                                                async: false,
                                                dataType: 'json',
                                                success: function(responseData) { 
                                                  console.log(responseData);
                                                }
                                            });
                                        }
                                        disable_today_highlight();
                                        if (deliverytime_global_status == 0  && app_version == 3) {
                                            delivery_date_pro_div_local_delivery(dateText);
                                        }
                                    },
                                    beforeShow: function() {
                                        local_zindex_timeout = setTimeout(function() {
                                            $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                        }, 0);
                                    }
                                });
                                if (datepicker_default_date == 1) {
                                    datepicker_var.datepicker("setDate", start_from);
                                    // $zestard_jq(".visible_datepicker").trigger('onSelect');
                                }
                            } else {
                                $.getScript( base_path_delivery_date + "js/locale_js/datepicker-" + locale + ".js", function( data, textStatus, jqxhr ) {
                                    //$zestard_jq.datepicker.setDefaults($zestard_jq.datepicker.regional[locale]); 
                                    $zestard_jq("#datepicker_box_local_delivery .date-box").append("<div class='visible_datepicker'></div>");
                                    $zestard_jq('.visible_datepicker').addClass('notranslate');
                                    $zestard_jq("#delivery-date-pro-local-delivery").attr("type", "hidden");
                                    datepicker_var = $zestard_jq(".visible_datepicker").datepicker({
                                        dateFormat: date_formate,
                                        minDate: start_from,
                                        maxDate: "'" + allowed_month + "'",
                                        beforeShowDay: unavailable,
                                        defaultDate: null,
                                        onSelect: function(dateText) {
                                            console.log(dateText,2)
                                            if($zestard_jq("[action='/cart']").length > 0){
                                                $zestard_jq(".delivery-date-hidden").remove();
                                                $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                                // Add local delivery information into cart attribute
                                                order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                                delivery_time = $zestard_jq("#delivery-time-local-delivery").val();
                                                console.log(order_type,$zestard_jq('#delivery-date-pro-local-delivery').val(),delivery_time,'checkout click local delivery')
                                                var data = { attributes: {} };
                                                data.attributes['Order-Type'] = order_type;
                                                data.attributes['Postal-Code'] = postal_code;
                                                data.attributes['Delivery-Date'] = dateText;
                                                data.attributes['Delivery-Time'] = delivery_time;
                                                data.attributes['Store-Pickup-Location-Name'] = '';
                                                data.attributes['Store-Pickup-Address'] = '';
                                                $zestard_jq.ajax({
                                                    type: 'POST',
                                                    url: '/cart/update.js',
                                                    data: data,
                                                    async: false,
                                                    dataType: 'json',
                                                    success: function(responseData) { 
                                                      console.log(responseData);
                                                    }
                                                });
                                            }
                                            $zestard_jq.getScript( base_path_delivery_date + "js/locale_js/datepicker-" + locale + ".js");
                                            if (deliverytime_global_status == 0  && app_version == 3) {
                                                delivery_date_pro_div_local_delivery(dateText);
                                            }
                                            $zestard_jq('.zAddToCart').prop('disabled', false);
                                            disable_today_highlight();
                                        },
                                        beforeShow: function() {
                                            local_zindex_timeout = setTimeout(function() {
                                                $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                            }, 0);
                                        }
                                    });
                                });
                            }
                        } else {
                            if (locale == "en") {
                                $zestard_jq.datepicker.setDefaults($zestard_jq.datepicker.regional[locale]);
                                datepicker_var = $zestard_jq("#delivery-date-pro-local-delivery").datepicker({
                                    dateFormat: date_formate,
                                    minDate: start_from,
                                    maxDate: "'" + allowed_month + "'",
                                    onSelect: function(dateText) {
                                        console.log(dateText,3)
                                        if($zestard_jq("[action='/cart']").length > 0){
                                            $zestard_jq(".delivery-date-hidden").remove();
                                            $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                            // Add local delivery information into cart attribute
                                            order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                            delivery_time = $zestard_jq("#delivery-time-local-delivery").val();
                                            console.log(order_type,$zestard_jq('#delivery-date-pro-local-delivery').val(),delivery_time,'checkout click local delivery')
                                            var data = { attributes: {} };
                                            data.attributes['Order-Type'] = order_type;
                                            data.attributes['Postal-Code'] = postal_code;
                                            data.attributes['Delivery-Date'] = dateText;
                                            data.attributes['Delivery-Time'] = delivery_time;
                                            data.attributes['Store-Pickup-Location-Name'] = '';
                                            data.attributes['Store-Pickup-Address'] = '';
                                            $zestard_jq.ajax({
                                                type: 'POST',
                                                url: '/cart/update.js',
                                                data: data,
                                                async: false,
                                                dataType: 'json',
                                                success: function(responseData) { 
                                                  console.log(responseData);
                                                }
                                            });
                                        }
                                        $zestard_jq('.zAddToCart').prop('disabled', false);
                                        if (deliverytime_global_status == 0  && app_version == 3) {
                                            delivery_date_pro_div_local_delivery(dateText);
                                        }
                                        disable_today_highlight();
                                    },
                                    beforeShowDay: unavailable,
                                    defaultDate: null,
                                    beforeShow: function() {
                                        local_zindex_timeout = setTimeout(function() {
                                            $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                        }, 0);
                                    }
                                });
                            } else {
                                datepicker_var = $zestard_jq("#delivery-date-pro-local-delivery").datepicker({
                                    dateFormat: date_formate,
                                    minDate: start_from,
                                    maxDate: "'" + allowed_month + "'",
                                    onSelect: function(dateText) {
                                        console.log(dateText,4)
                                        if($zestard_jq("[action='/cart']").length > 0){
                                            $zestard_jq(".delivery-date-hidden").remove();
                                            $zestard_jq("[action='/cart']").append('<input type="hidden" class="delivery-date-hidden" name="attributes[Delivery-Date]" value="'+ dateText +'">');
                                            // Add local delivery information into cart attribute
                                            order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                                            delivery_time = $zestard_jq("#delivery-time-local-delivery").val();
                                            console.log(order_type,$zestard_jq('#delivery-date-pro-local-delivery').val(),delivery_time,'checkout click local delivery')
                                            var data = { attributes: {} };
                                            data.attributes['Order-Type'] = order_type;
                                            data.attributes['Postal-Code'] = postal_code;
                                            data.attributes['Delivery-Date'] = dateText;
                                            data.attributes['Delivery-Time'] = delivery_time;
                                            data.attributes['Store-Pickup-Location-Name'] = '';
                                            data.attributes['Store-Pickup-Address'] = '';
                                            $zestard_jq.ajax({
                                                type: 'POST',
                                                url: '/cart/update.js',
                                                data: data,
                                                async: false,
                                                dataType: 'json',
                                                success: function(responseData) { 
                                                  console.log(responseData);
                                                }
                                            });
                                        }
                                        //$zestard_jq('#AddToCart').prop('disabled', false);
                                        $zestard_jq('.zAddToCart').prop('disabled', false);
                                        if (deliverytime_global_status == 0  && app_version == 3) {
                                            delivery_date_pro_div_local_delivery(dateText);
                                        }

                                        var userLang = navigator.language || navigator.userLanguage;
                                        //console.log ("The language is: " + userLang);
                                        disable_today_highlight();

                                    },
                                    beforeShowDay: unavailable,
                                    beforeShow: function() {
                                        local_zindex_timeout = setTimeout(function() {
                                            $zestard_jq('.ui-datepicker').css('z-index', 99999999999999);
                                        }, 0);
                                    }
                                });
                            }
                        }

                        if (app_version == 1 && datepicker_on_default == 1) {
                            remove_default_date();
                        }
                        if (app_version > 1 && type_of_app > 1) {
                            if (datepicker_default_date == 1) {
                                $zestard_jq("#delivery-date-pro-local-delivery").datepicker("setDate", "today + start_from");
                                // $zestard_jq("#delivery-date-pro-local-delivery").trigger('onSelect');
                            } else {
                                $zestard_jq('.visible_datepicker').datepicker('setDate', null);
                            }
                        }
                    }else{
                        $zestard_jq('#Local-Delivery').find('.date-box').remove();
                    }
                }, 300)
                $zestard_jq("#delivery-date-pro-local-delivery").prop("disabled", false);
            }, 100);
            $zestard_jq("#delivery-date-pro-local-delivery").prop("disabled", false);
            //Check App Version if it is 3(i.e Enterprise) or more then it will Exceute Following Code For Multiple Cut Off and Delivery Time
            if (app_version > 2 && type_of_app > 2) {
                if (deliverytime_global_status == 0) {
                    delivery_date_pro_local_delivery();
                    var result = "";
                    $zestard_jq.ajax({
                        url: base_path_delivery_date + "delivery-times",
                        data: { shop_name: shop_name, start_from: start_from, date_format: date_formate },
                        async: false,
                        success: function(response) {
                            if (response == 0) {
                                $zestard_jq("#delivery-time-local-delivery").html("");
                            } else {
                                $zestard_jq("#delivery-time-local-delivery").html("");
                                $zestard_jq("#delivery-time-local-delivery").append("<option value=''>Choose Time</option>");
                                for (var key in response) {
                                    $zestard_jq("#delivery-time-local-delivery").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                                }
                            }
                        }
                    });
                } else {
                    $zestard_jq('#delivery-time-local-delivery').html('');
                    $zestard_jq(time_array).each(function() {
                        $zestard_jq('#delivery-time-local-delivery').append("<option value='" + time_array[time_count] + "'" + ">" + time_array[time_count] + "</option>");
                        time_count++;
                    });
                }
            }
            local_button_timeout = setTimeout(function() {
                $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
                $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
            }, 3000);

            local_note_timeout = setTimeout(function() {
                // if (shop_name == "cheeseschool.myshopify.com") {
                //     textarea_variable = $zestard_jq('.delivery_date_pro textarea[name=note]');
                // } else {
                    textarea_variable = $zestard_jq('textarea[name=note]');
                // }
                old_order_note = textarea_variable.val();
                if (old_order_note) {
                    open_index = old_order_note.indexOf("(Delivery Date:");
                    if (open_index > -1) {
                        textarea_variable.html(old_order_note.substring(0, open_index - 1));
                    }
                }
            }, 500);

            local_checkout_click_timeout = setTimeout(function() {
                $zestard_jq('input[name=checkout], button[name=checkout], .googlepay, .paypal-button, input#checkout').on('click', function(event) {
                    var date = $zestard_jq('#date').val($zestard_jq('#delivery-date-pro-local-delivery').val());
                    var time = $zestard_jq('#time').val($zestard_jq('#delivery-time-local-delivery').val());
                    if (datepicker_on_default == 1) {
                        var temp_date = $zestard_jq("#datepicker_box_local_delivery").find('.visible_datepicker').val();
                        $zestard_jq("#delivery-date-pro-local-delivery").val(temp_date);
                    }

                    var cart_date = $zestard_jq('#delivery-date-pro-local-delivery').val();
                    var cart_time = $zestard_jq('#delivery-time-local-delivery').val();
                    $zestard_jq('#cart_date').attr('value', cart_date);
                    $zestard_jq('#cart_time').attr('value', cart_time);
                    order_note = '';
                    old_order_note = '';
                    if (app_status == 'Active') {
                        if (is_date_required == true && ((typeof $zestard_jq('#delivery-date-pro-local-delivery').val() == 'undefined') || ($zestard_jq('#delivery-date-pro-local-delivery').val() == ''))) {
                            // if (shop_name == 'pastaldente.myshopify.com') {
                            //     $zestard_jq('.alert_mesg').text(date_error_message);
                            // } else {
                                console.log(date_error_message,$zestard_jq('#delivery-date-pro-local-delivery').val())
                                alert(date_error_message);
                            // }
                            $zestard_jq('#delivery-date-pro-local-delivery').focus();
                            return false;
                            event.preventDefault();
                        }

                        if (is_time_required == true && ((typeof $zestard_jq('#delivery-time-local-delivery').val() == 'undefined') || ($zestard_jq('#delivery-time-local-delivery').val() == ''))) {
                            alert(time_error_message);
                            $zestard_jq('#delivery-time-local-delivery').focus();
                            return false;
                        }

                        if (add_delivery_information == 1) {
                            order_note = textarea_variable.val();
                            old_order_note = textarea_variable.val();
                        }
                        //Check Blocked Days and Dates  

                        if ($zestard_jq('#delivery-date-pro-local-delivery').val() != '') {
                            selected_delivery_date = $zestard_jq('#delivery-date-pro-local-delivery').val();
                            formatted_delivery_date = selected_delivery_date;
                            var blocked_status, json_response, blocked_date_status;
                            var todays_date = $zestard_jq('#delivery-date-pro-local-delivery').val();
                            var today = new Date(todays_date).getDay();
                            $zestard_jq.ajax({
                                url: base_path_delivery_date + "check-blocked-day?deliverytype=3&postal_code="+postal_code,
                                data: { todays_date: todays_date, date_format: date_formate, shop_name: shop_name },
                                async: false,
                                success: function(result) {
                                    json_response = $zestard_jq.parseJSON(result);
                                }
                            });
                            blocked_status = json_response.result;

                            $zestard_jq.ajax({
                                url: base_path_delivery_date + "check-blocked-date?deliverytype=3&postal_code="+postal_code,
                                data: { delivery_date: todays_date, date_format: date_formate, shop_name: shop_name },
                                async: false,
                                success: function(response) {
                                    blocked_date_status = response;
                                }
                            });

                            if (blocked_status == 0) {
                                alert('Sorry Delivery is Not Possible for ' + json_response.today + ' . Please Select Other Day');
                                event.preventDefault();
                            }
                            if (blocked_date_status == 0) {
                                alert('Sorry, The Delivery Date You Selected is Blocked. Please Select Other Delivery Date');
                                event.preventDefault();
                            }
                            if (blocked_date_status == 1 && blocked_status == 1) {
                                $zestard_jq.ajax({
                                    url: base_path_delivery_date + "check-cuttoff?deliverytype=3&postal_code="+postal_code,
                                    data: { start_from: start_from, date_format: date_formate, delivery_date: formatted_delivery_date, store_hour: store_hour, store_minute: store_minute, shop_name: shop_name, store_date: store_date },
                                    async: false,
                                    success: function(result) {
                                        cutoff_response = result;
                                    }
                                });


                                if (add_delivery_information == 1) {
                                    old_order_note = textarea_variable.val();
                                    if (old_order_note) {
                                        open_index = old_order_note.indexOf("(Delivery Date:");
                                        if (open_index > -1) {
                                            textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                        }
                                    }
                                    if (order_note == "" || typeof order_note === "undefined") {
                                        order_note = ($zestard_jq('#delivery-time-local-delivery').val() != '') ? " (Delivery Date: " + $zestard_jq('#delivery-date-pro-local-delivery').val() : " (Delivery Date: " + $zestard_jq('#delivery-date-pro-local-delivery').val() + ")";
                                    } else {
                                        order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro-local-delivery').val();
                                        order_note = ($zestard_jq('#delivery-time-local-delivery').val() != '') ? order_note : order_note + ")";
                                    }
                                    if ($zestard_jq('#delivery-time-local-delivery').val() != '') {
                                        order_note = ($zestard_jq('#delivery-date-pro-local-delivery').val() != '') ? order_note + ", Delivery Time: " + $zestard_jq('#delivery-time-local-delivery').val() + ")" : order_note + "(Delivery Time: " + $zestard_jq('#delivery-time-local-delivery').val() + ")";
                                    }
                                }
                                if (cutoff_response == 1) {
                                    if ($zestard_jq("#delivery-time-local-delivery").val() == "" || typeof $zestard_jq('#delivery-date-pro-local-delivery').val() === 'undefined') {
                                        if (is_time_required == true) {
                                            alert(time_error_message);
                                            $zestard_jq('#delivery-time-local-delivery').focus();
                                            event.preventDefault();
                                        } else {
                                            if (add_delivery_information == 1) {
                                                old_order_note = textarea_variable.val();
                                                if (old_order_note) {
                                                    open_index = old_order_note.indexOf("(Delivery Date:");
                                                    if (open_index > -1) {
                                                        textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                                    }
                                                }
                                                order_note = old_order_note;
                                                if (order_note == "" || typeof order_note === "undefined") {
                                                    order_note = ($zestard_jq('#delivery-time-local-delivery').val() != '') ? " (Delivery Date: " + $zestard_jq('#delivery-date-pro-local-delivery').val() : " (Delivery Date: " + $zestard_jq('#delivery-date-pro-local-delivery').val() + ")";
                                                } else {
                                                    order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro-local-delivery').val();
                                                    order_note = ($zestard_jq('#delivery-time-local-delivery').val() != '') ? order_note : order_note + ")";
                                                }
                                                if ($zestard_jq('#delivery-time-local-delivery').val() != '') {
                                                    order_note = ($zestard_jq('#delivery-date-pro-local-delivery').val() != '') ? order_note + ", Delivery Time: " + $zestard_jq('#delivery-time-local-delivery').val() + ")" : order_note + "(Delivery Time: " + $zestard_jq('#delivery-time-local-delivery').val() + ")";
                                                }
                                                textarea_variable.val(order_note);
                                            }
                                        }
                                    } else {
                                        if (add_delivery_information == 1) {
                                            old_order_note = textarea_variable.val();
                                            if (old_order_note) {
                                                open_index = old_order_note.indexOf("(Delivery Date:");
                                                if (open_index > -1) {
                                                    textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                                }
                                            }
                                            order_note = old_order_note;
                                            if (order_note == "" || typeof order_note === "undefined") {
                                                order_note = ($zestard_jq('#delivery-time-local-delivery').val() != '') ? " (Delivery Date: " + $zestard_jq('#delivery-date-pro-local-delivery').val() : " (Delivery Date: " + $zestard_jq('#delivery-date-pro-local-delivery').val() + ")";
                                            } else {
                                                order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro-local-delivery').val();
                                                order_note = ($zestard_jq('#delivery-time-local-delivery').val() != '') ? order_note : order_note + ")";
                                            }
                                            if ($zestard_jq('#delivery-time-local-delivery').val() != '') {
                                                order_note = ($zestard_jq('#delivery-date-pro-local-delivery').val() != '') ? order_note + ", Delivery Time: " + $zestard_jq('#delivery-time-local-delivery').val() + ")" : order_note + "(Delivery Time: " + $zestard_jq('#delivery-time-local-delivery').val() + ")";
                                            }
                                            textarea_variable.val(order_note);                                    }
                                        if (deliverytime_global_status == 0) {
                                            $zestard_jq.ajax({
                                                url: base_path_delivery_date + "check-delivery-time",
                                                data: { delivery_time: $zestard_jq("#delivery-time-local-delivery").val(), date_format: date_formate, delivery_date: formatted_delivery_date, shop_name: shop_name },
                                                async: false,
                                                success: function(result) {
                                                    deliverytime_response = result;
                                                }
                                            });
                                            if (deliverytime_response == 1 && $zestard_jq("#delivery-time-local-delivery").val() == null && is_time_required == true) {
                                                alert("Sorry No Time Slots Available For " + $zestard_jq("#delivery-date-pro-store-pickup").val() + " Please Select Other Date");
                                                event.preventDefault();
                                            }else if (deliverytime_response == 1) {

                                            } else {
                                                alert("Selected Delivery Time Slot is Full. Please Select Other Delivery Time");
                                                event.preventDefault();
                                            }
                                        }
                                    }
                                }
                                if (cutoff_response == 0) {
                                    alert("Cut Off Time is Over Please Select Other Delivery Date");
                                    event.preventDefault();
                                }
                                if (cutoff_response == 2) {
                                    alert("Sorry You Cannot Select " + $zestard_jq("#delivery-date-pro-local-delivery").val() + " As Delivery Date");
                                    event.preventDefault();
                                }
                            }
                            // Add local delivery information into cart attribute
                            order_type = $zestard_jq('#ztpl-delivery-option input[name="ztpl-delivery-option"]:checked').val();
                            delivery_time = $zestard_jq("#delivery-time-local-delivery").val();
                            var data = { attributes: {} };
                            data.attributes['Order-Type'] = order_type;
                            data.attributes['Postal-Code'] = postal_code;
                            data.attributes['Delivery-Time'] = delivery_time;
                            data.attributes['Store-Pickup-Location-Name'] = '';
                            data.attributes['Store-Pickup-Address'] = '';
                            $zestard_jq.ajax({
                                type: 'POST',
                                url: '/cart/update.js',
                                data: data,
                                async: false,
                                dataType: 'json',
                                success: function(responseData) { 
                                  console.log(responseData);
                                }
                            });
                        }
                    }
                });
                $zestard_jq('#delivery-time-local-delivery').on('change', function(){
                    var data = { attributes: {} };
                    // data.attributes['Order-Type'] = order_type;
                    // data.attributes['Delivery-Date'] = dateText;
                    data.attributes['Store-Pickup-Location-Name'] = '';
                    data.attributes['Store-Pickup-Address'] = '';
                    data.attributes['Delivery-Time'] = $zestard_jq(this).val();

                    $zestard_jq.ajax({
                        type: 'POST',
                        url: '/cart/update.js',
                        data: data,
                        dataType: 'json',
                        success: function(responseData) { 
                          console.log(responseData);
                        }
                    });
                });
            });
            if(datepicker_default_date != 1){
                local_default_date_timeout = setTimeout(function () {
                    $zestard_jq(".ui-state-highlight").removeClass('ui-state-highlight');
                    $zestard_jq(".ui-state-hover").removeClass('ui-state-hover');
                    remove_default_date();
                }, 2000);
            }else{
                local_default_date_timeout = setTimeout(function(){
                        $zestard_jq(".visible_datepicker").trigger('onSelect');
                        $zestard_jq('.visible_datepicker').find('.ui-state-active').trigger('click')
                        console.log('trigger123')
                        // $zestard_jq("#delivery-date-pro").trigger('onSelect');
                },3000);
            }
            $zestard_jq("#Local-Delivery").find('#datepicker_box_local_delivery').show();
        }
    }
    $zestard_jq('#CartSpecialInstructions').val(order_note);
    $zestard_jq('.ztpl-loader').addClass('hide');
}
//Following Function is for Showing Delivery Time Dynamically Based on Days
function delivery_date_pro_div(dateText) {
    var result = "";
    day = new Date(dateText).getDay();
    $zestard_jq.ajax({
        url: base_path_delivery_date + "delivery-times",
        data: { todays_date: dateText, date_format: date_formate, shop_name: shop_name },
        async: false,
        success: function(response) {
            if (response == 0) {
                $zestard_jq("#delivery-time").html("");
                if (is_time_required == true) {
                    alert('Sorry No Time Slots Available For ' + dateText + ' Please Select Other Date');
                    $zestard_jq("#delivery-date-pro").val("");
                    $zestard_jq("#delivery-date-pro").focus();
                }
            } else {
                $zestard_jq("#delivery-time").html("");
                $zestard_jq("#delivery-time").append("<option value=''>Choose Time</option>");
                for (var key in response) {
                    $zestard_jq("#delivery-time").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                }
            }
        }
    });
}
//Following Function is for Showing Delivery Time Dynamically Based on Days for store pickup
function delivery_date_pro_div_store_pickup(dateText) {
    var result = "";
    day = new Date(dateText).getDay();
    $zestard_jq.ajax({
        url: base_path_delivery_date + "delivery-times",
        data: { todays_date: dateText, date_format: date_formate, shop_name: shop_name },
        async: false,
        success: function(response) {
            if (response == 0) {
                $zestard_jq("#delivery-time-store-pickup").html("");
                if (is_time_required == true) {
                    alert('Sorry No Time Slots Available For ' + dateText + ' Please Select Other Date');
                    $zestard_jq("#delivery-date-pro-store-pickup").val("");
                    $zestard_jq("#delivery-date-pro-store-pickup").focus();
                }
            } else {
                $zestard_jq("#delivery-time-store-pickup").html("");
                $zestard_jq("#delivery-time-store-pickup").append("<option value=''>Choose Time</option>");
                for (var key in response) {
                    $zestard_jq("#delivery-time-store-pickup").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                }
            }
        }
    });
}

//Following Function is for Showing Delivery Time Dynamically Based on Days for Local delivery
function delivery_date_pro_div_local_delivery(dateText) {
    var result = "";
    day = new Date(dateText).getDay();
    $zestard_jq.ajax({
        url: base_path_delivery_date + "delivery-times",
        data: { todays_date: dateText, date_format: date_formate, shop_name: shop_name },
        async: false,
        success: function(response) {
            if (response == 0) {
                $zestard_jq("#delivery-time-local-delivery").html("");
                if (is_time_required == true) {
                    alert('Sorry No Time Slots Available For ' + dateText + ' Please Select Other Date');
                    $zestard_jq("#delivery-date-pro-local-delivery").val("");
                    $zestard_jq("#delivery-date-pro-local-delivery").focus();
                }
            } else {
                $zestard_jq("#delivery-time-local-delivery").html("");
                $zestard_jq("#delivery-time-local-delivery").append("<option value=''>Choose Time</option>");
                for (var key in response) {
                    $zestard_jq("#delivery-time-local-delivery").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                }
            }
        }
    });
}

function delivery_date_pro() {
    var day;
    $zestard_jq("#delivery-date-pro").change(function(dateText) {
        $zestard_jq(".ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active").css("cssText", "background:#000 !important;color:#fff !important;font-weight:700 !important;");
        var result = "";
        day = new Date(this.value).getDay();
        $zestard_jq.ajax({
            url: base_path_delivery_date + "delivery-times",
            data: { todays_date: this.value, date_format: date_formate, shop_name: shop_name },
            async: false,
            success: function(response) {
                if (response == 0) {
                    $zestard_jq("#delivery-time").html("");
                    if (is_time_required == true) {
                        alert('Sorry No Time Slots Available For ' + $zestard_jq("#delivery-date-pro").val() + ' Please Select Other Date');
                        $zestard_jq("#delivery-date-pro").val("");
                        $zestard_jq("#delivery-date-pro").focus();
                    }
                } else {
                    $zestard_jq("#delivery-time").html("");
                    $zestard_jq("#delivery-time").append("<option value=''>Choose Time</option>");
                    for (var key in response) {
                        $zestard_jq("#delivery-time").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                    }
                }
            }
        });
    });
}

function delivery_date_pro_store_pickup() {
    var day;
    $zestard_jq("#delivery-date-pro-store-pickup").change(function(dateText) {
        $zestard_jq(".ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active").css("cssText", "background:#000 !important;color:#fff !important;font-weight:700 !important;");
        var result = "";
        day = new Date(this.value).getDay();
        $zestard_jq.ajax({
            url: base_path_delivery_date + "delivery-times",
            data: { todays_date: this.value, date_format: date_formate, shop_name: shop_name },
            async: false,
            success: function(response) {
                if (response == 0) {
                    $zestard_jq("#delivery-time-store-pickup").html("");
                    if (is_time_required == true) {
                        alert('Sorry No Time Slots Available For ' + $zestard_jq("#delivery-date-pro-store-pickup").val() + ' Please Select Other Date');
                        $zestard_jq("#delivery-date-pro-store-pickup").val("");
                        $zestard_jq("#delivery-date-pro-store-pickup").focus();
                    }
                } else {
                    $zestard_jq("#delivery-time-store-pickup").html("");
                    $zestard_jq("#delivery-time-store-pickup").append("<option value=''>Choose Time</option>");
                    for (var key in response) {
                        $zestard_jq("#delivery-time-store-pickup").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                    }
                }
            }
        });
    });
}

function delivery_date_pro_local_delivery() {
    var day;
    $zestard_jq("#delivery-date-pro-local-delivery").change(function(dateText) {
        $zestard_jq(".ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active").css("cssText", "background:#000 !important;color:#fff !important;font-weight:700 !important;");
        var result = "";
        day = new Date(this.value).getDay();
        $zestard_jq.ajax({
            url: base_path_delivery_date + "delivery-times",
            data: { todays_date: this.value, date_format: date_formate, shop_name: shop_name },
            async: false,
            success: function(response) {
                if (response == 0) {
                    $zestard_jq("#delivery-time-local-delivery").html("");
                    if (is_time_required == true) {
                        alert('Sorry No Time Slots Available For ' + $zestard_jq("#delivery-date-pro-local-delivery").val() + ' Please Select Other Date');
                        $zestard_jq("#delivery-date-pro-local-delivery").val("");
                        $zestard_jq("#delivery-date-pro-local-delivery").focus();
                    }
                } else {
                    $zestard_jq("#delivery-time-local-delivery").html("");
                    $zestard_jq("#delivery-time-local-delivery").append("<option value=''>Choose Time</option>");
                    for (var key in response) {
                        $zestard_jq("#delivery-time-local-delivery").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                    }
                }
            }
        });
    });
}
// For remove default date as selected
function remove_default_date(){
    $zestard_jq(".visible_datepicker").val("");
    $zestard_jq(".visible_datepicker").find(".ui-state-active").removeClass("ui-state-active");
    $zestard_jq(".visible_datepicker").find(".ui-state-hover").removeClass("ui-state-hover");

}
// For remove todays date as selected
function disable_today_highlight(){
    setTimeout(function () {
        $zestard_jq(".ui-datepicker-today").find('a.ui-state-highlight').removeClass('ui-state-highlight');
        $zestard_jq(".ui-datepicker-today").find('a.ui-state-hover').removeClass('ui-state-hover');
    }, 10);
}