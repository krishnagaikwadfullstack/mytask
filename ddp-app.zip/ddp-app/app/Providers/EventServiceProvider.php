<?php

namespace App\Providers;

use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],
        'App\Events\AppInstallationProcessed' => [
           'App\Listeners\SendAppInstallationNotification',
        ],
        'App\Events\AppConfirmationProcessed' => [
           'App\Listeners\SendAppConfirmationNotification',
        ],
        'App\Events\ErrorOccurredEvent' => [
           'App\Listeners\SendErrorNotification',
        ],
        'App\Events\JavaScriptErrorOccurredEvent' => [
           'App\Listeners\SendJavaScriptErrorNotification',
        ],
        'App\Events\OrderProcessedEvent' => [
           'App\Listeners\SendOrderNotification',
        ],
        'App\Events\AppUnInstallationProcessed' => [
           'App\Listeners\SendAppUnInstallationNotification',
        ],
        'App\Events\WebhookProcessedEvent' => [
           'App\Listeners\SendWebhookNotification',
        ],
        'App\Events\FiveDayCronProcessedEvent' => [
           'App\Listeners\SendFiveDayCronNotification',
        ],
        'App\Events\PlanChangeCronProcessedEvent' => [
           'App\Listeners\SendPlanChangeCronNotification',
        ],
        'App\Events\PlanVerificationCronProcessedEvent' => [
           'App\Listeners\SendPlanVerificationNotification',
        ],
        'App\Events\TestChargeUpdateEvent' => [
           'App\Listeners\SendTestChargeUpdateNotification',
        ],
        'App\Events\TestPlanLiveStoreEvent' => [
           'App\Listeners\SendTestPlanLiveStoreNotification',
        ],
        'App\Events\CreateNewChargeEvent' => [
           'App\Listeners\SendCreateNewChargeNotification',
        ],
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
