<?php
$json = '' . file_get_contents('php://input') . '';
$result = json_decode($json);
$connection = new mysqli("localhost", "zestards_apps", "9]X$8}_q2~dl", "zestards_shopifylive_delivery_date_pro");

return true;
?>