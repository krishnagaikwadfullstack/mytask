<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Google\Auth\OAuth2;

use Google\AdsApi\AdWords\AdWordsServices;

use Google\AdsApi\AdWords\AdWordsSession;

use Google\AdsApi\AdWords\AdWordsSessionBuilder;

use Google\AdsApi\AdWords\v201809\cm\CampaignService;

use Google\AdsApi\AdWords\v201809\cm\OrderBy;

use Google\AdsApi\AdWords\v201809\cm\Paging;

use Google\AdsApi\AdWords\v201809\cm\Selector;

use Google\AdsApi\AdWords\v201809\cm\SortOrder;

use Google\AdsApi\AdWords\v201809\mcm\ManagedCustomer;

use Google\AdsApi\AdWords\v201809\mcm\ManagedCustomerService;

//use Google\AdsApi\Common\OAuth2TokenBuilder;

use Google\AdsApi\AdWords\v201809\mcm\CustomerService;

use Google\AdsApi\AdWords\v201809\mcm\RemarketingSettings;

use Google\Ads\GoogleAds\Lib\V8\GoogleAdsClient;

use Google\Ads\GoogleAds\Lib\V8\Resources\Customer;

use Google\Ads\GoogleAds\Lib\V8\GoogleAdsClientBuilder;

use Google\Ads\GoogleAds\Lib\V8\GoogleAdsException;

use Google\Ads\GoogleAds\Lib\OAuth2TokenBuilder;

use Google\Ads\GoogleAds\V8\Errors\GoogleAdsError;

use League\OAuth2\Client\Provider\Google;

use League\OAuth2\Client\Grant\RefreshToken;

use Google\ApiCore\ApiException;

use App\User;

use App\CustomerList;

use App\ChildCustomerList;
use Exception;


class GoogleauthController extends Controller{

    // Display order for Basic Plan
    
    public function index(Request $request){
        $shop = session('shop');
        if (empty($shop)) {
        $shop =  $request['shop'];
        }
        session(['shop' => $shop]);
        $user = User::where('store_name', $shop)->first();
        // $user_count = count($user);
       
        if(!is_null($user)){
            return redirect()->route('list-access-customer', ['shop' => $shop]);
        }else{

            session_start();    
            $provider = new Google([
                'authorizationUri' => 'https://accounts.google.com/o/oauth2/v2/auth',
                'tokenCredentialUri' => 'https://www.googleapis.com/oauth2/v4/token',
                'clientId' => '74122641614-oq2ka0lppos533c1uaavmhml49hbo6fi.apps.googleusercontent.com',
                'clientSecret' => 'rJHhb2vAT0-Ha6Ucle-Y8nXP',
                'redirectUri' => 'https://shopify.oxedent.com/public/checkauth',
                'accessType' => 'offline',
                'approval_prompt' => 'force',
                'scopes' => ['https://www.googleapis.com/auth/adwords'],
            ]);
            if (!isset($_GET['code'])) {
                // dd('ds',$request->all());
                    $authUrl = $provider->getAuthorizationUrl();
                    $_SESSION['oauth2state'] = $provider->getState();
                    header('Location: ' . $authUrl);
                    exit;
            }elseif (empty($_GET['state']) || ($_GET['state'] !== $_SESSION['oauth2state'])) {
                      unset($_SESSION['oauth2state']);
                      exit('Invalid state.');
            } else {
                // Try to get an access token (using the authorization code grant)
                $token = $provider->getAccessToken('authorization_code', [
                    'code' => $_GET['code']
                ]);
                // Optional: Now you have a token you can look up a users profile data
                try {
                    // We got an access token, let's now get the owner details
                    $ownerDetails = $provider->getResourceOwner($token);
                    $ownerDetails = $ownerDetails->toArray();
                    // Use these details to create a new profile
                    $user = User::create([
                            'access_token' => $token->getToken(),
                            'refresh_token' => $token->getRefreshToken(),
                            'name' => $ownerDetails['name'],
                            'email' => $ownerDetails['email'],
                            'store_name' => $shop,
                        ]);
                   
                    $user->save();
                    return redirect()->route('list-access-customer', ['shop' => $shop]);
                } catch (Exception $e) {
                    // Failed to get user details
                    exit('Something went wrong: ' . $e->getMessage());
                }
             }
        }
    }

    /**
        * This example lists the resource names for the customers that the authenticating user has access
        * to.
    */
    public function ListAccessibleCustomers(Request $request){
            $shop = session('shop');
        // dd($request->all(),$shop);
        if (empty($shop)) {
            $shop =  $request->shop;
            session(['shop' => $shop]);
        }
        $user = User::where('store_name', $shop)->first();
        try {
            // Generate a refreshable OAuth2 credential for authentication.
            $oAuth2Credential = (new OAuth2TokenBuilder())
                //->fromFile('/home/anujdala/domains/shopifydev/kamlesh/Kamlesh/adsapi_php.ini')
                ->withClientId('74122641614-oq2ka0lppos533c1uaavmhml49hbo6fi.apps.googleusercontent.com')
                ->withClientSecret('rJHhb2vAT0-Ha6Ucle-Y8nXP')
                ->withRefreshToken($user->refresh_token)
                ->build();

            // Construct a Google Ads client configured from a properties file and the
            // OAuth2 credentials above.
            $googleAdsClient = (new GoogleAdsClientBuilder())
                //->fromFile('/home/anujdala/domains/shopifydev/kamlesh/Kamlesh/adsapi_php.ini')
                ->withDeveloperToken('m7gnD_65QgMynX6EuXGohg')
                // ->withLoginCustomerId("4681827972")
                ->withOAuth2Credential($oAuth2Credential)
                ->build();   
        } catch (Exception $e) {
            $user = User::where('store_name', $shop)->delete();
            echo "Please remove Apps access to your google ads account, then try to connect again";
            exit(1);
        }

        try {
            $insert_status = $this->runExample($googleAdsClient, $shop);
            
        } catch (GoogleAdsException $googleAdsException) {
            printf(
                "Request with ID '%s' has failed.%sGoogle Ads failure details:%s",
                $googleAdsException->getRequestId(),
                PHP_EOL,
                PHP_EOL
            );
            foreach ($googleAdsException->getGoogleAdsFailure()->getErrors() as $error) {
                // @var GoogleAdsError $error 
                printf(
                    "\t%s: %s%s",
                    $error->getErrorCode()->getErrorCode(),
                    $error->getMessage(),
                    PHP_EOL
                );
            }
            exit(1);
        } catch (ApiException $apiException) {
            // dd($apiException);
            printf(
                "ApiException was thrown with message '%s'.%s",
                $apiException->getMessage(),
                PHP_EOL
            );
            exit(1);
        }
        if($insert_status == 0){
            //$message = 'No Customer Found';
           return redirect()->route('dashboard', ['shop' => $shop])
                                    ->with('status', 'No Customer Found');
        }else{

            return redirect()->route('dashboard', ['shop' => $shop]); 
        }
    
    }

    public static function runExample(GoogleAdsClient $googleAdsClient, $shop){
        $customerServiceClient = $googleAdsClient->getCustomerServiceClient();
        // dd($customerServiceClient->listAccessibleCustomers());
        // Issues a request for listing all accessible customers.
        $accessibleCustomers = $customerServiceClient->listAccessibleCustomers();

        $flag = 0;
        //echo "<pre>";
        $cusotmer_count = count($accessibleCustomers->getResourceNames()) . PHP_EOL;
        // Iterates over all accessible customers' resource names and prints them.
        foreach ($accessibleCustomers->getResourceNames() as $resourceName) {
            try {
                //$cusotmer_id = str_replace("customers/","",$resourceName);
                $getCustomer = $customerServiceClient->getCustomer($resourceName);
                $customer_id = $getCustomer->getId();
                $_this = new self;
                CustomerList::insert(['customer_id' => $customer_id, 'descriptive_name' => $getCustomer->getDescriptiveName(), 'manager_status' => $getCustomer->getManager(), 'store_name' => $shop ]);
                $customer = $_this->herirchyCustomers($customer_id, $shop);
                $flag = 1;
                /*if($getCustomer->getManager() != 1){
                    
                    
                }
                print_r($getCustomer->getId());
                print_r($getCustomer->getDescriptiveName());
                print_r($getCustomer->getManager());
                echo "</br>";*/
            } catch (Exception $e) {
                if($e->getCode() == 7)
                    continue;
                return 3;
            }
        }
        return $flag; 
    }

    /**
        * Gets the account hierarchy of the specified manager customer ID and login customer ID.
    */
    public function herirchyCustomers($adword_id, $shop){
        $user = User::where('store_name', $shop)->first();
        
        // Generate a refreshable OAuth2 credential for authentication.
        $oAuth2Credential = (new OAuth2TokenBuilder())
            //->fromFile()
            ->withClientId('74122641614-oq2ka0lppos533c1uaavmhml49hbo6fi.apps.googleusercontent.com')
            ->withClientSecret('rJHhb2vAT0-Ha6Ucle-Y8nXP')
            ->withRefreshToken($user->refresh_token)
            ->build();

        // Construct an API session configured from a properties file and the
        // OAuth2 credentials above.
        $session = (new AdWordsSessionBuilder())
            //->fromFile()
            ->withDeveloperToken('m7gnD_65QgMynX6EuXGohg')
            ->withClientCustomerId($adword_id)
            ->withOAuth2Credential($oAuth2Credential)
            ->build();

        $respone = self::runExample1(new AdWordsServices(), $session, $adword_id, $shop);
        return $respone;
    }

    public static function runExample1(AdWordsServices $adWordsServices, AdWordsSession $session, $adword_id, $shop) {
        $managedCustomerService = $adWordsServices->get($session, ManagedCustomerService::class);

        // Create selector.
        $selector = new Selector();
        $selector->setFields(['CustomerId', 'Name']);
        $selector->setOrdering([new OrderBy('CustomerId', SortOrder::ASCENDING)]);
        $selector->setPaging(new Paging(0, 500));

        // Maps from customer IDs to accounts and links.
        $customerIdsToAccounts = [];
        $customerIdsToChildLinks = [];
        $customerIdsToParentLinks = [];

        $totalNumEntries = 0;
        do {
            // Make the get request.
            $page = $managedCustomerService->get($selector);

            // Create links between manager and clients.
            if ($page->getEntries() !== null) {
                $totalNumEntries = $page->getTotalNumEntries();
                if ($page->getLinks() !== null) {
                    foreach ($page->getLinks() as $link) {
                        // Cast the indexes to string to avoid the issue when 32-bit PHP
                        // automatically changes the IDs that are larger than the 32-bit max
                        // integer value to negative numbers.
                        $managerCustomerId = strval($link->getManagerCustomerId());
                        $customerIdsToChildLinks[$managerCustomerId][] = $link;
                        $clientCustomerId = strval($link->getClientCustomerId());
                        $customerIdsToParentLinks[$clientCustomerId] = $link;
                    }
                }
                foreach ($page->getEntries() as $account) {
                    $customerIdsToAccounts[strval($account->getCustomerId())] = $account;
                }
            }

            // Advance the paging index.
            $selector->getPaging()->setStartIndex(
                $selector->getPaging()->getStartIndex() + 500
            );
        } while ($selector->getPaging()->getStartIndex() < $totalNumEntries);

        // Find the root account.
        $rootAccount = null;
        foreach ($customerIdsToAccounts as $account) {
            if (!array_key_exists(
                $account->getCustomerId(),
                $customerIdsToParentLinks
            )) {
                $rootAccount = $account;
                break;
            }
        }

        if ($rootAccount !== null) {
            // Display results.
            self::printAccountHierarchy($rootAccount, $customerIdsToAccounts, $customerIdsToChildLinks, $adword_id, $shop);
        } else {
            printf("No accounts were found.\n");
            return 2;
        }
    }

    
    private static function printAccountHierarchy($account, $customerIdsToAccounts, $customerIdsToChildLinks, $adword_id, $shop, $depth = null) {
        if ($depth === null) {
            //print "(Customer ID, Account Name)\n";

            self::printAccountHierarchy($account, $customerIdsToAccounts, $customerIdsToChildLinks,$adword_id, $shop,0);
            return;
        }
 
        $customerId = $account->getCustomerId();
        if($account->getCustomerId() != $adword_id){

            ChildCustomerList::insert(['child_customer_id' => $customerId ,'customer_id' => $adword_id, 'descriptive_name' => $account->getName(), 'store_name' => $shop ]);
        }
        
        if (array_key_exists($customerId, $customerIdsToChildLinks)) {
            foreach ($customerIdsToChildLinks[strval($customerId)] as $childLink) {
                $childAccount = $customerIdsToAccounts[strval($childLink->getClientCustomerId())];

                self::printAccountHierarchy($childAccount, $customerIdsToAccounts,$customerIdsToChildLinks, $adword_id, $shop, $depth + 1);
            }
        }   
    }

}
?>