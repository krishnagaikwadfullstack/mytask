<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App;
use Session;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\ShopModel;
use App\BlockConfig;
use Mail;
use App\AppSettings;
use App\TrialInfo;
use App\DevelopmentStore;
use App\StoreInformation;
use App\CutoffSettings;
use App\Events\AppInstallationProcessed;
use App\Events\AppConfirmationProcessed;
use App\Events\ErrorOccurredEvent;
use App\Events\CreateNewChargeEvent;
use Exception;

class callbackController extends Controller {

    public function __construct() {
        $this->api_version = getenv('API_VERSION');
        $this->error_info_array = [];
    }

    /**
     * Function index
     */
    public function index(Request $request) {
        $sh = App::make('ShopifyAPI');
        $getAppSettings = AppSettings::where('id', 1)->first();
        $shop = $request->shop;
        $this->error_info_array['shop'] = $shop;
        if ($shop) {
            try {
                $getShopDetails = ShopModel::whereStoreName($shop)->first();
                $this->error_info_array['shop_info'] = $getShopDetails;
                if ($getShopDetails) {
                    try {
                        // if store already in database 
                        session(['shop' => $shop]);
                        $sh = App::make('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $getShopDetails->access_token]);
                    } catch (Exception $e) {
                        $this->fn_send_error_mail($e,14);
                        echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                        exit;
                    }
                    
                    try {
                        //check that app is active or not
                        if ($getShopDetails->charge_id != "" && $getShopDetails->charge_id > 0 && $getShopDetails->status == "active") {
                            //check the version of app selected or not
                            if ($getShopDetails->app_version > 0 && $getShopDetails->type_of_app > 0) {
                                session(['shop' => $shop]);
                                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                            } else {
                                return redirect()->route('plans',['shop' => $shop])->with(['shop'=>$shop]);
                            }
                        } else {//if app is not active then redirect user to the payment process 
                            return redirect()->route('payment_process',['shop' => $shop])->with(['shop'=>$shop]);
                        }   
                    } catch (Exception $e) {
                        $this->fn_send_error_mail($e,15);
                        echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                        exit;
                    }
                } else {
                    $read_all_orders = '';
                    return view('appconfiguration',compact(['shop','read_all_orders']));
                }
            } catch (Exception $e) {
                $this->fn_send_error_mail($e,1);
                echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                exit;
            }
        }
    }

    /**
     * Function redirect
     */
    public function redirect(Request $request) {
        $this->api_version = getenv('API_VERSION');
        $shop = $request->shop;
        $code = $request->code;
        $getAppSettings = AppSettings::where('id', 1)->first();
        $getShopDetails = ShopModel::whereStoreName($shop)->first();
        $this->error_info_array['shop'] = $shop;

        if ($shop != "" && $code != "") {
            try {
                ## Check trial days info
                $trialDays = env('TRIAL_DAYS');
                $getTrialDetails = TrialInfo::where('store_name', $shop)->first();
                // If trial is already exists
                if ($getTrialDetails)
                    $trialDays = $this->fn_get_trial_days($shop);

                ## If store is already exits then redirect to dashboard or payment.
                if (isset($getShopDetails) && !empty($getShopDetails) && !empty($getShopDetails->charge_id)) {
                    try {
                        $this->error_info_array['shop_info'] = $getShopDetails;
                        $sh = App::make('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $getShopDetails->access_token]);
                        $url = 'admin/api/'.$this->api_version.'/recurring_application_charges/' . $getShopDetails->charge_id . '.json';
                        $charge = $sh->call(['URL' => $url, 'METHOD' => 'GET']);
                        $chargeId = $getShopDetails->charge_id;
                        $chargeStatus = $getShopDetails->status;
                        //prevent the multiple store entry 
                        if (!empty($chargeId) && $chargeId > 0 && $chargeStatus == "active") {
                            session(['shop' => $shop]);
                            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                        } else {
                            return redirect()->route('payment_process',['shop' => $shop])->with(['shop'=>$shop]);
                        }
                    } catch (Exception $e) {
                        $this->fn_send_error_mail($e,16);
                        echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                        exit;
                    }
                }

                $sh = App::make('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $shop]);
                //check that request is Generated from shopify or not
                $verify = $sh->verifyRequest($request->all());
                if ($verify) {
                    ##Save store information into database
                    try {
                        $accessToken = $sh->getAccessToken($code);
                        //code by kamlesh
                        $sh = app('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $accessToken]);
                        $shopi_info = $sh->callAdvance(['URL' => '/admin/api/'.$this->api_version.'/shop.json', 'METHOD' => 'GET']);
                        $this->error_info_array['shop_info'] = $shopi_info->shop;
                        $shop_address = $this->getShopAddress($shopi_info);

                        ShopModel::insert(['access_token' => $accessToken, 'store_name' => $shop, 'email' => $shopi_info->shop->email, 'shop_name' => $shopi_info->shop->name, 'owner_name' => $shopi_info->shop->shop_owner, 'plan_name'=> $shopi_info->shop->plan_name, 'phone'=> $shopi_info->shop->phone,'address'=> $shop_address, 'country_name'=> $shopi_info->shop->country_name]);
                        $getShopDetails = ShopModel::whereStoreName($shop)->first();
                        $getShopId = $getShopDetails->id;
                        $encryptShop = crypt($getShopId, "ze");
                        $encryptFinal = str_replace(['/', '.'], "Z", $encryptShop);
                        $getShopDetails->update(['store_encrypt' => $encryptFinal]);
                        //inserting the default configuration
                        BlockConfig::insert(['block_date' => null, 'alloved_month' => 6, 'date_interval' => 1, 'days' => null, 'hours' => 0, 'minute' => 0, 'shop_id' => $getShopId, 'app_title' => 'Delivery Date', 'date_error_message' => 'Please Enter Delivery Date', 'date_format' => 'yy/mm/dd', 'app_status' => 'Active', 'show_datepicker_label' => 1, 'datepicker_label' => 'Pick a delivery date:', 'add_delivery_information' => 0, 'language_locale' => 'en']);

                        ## insert default configuration
                        $getShopDetails->fn_locations()->create(['company_name'=>$shopi_info->shop->name,'address'=>$shop_address ,'city'=> $shopi_info->shop->city,'country'=>$shopi_info->shop->country_name,'state'=>$shopi_info->shop->province ,'zipcode'=>$shopi_info->shop->zip]);

                        $getShopDetails->fn_local_delivery()->create([]);
                        $getShopDetails->fn_store_pickup()->create([]);
                        session(['shop' => $shop]);
                        $sh->setup(['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $accessToken]);
                    } catch (Exception $e) {
                        dd($e);
                        $this->fn_send_error_mail($e,2);
                        echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                        exit;
                    }

                    ## Webhook and add snippets section
                    try {
                        //for creating the uninstall webhook
                        $url = 'https://' . $shop . '/admin/api/' . $this->api_version . '/webhooks.json';
                        {
                            $webhookData = [
                                'webhook' => [
                                    'topic' => 'app/uninstalled',
                                    'address' => env('SHOPIFY_WEBHOOK_1_ADDRESS'),
                                    'format' => 'json'
                                ]
                            ];
                        }
                        $uninstall = $sh->appUninstallHook($accessToken, $url, $webhookData); 
                        {
                            //webhook for checkout                    
                            $webhookData = [
                                'webhook' => [
                                    'topic' => 'orders/create',
                                    'address' => env('SHOPIFY_WEBHOOK_2_ADDRESS'),
                                    'format' => 'json'
                                ]
                            ];
                        }
                        $checkout = $sh->appUninstallHook($accessToken, $url, $webhookData);
                        {
                            //webhook for shop update                    
                            $webhookData = [
                                'webhook' => [
                                    'topic' => 'shop/update',
                                    'address' => env('SHOPIFY_WEBHOOK_3_ADDRESS'),
                                    'format' => 'json'
                                ]
                            ];
                        }
                        $shopupdate = $sh->appUninstallHook($accessToken, $url, $webhookData);
                        {
                            //webhook for order update
                            $webhookData = [
                                'webhook' => [
                                    'topic' => 'orders/updated',
                                    'address' => env('SHOPIFY_WEBHOOK_4_ADDRESS'),
                                    'format' => 'json'
                                ]
                            ];
                        }
                        $orderupdate = $sh->appUninstallHook($accessToken, $url, $webhookData);
                        //api call for get theme info
                        $theme = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/', 'METHOD' => 'GET']); //'DATA' => ['role' => 'main']     
                        foreach ($theme->themes as $themeData) {
                            if ($themeData->role != 'demo') {
                                $theme_id = $themeData->id;
                                $content = View('snippets')->render();
                                $view = (string) $content;
                                $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'snippets/delivery-date.liquid', 'value' => $view]]]);
                            }
                        }
                    } catch (Exception $e) {
                        $this->fn_send_error_mail($e,3);
                        echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                        exit;
                    }
                    ## Save store information section
                    try {
                        $getShopDetails = $getShopDetails->refresh();
                        $getShopId = $getShopDetails->id;
                        StoreInformation::updateOrCreate(['store_name'=>$shopi_info->shop->name],[
                            'shop_id' => $getShopId, 
                            'store_information_id' => $shopi_info->shop->id, 
                            'store_name' => $shopi_info->shop->name, 
                            'store_email' => $shopi_info->shop->email, 
                            'store_domain' => $shopi_info->shop->domain, 
                            'store_address'=> $shop_address, 
                            'store_phone'=> $shopi_info->shop->phone,
                            'store_created'=> date('Y-m-d H:i:s', strtotime($shopi_info->shop->created_at)),
                            'store_updated'=> date('Y-m-d H:i:s', strtotime($shopi_info->shop->updated_at)), 
                            'store_country_name'=> $shopi_info->shop->country_name, 
                            'store_currency'=> $shopi_info->shop->currency, 
                            'store_owner' => $shopi_info->shop->shop_owner, 
                            'store_plan_name'=> $shopi_info->shop->plan_name 
                        ]);
                        $shopi_info->shop_id = $getShopId;
                        //send the installation follow up mail to client and support
                        event(new AppInstallationProcessed($shopi_info));
                        return redirect()->route('plans',['shop' => $shop])->with(['shop'=>$shop]);
                        //redirecting to the Shopify payment page
                        echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>';
                    } catch (Exception $e) {
                        $this->fn_send_error_mail($e,5);
                        echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                        exit;
                    }
                }
            } catch (Exception $e) {
                $this->fn_send_error_mail($e,6);
                echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                exit;
            }
        }
    }

    /**
     * function dashboard
     */
    public function dashboard() {
        $shop = session('shop') ?? request()->get('shop');
        $getAppSettings = AppSettings::where('id', 1)->first();
        $getShopDetails = ShopModel::whereStoreName($shop)->first();
        $sh = App::make('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $getShopDetails->access_token]);
        return view('dashboard');
    }

    /**
     * function payment_method
     */
    public function payment_method(Request $request) {
        $shop = session('shop') ?? request()->get('shop');
        $this->error_info_array['shop'] = $shop;
        try {
            $app_settings = AppSettings::where('id', 1)->first();
            $select_store = ShopModel::whereStoreName($shop)->first();
            if (!is_null($select_store)) {
                $this->error_info_array['shop_info'] = $select_store;
                $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $select_store->access_token]);

                $charge_id = $select_store->charge_id;
                if(empty($charge_id) || is_null($charge_id)) {
                   return redirect()->route('plans',['shop' => $shop])->with(['shop'=>$shop]);
                }else{
                    $url = 'admin/api/'.$this->api_version.'/recurring_application_charges/' . $charge_id . '.json';
                    $charge = $sh->call(['URL' => $url, 'METHOD' => 'GET']);
                    if (!empty($charge)) {
                        if ($charge->recurring_application_charge->status == "pending") {
                            echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>';
                        } elseif ($charge->recurring_application_charge->status == "declined" || $charge->recurring_application_charge->status == "expired") {
                            //creating the new Recuring charge after declined app
                            $url = 'https://' . $shop .'/admin/api/'.$this->api_version.'/recurring_application_charges.json';
                            $zestard_demo_stores = explode(',', env('SHOPIFY_STORE_NAME'));
                            if (in_array($shop, $zestard_demo_stores) || $select_store->plan_name == 'partner_test' || $select_store->plan_name == 'Developer Preview' || $select_store->plan_name == 'affiliate') {
                                ## Check trial days info
                                $trialDays = env('TRIAL_DAYS');
                                $getTrialDetails = TrialInfo::where('store_name', $shop)->first();
                                // If trial is already exists
                                if ($getTrialDetails)
                                    $trialDays = $this->fn_get_trial_days($shop);
                                $charge = $sh->call([
                                    'URL' => $url,
                                    'METHOD' => 'POST',
                                    'DATA' => array(
                                        'recurring_application_charge' => array(
                                            'name' => 'Delivery Date Pro - Basic Version',
                                            'price' => 0.01,
                                            'return_url' => url('payment_success?shop='.$shop),
                                            // "capped_amount" => 30,
                                            // "terms" => "Additional charges as per the plan",
                                            'test' => true,
                                            'trial_days' => $trialDays
                                        )
                                    )
                                        ], false);
                            } else {
                                $charge = $sh->call([
                                    'URL' => $url,
                                    'METHOD' => 'POST',
                                    'DATA' => array(
                                        'recurring_application_charge' => array(
                                            'name' => 'Delivery Date Pro - Basic Version',
                                            'price' => env('APP_PRICE'),
                                            'return_url' => url('payment_success?shop='.$shop),
                                            // "capped_amount" => 30,
                                            // "terms" => "Additional charges as per the plan",
                                        //'test' => true
                                        )
                                    )
                                        ], false);
                            }
                            //updating the charge info in the database
                            $create_charge = ShopModel::where('store_name', $shop)->update(['charge_id' => (string) $charge->recurring_application_charge->id, 'api_client_id' => $charge->recurring_application_charge->api_client_id, 'price' => $charge->recurring_application_charge->price, 'status' => $charge->recurring_application_charge->status, 'billing_on' => $charge->recurring_application_charge->billing_on, 'payment_created_at' => $charge->recurring_application_charge->created_at, 'activated_on' => $charge->recurring_application_charge->activated_on, 'trial_ends_on' => $charge->recurring_application_charge->trial_ends_on, 'cancelled_on' => $charge->recurring_application_charge->cancelled_on, 'trial_days' => $charge->recurring_application_charge->trial_days, 'decorated_return_url' => $charge->recurring_application_charge->decorated_return_url, 'confirmation_url' => $charge->recurring_application_charge->confirmation_url, 'domain' => $shop]);

                            //redirecting to the Shopify payment page
                            echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>';
                        } else {
                            //check that user selected any plan or not
                            if ($select_store->app_version > 0 && $select_store->type_of_app > 0) {
                                session(['shop' => $shop]);
                                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                            } else {//Redirect user on the plan page where user can select the relevant plan
                                return redirect()->route('plans',['shop' => $shop])->with(['shop'=>$shop]);
                            }
                        }
                    }
                }
            }
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,7);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit;
        }
    }

    /**
     * Function paymentComplete
     */
    public function paymentComplete(Request $request) {
        $shop = session('shop') ?? request()->get('shop');
        $this->error_info_array['shop'] = $shop;
        try {
            $getAppSettings = AppSettings::where('id', 1)->first();
            $getShopDetails = ShopModel::whereStoreName($shop)->first();
            $this->error_info_array['shop_info'] = $getShopDetails;
            $getShopId = $getShopDetails->id;
            $sh = App::make('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $getShopDetails->access_token]);
            $chargeId = $request->charge_id;
            $url = 'admin/api/'.$this->api_version.'/recurring_application_charges/#{' . $chargeId . '}.json';
            $charge = $sh->call(['URL' => $url, 'METHOD' => 'GET',]);
            $status = $charge->recurring_application_charges[0]->status;
            ShopModel::where('store_name', $shop)->where('charge_id', $chargeId)->update(['status' => $status]);
            if ($status == "active") {
                // $active_url = '/admin/api/'.$this->api_version.'/recurring_application_charges/' . $chargeId . '/activate.json';
                // $activateCharge = $sh->call(['URL' => $active_url, 'METHOD' => 'POST', 'HEADERS' => array('Content-Length: 0')]);
                // $activateChargeArray = get_object_vars($activateCharge);
                $activeStatus = $charge->recurring_application_charges[0]->status;
                $trialStart = $charge->recurring_application_charges[0]->activated_on;
                $trialEnd = $charge->recurring_application_charges[0]->trial_ends_on;
                $trialDays = $charge->recurring_application_charges[0]->trial_days;
                ShopModel::where('store_name', $shop)->where('charge_id', $chargeId)->update(['status' => $activeStatus, 'activated_on' => $trialStart, 'trial_ends_on' => $trialEnd]);
                //return redirect()->route('dashboard');
                //check if any trial info is exists or not
                if ($trialDays > 0) {
                    $getTrialDetails = TrialInfo::updateOrCreate(['store_name'=>$shop],[
                        'store_name' => $shop,
                        'shop_id' => $getShopId,
                        'trial_days' => $trialDays,
                        'activated_on' => $trialStart,
                        'trial_ends_on' => $trialEnd
                    ]);
                }
                //check that user selected any plan or not
                if ($getShopDetails->app_version > 0 && $getShopDetails->type_of_app > 0) {
                    session(['shop' => $shop]);
                    return redirect()->route('dashboard',['shop' => $shop])->with(['shop'=>$shop]);
                } else {
                    return redirect()->route('plans',['shop' => $shop])->with(['shop'=>$shop]);
                }
            } elseif ($status == "declined") {//Redirect user to the confirmation page
                echo '<script>window.top.location.href="https://' . $shop . '/admin/apps"</script>';
            }
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,8);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit();
        }
    }

    /**
     * for the help page
     */
    public function help(Request $request) {
        $shop = session('shop') ?? request()->get('shop');
        $shop_find = ShopModel::whereStoreName($shop)->first();
        $app_version = $shop_find->app_version;
        return view('help', ['active' => 'order', 'id' => $shop_find->id, 'app_version' => $app_version, 'shop' => $shop, 'active' => 'help']);
    }

    /**
     * function plans
     */
    public function plans() {
        $data['shop'] = session('shop') ?? request()->get('shop');
        $data['getShopDetails'] = ShopModel::where('store_name', $data['shop'])->first();
        if ($data['getShopDetails']->app_version > 0)
            return redirect()->route('dashboard', ['shop' => $data['shop']])->with(['shop'=>$data['shop']]);
        return view('backend.plans', compact('data'));
    }

    /**
     * //For showing plans page when changing version
     */
    public function changePlan() {
        $data['shop'] = session('shop') ?? request()->get('shop');
        $data['getShopDetails'] = ShopModel::where('store_name', $data['shop'])->first();
        return view('backend.plans', compact('data'));
    }

    /**
     * //to create the usage charge as per the plan selected by user
     */
    public function updatePlan(Request $request, $planId) {
        $shop = session('shop') ?? request()->get('shop');
        try {
            if (empty($shop)) {
                $shop = request()->get('shop');
            }
            $this->error_info_array['shop'] = $shop;
            $getShopDetails = ShopModel::whereStoreName($shop)->first();
            $getAppSettings = AppSettings::where('id', 1)->first();
            $this->error_info_array['shop_info'] = $getShopDetails;
            $sh = App::make('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $getShopDetails->access_token]);
            if ($planId == 2) {
                $description = "Professional";
                $price = env('APP_PRICE') + env('PROFESSIONAL');
                $appVersion = 2;
                $typeOfApp = 2;
                $app_plan_name = "Delivery Date Pro - Professional Version";
            } elseif ($planId == 3) {
                $description = "Enterprise";
                $price = env('APP_PRICE') + env('ENTERPRISE');
                $appVersion = 3;
                $typeOfApp = 3;
                $app_plan_name = "Delivery Date Pro - Enterprise Version";
            } elseif ($planId == 4) {
                $description = "Ultimate";
                $price = env('APP_PRICE') + env('ULTIMATE');
                $appVersion = 4;
                $typeOfApp = 4;
                $app_plan_name = "Delivery Date Pro - Ultimate Version";
            }
            ## Check trial days info
            $trialDays = env('TRIAL_DAYS');
            $getTrialDetails = TrialInfo::where('store_name', $shop)->first();
            // If trial is already exists
            if ($getTrialDetails)
                $trialDays = $this->fn_get_trial_days($shop);

            $url = 'https://' . $shop . '/admin/api/'.$this->api_version.'/recurring_application_charges.json';
            $zestard_demo_stores = explode(',', env('SHOPIFY_STORE_NAME'));
            if (in_array($shop, $zestard_demo_stores) || $getShopDetails->plan_name == 'partner_test' || $getShopDetails->plan_name == 'Developer Preview' || $getShopDetails->plan_name == 'affiliate') {
                // For zestard  and development store
                $charge = $sh->call([
                    'URL' => $url,
                    'METHOD' => 'POST',
                    'DATA' => array(
                        'recurring_application_charge' => array(
                            'name' => $app_plan_name,
                            'price' => 0.01,
                            'return_url' => url('payment_success?shop='.$shop),
                            // "capped_amount" => 30,
                            // "terms" => "Additional charges as per the plan",
                            'test' => true,
                            'trial_days' => $trialDays
                        )
                )], false);

                $updateShopData = array(
                    'charge_id' => (string) $charge->recurring_application_charge->id,
                    'api_client_id' => $charge->recurring_application_charge->api_client_id,
                    'price' => $charge->recurring_application_charge->price,
                    'status' => $charge->recurring_application_charge->status,
                    'billing_on' => $charge->recurring_application_charge->billing_on,
                    'payment_created_at' => $charge->recurring_application_charge->created_at,
                    'activated_on' => $charge->recurring_application_charge->activated_on,
                    'trial_ends_on' => $charge->recurring_application_charge->trial_ends_on,
                    'cancelled_on' => $charge->recurring_application_charge->cancelled_on,
                    'trial_days' => $charge->recurring_application_charge->trial_days,
                    'decorated_return_url' => $charge->recurring_application_charge->decorated_return_url,
                    'confirmation_url' => $charge->recurring_application_charge->confirmation_url,
                    'usage_price' => $price, 
                    'app_version' => $appVersion,
                    'type_of_app' => $typeOfApp,
                    'upgrade_status' => "Y"
                );
                ShopModel::where('store_name', $shop)->update($updateShopData);

                // $updateData = array(
                //         'app_version' => $appVersion,
                //         'type_of_app' => $typeOfApp,
                //         'upgrade_status' => "Y"
                //     );
                // ShopModel::where('store_name', $shop)->where('charge_id', $recuringId)->update($updateData);
                if ($planId == 4) {
                    // insert product snippet file to the product theme
                    $theme = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/', 'METHOD' => 'GET']);
                    foreach ($theme->themes as $themeData) {
                        if ($themeData->role != 'demo') {
                            $theme_id = $themeData->id;
                            $content = View('product_snippets')->render();
                            $view = (string) $content;
                            $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'snippets/product-delivery-date.liquid', 'value' => $view]]]);
                        }
                    }
                } 
                echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>'; 
            } else {

                // for client store
                //creating the Recurring charge for app
                $url = 'https://' . $shop . '/admin/api/'.$this->api_version.'/recurring_application_charges.json';
                $charge = $sh->call([
                    'URL' => $url,
                    'METHOD' => 'POST',
                    'DATA' => array(
                        'recurring_application_charge' => array(
                            'name' => $app_plan_name,
                            'price' => $price,
                            'return_url' => url('payment_success?shop='.$shop),
                            // "capped_amount" => 30,
                            // "terms" => "Additional charges as per the plan",
                            //'test' => true,
                            'trial_days' => $trialDays
                        )
                    )], false);
            
                $updateShopData = array(
                    'charge_id' => (string) $charge->recurring_application_charge->id,
                    'api_client_id' => $charge->recurring_application_charge->api_client_id,
                    'price' => $charge->recurring_application_charge->price,
                    'status' => $charge->recurring_application_charge->status,
                    'billing_on' => $charge->recurring_application_charge->billing_on,
                    'payment_created_at' => $charge->recurring_application_charge->created_at,
                    'activated_on' => $charge->recurring_application_charge->activated_on,
                    'trial_ends_on' => $charge->recurring_application_charge->trial_ends_on,
                    'cancelled_on' => $charge->recurring_application_charge->cancelled_on,
                    'trial_days' => $charge->recurring_application_charge->trial_days,
                    'decorated_return_url' => $charge->recurring_application_charge->decorated_return_url,
                    'confirmation_url' => $charge->recurring_application_charge->confirmation_url,
                    'usage_price' => $price, 
                    'app_version' => $appVersion,
                    'type_of_app' => $typeOfApp,
                    'upgrade_status' => "Y"
                );
                ShopModel::where('store_name', $shop)->update($updateShopData);
                if ($planId == 4) {
                    $theme = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/', 'METHOD' => 'GET']);
                    foreach ($theme->themes as $themeData) {
                        if ($themeData->role != 'demo') {
                            $theme_id = $themeData->id;
                            $content = View('product_snippets')->render();
                            $view = (string) $content;
                            $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'snippets/product-delivery-date.liquid', 'value' => $view]]]);
                        }
                    }
                }
                echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>'; 
            }
            // return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,9);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit();
        }
    }

    /**
     * For Sending email on confirmation of usage charge during trial period
     */
    public function send_confirm_email(Request $request) {
        try {
            $shop = $request->input('shop');
            $shop_find = ShopModel::whereStoreName($shop)->first();
            $trialDays = $this->fn_get_trial_days($shop);
            $zestard_demo_stores = explode(',', env('SHOPIFY_STORE_NAME'));
            if (!in_array($shop, $zestard_demo_stores) && $shop_find->plan_name != 'partner_test' && $shop_find->plan_name != 'Developer Preview' && $shop_find->plan_name != 'affiliate' && $trialDays <= 0) {
                // if($trialDays <= 0)
                    event(new AppConfirmationProcessed($shop_find));
            }
            return $trialDays;
        } catch (Exception $e) {
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
        }
    }


    // For Sending email on confirmation of usage charge during trial period
    public function send_demo_confirm_email(Request $request) {
        try {
            // $shop = $request->input('shop');
            // $trialDays = $this->fn_get_trial_days($shop);
            stream_context_create([
                'tls' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true,
                ]
            ]);
            $shop_find = ShopModel::whereStoreName($request->get('shop'))->first();
            event(new AppConfirmationProcessed($shop_find));
            dd($request->all(),$shop_find);
            // $zestard_demo_stores = explode(',', env('SHOPIFY_STORE_NAME'));
            // if (!in_array($shop, $zestard_demo_stores) && $shop_find->plan_name != 'partner_test' && $shop_find->plan_name != 'Developer Preview' && $shop_find->plan_name != 'affiliate' && $trialDays <= 0) {
            //     // if($trialDays <= 0)
            // }
            // return $trialDays;
        } catch (Exception $e) {
            dd($e);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
        }
    }
    /**
     * function basic
     */
    public function basic(Request $request) 
    {
        $shop = session('shop') ?? request()->get('shop');
        $this->error_info_array['shop'] = $shop;
        try {
            $shop_find = ShopModel::whereStoreName($shop)->first();
            $app_settings = AppSettings::where('id', 1)->first();
            $this->error_info_array['shop_info'] = $shop_find;
            // session(['free_trial_plan' => 1]);
            ## If app version is basic then return to dashboard page
            if($shop_find->app_version == 1)
                return redirect()->route('dashboard',['shop' => $shop])->with(['shop'=>$shop]);
            // when user select basic verison
            $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);

            ## Check trial days info
            $trialDays = env('TRIAL_DAYS');
            $getTrialDetails = TrialInfo::where('store_name', $shop)->first();
            // If trial is already exists
            if ($getTrialDetails)
                $trialDays = $this->fn_get_trial_days($shop);

            //creating the Recurring charge for app
            $url = 'https://' . $shop . '/admin/api/'.$this->api_version.'/recurring_application_charges.json';
            $zestard_demo_stores = explode(',', env('SHOPIFY_STORE_NAME'));
            if (in_array($shop, $zestard_demo_stores) || $shop_find->plan_name == 'partner_test' || $shop_find->plan_name == 'Developer Preview' || $shop_find->plan_name == 'affiliate') {
                $charge = $sh->call([
                    'URL' => $url,
                    'METHOD' => 'POST',
                    'DATA' => array(
                        'recurring_application_charge' => array(
                            'name' => 'Delivery Date Pro - Basic Version',
                            'price' => 0.01,
                            'return_url' => url('payment_success?shop='.$shop),
                            // "capped_amount" => 30,
                            // "terms" => "Additional charges as per the plan",
                            'test' => true,
                            'trial_days' => $trialDays
                        )
                    )
                        ], false);
            } else {
                $charge = $sh->call([
                    'URL' => $url,
                    'METHOD' => 'POST',
                    'DATA' => array(
                        'recurring_application_charge' => array(
                            'name' => 'Delivery Date Pro - Basic Version',
                            'price' => env('APP_PRICE'),
                            'return_url' => url('payment_success?shop='.$shop),
                            // "capped_amount" => 30,
                            // "terms" => "Additional charges as per the plan",
                            //'test' => true,
                            'trial_days' => $trialDays
                        )
                    )
                        ], false);
            }
            $updateShopData = array(
                'charge_id' => (string) $charge->recurring_application_charge->id,
                'api_client_id' => $charge->recurring_application_charge->api_client_id,
                'price' => $charge->recurring_application_charge->price,
                'status' => $charge->recurring_application_charge->status,
                'billing_on' => $charge->recurring_application_charge->billing_on,
                'payment_created_at' => $charge->recurring_application_charge->created_at,
                'activated_on' => $charge->recurring_application_charge->activated_on,
                'trial_ends_on' => $charge->recurring_application_charge->trial_ends_on,
                'cancelled_on' => $charge->recurring_application_charge->cancelled_on,
                'trial_days' => $charge->recurring_application_charge->trial_days,
                'decorated_return_url' => $charge->recurring_application_charge->decorated_return_url,
                'confirmation_url' => $charge->recurring_application_charge->confirmation_url,
                'usage_price' => env('APP_PRICE'), 
                'app_version' => 1, 
                'type_of_app' => 1
            );
            ShopModel::where('store_name', $shop)->update($updateShopData);
            echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>';
           
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,13);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit();
        }
    }

    /**
     * function professional
     * For Redirecting to the confirm page
     */
    public function professional(Request $request) 
    {
        $shop = $request->shop;
        $getShopDetails = ShopModel::whereStoreName($shop)->first();
        if($getShopDetails->app_version == 2 ){//|| $trialDays > 0
            return redirect()->route('dashboard',['shop' => $shop])->with(['shop'=>$shop]);
        }else{
            return redirect()->route('plan',['plan_id' => 2,'shop' => $shop])->with(['shop'=>$shop]);
        }
    }

    /**
     * function enterprise
     */
    public function enterprise(Request $request) 
    {//For Redirecting to the confirm page  
        $shop = $request->input('shop');
        $getShopDetails = ShopModel::whereStoreName($shop)->first();
        if($getShopDetails->app_version == 3){
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
        }else{
            return redirect()->route('plan',['plan_id' => 3,'shop' => $shop])->with(['shop'=>$shop]);
        }
    }

    /**
     * function ultimate For Redirecting to the confirm page
     */
    public function ultimate(Request $request) 
    {
        $shop = $request->input('shop');
        $user_settings = ShopModel::whereStoreName($shop)->first();
        $app_version = $user_settings->app_version ?? '';
        if($app_version == 4){
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
        }else{
            return redirect()->route('plan',['plan_id' => 4,'shop' => $shop])->with(['shop'=>$shop]);
        }
    }

    /**
     * function planConfirm
     * For Redirecting to the confirm page
     */
    public function planConfirm(Request $request) 
    {
        $plan = $request->plan;
        $shop = $request->input('shop');
        $user_settings = ShopModel::whereStoreName($shop)->first();
        $app_version = $user_settings->app_version;
        return view('backend.plan_confirm', ['plan' => $plan, 'shop' => $shop]);
    }

    /**
     * function upgrade_to_ultimate
     */
    public function upgrade_to_ultimate(Request $request) 
    {
        try {
            $shop = $request->input('shop');
            $this->error_info_array['shop'] = $shop;
            $shop_find = ShopModel::whereStoreName($shop)->first();
            $app_settings = AppSettings::where('id', 1)->first();
            $this->error_info_array['shop_info'] = $shop_find;
            $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);
            $id = $shop_find->charge_id;
            $url = 'admin/api/'.$this->api_version.'/recurring_application_charges/' . $id . '.json';
            $charge = $sh->call(['URL' => $url, 'METHOD' => 'GET']);
            $recuring_id = (string) $charge->recurring_application_charge->id;
            $url = '/admin/api/'.$this->api_version.'/recurring_application_charges/' . $recuring_id . '/usage_charges.json';
            $plan_argument = [
                'usage_charge' => [
                    'description' => 'Enterprise',
                    'price' => 13.00,
                ]
            ];
            $plan4 = $sh->call(['URL' => $url, 'METHOD' => 'POST', 'DATA' => $plan_argument]);
            $update_usagecharge_status = ShopModel::where('store_name', $shop)->where('charge_id', $recuring_id)->update(['usage_charge_id' => $plan4->usage_charge->id, 'usage_price' => $plan4->usage_charge->price, 'app_version' => 4, 'type_of_app' => 4]);
            return redirect()->route('dashboard',['shop' => $shop])->with(['shop'=>$shop]);
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,12);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit();
        }
    }


    /* Put shortcode directly in product snippet file */
    public function SnippetCreateProduct(Request $request) 
    {
        $shop = session('shop') ?? request()->get('shop');
        $this->error_info_array['shop'] = $shop;
        try {
            $shop_find = ShopModel::whereStoreName($shop)->first();
            $app_version = $shop_find->app_version;
            $this->error_info_array['shop_info'] = $shop_find;
            $app_settings = AppSettings::where('id', 1)->first();
            $is_exist = '';
            $str_to_insert = '';
            if ($app_version == 1 || $app_version == 2 || $app_version == 3) {
                $is_exist = "{% include 'delivery-date' %}";
                $str_to_insert = " {% include 'delivery-date' %} ";
            } else {
                if ($request->template_id == 2) { // product page
                    $is_exist = "{% include 'product-delivery-date' %}";
                    $str_to_insert = " {% include 'product-delivery-date' %} ";
                } else {
                    $is_exist = "{% include 'delivery-date' %}";
                    $str_to_insert = " {% include 'delivery-date' %} ";
                }
            }
            $sh = app('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);
            //api call for get theme info
            $theme = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes.json?role=main', 'METHOD' => 'GET']);
            if ($theme->themes[0]->role == 'main') {
                $theme_id = $theme->themes[0]->id;
                $theme_data = $sh->call(['URL' => '/admin/themes/' . $theme_id . '/assets.json', 'METHOD' => 'GET']);
                $theme_two_flag = $product_form_flag = $main_product_flag = false;
                if(isset($theme_data->assets)){
                    foreach ($theme_data->assets as $key => $value) {
                        if($value->key == "templates/product.json"){
                            $theme_two_flag = true;
                        }
                        if($value->key == "sections/main-product.liquid"){
                            $main_product_flag = true;
                        }
                        if($value->key == "snippets/product-form.liquid"){
                            $product_form_flag = true;
                        }
                    }
                }
                
                if($theme_two_flag == false){
                    $product_template = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json?asset[key]=sections/product-template.liquid&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                    $old_str = $product_template->asset->value;
                }
                if($theme_two_flag) {
                    //if shopify 2.0
                    /*if($main_product_flag)
                        $liquid_name = 'sections/main-product.liquid';
                    if($product_form_flag)
                        $liquid_name = 'snippets/product-form.liquid';

                    $main_product = $sh->call(['URL' => '/admin/themes/' . $theme_id . '/assets.json?asset[key]='.$liquid_name.'&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                    $old_str = $main_product->asset->value;
                    $str_to_insert = "{% render 'product-delivery-date' %}";
                    if (strpos($old_str, $str_to_insert) === false) {
                        if($main_product_flag)
                            $find = '<div class="product-form__buttons">';
                        if($product_form_flag)
                            $find = '{%- endform -%}';
                        $pos1 = strpos($old_str, $find) - 1;
                        $newstr = substr_replace($old_str, $str_to_insert, $pos1, 0);
                        $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => $liquid_name, 'value' => $newstr]]]);
                    } else {
                        Session::flash('error', 'Your Shortcode has been already pasted in the cart template page. If the datepicker section still does not appear, contact us for more support.');
                        return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                    }*/
                }elseif (strpos($old_str, $is_exist) === false) {
                    $find = "{{ product.title }}";
                    if (strpos($old_str, $find) !== false) {
                        //if find string available in liquide file                    
                        $pos = strpos($old_str, $find) + 30;
                        $newstr = substr_replace($old_str, $str_to_insert, $pos, 0);
                        $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'sections/product-template.liquid', 'value' => $newstr]]]);
                    } else {
                        //if find string NOT available in liquide file                    
                        $find1 = "{% if section.settings.product_quantity_enable %}";
                        $pos1 = strpos($old_str, $find1);
                        $newstr = substr_replace($old_str, $str_to_insert, $pos1, 0);
                        $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'sections/product-template.liquid', 'value' => $newstr]]]);
                    }
                } else {
                    if (request()->wantsJson()) {
                        return response()->json(['status'=>'error', 'message'=>'Your Shortcode has been already pasted in the product template page. If the datepicker section still does not appear, contact us for more support.']);
                    }
                    Session::flash('error', 'Your Shortcode has been already pasted in the product template page. If the datepicker section still does not appear, contact us for more support.');
                    return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                }
            } else {
                if (request()->wantsJson()) {
                    return response()->json(['status'=>'error', 'message'=>'Someting went wrong, Please try manual process.']);
                }
                Session::flash('error', 'Someting went wrong, Please try manual process.');
                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
            }
            if (request()->wantsJson()) {
                return response()->json(['status'=>'success', 'message'=>'Your shortcode has been added successfully in product template page.']);
            }
            Session::flash('success', 'Your shortcode has been added successfully in product template page');
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,10);
            if (request()->wantsJson()) {
                return response()->json(['status'=>'error', 'message'=>'we are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Can you please try manual process.']);
            }
            Session::flash('error', 'we are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Can you please try manual process.');
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit();
        }
    }

    /* Put shortcode directly in cart snippet file */
    public function SnippetCreateCart(Request $request) 
    {
        $shop = session('shop') ?? request()->get('shop');
        $this->error_info_array['shop'] = $shop;
        try {
            $template = request()->get('template') ?? '';
            $shop_find = ShopModel::whereStoreName($shop)->first();
            $this->error_info_array['shop_info'] = $shop_find;
            $app_settings = AppSettings::where('id', 1)->first();
            $sh = app('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);
            //api call for get theme info
            $theme = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes.json', 'METHOD' => 'GET']);
            if ($template == 'checkout') {
                foreach ($theme->themes as $themeData) {
                    if ($themeData->role != 'demo') {
                        $theme_id = $themeData->id;
                        $product_template = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json?asset[key]=layout/checkout.liquid&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                        $string_value = $product_template->asset->value;
                        $contain_section = '<div class="sidebar" role="complementary">';
                        if (strpos($string_value, $contain_section) !== false) {
                            $is_exist = "{% include 'delivery-date' %}";
                            if (strpos($string_value, $is_exist) !== false) {
                                if (request()->wantsJson()) {
                                    return response()->json(['status'=>'error', 'message'=>'Your Shortcode has been already pasted in the checkout template page. If the datepicker section still does not appear, contact us for more support.']);
                                }
                                Session::flash('error', 'Your Shortcode has been already pasted in the checkout template page. If the datepicker section still does not appear, contact us for more support.');
                                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                            } else {
                                $str_to_insert = "{% include 'delivery-date' %}";
                                $find = '<div class="sidebar__header">';
                                if (strpos($string_value, $find) !== false) {
                                    //if find string available in liquide file                            
                                    $pos = strpos($string_value, $find);
                                    $newstr = substr_replace($string_value, $str_to_insert, $pos, 0);
                                    $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'layout/checkout.liquid', 'value' => $newstr]]]);
                                }
                            }
                        }
                    }
                }
            } else {
                foreach ($theme->themes as $themeData) {
                    if ($themeData->role == 'main') {
                        $theme_id = $themeData->id;
                        $theme_data = $sh->call(['URL' => '/admin/themes/' . $theme_id . '/assets.json', 'METHOD' => 'GET']);
                        $theme_two_flag = $cart_flag = $main_cart_flag = $main_cart_item_flag = false;
                        if(isset($theme_data->assets)){
                            foreach ($theme_data->assets as $key => $value) {
                                if($value->key == "templates/cart.json"){
                                    $theme_two_flag = true;
                                }
                                if($value->key == "sections/main-cart-items.liquid"){
                                    $main_cart_item_flag = true;
                                }
                                if($value->key == "sections/main-cart.liquid"){
                                    $main_cart_flag = true;
                                }
                                if($value->key == "sections/cart.liquid"){
                                    $cart_flag = true;
                                }
                            }
                        }
                        $string_value = $product_template = '';
                        $contain_section = "{% section 'cart-template' %}";
                        if($theme_two_flag == false){
                            $product_template = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json?asset[key]=templates/cart.liquid&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                            $string_value = $product_template->asset->value;
                            $contain_section = "{% section 'cart-template' %}";
                        }
                        if($theme_two_flag) {
                            //if shopify 2.0
                            /*if($main_cart_item_flag)
                                $liquid_name = 'main-cart-items.liquid';
                            if($main_cart_flag)
                                $liquid_name = 'main-cart.liquid';
                            if($cart_flag)
                                $liquid_name = 'cart.liquid';
                            $main_cart_items = $sh->call(['URL' => '/admin/themes/' . $theme_id . '/assets.json?asset[key]=sections/'.$liquid_name.'&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                            if(!isset($main_cart_items->asset))
                                continue;
                            $old_str = $main_cart_items->asset->value;
                            $is_exist = "{% render 'delivery-date' %}";
                            if (strpos($old_str, $is_exist) === false) {
                                $str_to_insert = " {% render 'delivery-date' %} ";
                                $find = '</form>';
                                $pos1 = strpos($old_str, $find) - 1;
                                $newstr = substr_replace($old_str, $str_to_insert, $pos1, 0);
                                $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'sections/'.$liquid_name, 'value' => $newstr]]]);
                            } else {
                                Session::flash('error', 'Your Shortcode has been already pasted in the cart template page. If the datepicker section still does not appear, contact us for more support.');
                                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                            } */
                        }elseif (strpos($string_value, $contain_section) !== false) {
                            //if cart-template.liquid available
                            $product_template = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json?asset[key]=sections/cart-template.liquid&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                            $old_str = $product_template->asset->value;
                            $is_exist = "{% include 'delivery-date' %}";
                            if (strpos($old_str, $is_exist) === false) {
                                $str_to_insert = " {% include 'delivery-date' %} ";
                                $find = '<div class="cart__footer">';
                                if (strpos($old_str, $find) !== false) {
                                    //if find string available in liquide file                            
                                    $pos = strpos($old_str, $find);
                                    $newstr = substr_replace($old_str, $str_to_insert, $pos, 0);
                                    $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'sections/cart-template.liquid', 'value' => $newstr]]]);
                                } else {
                                    //if find string NOT available in liquide file
                                    $find1 = "{{ cart.note }}";
                                    $pos1 = strpos($old_str, $find1) + 30;
                                    $newstr = substr_replace($old_str, $str_to_insert, $pos1, 0);
                                    $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'sections/cart-template.liquid', 'value' => $newstr]]]);
                                }
                            } else {
                                if (request()->wantsJson()) {
                                    return response()->json(['status'=>'error', 'message'=>'Your Shortcode has been already pasted in the cart template page. If the datepicker section still does not appear, contact us for more support.']);
                                }
                                Session::flash('error', 'Your Shortcode has been already pasted in the cart template page. If the datepicker section still does not appear, contact us for more support.');
                                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                            }
                        } else {
                            //if cart-template.liquid not available
                            $product_template = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json?asset[key]=templates/cart.liquid&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                            $old_str = $product_template->asset->value;
                            $is_exist = "{% include 'delivery-date' %}";
                            if (strpos($old_str, $is_exist) === false) {
                                $str_to_insert = " {% include 'delivery-date' %} ";
                                $find = "{{ cart.note }}";
                                $pos = strpos($old_str, $find) + 100;
                                $newstr = substr_replace($old_str, $str_to_insert, $pos, 0);
                                if (strpos($old_str, $is_exist) == '') {
                                    Session::flash('error', 'Someting went wrong, Please try manual process.');
                                    if (request()->wantsJson()) {
                                        return response()->json(['status'=>'error', 'message'=>'Someting went wrong, Please try manual process.']);
                                    }
                                    return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                                } else {
                                    //api call for creating snippets                 
                                    $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'templates/cart.liquid', 'value' => $newstr]]]);
                                }
                            } else {
                                if (request()->wantsJson()) {
                                    return response()->json(['status'=>'error', 'message'=>'Your Shortcode has been already pasted in the cart template page. If the datepicker section still does not appear, contact us for more support.']);
                                }
                                Session::flash('error', 'Your Shortcode has been already pasted in the cart template page. If the datepicker section still does not appear, contact us for more support.');
                                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                            }
                        }
                    }
                }
            }
            if (request()->wantsJson()) {
                return response()->json(['status'=>'success', 'message'=>'Your shortcode has been added successfully in cart template page']);
            }
            Session::flash('success', 'Your shortcode has been added successfully in cart template page');
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,11);
            if (request()->wantsJson()) {
                return response()->json(['status'=>'error', 'message'=>'we are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Can you please try manual process.']);
            }
            Session::flash('error', 'we are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Can you please try manual process.');
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please refresh the page or try after some time.";
            exit();
        }
    }

    /**
     * function updateCharge
     * @param $shop_info
     */
    public function updateCharge(Request $request){
        $shop = $request->shop;
        try {
            $objShopInfo = ShopModel::whereStoreName($shop)->first();
            $getAppSettings = AppSettings::where('id', 1)->first();
            $sh = App::make('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $objShopInfo->store_name, 'ACCESS_TOKEN' => $objShopInfo->access_token]);

            ##checking app price
            $arrPrices = ['1'=>7.99, '2'=>10.99, '3'=>14.99, '4'=>15.99];
            $arrNames = ['1'=>'Delivery Date Pro - Basic Version', '2'=>'Delivery Date Pro - Professional Version', '3'=>'Delivery Date Pro - Enterprise Version', '4'=>'Delivery Date Pro - Ultimate Version'];
            $price = $arrPrices[$objShopInfo->app_version];
            ##creating the Recurring charge for app
            $url = 'https://' . $objShopInfo->store_name . '/admin/recurring_application_charges.json';
            $charge = $sh->call([
                'URL' => $url,
                'METHOD' => 'POST',
                'DATA' => array(
                    'recurring_application_charge' => array(
                        'name' => $arrNames[$objShopInfo->app_version],
                        'price' => $price,
                        'return_url' => url('payment_success?shop='.$shop),
                        'trial_days' => 0
                    )
                )
            ], false);
            ##update charge data in usersetting table
            $updateShopData = array(
                'charge_id' => (string) $charge->recurring_application_charge->id,
                'api_client_id' => $charge->recurring_application_charge->api_client_id,
                'price' => $charge->recurring_application_charge->price,
                'status' => $charge->recurring_application_charge->status,
                'billing_on' => $charge->recurring_application_charge->billing_on,
                'payment_created_at' => $charge->recurring_application_charge->created_at,
                'cancelled_on' => $charge->recurring_application_charge->cancelled_on,
                'trial_days' => $charge->recurring_application_charge->trial_days,
                'decorated_return_url' => $charge->recurring_application_charge->decorated_return_url,
                'confirmation_url' => $charge->recurring_application_charge->confirmation_url,
                'domain' => $objShopInfo->store_name
            );
            $objShopInfo->update($updateShopData);
            event(new CreateNewChargeEvent($objShopInfo->refresh()));
            echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>';
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,16);
            Session::flash('error', 'we are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Can you please try manual process.');
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
        }
    }

    /**
     * function getShopAddress
     * @param $shop_info
     */
    public function getShopAddress($shop_info){
        try {
            $shop_address = "";
            if($shop_info->shop->address1 != '')
                $shop_address .= $shop_info->shop->address1.', ';

            if($shop_info->shop->city != '')
                $shop_address .= $shop_info->shop->city.', ';

            if($shop_info->shop->province != '')
                $shop_address .= $shop_info->shop->province.' - ';

            if($shop_info->shop->zip != '')
                $shop_address .= $shop_info->shop->zip;

            return $shop_address;   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return "";
        }
    }

    /**
     * function fn_get_trial_days
     * @param $shop = TrialDays Model
     */
    private function fn_get_trial_days($shop){
        ## Return trial days
        $getTrialDetails = TrialInfo::whereStoreName($shop)->first();
        $trialEndDay = $getTrialDetails->trial_ends_on;
        $currentDate = date("Y-m-d");
        if (strtotime($currentDate) < strtotime($trialEndDay)) {
            $date1 = date_create($trialEndDay);
            $date2 = date_create($currentDate);
            $trianRemaining = date_diff($date2, $date1);
            return $trianRemaining->format("%a");
        } else {
            return 0;
        }
    }

    /**
     * function fn_send_error_mail
     * @param $exception = Exception instance
     */
    private function fn_send_error_mail($exception,$error_type){
        $this->error_info_array['error_msg'] = $exception->getMessage();
        $this->error_info_array['error_line_no'] = $exception->getLine();
        $this->error_info_array['error_type'] = $error_type;
        $this->error_info_array['file_path'] = $exception->getFile();
        event(new ErrorOccurredEvent($this->error_info_array));
    }
}