<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\ShopModel;
use App\CutoffSettings;
use App\Regions;
use App\RegionSettings;

class cutoffController extends Controller
{
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	public function cut_off(Request $request)
	{				
		$shop = session('shop') ?? $_GET['shop'];
		$shop_find = ShopModel::where('store_name' , $shop)->first();
		$shop_id = $shop_find->id;
		$config = $shop_find->block_config ?? [];
		$data['config'] = $config;
		$data['active'] = 'date';
		$settings = $shop_find->cutoff_settings;
		$region = Regions::where('shop_id',$shop_id)->get();
		$data['region'] = $region;
		$data['settings'] = $settings;
		$data['global_flag']= $shop_find->global_cutoff_time_status;	
		$region_settings = RegionSettings::where('shop_id',$shop_id)->get();	
		$region_set = $config->region_settings;
		## check region setting and return to that view.
		if($region_set != 1)
			return view('cutoff_settings',$data);
		## check region setting count greater than zero.
		if(count($region_settings) > 0)
			return view('cutoff_settings_view',compact($data,$shop));
		return view('cutoff_settings_region',$data);
	}

	/**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
	public function save_cut_off(Request $request)	
	{
		$shop = session('shop') ?? request()->get('shop');
		try {
			$temp = ShopModel::where('store_name' , $shop)->first();
			$shop_id = $temp->id;
			## Check global cutoff setting is avaialble or not.
			$temp->global_cutoff_time_status = ($request->input('global_cutoff_time')) ? 1 : 0;
			$temp->save();
			$count = count($request->input('hour'));					
			for($i=0; $i<$count; $i++)
			{
				$hour = $request->input('hour')[$i];
				$minute = $request->input('minute')[$i];
				## if minute and hour empty then set null.
				if($hour == "" || $minute == "")
					$hour = $minute = "-";
				$info = ['cutoff_day' => $i, 'cutoff_hour' => $hour, 'cutoff_minute' =>$minute, 'store' => $shop, 'shop_id' => $shop_id];
				## update if data available in DB otherwise create new record.
				$objCutoffSetting = CutoffSettings::updateOrCreate(['cutoff_day' => $i, 'store' => $shop],$info);
			}

			$notification = ['message' => 'Settings Saved Successfully.',
			'alert-type' => 'success'];
			return redirect()->route('cut-off', ['notification'=>$notification, 'shop' => $shop])->with(['notification'=>$notification, 'shop'=>$shop]);

		} catch (Exception $e) {
			$notification = [
				'message' => 'Something went wrong.',
				'alert-type' => 'error'
			];
			if(isset($request['debug']) && $request['debug'] == true)
                $notification['message'] = $e->getMessage();
            return redirect()->route('cut-off',['notification'=>$notification, 'shop'=>$shop])->with(['notification'=>$notification, 'shop'=>$shop]);
		}
	}
}