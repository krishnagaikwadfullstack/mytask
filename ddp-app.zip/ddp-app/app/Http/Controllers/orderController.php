<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\ShopModel;
use App\OrderDetails;
use App\BlockConfig;
use App\AppSettings;
use Response;
use Exception;
use App\Regions;
use DataTables;

class orderController extends Controller
{    
	public function __construct(){
		$this->api_version = getenv('API_VERSION');
	}
	#Manage order page display
	public function index(Request $request)
	{
		try {
			$shop = session('shop') ?? request()->get('shop');
			if(empty($shop))
			{
				if(isset($_GET['shop']))
					$shop = $_GET['shop'];

				if(isset($_GET['store']))
					$shop = $_GET['store'];
				session(['shop' => $shop]);
			}
			## Apply Status Search filter query
			$status_filter = $request->get('status_filter');
			$order_status_filter = '';
			if(isset($status_filter) && !empty($status_filter)){
				$order_status = $request->get('status_filter');
				$arr_payment_status = ['paid','partially_paid','partially_refunded','refunded','pending','expired','voided','authorized'];
				if(in_array($order_status, $arr_payment_status))
					$order_status_filter = ['financial_status' => $order_status];

				$arr_fulfill_status = ['unfulfilled','fulfilled','partial'];
				if(in_array($order_status, $arr_fulfill_status)){
					$order_status = ($order_status == 'unfulfilled') ? 'unshipped' : $order_status;
					$order_status_filter = ['fulfillment_status' => $order_status];
				}
			}
			## Get data according to select Date Range.
			$start_date = $request->get('start_date');
			$end_date = $request->get('end_date');
			// dd($start_date,$end_date);
			$shop_detail = ShopModel::whereStoreName($shop)->first();
			$date_format = $shop_detail->block_config->date_format;
			// dd($date_format);
			## Get settings data
			$shop_find = ShopModel::with(['order_details'=> function($q) use($order_status_filter,$start_date,$end_date,$date_format){
				$q->whereNotNull('order_information');
				if(isset($order_status_filter) && !empty($order_status_filter)){
					$q->where($order_status_filter);
				}
				if(!empty($start_date) && !empty($end_date)){
					// dd($start_date,$end_date);
					if($date_format=="dd/mm/yy"){
						$arr_start_date = explode('/',$start_date);
						$start_date = $arr_start_date[2].'/'.$arr_start_date[1].'/'.$arr_start_date[0];
						$arr_end_date = explode('/',$end_date);
						$end_date = $arr_end_date[2].'/'.$arr_end_date[1].'/'.$arr_end_date[0];
					}else if($date_format=="mm/dd/yy"){
						$arr_start_date = explode('/',$start_date);
						$start_date = $arr_start_date[2].'/'.$arr_start_date[0].'/'.$arr_start_date[1];
						$arr_end_date = explode('/',$end_date);
						$end_date = $arr_end_date[2].'/'.$arr_end_date[0].'/'.$arr_end_date[1];
					}
					$q->where('delivery_date', '>=', $start_date);
					$q->where('delivery_date', '<=', $end_date);
				}
			}])->whereStoreName($shop)->first();
			$shop_id = $shop_find->id;
			$records_per_page = $shop_find->records_per_page;
			$app_version = $shop_find->app_version;	
			$setting  = [];
			$setting  = $shop_find->block_config;
			$current_date_format  = $setting['date_format'];

			// For Calculating todays and this weeks orders
			$todays_date = date("d-m-Y");
			$day = date("w",strtotime($todays_date));
			$week = 6-$day;
			$end_of_week = strtotime("+$week days", strtotime($todays_date));
			$start_of_week = strtotime("-$day days", strtotime($todays_date));
			$orders = [];
			$records_per_page = 5;
			$all_orders = $shop_find->order_details->unique('order_name');
			$todays_orders = $weeks_orders = 0;
			#Get order data from database to set delivery date and delivery time in current format
			foreach ($all_orders as $key => $order) {				
				if(!is_null($order->delivery_date)){
					if(strtotime($order->delivery_date) == strtotime(date('Y-m-d')))
						++$todays_orders;
					if(strtotime($order->delivery_date) >= $start_of_week && strtotime($order->delivery_date) <= $end_of_week)
						$weeks_orders++;
				}
			}
			
			if($current_date_format == 'dd/mm/yy' || $current_date_format == 'mm/dd/yy') {
				$start_of_week = date("d/m/Y", $start_of_week);
				$end_of_week = date("d/m/Y", $end_of_week);
			}

			if($current_date_format == 'yy/mm/dd') {
				$start_of_week  = date("Y/m/d", $start_of_week);
				$end_of_week  = date("Y/m/d", $end_of_week);
			}
				
			## For ajax pagination
			if ($request->ajax()) {
	            return Datatables::of($all_orders)
	                ->addIndexColumn()
	                ->addColumn('order_number', function ($row) {
	                    return $row->order_information['order_number'];
	                })
	                ->addColumn('name', function ($row) {
	                	// dd($row->order_information);
	                    return $row->customer_name;
	                })
	                ->addColumn('product_name', function ($row) {
	                	$product_name = '';
	                	foreach($row->order_information['line_items'] as $product) {
							$product_name = $product['title']."(".$product['quantity'].")";
						}
	                    return $product_name;
	                })
	                ->addColumn('delivery_date', function ($row) use($current_date_format,$app_version) {
	                	$date_final = '';
	                	if($app_version == 4 && (empty($row->delivery_date) || $row->delivery_date == '0000-00-00')){
	                		$arr_date_format = ['mm/dd/yy'=>'m/d/Y','dd/mm/yy'=>'d/m/Y','yy/mm/dd'=>'Y/m/d'];
	                		$current_date_format = $arr_date_format[$current_date_format];
	                		foreach($row->order_information['line_items'] as $product_name) {
								foreach($product_name['properties'] as $property){
									if($property['name'] == "Delivery-Date"){
										$product_delivery_date = $property['value'];
										if(!empty($product_delivery_date))
											$date_final = $this->fn_format_date($current_date_format,$product_delivery_date);
									}
								}
							}
							return $date_final;
	                	}
						$raw_date = explode('-', $row->delivery_date);
	                	if($current_date_format == "mm/dd/yy") {
							$date_final = implode('/', array($raw_date['1'], $raw_date['2'], $raw_date['0']));
						} else if($current_date_format == "dd/mm/yy") {
							$date_final = implode('/', array($raw_date['2'], $raw_date['1'], $raw_date['0']));	
						} else if($current_date_format == "yy/mm/dd") {
							$date_final = implode('/', array($raw_date['0'], $raw_date['1'], $raw_date['2']));
						}
	                    return $date_final;
	                })
	                ->addColumn('delivery_time', function ($row) use($app_version) {
	                	if($app_version == 4 && empty($row->delivery_time)){
	                		$product_delivery_time = '';
	                		foreach($row->order_information['line_items'] as $product_name) {
								foreach($product_name['properties'] as $property){
									if($property['name'] == "Delivery-Time"){
										$product_delivery_time = $property['value'];
									}
								}
							}
							return $product_delivery_time;
	                	}
	                    return $row->delivery_time;
	                })
	                ->addColumn('status', function ($row) {
	                    return $row->order_information['financial_status'];
	                })
	                ->addColumn('order_status', function ($row) {
	                    return ($row->order_information['fulfillment_status'] == null) ? 'Unfulfilled' : $row->order_information['fulfillment_status'];
	                })
	                ->addColumn('action', function ($row) use($current_date_format,$app_version){
	                	$date_final = '-';
	                	if($app_version == 4 && (empty($row->delivery_date) || $row->delivery_date == '0000-00-00')){
	                		$arr_date_format = ['mm/dd/yy'=>'m/d/Y','dd/mm/yy'=>'d/m/Y','yy/mm/dd'=>'Y/m/d'];
	                		$current_date_format = $arr_date_format[$current_date_format];
	                		foreach($row->order_information['line_items'] as $product_name) {
								foreach($product_name['properties'] as $property){
									if($property['name'] == "Delivery-Date"){
										$product_delivery_date = $property['value'];
										if(!empty($product_delivery_date))
											$date_final = $this->fn_format_date($current_date_format,$product_delivery_date);
									}
								}
							}
	                	}else{
		                	if($current_date_format == "mm/dd/yy") {
								$raw_date = explode('-', $row->delivery_date);
								$date_final = implode('/', array($raw_date['1'], $raw_date['2'], $raw_date['0']));
							} else if($current_date_format == "dd/mm/yy") {
								$raw_date = explode('-', $row->delivery_date);
								$date_final = implode('/', array($raw_date['2'], $raw_date['1'], $raw_date['0']));	
							} else if($current_date_format == "yy/mm/dd") {
								$raw_date = explode('-', $row->delivery_date);
								$date_final = implode('/', array($raw_date['0'], $raw_date['1'], $raw_date['2']));
							}	                   
	                	}
	                	$delivery_time = $row->delivery_time;
	                	if($app_version == 4 && empty($row->delivery_time)){
	                		$delivery_time = '';
	                		foreach($row->order_information['line_items'] as $product_name) {
								foreach($product_name['properties'] as $property){
									if($property['name'] == "Delivery-Time"){
										$delivery_time = $property['value'];
									}
								}
							}
	                	}
	                	// $arr_delivery_time = [];
	                	// switch ($row->order_type) {
						//   case "1":
						//     $arr_delivery_time = $row->delivery_time;
						//     break;
						//   case "2":
						//     $arr_delivery_time = $row->delivery_time;
						//     break;
						//   case "3":
						//     $arr_delivery_time = $row->delivery_time;
						//     break;
						// }
	                    return '<button type="button" class="btn btn-primary edit-delivery-details" data-toggle="modal" data-target="#ddt-update" data-id="'.$row->order_information['id'].'" data-order-number="'.$row->order_information['order_number'].'" data-delivery-date="'.$date_final.'" data-delivery-time="'.$delivery_time.'">edit</button>';
	                })
	                ->make(true);		
	        }
			return view('order', ['orderlist'=> $all_orders,'shop_id'=>$shop_id, 'shop' => $shop, 'app_version' => $app_version, 'settings'=>$setting,'records_per_page' => $records_per_page, 'weeks_orders' => $weeks_orders, 'todays_orders' => $todays_orders,'todays_date' => $todays_date, 'start_of_week' => $start_of_week, 'end_of_week' => $end_of_week,'shop_detail'=>$shop_find]);	
		} catch (Exception $e) {
			dd($e);
			if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
		}
	}
	
	/**
     * #Manage order page display with pagination
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
	public function orders(Request $request)
    {
    	try {
    		$page = '';
			$shop = session('shop');
			if(empty($shop))
			{
				if(isset($_GET['shop']))
					$shop = $_GET['shop'];

				if(isset($_GET['store']))
					$shop = $_GET['store'];

				session(['shop' => $shop]);
			}

			$shop_find = ShopModel::where('store_name' , $shop)->first();
			## update records_per_page
			if($request->input('records_length'))
				$shop_find->update(['records_per_page' =>$request->input('records_length')]);
			
			$app_settings = AppSettings::where('id', 1)->first();
			$shop_id = $shop_find->id;
			$app_version = $shop_find->app_version;
			$setting = [];
			$setting = $shop_find->block_config;
			$current_date_format = $setting['date_format'];
			$sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);		
			$records_per_page = $shop_find->records_per_page;		
			$records_per_page = 5;
			// if($_SERVER["REMOTE_ADDR"] == '47.15.122.164'){
			// 	$records_per_page = 2;
			// }
			$page_info = $request->input('page_info') ?? '';
			// For Calculating todays and this weeks orders
			$todays_date = date("d-m-Y");
			$day = date("w",strtotime($todays_date));						
			$week = 6-$day;	
			$temp_date = date("d-m-Y",strtotime("20-12-2017"));			
			$start_of_week = strtotime("-$day days", strtotime($todays_date));           
			$end_of_week = strtotime("+$week days", strtotime($todays_date));		
			
			$orders = [];
			#Api call for Order data
			$orders = $sh->callAdvance(['URL' => 'admin/api/'.$this->api_version.'/orders.json?page_info='.$page_info."&limit=".$records_per_page, 'METHOD' => 'GET']);
			
			$all_orders = $orders->orders;	  
			$todays_orders = $weeks_orders = 0;

			#Get order data from database to set delivery date in current format
			$ztpl_db_orders = $shop_find->order_details()->select('id','order_id','delivery_date','delivery_time')->orderBy('id','DESC')->get()->keyBy('order_id')->map(function($item, $index) {
				   $data[0] = $item->delivery_date;
				   $data[1] = $item->delivery_time;
				   return $data;
				})->toArray();

			#Get order data from database to set delivery date and delivery time in current format
			foreach ($all_orders as $key => $order)
			{	
				if(array_key_exists($order->id, $ztpl_db_orders)) {
					$delivery_date = $ztpl_db_orders[$order->id][0]; 
					$delivery_time = $ztpl_db_orders[$order->id][1];
					$all_orders[$key]->delivery_date = $delivery_date;
					$all_orders[$key]->delivery_time = $delivery_time;
				}

				if (isset($delivery_date)) {
					$temp_delivery_date = explode("-",$delivery_date);
					if($current_date_format == 'dd/mm/yy')
						$delivery_date = $temp_delivery_date[2]."-".$temp_delivery_date[1]."-".$temp_delivery_date[0];

					if($current_date_format == 'mm/dd/yy')
						$delivery_date = $temp_delivery_date[1]."-".$temp_delivery_date[2]."-".$temp_delivery_date[0];

					if($current_date_format == 'yy/mm/dd')
						$delivery_date = $temp_delivery_date[0]."-".$temp_delivery_date[1]."-".$temp_delivery_date[2];
					## set todays orders count
					if(strtotime($delivery_date) == strtotime(date('Y-m-d')))
						++$todays_orders;
					## set this week orders count
					if(strtotime($delivery_date) >= $start_of_week && strtotime($delivery_date) <= $end_of_week)
						$weeks_orders++;	
				}
			}

			#Api call for Order data
			$count = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/orders/count.json?status=any','METHOD' => 'GET']);
			$orders_count = (array)$count;
			$order_count = $orders_count['count'];
			#Get data with pagination
			if(isset($orders->headers['link'])){
		        	$next = $orders->headers['link'];
		    		$page_params = explode(',',$next);

		    		if(isset($page_params[1])){
		    			$next_url = explode(',',$page_params[1]);
		    			$previous_url = explode(',',$page_params[0]);
		    		}else{
		    			$check = explode('; ', $page_params[0]);
		    			$check = str_replace('"', '', $check[1]);
		    			if(strpos($check, 'next') !== false){
							$next_url = explode(',',$page_params[0]);
		    				$previous_url = '';     					
						}else{
							$previous_url = explode(',',$page_params[0]);
		    				$next_url = '';     					
						}
		    		}

		    		$next_param = '';
		    		if($next_url != ''){
		    			$str = substr($next_url[0], 1, -1);
		    			$url_components = parse_url(substr($str, 0, strpos($str, ">")));
						parse_str($url_components['query'], $next_params);
						$next_param = $next_params['page_info'];
		    		}

					$previous_param = '';
		    		if($previous_url != ''){
		    			$str = substr($previous_url[0], 1, -1);
		    			$url_components = parse_url(substr($str, 0, strpos($str, ">")));
						parse_str($url_components['query'], $previous_params);
						$previous_param = $previous_params['page_info'];
		    		}
			}
			      	
			if($current_date_format == 'dd/mm/yy' || $current_date_format == 'mm/dd/yy') {
				$start_of_week = date("d/m/Y", $start_of_week);
				$end_of_week = date("d/m/Y", $end_of_week);
			}

			if($current_date_format == 'yy/mm/dd') {								
				$start_of_week  = date("Y/m/d", $start_of_week);	
				$end_of_week  = date("Y/m/d", $end_of_week);	
			}

			return view('order', ['orderlist'=> $all_orders,'shop_id'=>$shop_id, 'shop' => $shop, 'app_version' => $app_version, 'settings'=>$setting,'records_per_page' => $records_per_page, 'weeks_orders' => $weeks_orders, 'todays_orders' => $todays_orders,'todays_date' => $todays_date, 'start_of_week' => $start_of_week, 'end_of_week' => $end_of_week,'next' => $next_param,'previous' => $previous_param]);	
    	} catch (Exception $e) {
    		if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return false;
    	}
    }	
	
	#Export data from manage order page 
	public function order_export(Request $request)
	{
		$shop = session('shop');
		if(empty($shop)) {
			$shop = $_GET['shop'] ?? $request->input('shop');
			session(['shop' => $shop]);
		}
		try {
			// $app_settings = AppSettings::find(1);
			## Apply Status Search filter query
			$status = $request->get('status');
			$order_status_filter = '';
			if(isset($status) && !empty($status)){
				$arr_payment_status = ['paid','partially_paid','partially_refunded','refunded','pending','expired','voided','authorized'];
				if(in_array($status, $arr_payment_status))
					$order_status_filter = ['financial_status' => $status];

				$arr_fulfill_status = ['unfulfilled','fulfilled','partial'];
				if(in_array($status, $arr_fulfill_status)){
					$status = ($status == 'unfulfilled') ? 'unshipped' : $status;
					$order_status_filter = ['fulfillment_status' => $status];
				}
			}
			## Get data according to select Date Range.
			$start_date = $request->get('min');
			$end_date = $request->get('max');
			## Get settings data
			$shop_find = ShopModel::with(['order_details'=> function($q) use($order_status_filter,$start_date,$end_date){
				$q->whereNotNull('order_information');
				if(isset($order_status_filter) && !empty($order_status_filter)){
					$q->where($order_status_filter);
				}
				if(!empty($start_date) && !empty($end_date)){
					// dd($start_date,$end_date);
					$q->where('delivery_date', '>=', $start_date);
					$q->where('delivery_date', '<=', $end_date);
				}
			}])->whereStoreName($shop)->first();
			
			$shop_id = $shop_find->id;
			$app_version = $shop_find->app_version;
			$settings = [];
			$settings = $shop_find->block_config;
			$current_date_format = $settings['date_format'];
			$orders = [];
			$all_orders = $shop_find->order_details->unique('order_name');
			if(count($all_orders) > 250){
				$arr_filter_data = $request->all();
				unset($arr_filter_data['_token']);
				OrderReport::create(['shop_id'=>$shop_id,'filter_data'=>$arr_filter_data]);
				$notification = [
					'message' => 'Selected date order will be sent on your email within 5 minute.',
					'alert-type' => 'success'
				];
	            return redirect()->route('order', ['notification'=>$notification,'shop'=> request()->get('shop')])->with(['notification'=>$notification,'shop'=> request()->get('shop')]);
			}
			$orders_array = array();
			$delivery_time_enabled = $settings->admin_time_status;
			$region_setting_enabled = $settings->region_settings;
	        $filename = "Orders.csv";
	        ## if start date and end date available then create filename using date
	        if(!empty($start_date) && !empty($end_date))
	        	$filename = "Orders_from_".$start_date."_to_".$end_date.".csv ";

	        $old_order_no = $new_order_no = $timestamp_flag = 0;
	        $useremail = $fullname = "";

			if($shop=="the-bunched-co.myshopify.com") {
				if($delivery_time_enabled == 1) {
					$orders_header=array("Order Number","Name","Email","Product Name(Quantity)","Delivery Date","Delivery Time", "Delivery Address");  
				} else {
					$orders_header=array("Order Number","Name","Email","Product Name(Quantity)","Delivery Date", "Delivery Address");  
				}
				foreach ($all_orders as $order_detail) {
					$order = $order_detail->order_information;
					$time_attribute = "";
					$product_delivery_date_array = array();
					$temp_product_delivery_date_array = array();
					$product_delivery_time_array = array();
					$product_region_array = array();
					$product_details_array = array();	
					$address = empty($order['billing_address']) ? '' : ($order['billing_address']->address1 . ' ' . $order['billing_address']['address2'] . ' ' . $order['billing_address']['city'] . ' ' . $order['billing_address']['zip'] . ' ' . $order['billing_address']['province'] . ' ' . $order['billing_address']['country'] );		
					if(empty($order['customer'])) {
						$fullname="";
						$useremail="";
					} else {
						$fullname=$order['customer']['first_name'] ." ". $order['customer']['last_name'];
						$useremail=$order['email'];
					}

					foreach($order['line_items'] as $product_name) {
						$product_delivery_date = " ";			
						$product_delivery_time = " ";					
						foreach($product_name['properties'] as $property) {
							if($property['name'] == "Delivery-Date") {
								$product_delivery_date = ", ".$property['value'];
								array_push($product_delivery_date_array, strtotime(str_replace("/","-",$property['value'])));
								array_push($temp_product_delivery_date_array, str_replace("/","-",$property['value']));
							}

							if($property['name'] == "Delivery-Time") {
								array_push($product_delivery_time_array, ($property['value']));
								$product_delivery_time = ", ".$property['value'];
							}

							if($property['name'] == "Region") {
								array_push($product_region_array, ($property['value']));
								$product_region_time = ", ".$property['value'];
							}
						}
						if($product_delivery_time == " ")
						{
							array_push($product_delivery_time_array, "-");
						}
						if($product_region_time == " ")
						{
							array_push($product_region_array, "-");
						}

						$product_details = $product_name['title']."(".$product_name['quantity']."".$product_region_array."".$product_delivery_date."".$product_delivery_time.")";
						array_push($product_details_array, $product_details);
					}
					if($request->input('repeat')) {
						//Do Nothing
					} else {
						$new_order_no = $order['order_number'];
						if($new_order_no == $old_order_no) {					
							$fullname = $useremail = "";
						}
					}

					$old_order_no = $new_order_no;
					if($start_date=="" || $end_date=="") {
						if($delivery_time_enabled == 1) {
							array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail, implode("\n", $product_details_array), implode("\n", $temp_product_delivery_date_array), implode("\n", $product_delivery_time_array), $address));								
						} else {						
							array_push($orders_array,array("#".$order['order_number'],$fullname, $useremail, implode("\n", $product_details_array), implode("\n", $temp_product_delivery_date_array), $address));
						}
					} else {
						if($request->input('current_format') == 'd/m/Y') {	
							$start_date = str_replace("/","-",$start_date);
							$end_date = str_replace("/","-",$end_date);
						}						
						if($request->input('current_format') == 'm/d/Y') {
							$temp_start_date = explode("/",$start_date);
							$temp_end_date = explode("/",$end_date);
							$start_date = $temp_start_date[1]."-".$temp_start_date[0]."-".$temp_start_date[2];
							$end_date = $temp_end_date[1]."-".$temp_end_date[0]."-".$temp_end_date[2];
						}
						if($request->input('current_format') == 'Y/m/d') {
							$start_date = date("d-m-Y", strtotime($start_date));
							$end_date   = date("d-m-Y", strtotime($end_date));	
						}												
						if(count($product_delivery_date_array) > 0) {
							foreach($product_delivery_date_array as $timestamp) {
								if(!empty($timestamp)) {
									if($timestamp >= strtotime($start_date) && $timestamp <= strtotime($end_date)) {
										$timestamp_flag = 1;
									}								
								}
							}					
						}										
						if($timestamp_flag == 1) {	
							if($delivery_time_enabled == 1) {			
								$product_details = $product_name->title."(".$product_name->quantity.",".$product_delivery_date.", ".$product_delivery_time.")";						
								array_push($orders_array,array("#".$order['order_number'],$fullname, $useremail, implode("\n", $product_details_array),implode("\n", $temp_product_delivery_date_array), implode("\n", $product_delivery_time_array), $address));			
							} else {							
								$product_details = $product_name->title."(".$product_name->quantity.",".$product_delivery_date.")";				
								array_push($orders_array,array("#".$order['order_number'],$fullname, $useremail, implode("\n", $product_details_array), implode("\n", $temp_product_delivery_date_array), $address));
							}												
							$timestamp_flag = 0;
						}					
					}		
				}
			} else {
				if($delivery_time_enabled == 1) {
					if($region_setting_enabled == 1){
						$orders_header = array("Order Number","Name","Email","Product Name(Quantity)","Region","Delivery Date","Delivery Time");  
					}else{
						$orders_header = array("Order Number","Name","Email","Product Name(Quantity)","Delivery Date","Delivery Time");  
					}
				} else {
					if($region_setting_enabled == 1){
						$orders_header = array("Order Number","Name","Email","Product Name(Quantity)","Region","Delivery Date");  
					}else{
						$orders_header = array("Order Number","Name","Email","Product Name(Quantity)","Delivery Date");  
					}
				}
				foreach ($all_orders as  $key => $order_detail) {
					$order = $order_detail->order_information;
					$time_attribute = $region_attribute = $delivery_date = $delivery_time = '';
					if ($app_version == 4) {
						$first_name = $order['customer']['first_name'] ?? "";
						$last_name = $order['customer']['last_name'] ?? "";
						$useremail = $order['email'] ?? "";
						$fullname = $first_name ." ". $last_name;
						$product_delivery_date = $product_delivery_time = '';
						if($current_date_format == 'dd/mm/yy') {	
							$start_date=str_replace("/","-",$start_date);	
							$start_date = explode("-",$start_date);
							$start_date = $start_date[2].'-'.$start_date[1].'-'.$start_date[0];
							$end_date=str_replace("/","-",$end_date);
							$end_date = explode("-",$end_date);
							$end_date = $end_date[2].'-'.$end_date[1].'-'.$end_date[0];
						}	
						foreach($order['line_items'] as $product_name) {
							foreach($product_name['properties'] as $property){
								if($property['name'] == "Delivery-Date"){
									$product_delivery_date = $property['value'];
									if(!empty($product_delivery_date))
										$product_delivery_date = $this->fn_format_date($request->input('current_format'),$product_delivery_date);
								}
								if($property['name'] == "Delivery-Time"){
									$product_delivery_time = $property['value'];
								}
							}
							if(empty($product_delivery_date))
								$product_delivery_date = $this->fn_format_date($request->input('current_format'),$order_detail['delivery_date']);
							if(empty($product_delivery_time))
								$product_delivery_time = $order_detail['delivery_time'];
							
							// if((strtotime($product_delivery_date) >= strtotime($start_date)) && (strtotime($product_delivery_date) <= strtotime($end_date))){
								array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail,$product_name['title']."(".$product_name['quantity'].")",$product_delivery_date,$product_delivery_time));
							// }
						}
					}
					//changed condition to not for version 
					if(!empty($order['note_attributes']) && $app_version != 4) {
						foreach ($order['note_attributes'] as $atributes) {
							if($atributes['name'] == "Delivery-Date" || $atributes['name'] == "delivery_date") {
								if(strtotime($atributes['value']) === '') {
									$date_string = (string)$atributes['value'];
									$date_final = str_replace("/","-",$date_string);
									if($request->input('current_format') == 'd/m/Y')
										$delivery_date = $date_final;

									if($request->input('current_format') == 'Y/m/d')
										$delivery_date  = date("d-m-Y", strtotime($date_final));

									if($request->input('current_format') == 'm/d/Y') {
										$temp_delivery_date = explode("-",$date_final);
										$delivery_date = $temp_delivery_date[1]."-".$temp_delivery_date[0]."-".$temp_delivery_date[2];
									}
								} else {														
									$delivery_date = $atributes['value'];
								}
							}
							if($atributes['name'] == "Delivery-Time")
								$time_attribute = $atributes['value'];
							$delivery_time = $time_attribute ?? '-';

							# for region #
							if($atributes['name'] == "Region")
								$region_attribute = $atributes['value'];						
							$delivery_region = $region_attribute ?? '-';
							# end #
						}

						$first_name = $order['customer']['first_name'] ?? "";
						$last_name = $order['customer']['last_name'] ?? "";
						$useremail = $order['email'] ?? "";
						$fullname = $first_name ." ". $last_name;
						foreach($order['line_items'] as $product_name) {
							if(is_null($request->input('repeat'))) {
								$new_order_no = $order['order_number'];
								if($new_order_no == $old_order_no)
									$fullname = $useremail = "";
							}

							if($start_date == "" || $end_date == "") {
								$product_details = $product_name['title']."(".$product_name['quantity'].")";
								if($delivery_time_enabled == 1) {
									if($shop=="the-bunched-co.myshopify.com" || $app_version == 4) {
										$product_delivery_date = $product_delivery_time = "-";
										foreach($product_name['properties'] as $property) {
											if($property['name'] == "Delivery-Date" || $property['name'] == "delivery_date")
												$product_delivery_date = $property['value'];

											if($property['name'] == "Delivery-Time")
												$product_delivery_time = $property['value'];

										}

										$product_details = $product_name['title']."(".$product_name['quantity'].", ".$product_delivery_date.", ".$product_delivery_time.")";
										$product_delivery_time = $property['value'];
										array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail, $product_details,$product_delivery_date, $product_delivery_time));	
									} else if($region_setting_enabled == 1) {
										array_push($orders_array,array("#".$order['order_number'], $fullname, $useremail, $product_details, $delivery_region, $delivery_date, $delivery_time));
									} else {
										array_push($orders_array,array("#".$order['order_number'],$fullname, $useremail, $product_details, $delivery_date, $delivery_time));
									}
								} else {
									if($shop=="the-bunched-co.myshopify.com" || $app_version == 4)
									{
										$product_details = $product_name['title']."(".$product_name['quantity'].", ".$product_delivery_date.")";
										$product_delivery_date = $product_delivery_time = "-";
										foreach($product_name['properties'] as $property)
										{
											if($property['name'] == "Delivery-Date" || $property['name'] == "delivery_date")
												$product_delivery_date = $property['value'];

											if($property['name'] == "Delivery-Time")
												$product_delivery_time = $property['value'];
										}
										array_push($orders_array,array("#".$order['order_number'],$fullname, $useremail, $product_details, "-"));
									} else if($region_setting_enabled == 1){
										array_push($orders_array,array("#".$order['order_number'], $fullname, $useremail, $product_details, $delivery_region, $delivery_date));
									} else {
										array_push($orders_array,array("#".$order['order_number'],$fullname, $useremail, $product_details, $delivery_date));
									}
								}
							} else {
								$product_delivery_date = $product_delivery_time = $product_delivery_region = "-";
								foreach($product_name['properties'] as $property) {
									if($property['name'] == "Delivery-Date" || $property['name'] == "delivery_date")
										$product_delivery_date = $property['value'];

									if($property['name'] == "Delivery-Time")
										$product_delivery_time = $property['value'];

									if($property['name'] == "Region")
										$product_delivery_region = $property['value'];
								}

								if($current_date_format == 'dd/mm/yy') {	
									$start_date=str_replace("/","-",$start_date);	
									$start_date = explode("-",$start_date);
									$start_date = $start_date[2].'-'.$start_date[1].'-'.$start_date[0];
									$end_date=str_replace("/","-",$end_date);
									$end_date = explode("-",$end_date);
									$end_date = $end_date[2].'-'.$end_date[1].'-'.$end_date[0];
								}						
									
									
								// if((strtotime($delivery_date) >= strtotime($start_date)) && (strtotime($delivery_date) <= strtotime($end_date))) {
								if($delivery_time_enabled == 1) {
									if($shop=="the-bunched-co.myshopify.com" || $app_version == 4) {
										array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail,$product_name['title']."(".$product_name['quantity'].", ".$product_delivery_date.", ".$product_delivery_time.")","-", "-"));						
									} else {	
										if($region_setting_enabled == 1 && $shop == "casinetto.myshopify.com"){
											array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail,$product_name['title']."(".$product_name['quantity'].")",$delivery_region,$delivery_date, $delivery_time));
										} else {
											array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail,$product_name['title']."(".$product_name['quantity'].")",$delivery_date, $delivery_time));
										}
									}					
								} else {
									if($shop=="the-bunched-co.myshopify.com" || $app_version == 4) {
										array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail,$product_name['title']."(".$product_name['quantity'].", ".$product_delivery_date.")", $delivery_date));			
									} else {
										if($region_setting_enabled == 1 && $shop == "casinetto.myshopify.com"){
											array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail,$product_name['title']."(".$product_name['quantity'].")",$delivery_region,$delivery_date));
										}	else {
											array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail,$product_name['title']."(".$product_name['quantity'].")",$delivery_date));
										}
									}
								}
								// }
							}
							$old_order_no = $new_order_no;
						}
					} else {
						// changed condition to not null
						if($start_date == "" && $end_date == "") {
							$first_name = $order['customer']['first_name'] ?? "";
							$last_name = $order['customer']['last_name'] ?? "";
							$fullname = $first_name ." ". $last_name;
							$useremail = $order['email'] ?? "";
							## Foreach for order items
							foreach ($order['line_items'] as $product_name) {

								if(is_null($request->input('repeat'))) {
									$new_order_no = $order['order_number'];
									if($new_order_no == $old_order_no)
										$fullname = $useremail = "";
								}

								if($shop=="the-bunched-co.myshopify.com") {
									$product_delivery_date = $product_delivery_time = "-";
									foreach($product_name['properties'] as $property)
									{
										if($property['name'] == "Delivery-Date" || $property['name'] == "delivery_date")
											$product_delivery_date = $property['value'];
										
										if($property['name'] == "Delivery-Time")
											$product_delivery_time = $property['value'];
									}
									array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail,$product_name['title']."(".$product_name['quantity'].", ".$product_delivery_date.", ".$product_delivery_time.")","-", "-"));						
								} else {

									if($region_setting_enabled == 1 && $shop == "casinetto.myshopify.com"){
										array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail,$product_name['title']."(".$product_name['quantity'].")",$delivery_region,"-", "-"));
									} else {

										$product_delivery_date = $product_delivery_time = "-";
										foreach($product_name['properties'] as $property) {
											if($property['name'] == "Delivery-Date" || $property['name'] == "delivery_date")
												$product_delivery_date = $property['value'];

											if($property['name'] == "Delivery-Time" || $property['name'] == "delivery_time"|| $property['name'] == "delivery-time")
												$product_delivery_time = $property['value'];
										}
										
										// if((strtotime($product_delivery_date) >= strtotime($start_date)) && (strtotime($product_delivery_date) <= strtotime($end_date))){
											array_push($orders_array,array("#".$order['order_number'],$fullname,$useremail,$product_name['title']."(".$product_name['quantity'].")",$product_delivery_date, $product_delivery_time));
										// }
									}
								}
								$old_order_no = $new_order_no;	
							}			
						}		
					}
				}
			}	
		} catch (Exception $e) {
			dd($e);
			$notification = [
				'message' => 'Something went wrong.',
				'alert-type' => 'error'
			];
			if(isset($request['debug']) && $request['debug'] == true)
                $notification['message'] = $e->getMessage();
            return redirect()->route('order', ['notification'=>$notification,'shop'=> request()->get('shop')])->with(['notification'=>$notification,'shop'=> request()->get('shop')]);
		}
		
		if (empty($orders_array)) {
			$notification = [
				'message' => 'There are no Orders in selected Delivery Date.',
				'alert-type' => 'error'
			];
            return redirect()->route('order', ['notification'=>$notification,'shop'=> request()->get('shop')])->with(['notification'=>$notification,'shop'=> request()->get('shop')]);
		}
		## Put data into csv file and export
		$callback = function() use ($orders_array, $orders_header)
		{
			$fp = fopen('php://output', 'w');
			fputcsv($fp, $orders_header);
			foreach($orders_array as $order_row)
			{
				fputcsv($fp,$order_row);
			}
			fclose($fp);
		};
		$headers = array(
			"Content-type" => "text/csv",
			"Content-Disposition" => "attachment; filename=$filename",
			"Pragma" => "no-cache",
			"Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
			"Expires" => "0"
		);
		return Response::stream($callback, 200, $headers);
	}
	
	/**
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
	public function getDeliveryUpdate(Request $request){
		try {
			$order_id = $request->order_id;
			$shop = $request->shop;
			$app_settings = AppSettings::find(1);
			$shop_find = ShopModel::whereStoreName($shop)->first();
			$shop_id = $shop_find->id;
			$order_detail = $shop_find->order_details()->where('order_id',$order_id)->first();

			if($order_detail->delivery_date == "0000-00-00" || $order_detail->delivery_date == "1969-12-31" || $order_detail->delivery_date == "1969-01-01" || $order_detail->delivery_date == "1970-01-01")
				return 0;
			return 1;	
		} catch (Exception $e) {
			if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return 0;
		}
	}
	
	/**
     * To update delivery date and delivery time from manage order - admin panel 
     * Set delivery date from thank you page - customer side
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
	public function updateDeliveryDate(Request $request)
	{
		try {
			$order_id = $request->order_id;
			$shop = $request->shop;
			$delivery_region = $request->delivery_region_name;
			$app_settings = AppSettings::find(1);
			$shop_find = ShopModel::with('order_details')->whereStoreName($shop)->first();
			$shop_id = $shop_find->id;
			$setting = $shop_find->block_config;
			$current_date_format = $setting->date_format;
			$sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' =>$app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_find->access_token]);
			#Set delivery_date value for manage order page
			if($request->new_delivery_date){
				$delivery_date = $request->new_delivery_date;
				#Change date format to Y-m-d to save in database
				if($current_date_format == 'dd/mm/yy')
				{
					$temp_delivery_date = explode("/",$delivery_date);
					$delivery_date = $temp_delivery_date[2]."-".$temp_delivery_date[1]."-".$temp_delivery_date[0];
				}

				if($current_date_format == 'mm/dd/yy')
				{
					$temp_delivery_date = explode("/",$delivery_date);
					$delivery_date = $temp_delivery_date[2]."-".$temp_delivery_date[0]."-".$temp_delivery_date[1];
				}

				if($current_date_format == 'yy/mm/dd') {
					$delivery_date = str_replace('/', '-', $delivery_date);
				}
			} else {
				#Set delivery_date value for thank you page
				$date = str_replace('/', '-', $request->date);
				$delivery_date = date('Y-m-d', strtotime($date));
			}
			#Set delivery_time value for manage order page or thank you page
			$delivery_time = $request->new_delivery_time ?? $request->time;
			$data = [
				'id' => $order_id,
				'note_attributes' => [
					[
						'name' => 'Delivery-Date',
						'value' => $delivery_date
					],
					[
						'name' => 'Delivery-Time',
						'value' => $delivery_time
					]
				]
			];
			if($delivery_region != '') {
				$data['note_attributes'][] = [
					'name' => 'Region',
					'value' => $delivery_region
				];
			}
			$input_params = ['order' => $data];
			$response = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/orders/'.$order_id.'json', 'METHOD' => 'PUT','DATA' => json_encode($input_params,true)]);
			$order = $shop_find->order_details()->where('order_id',$order_id)->first();
			$url = '/admin/api/'.$this->api_version.'/orders/'.$order_id.'.json';
			$shopify_order = $sh->call(['URL' => $url, 'METHOD' => 'GET']);
			## If order data not stored into our database then, Get order from shopify and store into our database
			if(is_null($order)){
				$results = $shop_find->order_details()->updateOrCreate(['order_id'=>$order_id],[
					'shop_id'		=> $shop_find->id,
                    'order_id'      => $order_id,
                    'order_name'    => $shopify_order->order->name ?? $order_id,
					'delivery_date' => $delivery_date, 
					'delivery_time' => $delivery_time,
                    // 'product_delivery_info' =>  $delivery_info_json,
                    // 'ip_address'    =>  $ipaddress,
                    // 'browser_info'  =>  json_encode($user_agent),
                    'customer_email'=>  $shopify_order->order->email,
                    'customer_name' =>  $shopify_order->order->customer->first_name . " " . $shopify_order->order->customer->last_name,
                    'admin_email'   =>  $shop_find->email,
                    'type_of_app'   =>  $shop_find->type_of_app,
                    'app_version'   =>  $shop_find->app_version,
                    'details'       =>  $shop,
                    'order_information'=>  $shopify_order->order
				]);
			}else{
				$order_data = $order->order_information;
				$order_data['financial_status'] = $shopify_order->order->financial_status;
				$order_data['fulfillment_status'] = $shopify_order->order->fulfillment_status;
				// dd($order_data['note_attributes'],$data['note_attributes']);
				$order_data['note_attributes'] = $data['note_attributes'];
				// dd('update',$order_data);
				# Update new delivery date and delivery time in database
				$results = $shop_find->order_details()->where('order_id',$order_id)->update(['delivery_date' => $delivery_date, 'delivery_time' => $delivery_time,'order_information' => json_encode($order_data)]);
			}
			## If updated successfully retun response
			if($results)
				return 1;
			return 0;
		} catch (Exception $e) {
			dd($e->getMessage());
			if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return 0;
		}
	}

	/**
     * function fn_format_date
     * @param $exception = Exception instance
     */
    private function fn_format_date($date_format,$product_delivery_date) {
    	$converted_date = '';
        if($date_format == "m/d/Y") {
        	if(strtotime($product_delivery_date) == false){
        		// $date_string = str_replace(",","",$product_delivery_date);
        		$raw_date = explode('/', $product_delivery_date);
        		$converted_date = implode('/', array($raw_date['1'], $raw_date['0'], $raw_date['2']));
        	}else{
        		// $date_string = str_replace(",","",$product_delivery_date);
        		$date = date_create($product_delivery_date);
        		$converted_date = date_format($date,"m/d/Y");
        		
        	}
        }else if($date_format == "d/m/Y"){
        	if(strtotime($product_delivery_date) == false){
        		$raw_date = explode('/', $product_delivery_date);
        		$converted_date = implode('-', array($raw_date['0'], $raw_date['1'], $raw_date['2']));
        	}else{
        		$date_string = $product_delivery_date;
        		$date = date_create($date_string);
        		$converted_date = date_format($date,"d-m-Y");
        		
        	}	
        }else if($date_format == "Y/m/d"){
        	if(strtotime($product_delivery_date) == false){
        		$date_string = $product_delivery_date;
        		$raw_date = explode('/', $date_string);
        		$converted_date = implode('-', array($raw_date['2'], $raw_date['1'], $raw_date['0']));
        	}else{
        		$date_string = $product_delivery_date;
        		$date = date_create($date_string);
        		$converted_date = date_format($date,"Y-m-d");
        		
        	}
        }
        return $converted_date;
    }

    public function getStoreInfo() {

     	$filename = "DDP_Store_Info.csv";
    	$data_header = array("Store Name","App Version","Payment Status","Store shopify_plan");

    	$data_array = ShopModel::select('store_name as Store Name', 'app_version as App Version', 'status as Payment Status', 'plan_name as Store shopify_plan')->get()->toArray();

    	## Put data into csv file and export
		$callback = function() use ($data_array, $data_header)
		{
			$fp = fopen('php://output', 'w');
			fputcsv($fp, $data_header);
			foreach($data_array as $data_row)
			{
				fputcsv($fp,$data_row);
			}
			fclose($fp);
		};
		$headers = array(
			"Content-type" => "text/csv",
			"Content-Disposition" => "attachment; filename=$filename",
			"Pragma" => "no-cache",
			"Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
			"Expires" => "0"
		);
		return Response::stream($callback, 200, $headers);
    }
}
