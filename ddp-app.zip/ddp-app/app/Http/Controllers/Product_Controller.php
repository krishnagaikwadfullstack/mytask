<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App;
use Exception;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\Models\ShopModel;
use App\Models\ProductSettings;
use App\Models\AppSettings;

class Product_Controller extends Controller {

    public function __construct() {
        $this->api_version = getenv('API_VERSION');
        // echo $this->api_version;exit;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function save_product_settings(Request $request) 
    {
        $shop = session('shop') ?? request()->get('shop');
        try {
            $selected_products_count = (!is_null($request->input('selected_product'))) ? count($request->input('selected_product')) : 0;
            $selected_products = $request->input('selected_product') ?? [];
            $all_products = $request->input('all_product_ids');
            $all_products_count = count($request->input('all_product_ids'));
            $data = array();
            $data['global_product_delivery_time'] = $request->input('global_product_delivery_time') ?? 0;
            $data['global_product_blocked_dates'] = $request->input('global_product_blocked_dates') ?? 0;
            $data['global_product_blocked_days'] = $request->input('global_product_blocked_days') ?? 0;
            $data['global_product_pre_order'] = $request->input('global_product_pre_order') ?? 0;
            $data['global_product_date_interval'] = $request->input('global_product_date_interval') ?? 0;
            $data['global_product_cut_off'] = $request->input('global_product_cut_off') ?? 0;

            $shop_info = ShopModel::whereStoreName($shop)->first();
            $shop_id = $shop_info->id;
            ## update block config data
            $shop_info->block_config()->update($data);
            for ($i = 0; $i < $all_products_count; $i++) {
                $data = array();
                $product_id = $all_products[$i];
                // $data['status'] = 1; //changed from 0 to 1 by Bhushan Amasa
                // if ($selected_products_count > 0)
                $data['status'] = (in_array($product_id, $selected_products)) ? 1 : 0;
                ## Get product setting data.
                $product_settings = $shop_info->product_settings()->whereProductId($product_id)->first();
                if ($request->input('delivery_time_' . $product_id) != '') {
                    $data['delivery_times'] = $request->input('delivery_time_' . $product_id);
                } else {
                    $data['delivery_times'] = !empty($product_settings) ? $product_settings->delivery_times : '';
                }

                $blocked_dates = $request->input('blockeddate_' . $product_id);
                if ($blocked_dates) {
                    $data['blocked_dates'] = str_replace("/", "-", implode(",", $request->input('blockeddate_' . $product_id)));
                }

                if (count($request->input('days_' . $product_id)) > 0)
                    $data['blocked_days'] = implode(",", $request->input('days_' . $product_id));

                $pre_order_time = $request->input('allowed_month_' . $product_id);
                $date_interval = $request->input('intervel_' . $product_id);
                $date_interval = ($date_interval == 0 || $date_interval == '') ? 0 : $date_interval;
                
                $cut_off_hours = $request->input('hour_' . $product_id);
                $cut_off_minutes = $request->input('minute_' . $product_id);
                $data['pre_order_time'] = !empty($pre_order_time) ? $pre_order_time : 6;
                $data['date_interval'] = $date_interval;
                $data['shop_id'] = $shop_id;
                $data['cut_off_hours'] = !empty($cut_off_hours) ? $cut_off_hours : 0;
                $data['cut_off_minutes'] = !empty($cut_off_minutes) ? $cut_off_minutes : (!empty($product_settings) ? $product_settings->cut_off_minutes : 0);
                $data['product_id'] = $product_id;
                $data['shop'] = $shop;
                ## Update if record exist otherwise create new.
                $shop_info->product_settings()->updateOrCreate(['shop' => $shop, 'product_id' => $product_id],$data);
            }
            $notification = [
                'message' => 'Settings Saved Successfully.',
                'alert-type' => 'success'
            ];
            return redirect()->route('product-settings', ['shop' => $shop])->with(['shop' => $shop,'notification'=> $notification]); 
        } catch (Exception $e) {
            $notification = [
                'message' => 'Something went wrong.',
                'alert-type' => 'error'
            ];
            if(isset($request['debug']) && $request['debug'] == true)
                $notification['message'] = $e->getMessage();
            return redirect()->route('product-settings', ['shop' => $shop])->with(['shop' => $shop,'notification'=> $notification]);
            
        }
    }

    /**
     * get response.
     *
     * @return \Illuminate\Http\Response
     */
    public function product_settings() 
    {
        try {
            $shop = session('shop') ?? request()->get('shop');
            $shop_info = ShopModel::whereStoreName($shop)->first();
            $configuration = $shop_info->block_config;
            $product_settings = $shop_info->product_settings;
            $product_settings_array = array();
            foreach ($product_settings as $product) 
            {
                $product_id = $product->product_id;
                $product_settings_array[$product_id] = $shop_info->product_settings()->whereProductId($product_id)->first();
            }
            return view('product_settings', ['product_settings' => json_encode($product_settings_array), 'configuration' => $configuration, 'count' => count($product_settings_array), 'shop' => $shop]);
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function get_product_settings(Request $request) {
        try {
            $shop_name = $request->input('shop_name');
            $store_settings = ShopModel::whereStoreName($shop_name)->first();
            $product_settings = $store_settings->product_settings()->whereProductId($request->input('product_id'))->first();
            $app_config = $store_settings->block_config;
            $settings = array();
            $settings['product_settings'] = $product_settings;
            $settings['app_config'] = $app_config;
            if ($store_settings->app_version == 4)
                return json_encode($settings);
            return 0;
        } catch (Exception $e) {
            return 0;
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function product_data(Request $request) 
    {
        try {
            $app_settings = AppSettings::where('id', 1)->first();
            $shop = session('shop') ?? request()->get('shop');
            $select_store = ShopModel::whereStoreName($shop)->first();
            $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $select_store->access_token]);
            $draw = $request['draw'];
            $start = $request['start'];
            $length = $request['length'];
            $count = $sh->call(['URL' => '/admin/api/' . $this->api_version . '/products/count.json', 'METHOD' => 'GET']);
            $products_count = (array) $count;
            $product_count = $products_count['count'];
            $total_products = array('draw' => $draw, 'recordsTotal' => $product_count, 'recordsFiltered' => $product_count);
            $search_url = $request['search']['value'];
            $search = urlencode($search_url);
            $limit = 250;
            // $limit = $request->length;
            
            $i = 0;
            $next_param = "";
            $default_image = url('/image/default.png');
            do{
                ## check search parameter available then pass to api call.
                $str_param = '&page_info='.$next_param;
                if ($search)
                    $str_param = '&title='.$search;
                $product_list = $sh->callAdvance(['URL' => '/admin/api/' . $this->api_version . '/products.json?limit=' . $limit .$str_param, 'METHOD' => 'GET']);
                ## Check header has link parameter. then add pagination parameters
                if(isset($product_list->headers['link'])){
                    $next = $product_list->headers['link'];
                    $page_params = explode(',',$next);

                    if(isset($page_params[1])){
                        $next_url = explode(',',$page_params[1]);
                        $previous_url = explode(',',$page_params[0]);
                    } else {
                        $check = explode('; ', $page_params[0]);
                        $check = str_replace('"', '', $check[1]);
                        if(strpos($check, 'next') !== false){
                            $next_url = explode(',',$page_params[0]);
                            $previous_url = '';                         
                        } else {
                            $previous_url = explode(',',$page_params[0]);
                            $next_url = '';                         
                        }
                    }
                    ## Assign next page url
                    $next_param = '';
                    if($next_url != ''){
                        $str = substr($next_url[0], 1, -1);
                        $url_components = parse_url(substr($str, 0, strpos($str, ">")));
                        parse_str($url_components['query'], $next_params);
                        $next_param = $next_params['page_info'];
                    }
                    ## Assign previous page url
                    $previous_param = '';
                    if($previous_url != ''){
                        $str = substr($previous_url[0], 1, -1);
                        $url_components = parse_url(substr($str, 0, strpos($str, ">")));
                        parse_str($url_components['query'], $previous_params);
                        $previous_param = $previous_params['page_info'];
                    }
                }
                ## Assign product image,name and id into array.
                foreach ($product_list->products as $product) {
                    $image = (isset($product->images[0])) ? $product->images[0]->src : "";
                    $total_products['data'][] = array('product_id' => $product->id, 'product_image' => $image, 'product_name' => $product->title);
                }
            } while ($next_param != '');
            ## assign return response data
            $return_arr = array();
            for ($i = $start; $i < $start + $length; $i++) 
            {
                if (isset($total_products['data'][$i]))
                    $return_arr[] = $total_products['data'][$i];
                else
                    break;
            }
            $total_products['data'] = $return_arr;
            return json_encode($total_products);   
        } catch (Exception $e) {
            return json_encode([]);
        }
    }

    /**
     * return json data.
     *
     * @return \Illuminate\Http\Response
     */
    public function get_product_data(Request $request) 
    {
        try {
            $product_settings_array = ProductSettings::get()->keyBy('product_id')->toArray();
            return json_encode($product_settings_array);   
        } catch (Exception $e) {
            return json_decode([]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function check_data(Request $request) 
    {
        try {
            $product_data = array();
            parse_str($request->input('data'), $product_data);
            if (isset($product_data['selected_product'])) {
                $selected_products_count = count($product_data['selected_product']);
                $selected_products = $product_data['selected_product'];
                $shop = session('shop') ?? request()->get('shop');
                $data = array();
                $data['global_product_delivery_time'] = isset($product_data['global_product_delivery_time']) ? 1 : 0;
                $data['global_product_blocked_dates'] = isset($product_data['global_product_blocked_dates']) ? 1 : 0;
                $data['global_product_blocked_days'] = isset($product_data['global_product_blocked_days']) ? 1 : 0;
                $data['global_product_pre_order'] = isset($product_data['global_product_pre_order']) ? 1 : 0;
                $data['global_product_date_interval'] = isset($product_data['global_product_date_interval']) ? 1 : 0;
                $data['global_product_cut_off'] = isset($product_data['global_product_cut_off']) ? 1 : 0;
                ## Get block config data and update 
                $shop_info = ShopModel::whereStoreName($shop)->first();
                $shop_info->block_config()->update($data);
                ## Product setting data Update if record exist otherwise create new.
                for ($i = 0; $i < $selected_products_count; $i++) {
                    $data = array();
                    $product_id = $selected_products[$i];
                    $data['delivery_times'] = "";
                    if (isset($product_data['delivery_time_' . $product_id]))
                        $data['delivery_times'] = $product_data['delivery_time_' . $product_id];

                    $data['blocked_dates'] = str_replace("/", "-", implode(",", $product_data['blockeddate_' . $product_id]));
                    if (isset($product_data['days_' . $product_id])) {
                        if (count($product_data['days_' . $product_id]) > 0) {
                            $data['blocked_days'] = implode(",", $product_data['days_' . $product_id]);
                        }
                    }
                    $data['pre_order_time'] = $product_data['allowed_month_' . $product_id];
                    $data['date_interval'] = $product_data['intervel_' . $product_id];
                    $data['cut_off_hours'] = empty($product_data['hour_' . $product_id]) ? 0 : $product_data['hour_' . $product_id];
                    $data['cut_off_minutes'] = empty($product_data['minute_' . $product_id]) ? 0 : $product_data['minute_' . $product_id];
                    $data['shop'] = $shop;
                    $data['product_id'] = $product_id;
                    ## Update if record exist otherwise create new.
                    $data = ProductSettings::updateOrCreate(['shop' => $shop, 'product_id' => $product_id],$data);
                }
            }
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return 0;
        }
    }
}
