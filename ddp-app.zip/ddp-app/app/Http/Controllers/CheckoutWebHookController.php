<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\ShopModel;
use App\AppSettings;
use App\OrderDetails;
use Exception;
use App;
use App\Events\WebhookProcessedEvent;

class CheckoutWebHookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $store_name = $data = $customer_name = '';
        try {
            $data = file_get_contents('php://input');
            // event(new WebhookProcessedEvent(['message'=>'Before Data-'.$data]));
            $result = json_decode($data);

            $order_id = $result->id;
            $customer_email = $result->email;
            if(isset($result->customer)){
                $customer_name = $result->customer->first_name . " " . $result->customer->last_name ;
            }
            $order_name = $result->name;
            $other_note = $result->note;    
            $url = explode("/", $result->order_status_url);     
            $store_name = $_SERVER['HTTP_X_SHOPIFY_SHOP_DOMAIN'];
            $objShopDetails = ShopModel::where('store_name',$store_name)->first();
            $date_format="";
            $user_agent =  $result->client_details->user_agent ?? '';
            $ipaddress  =  $result->client_details->browser_ip ?? '';
            $shop_id = $objShopDetails->id ?? "";
            $type_of_app= $objShopDetails->type_of_app ?? "";
            $app_version= $objShopDetails->app_version ?? "";
            $access_token = $objShopDetails->access_token ?? "";
            $status = $objShopDetails->status ??"";
            $delivery_date = $delivery_time = $date = $obj_block_config = $tag_date = "";
            ## Assign delivery date and time variable value
            foreach($result->note_attributes as $attributes) {
                if($attributes->name == "Shipping-Date" OR $attributes->name == "date" OR $attributes->name == "Delivery-Date")
                    $delivery_date = $attributes->value;

                if($attributes->name == "Delivery-Time")
                    $delivery_time = $attributes->value;
            }
            
             ##Check shop is exist in our database.
            if (!is_null($objShopDetails))
                $obj_block_config = $objShopDetails->block_config;

            $date_format = $obj_block_config->date_format ?? "";     
            $date_require_option = $obj_block_config->require_option ?? "";
            $time_require_option = $obj_block_config->time_require_option ?? ""; 
            $add_delivery_information = $obj_block_config->add_delivery_information ?? "";
            ## Check date format
            if($date_format != "" && !empty($delivery_date)) {
                $date = str_replace("/","-",$delivery_date);
                $tag_date = $date;
                if($date_format == "dd/mm/yy")
                    $date = date("Y-m-d", strtotime($date));

                if($date_format == "mm/dd/yy")
                    $date = date("Y-m-d",strtotime($delivery_date));

                if($date_format == "yy/mm/dd")
                    $date = str_replace("/","-",$delivery_date);
            }

            $date_flag = $time_flag = 0;        
            $msg = "Hi There, Due to some Reason we have Found that ";
            if($date == "" || empty($date) || $date == "0000-00-00" || $date == "1969-12-31" || $date == "1970-01-01") {               
                if($date_require_option == '1') {
                    $date_flag = 1;
                    $msg = $msg . "Delivery Date";      
                }
            }

            if($delivery_time == "" || empty($delivery_time)) {       
                if($time_require_option == 1) {
                    $time_flag = 1;
                    if($date_flag == 1)
                        $msg = $msg . "&";
                    $msg = $msg . "Delivery Time ";     
                }
            }
            
            if($date_flag == 1 || $time_flag == 1) {   
                $msg = $msg . "has not been Captured for Order #$order_id on your Store $store_name
                from Device $user_agent";
            }
            
            $delivery_info = $delivery_date_array = $delivery_time_array = $delivery_info = array();
            $delivery_date_temp = $delivery_time_temp = "";
            ## assign delivery date and time
            foreach($result->line_items as $item) {
                foreach($item->properties as $property) {
                    if($property->name == 'Delivery-Date')
                        $delivery_date_temp = $property->value;

                    if($property->name == 'Delivery-Time')
                        $delivery_time_temp = $property->value;
                }
                $temp_delivery_info = array($delivery_date_temp, $delivery_time_temp);
                array_push($delivery_info, $temp_delivery_info);
            }
            $delivery_info_json = json_encode($delivery_info);
            ## get app setting data
            $objAppSetting = AppSettings::where('id', 1)->first();
            $api_key = $objAppSetting->api_key;
            $shared_secret = $objAppSetting->shared_secret;
            $admin_email = $objShopDetails->email ?? "";
            $insert_data = [
                    'shop_id'       =>  $shop_id,
                    'order_id'      =>  $order_id,
                    'order_name'    =>  $order_id,
                    'delivery_date' =>  (!empty($date)) ? $date : null,
                    'delivery_time' =>  $delivery_time,
                    'product_delivery_info' =>  $delivery_info_json,
                    'ip_address'    =>  $ipaddress,
                    'browser_info'  =>  json_encode($user_agent),
                    'customer_email'=>  $customer_email,
                    'customer_name' =>  $customer_name,
                    'admin_email'   =>  $admin_email,
                    'type_of_app'   =>  $type_of_app,
                    'app_version'   =>  $app_version,
                    'details'       =>  $store_name
                ];
                
            if($date == "" || empty($date) || $date == "0000-00-00" || $date == "1969-12-31") {
                $date_flag = 1;
                $msg = $msg . "Delivery Date";
                $insert_data['order_name'] = $order_name;
            } else {
                $insert_data['delivery_info_status'] = 1;
            }

            ## Store order data into database.
            try {
                OrderDetails::create($insert_data);   
            } catch (Exception $e) {
                // OrderDetails::create(['details'=>$e->getMessage()]);
                event(new WebhookProcessedEvent(['message'=>'Error occured in checkout webhook call while storing order details in store- '.$store_name.'. File Path-'.$e->getFile().' Error-'.$e->getMessage().' At line-'.$e->getLine()]));
            }

            ## store information into file
            if($store_name == 'iga-essentials.myshopify.com'){
                $myfile = fopen("debug12.txt", "a") or die("Unable to open file!");
                fwrite($myfile, json_encode($_SERVER));
                fwrite($myfile, $objShopDetails);
                fwrite($myfile, $json);
                fclose($myfile);
            }
            $this->api_version = getenv('API_VERSION');
            ## check date is not empty
            if($date == "" || empty($date) || $date == "0000-00-00" || $date == "1969-12-31" || $date == "1970-01-01"){

            } else {
                if($add_delivery_information == 1){
                    try {
                        $url = "https://$api_key:$shared_secret@$store_name/admin/orders/$order_id.json";
                        $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, $url);
                        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json',"X-Shopify-Access-Token: $access_token"));
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($curl, CURLOPT_VERBOSE, 0);
                        curl_setopt($curl, CURLOPT_HEADER, 0);
                        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "GET");       
                        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                        $response = curl_exec($curl);
                        curl_close ($curl);
                        
                        $order_data_array = json_decode($response);
                        $previous_tags =  $order_data_array->order->tags;                       
                        $tags = "$previous_tags , $tag_date , $delivery_time";      
                        $note = '';
                        if($store_name == 'virginiamaryflorist.myshopify.com' || $store_name == "li-lac-chocolates.myshopify.com"){
                            $note = $other_note;
                        } else {
                            $note = $other_note." Delivery Date:- ".$tag_date;
                            if(!empty($delivery_time))
                                $note = $note." "." Delivery Time:- ".$delivery_time;
                        }
                        $order_data = [
                            'order' => [
                                'id'   =>   "$order_id",
                                'tags' =>   "$tags",
                                'note' =>   $note,
                            ] 
                        ];

                        $url = "https://$api_key:$shared_secret@$store_name/admin/orders/$order_id.json";
                        $curl = curl_init();
                        curl_setopt($curl, CURLOPT_URL, $url);
                        curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/json',"X-Shopify-Access-Token: $access_token"));
                        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                        curl_setopt($curl, CURLOPT_VERBOSE, 0);
                        curl_setopt($curl, CURLOPT_HEADER, 0);
                        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                        curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($order_data));
                        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                        $response = curl_exec($curl);
                        curl_close ($curl);
                    } catch (Exception $e) {
                        event(new WebhookProcessedEvent(['message'=>'Error occured in checkout webhook  order api in store- '.$store_name.'. File Path-'.$e->getFile().' Error-'.$e->getMessage().' At line-'.$e->getLine()]));                
                    }
               }      
            }
            // event(new WebhookProcessedEvent(['message'=>'successfully done.']));
        } catch (Exception $e) {
            event(new WebhookProcessedEvent(['message'=>'Error occured in checkout webhook call in store- '.$store_name.' Data-'.$data.'. File Path-'.$e->getFile().' Error-'.$e->getMessage().' At line-'.$e->getLine()]));
        }
    }
}
