<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Events\AppUnInstallationProcessed;
use App\ShopModel;
use Exception;
use App\Events\WebhookProcessedEvent;

class WebHookController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        try {
            $data = file_get_contents('php://input');
            $result = json_decode($data);
            $store_name = $result->myshopify_domain ?? 'N/A';
            $store_email = $result->email;
            $objShopDetails = ShopModel::whereStoreName($store_name)->first();
            ## check all table has data then delete it.
            if(!is_null($objShopDetails)){
                if(!is_null($objShopDetails->trial_info))
                    $objShopDetails->trial_info()->delete();

                if(count($objShopDetails->product_settings) > 0)
                    $objShopDetails->product_settings()->delete();

                if(count($objShopDetails->delivery_time_settings) > 0)
                    $objShopDetails->delivery_time_settings()->delete();

                if(count($objShopDetails->cutoff_settings) > 0)
                    $objShopDetails->cutoff_settings()->delete();

                if(!is_null($objShopDetails->block_config))
                    $objShopDetails->block_config()->delete();
                
                $objShopDetails = $objShopDetails->delete();
                event(new AppUnInstallationProcessed($result));
            }   
        } catch (Exception $e) {
            event(new WebhookProcessedEvent(['message'=>'Error occured in app uninstall webhook call  File Path-'.$e->getFile().' Error-'.$e->getMessage().' At line-'.$e->getLine()]));
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            echo "done";
        } catch (Exception $e) {
            event(new WebhookProcessedEvent(['message'=>'Error occured in app uninstall webhook call File Path-'.$e->getFile().' Error-'.$e->getMessage().' At line-'.$e->getLine()]));
        }
    }
}
