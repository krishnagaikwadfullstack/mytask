<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\ShopModel;
use App\DeliveryTimeSettings;

class deliverytimeController extends Controller
{	
	/**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	public function delivery_time(Request $request)
	{					
		$shop = session('shop') ?? $_GET['shop'];
		$shop_find = ShopModel::where('store_name' , $shop)->first();
		$shop_id = $shop_find->id;
		$data['config'] = $shop_find->block_config ?? [];
		$data['active'] = 'date';
		$data['settings'] = $shop_find->delivery_time_settings;
		$data['count_flag'] = $shop_find->delivery_time_count_status;				
		$data['global_flag'] = $shop_find->global_delivery_time_status;				
		return view('delivery_time_settings',$data);
	}
	
	/**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
	public function save_delivery_times(Request $request)
	{
		try {
			$shop = session('shop') ?? $_GET['shop'];
			$temp = ShopModel::where('store_name' , $shop)->first();
	        $shop_id = $temp->id;
	        ## Check count_flag & global_delivery_time is avaialble or not and save status.
			$temp->delivery_time_count_status = ($request->input('count_flag')) ? 1 : 0;
			$temp->global_delivery_time_status = ($request->input('global_delivery_time')) ? 1 : 0;
			$temp->save();
			## Store delivery times.
			for($i=0; $i<7; $i++)
			{
				$delivery_times = json_encode($request->input('delivery_time_'.$i));
				$count = 0;
				## check count then available
				if(!empty($request->input('count_'.$i)))
					$count = implode(",",$request->input('count_'.$i));

				$info = ['store' => $shop, 'day' => $i,'delivery_times' => $delivery_times ,'count' => $count, 'shop_id' => $shop_id];
				## update if data available in DB otherwise create new record.
				DeliveryTimeSettings::updateOrCreate(['day' => $i, 'store' => $shop],$info);
			}
			$notification = [
				'message' => 'Settings Saved Successfully.',
				'alert-type' => 'success'
			];
			return redirect()->route('delivery-time',['notification'=>$notification, 'shop' => $shop])->with(['notification'=>$notification, 'shop'=>$shop]);
		} catch (Exception $e) {
			$notification = [
				'message' => 'Something went wrong.',
				'alert-type' => 'error'
			];
			if(isset($request['debug']) && $request['debug'] == true)
                $notification['message'] = $e->getMessage();
            return redirect()->route('delivery-time')->with('notification',$notification);
		}
	}
			
}