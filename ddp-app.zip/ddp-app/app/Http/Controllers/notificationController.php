<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App;
use Exception;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\ShopModel;
use App\AppSettings;
use App\StoreInformation;
use App\Events\FrontendErrorOccurredEvent;

class NotificationController extends Controller
{
    public function __construct() {
        $this->api_version = getenv('API_VERSION');
    }
    
    /**
     * Function fn_frontend_error_mail
    */
    public function fn_frontend_error_mail(Request $request)
    {
        $error_info_array['shop'] = $shop = $request->get('shop');
        $shop_detail = ShopModel::with('fn_error_log')->whereStoreName($shop)->first();
        if(!is_null($shop_detail)){
            $error_info_array['error_msg'] = $request->get('message');
            $error_info_array['error_line_no'] = $request->get('lineNumber') ?? '';
            $error_info_array['error_type'] = 20;
            $error_info_array['domain'] = $shop;
            $error_info_array['email'] = $shop_detail->email;
            $error_info_array['file_path'] = $request->get('filename') ?? 'cartsnippets.js';
            if(is_null($shop_detail->fn_error_log) || $shop_detail->fn_error_log->status == 2){
                $shop_detail->fn_error_log()->updateOrCreate(['shop_id'=>$shop_detail->id],
                    [
                        'shop_id'=>$shop_detail->id,
                        'error_msg'=>$request->get('message'),
                        'status'=>1
                    ]);
                event(new FrontendErrorOccurredEvent($error_info_array));
                return response()->json(['success'=>'true','message' => 'Success.'], 200);
            }
            return response()->json(['success'=>'true','message' => 'Already email sent.'], 200);
        }
    }
}