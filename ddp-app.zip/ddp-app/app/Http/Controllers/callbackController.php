<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App;
use Mail;
use Session;
use Exception;
use App\Models\ShopModel;
use App\Models\BlockConfig;
use App\Models\AppSettings;
use App\Models\TrialInfo;
use App\Models\DevelopmentStore;
use App\Models\StoreInformation;
use App\Models\CutoffSettings;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\Events\ErrorOccurredEvent;
use App\Events\AppInstallationProcessed;
use App\Events\AppConfirmationProcessed;
use App\Events\CreateNewChargeEvent;

class callbackController extends Controller {

    public function __construct() {
        $this->api_version = env('API_VERSION');
        $this->error_info_array = [];
        $this->app_settings = AppSettings::where('id', 1)->first();
        $this->trial_days = env('TRIAL_DAYS');
    }

    /**
     * Function index
     * @param $request Illuminate\Http\Request
     * @return redirect to app installation or dashborad page or plans selection page
     */
    public function index(Request $request) {
        $shop = $request->shop ?? '';
        $this->error_info_array['shop'] = $shop;
        try {
            if(is_null($shop)){
                echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                    exit;
            }

            $obj_shop_detail = ShopModel::whereStoreName($shop)->first();
            $this->error_info_array['shop_info'] = $obj_shop_detail;
            if(is_null($obj_shop_detail)){
                $read_all_orders = '';
                return view('appconfiguration',compact(['shop','read_all_orders']));
            }
            ##if store already in database 
            try {
                ##check that app is active or not
                if ($obj_shop_detail->charge_id != "" && $obj_shop_detail->charge_id > 0 && $obj_shop_detail->status == "active") {
                    ##check the version of app selected or not
                    if ($obj_shop_detail->app_version > 0 && $obj_shop_detail->type_of_app > 0) {
                        session(['shop' => $shop]);
                        return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                    } 
                    return redirect()->route('select-plans',['shop' => $shop])->with(['shop'=>$shop]);
                }
                ##if app is not active then redirect user to the payment process 
                return redirect()->route('payment_process',['shop' => $shop])->with(['shop'=>$shop]);

            } catch (Exception $e) {
                $this->fn_send_error_mail($e,15);
                echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                exit;
            }
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,1);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit;
        }
    }

    /**
     * Function redirect
     * @param $request Illuminate\Http\Request
     * @return redirect to dashborad page or payment process or plans selection page
     */
    public function redirect(Request $request) {
        $shop = $request->shop;
        $code = $request->code;
        $obj_shop_detail = ShopModel::whereStoreName($shop)->first();
        $this->error_info_array['shop'] = $shop;
        try {
            ## If shop and code empty then show error message.
            if ($shop == "" || $code == "") {
                // $this->fn_send_error_mail($e,6);
                echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                exit;
            }

            try {
                ## If store is already exits then redirect to dashboard or payment.
                if (isset($obj_shop_detail) && !empty($obj_shop_detail) && !empty($obj_shop_detail->charge_id)) {
                    $this->error_info_array['shop_info'] = $obj_shop_detail;
                    /*$sh = App::make('ShopifyAPI', ['API_KEY' => $this->app_settings->api_key, 'API_SECRET' => $this->app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $obj_shop_detail->access_token]);
                    $url = 'admin/api/'.$this->api_version.'/recurring_application_charges/' . $obj_shop_detail->charge_id . '.json';
                    $charge = $sh->call(['URL' => $url, 'METHOD' => 'GET']);*/
                    ## Implement logic here for checking database charge is id valid or not.

                    $chargeId = $obj_shop_detail->charge_id;
                    $chargeStatus = $obj_shop_detail->status;
                    //prevent the multiple store entry 
                    if (!empty($chargeId) && $chargeId > 0 && $chargeStatus == "active") {
                        session(['shop' => $shop]);
                        return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                    } else {
                        return redirect()->route('payment_process',['shop' => $shop])->with(['shop'=>$shop]);
                    }
                }
            } catch (Exception $e) {
                $this->fn_send_error_mail($e,16);
                echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                exit;
            }

            $sh = App::make('ShopifyAPI', ['API_KEY' => $this->app_settings->api_key, 'API_SECRET' => $this->app_settings->shared_secret, 'SHOP_DOMAIN' => $shop]);

            ## Check that request is Generated from shopify or not
            $verify = $sh->verifyRequest($request->all());
            if ($verify) {
                try {
                    $access_token = $sh->getAccessToken($code);
                    $sh = app('ShopifyAPI', ['API_KEY' => $this->app_settings->api_key, 'API_SECRET' => $this->app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $access_token]);
                    $shop_info = $sh->callAdvance(['URL' => '/admin/api/'.$this->api_version.'/shop.json', 'METHOD' => 'GET']);
                    $this->error_info_array['shop_info'] = $shop_info->shop;
                    $shop_address = $this->fn_get_shop_address($shop_info);

                    ## Save store information into database
                    ShopModel::updateOrCreate([ 'store_name' => $shop],['access_token' => $access_token, 'store_name' => $shop, 'email' => $shop_info->shop->email, 'shop_name' => $shop_info->shop->name, 'owner_name' => $shop_info->shop->shop_owner, 'plan_name'=> $shop_info->shop->plan_name, 'phone'=> $shop_info->shop->phone,'address'=> $shop_address, 'country_name'=> $shop_info->shop->country_name]);

                    $obj_shop_detail = ShopModel::whereStoreName($shop)->first();
                    $encryptShop = crypt($obj_shop_detail->id, "ka");
                    $encryptFinal = str_replace(['/', '.'], "Z", $encryptShop);
                    $obj_shop_detail->update(['store_encrypt' => $encryptFinal]);

                    ## inserting the default configuration
                    $obj_shop_detail->block_config()->updateOrCreate([ 'shop_id' => $obj_shop_detail->id],['block_date' => null, 'alloved_month' => 6, 'date_interval' => 1, 'days' => null, 'hours' => 0, 'minute' => 0, 'shop_id' => $obj_shop_detail->id, 'app_title' => 'Delivery Date', 'date_error_message' => 'Please Enter Delivery Date', 'date_format' => 'yy/mm/dd', 'app_status' => 'Active', 'show_datepicker_label' => 1, 'datepicker_label' => 'Pick a delivery date:', 'add_delivery_information' => 0, 'language_locale' => 'en']);
                    session(['shop' => $shop]);
                    $sh->setup(['API_KEY' => $this->app_settings->api_key, 'API_SECRET' => $this->app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $access_token]);
                } catch (Exception $e) {
                    $this->fn_send_error_mail($e,2);
                    echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                    exit;
                }

                ## Webhook and add snippets section
                try {
                    //for creating the uninstall webhook
                    $url = 'https://' . $shop . '/admin/api/' . $this->api_version . '/webhooks.json';
                    $webhook_data = [
                        'webhook' => [
                            'topic' => 'app/uninstalled',
                            'address' => env('SHOPIFY_WEBHOOK_1_ADDRESS'),
                            'format' => 'json'
                        ]
                    ];

                    $uninstall = $sh->appUninstallHook($access_token, $url, $webhook_data);
                    //webhook for checkout
                    $webhook_data = [
                        'webhook' => [
                            'topic' => 'orders/create',
                            'address' => env('SHOPIFY_WEBHOOK_2_ADDRESS'),
                            'format' => 'json'
                        ]
                    ];
                    $checkout = $sh->appUninstallHook($access_token, $url, $webhook_data);
                    //webhook for shop update
                    $webhook_data = [
                        'webhook' => [
                            'topic' => 'shop/update',
                            'address' => env('SHOPIFY_WEBHOOK_3_ADDRESS'),
                            'format' => 'json'
                        ]
                    ];
                    $shopupdate = $sh->appUninstallHook($access_token, $url, $webhook_data);

                    ## api call for get theme info
                    $theme = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/', 'METHOD' => 'GET']); //'DATA' => ['role' => 'main']     
                    foreach ($theme->themes as $themeData) {
                        if ($themeData->role != 'demo') {
                            $theme_id = $themeData->id;
                            $content = View('snippets')->render();
                            $view = (string) $content;
                            $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'snippets/delivery-date.liquid', 'value' => $view]]]);
                        }
                    }
                } catch (Exception $e) {
                    $this->fn_send_error_mail($e,3);
                    echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                    exit;
                }

                try {
                    ## Save store information section
                    $obj_shop_detail = $obj_shop_detail->refresh();
                    $obj_shop_detail->store_information()->updateOrCreate(['shop_id' => $obj_shop_detail->id],[
                        'shop_id' => $obj_shop_detail->id, 
                        'store_information_id' => $shop_info->shop->id, 
                        'store_name' => $shop_info->shop->name, 
                        'store_email' => $shop_info->shop->email, 
                        'store_domain' => $shop_info->shop->domain, 
                        'store_address'=> $shop_address, 
                        'store_phone'=> $shop_info->shop->phone,
                        'store_created'=> date('Y-m-d H:i:s', strtotime($shop_info->shop->created_at)),
                        'store_updated'=> date('Y-m-d H:i:s', strtotime($shop_info->shop->updated_at)), 
                        'store_country_name'=> $shop_info->shop->country_name, 
                        'store_currency'=> $shop_info->shop->currency, 
                        'store_owner' => $shop_info->shop->shop_owner, 
                        'store_plan_name'=> $shop_info->shop->plan_name 
                    ]);
                    ## Send the installation follow up mail to client and admin
                    event(new AppInstallationProcessed($shop_info));
                    return redirect()->route('select-plans',['shop' => $shop])->with(['shop'=>$shop]);
                    ## redirecting to the Shopify payment page
                    // echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>';
                } catch (Exception $e) {
                    $this->fn_send_error_mail($e,5);
                    echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
                    exit;
                }
            }
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,6);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit;
        }
    }

    /**
     * Function fn_payment_process
     * @param $request Illuminate\Http\Request
     * @return view blade file or redirect to charge confirmation page
     */
    public function fn_payment_process(Request $request) {
        $shop = session('shop') ?? request()->get('shop');
        $this->error_info_array['shop'] = $shop;
        try {
            $obj_store_detail = ShopModel::whereStoreName($shop)->first();
            if (!is_null($obj_store_detail)) {
                $this->error_info_array['shop_info'] = $obj_store_detail;
                $sh = App::make('ShopifyAPI', ['API_KEY' => $this->app_settings->api_key, 'API_SECRET' => $this->app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $obj_store_detail->access_token]);

                $charge_id = $obj_store_detail->charge_id;
                ## If charge id not stored in DB then create new
                if(empty($charge_id) || is_null($charge_id))
                   return redirect()->route('select-plans',['shop' => $shop])->with(['shop'=>$shop]);

                $url = 'admin/api/'.$this->api_version.'/recurring_application_charges/' . $charge_id . '.json';
                $charge = $sh->call(['URL' => $url, 'METHOD' => 'GET']);
                if (!empty($charge)) {
                    if ($charge->recurring_application_charge->status == "pending") {
                        echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>';
                    } elseif ($charge->recurring_application_charge->status == "declined" || $charge->recurring_application_charge->status == "expired") {
                        //creating the new Recuring charge after declined app
                        $url = 'https://' . $shop .'/admin/api/'.$this->api_version.'/recurring_application_charges.json';
                        $arr_demo_stores = explode(',', env('SHOPIFY_STORE_NAME'));
                        $arr_demo_plans = ['Developer Preview','partner_test','affiliate'];
                        ## Check trial days info
                        $get_trial_details = $obj_store_detail->trial_info;
                        ## If trial is already exists
                        if ($get_trial_details)
                            $this->trial_days = $this->fn_get_trial_days($shop);

                        ### Need add plan wise price not basic price
                        $arr_charge_param = ['name' => 'Delivery Date Pro','price' => env('APP_PRICE'),'return_url' => url('payment_success?shop='.$shop)];

                        if (in_array($shop, $arr_demo_stores) || in_array($obj_shop_detail->plan_name, $arr_demo_plans)) {
                            $arr_charge_param = ['name' => 'Delivery Date Pro','price' => 0.01,'return_url' => url('payment_success?shop='.$shop),'test' => true,'trial_days' => $this->trial_days];
                        }

                        $charge = $sh->call([
                            'URL' => $url,
                            'METHOD' => 'POST',
                            'DATA' => array(
                                'recurring_application_charge' =>  $arr_charge_param
                            )
                        ], false);

                        //updating the charge info in the database
                        $obj_store_detail->update(['charge_id' => (string) $charge->recurring_application_charge->id, 'api_client_id' => $charge->recurring_application_charge->api_client_id, 'price' => $charge->recurring_application_charge->price, 'status' => $charge->recurring_application_charge->status, 'billing_on' => $charge->recurring_application_charge->billing_on, 'payment_created_at' => $charge->recurring_application_charge->created_at, 'activated_on' => $charge->recurring_application_charge->activated_on, 'trial_ends_on' => $charge->recurring_application_charge->trial_ends_on, 'cancelled_on' => $charge->recurring_application_charge->cancelled_on, 'trial_days' => $charge->recurring_application_charge->trial_days, 'decorated_return_url' => $charge->recurring_application_charge->decorated_return_url, 'confirmation_url' => $charge->recurring_application_charge->confirmation_url, 'domain' => $shop]);

                        ## Redirecting to the Shopify payment page
                        echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>';
                    } else {
                        ## Check that user selected any plan or not
                        if ($obj_store_detail->app_version > 0 && $obj_store_detail->type_of_app > 0) {
                            session(['shop' => $shop]);
                            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                        } 
                        ## Redirect user on the plan page where user can select the relevant plan
                        return redirect()->route('select-plans',['shop' => $shop])->with(['shop'=>$shop]);
                    }
                }
                ### if charge not available then need to add code for...
            }
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,7);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit;
        }
    }

    /**
     * Function fn_payment_success
     * @param $request Illuminate\Http\Request
     * @return view blade file or redirect to charge confirmation page
     */
    public function fn_payment_success(Request $request) {
        $shop = session('shop') ?? request()->get('shop');
        $this->error_info_array['shop'] = $shop;
        try {
            $obj_shop_detail = ShopModel::whereStoreName($shop)->first();
            $this->error_info_array['shop_info'] = $obj_shop_detail;
            $sh = App::make('ShopifyAPI', ['API_KEY' => $this->app_settings->api_key, 'API_SECRET' => $this->app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $obj_shop_detail->access_token]);
            $chargeId = $request->charge_id;
            $url = 'admin/api/'.$this->api_version.'/recurring_application_charges/#{' . $chargeId . '}.json';
            $charge = $sh->call(['URL' => $url, 'METHOD' => 'GET',]);
            $status = $charge->recurring_application_charges[0]->status;
            ## Redirect user to the dashboard or plan selection page
            if ($status == "active") {
                $trial_start = $charge->recurring_application_charges[0]->activated_on;
                $trial_end = $charge->recurring_application_charges[0]->trial_ends_on;
                $this->trial_days = $charge->recurring_application_charges[0]->trial_days;
                //ShopModel::where('store_name', $shop)->where('charge_id', $chargeId)
                $obj_shop_detail->update(['status' => $status, 'activated_on' => $trial_start, 'trial_ends_on' => $trial_end]);
                ## Check if any trial info is exists or not
                if ($this->trial_days > 0) {
                    $get_trial_details = $obj_shop_detail->trial_info()->updateOrCreate(['shop_id' => $obj_shop_detail->id],[
                        'store_name' => $shop,
                        'shop_id' => $obj_shop_detail->id,
                        'trial_days' => $this->trial_days,
                        'activated_on' => $trial_start,
                        'trial_ends_on' => $trial_end
                    ]);
                }
                ## Check that user selected any plan or not
                if ($obj_shop_detail->app_version > 0 && $obj_shop_detail->type_of_app > 0) {
                    session(['shop' => $shop]);
                    return redirect()->route('dashboard',['shop' => $shop])->with(['shop'=>$shop]);
                }
                return redirect()->route('select-plans',['shop' => $shop])->with(['shop'=>$shop]);
            }
            ## Redirect user to the confirmation page
            ### Need to verify on live and redirect to proper route.
            if ($status == "declined") {
                $obj_shop_detail->update(['status' => $status]);
                echo '<script>window.top.location.href="https://' . $shop . '/admin/apps"</script>';
                exit();
            }
            ### Need to add last condition for other than active and declined status
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,8);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit();
        }
    }

    /**
     * function fn_plan For selecting plans
     * @return view blade file
     */
    public function fn_plan() {
        $data['shop'] = session('shop') ?? request()->get('shop');
        $data['obj_shop_detail'] = ShopModel::where('store_name', $data['shop'])->first();
        if ($data['obj_shop_detail']->app_version > 0)
            return redirect()->route('dashboard', ['shop' => $data['shop']])->with(['shop'=>$data['shop']]);
        return view('backend.plans', compact('data'));
    }

    /**
     * function fn_select_plan For showing plans page when changing version
     * @return view blade file
     */
    public function fn_select_plan() {
        $data['shop'] = session('shop') ?? request()->get('shop');
        $data['obj_shop_detail'] = ShopModel::where('store_name', $data['shop'])->first();
        return view('backend.plans', compact('data'));
    }

    /**
     * function fn_update_plan To create the recurring application charge as per the plan
     * @param $request Illuminate\Http\Request, $planId int
     * @return \Illuminate\Http\Response
     */
    public function fn_update_plan(Request $request, $planId) {
        $shop = session('shop') ?? request()->get('shop');
        $this->error_info_array['shop'] = $shop;
        try {
            $obj_shop_detail = ShopModel::whereStoreName($shop)->first();
            $this->error_info_array['shop_info'] = $obj_shop_detail;
            if($obj_shop_detail->app_version == $planId)
                return redirect()->route('dashboard',['shop' => $shop])->with(['shop'=>$shop]);

            $sh = App::make('ShopifyAPI', ['API_KEY' => $this->app_settings->api_key, 'API_SECRET' => $this->app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $obj_shop_detail->access_token]);

            ## Set plan wise description, price, app version and app type.
            if ($planId == 1) {
                $price = env('APP_PRICE');
                $type_of_app = $app_version = 1;
            } elseif ($planId == 2) {
                $price = env('APP_PRICE') + env('ADVANCE');
                $app_version = $type_of_app = 2;
            } elseif ($planId == 3) {
                $price = env('APP_PRICE') + env('PREMIUM');
                $app_version = $type_of_app = 3;
            }

            ## Check trial days info
            $get_trial_details = $obj_shop_detail->trial_info;
            ## If trial is already exists
            if ($get_trial_details)
                $this->trial_days = $this->fn_get_trial_days($shop);

            $url = 'https://' . $shop . '/admin/api/'.$this->api_version.'/recurring_application_charges.json';
            $arr_demo_stores = explode(',', env('SHOPIFY_STORE_NAME'));
            $arr_demo_plans = ['Developer Preview','partner_test','affiliate'];

            ## For client store
            $arr_charge_param = ['name' => 'Delivery Date Pro','price' => $price,'return_url' => url('payment_success?shop='.$shop),'trial_days' => $this->trial_days];

            ## For development store
            if (in_array($shop, $arr_demo_stores) || in_array($obj_shop_detail->plan_name, $arr_demo_plans)) {
                $arr_charge_param = ['name' => 'Delivery Date Pro','price' => 0.01,'return_url' => url('payment_success?shop='.$shop),'test' => true,'trial_days' => $this->trial_days];
            }

            ## Creating the Recurring charge for app
            $charge = $sh->call([
                'URL' => $url,
                'METHOD' => 'POST',
                'DATA' => array(
                    'recurring_application_charge' =>  $arr_charge_param
                )
            ], false);

            $updateShopData = [
                'charge_id' => (string) $charge->recurring_application_charge->id,
                'api_client_id' => $charge->recurring_application_charge->api_client_id,
                'price' => $charge->recurring_application_charge->price,
                'status' => $charge->recurring_application_charge->status,
                'billing_on' => $charge->recurring_application_charge->billing_on,
                'payment_created_at' => $charge->recurring_application_charge->created_at,
                'activated_on' => $charge->recurring_application_charge->activated_on,
                'trial_ends_on' => $charge->recurring_application_charge->trial_ends_on,
                'cancelled_on' => $charge->recurring_application_charge->cancelled_on,
                'trial_days' => $charge->recurring_application_charge->trial_days,
                'decorated_return_url' => $charge->recurring_application_charge->decorated_return_url,
                'confirmation_url' => $charge->recurring_application_charge->confirmation_url,
                'usage_price' => $price, 
                'app_version' => $app_version,
                'type_of_app' => $type_of_app,
                'upgrade_status' => "Y"
            ];
            $obj_shop_detail->update($updateShopData);

            if ($planId == 4) {
                $theme = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/', 'METHOD' => 'GET']);
                foreach ($theme->themes as $themeData) {
                    if ($themeData->role != 'demo') {
                        $theme_id = $themeData->id;
                        $content = View('product_snippets')->render();
                        $view = (string) $content;
                        $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'snippets/product-delivery-date.liquid', 'value' => $view]]]);
                    }
                }
            }
            echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>';
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,9);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit();
        }
    }

    /**
     * function fn_update_charge
     * @param $shop_info
     */
    public function fn_update_charge(Request $request){
        $shop = $request->shop;
        try {
            $objShopInfo = ShopModel::whereStoreName($shop)->first();
            $getAppSettings = AppSettings::where('id', 1)->first();
            $sh = App::make('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $objShopInfo->store_name, 'ACCESS_TOKEN' => $objShopInfo->access_token]);

            ##checking app price
            $arrPrices = ['1'=>7.99, '2'=>10.99, '3'=>14.99, '4'=>15.99];
            $arrNames = ['1'=>'Delivery Date Pro - Basic Version', '2'=>'Delivery Date Pro - Professional Version', '3'=>'Delivery Date Pro - Enterprise Version', '4'=>'Delivery Date Pro - Ultimate Version'];
            $price = $arrPrices[$objShopInfo->app_version];
            ##creating the Recurring charge for app
            $url = 'https://' . $objShopInfo->store_name . '/admin/recurring_application_charges.json';
            $charge = $sh->call([
                'URL' => $url,
                'METHOD' => 'POST',
                'DATA' => array(
                    'recurring_application_charge' => array(
                        'name' => $arrNames[$objShopInfo->app_version],
                        'price' => $price,
                        'return_url' => url('payment_success?shop='.$shop),
                        'trial_days' => 0
                    )
                )
            ], false);
            ##update charge data in usersetting table
            $updateShopData = array(
                'charge_id' => (string) $charge->recurring_application_charge->id,
                'api_client_id' => $charge->recurring_application_charge->api_client_id,
                'price' => $charge->recurring_application_charge->price,
                'status' => $charge->recurring_application_charge->status,
                'billing_on' => $charge->recurring_application_charge->billing_on,
                'payment_created_at' => $charge->recurring_application_charge->created_at,
                'cancelled_on' => $charge->recurring_application_charge->cancelled_on,
                'trial_days' => $charge->recurring_application_charge->trial_days,
                'decorated_return_url' => $charge->recurring_application_charge->decorated_return_url,
                'confirmation_url' => $charge->recurring_application_charge->confirmation_url,
                'domain' => $objShopInfo->store_name
            );
            $objShopInfo->update($updateShopData);
            event(new CreateNewChargeEvent($objShopInfo->refresh()));
            echo '<script>window.top.location.href="' . $charge->recurring_application_charge->confirmation_url . '"</script>';
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,16);
            Session::flash('error', 'we are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Can you please try manual process.');
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
        }
    }

    /**
     * function fn_create_cart_snippet Put shortcode directly in cart snippet/liquid file
     * @param $request Illuminate\Http\Request
     * @return \Illuminate\Http\Response
     */
    public function fn_create_cart_snippet(Request $request) 
    {
        $shop = session('shop') ?? request()->get('shop');
        $this->error_info_array['shop'] = $shop;
        try {
            $template = request()->get('template') ?? '';
            $obj_shop_detail = ShopModel::whereStoreName($shop)->first();
            $this->error_info_array['shop_info'] = $obj_shop_detail;
            $sh = app('ShopifyAPI', ['API_KEY' => $this->app_settings->api_key, 'API_SECRET' => $this->app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $obj_shop_detail->access_token]);
            //api call for get theme info
            $theme = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes.json', 'METHOD' => 'GET']);
            if ($template == 'checkout') {
                foreach ($theme->themes as $themeData) {
                    if ($themeData->role != 'demo') {
                        $theme_id = $themeData->id;
                        $product_template = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json?asset[key]=layout/checkout.liquid&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                        $string_value = $product_template->asset->value;
                        $contain_section = '<div class="sidebar" role="complementary">';
                        if (strpos($string_value, $contain_section) !== false) {
                            $is_exist = "{% include 'delivery-date' %}";
                            if (strpos($string_value, $is_exist) !== false) {
                                Session::flash('error', 'Your Shortcode has been already pasted in the checkout template page. If the datepicker section still does not appear, contact us for more support.');
                                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                            } else {
                                $str_to_insert = "{% include 'delivery-date' %}";
                                $find = '<div class="sidebar__header">';
                                if (strpos($string_value, $find) !== false) {
                                    //if find string available in liquide file                            
                                    $pos = strpos($string_value, $find);
                                    $newstr = substr_replace($string_value, $str_to_insert, $pos, 0);
                                    $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'layout/checkout.liquid', 'value' => $newstr]]]);
                                }
                            }
                        }
                    }
                }
            } else {
                foreach ($theme->themes as $themeData) {
                    if ($themeData->role == 'main') {
                        $theme_id = $themeData->id;
                        $theme_data = $sh->call(['URL' => '/admin/themes/' . $theme_id . '/assets.json', 'METHOD' => 'GET']);
                        $theme_two_flag = $cart_flag = $main_cart_flag = $main_cart_item_flag = false;
                        if(isset($theme_data->assets)){
                            foreach ($theme_data->assets as $key => $value) {
                                if($value->key == "templates/cart.json"){
                                    $theme_two_flag = true;
                                }
                                if($value->key == "sections/main-cart-items.liquid"){
                                    $main_cart_item_flag = true;
                                }
                                if($value->key == "sections/main-cart.liquid"){
                                    $main_cart_flag = true;
                                }
                                if($value->key == "sections/cart.liquid"){
                                    $cart_flag = true;
                                }
                            }
                        }
                        $string_value = $product_template = '';
                        $contain_section = "{% section 'cart-template' %}";
                        if($theme_two_flag == false){
                            $product_template = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json?asset[key]=templates/cart.liquid&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                            $string_value = $product_template->asset->value;
                            $contain_section = "{% section 'cart-template' %}";
                        }
                        if($theme_two_flag) {
                            //if shopify 2.0
                            if($main_cart_item_flag)
                                $liquid_name = 'main-cart-items.liquid';
                            if($main_cart_flag)
                                $liquid_name = 'main-cart.liquid';
                            if($cart_flag)
                                $liquid_name = 'cart.liquid';
                            $main_cart_items = $sh->call(['URL' => '/admin/themes/' . $theme_id . '/assets.json?asset[key]=sections/'.$liquid_name.'&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                            if(!isset($main_cart_items->asset))
                                continue;
                            $old_str = $main_cart_items->asset->value;
                            $is_exist = "{% render 'delivery-date' %}";
                            if (strpos($old_str, $is_exist) === false) {
                                $str_to_insert = " {% render 'delivery-date' %} ";
                                $find = '</form>';
                                $pos1 = strpos($old_str, $find) - 1;
                                $newstr = substr_replace($old_str, $str_to_insert, $pos1, 0);
                                $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'sections/'.$liquid_name, 'value' => $newstr]]]);
                            } else {
                                Session::flash('error', 'Your Shortcode has been already pasted in the cart template page. If the datepicker section still does not appear, contact us for more support.');
                                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                            } 
                        }elseif (strpos($string_value, $contain_section) !== false) {
                            //if cart-template.liquid available
                            $product_template = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json?asset[key]=sections/cart-template.liquid&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                            $old_str = $product_template->asset->value;
                            $is_exist = "{% include 'delivery-date' %}";
                            if (strpos($old_str, $is_exist) === false) {
                                $str_to_insert = " {% include 'delivery-date' %} ";
                                $find = '<div class="cart__footer">';
                                if (strpos($old_str, $find) !== false) {
                                    //if find string available in liquide file                            
                                    $pos = strpos($old_str, $find);
                                    $newstr = substr_replace($old_str, $str_to_insert, $pos, 0);
                                    $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'sections/cart-template.liquid', 'value' => $newstr]]]);
                                } else {
                                    //if find string NOT available in liquide file
                                    $find1 = "{{ cart.note }}";
                                    $pos1 = strpos($old_str, $find1) + 30;
                                    $newstr = substr_replace($old_str, $str_to_insert, $pos1, 0);
                                    $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'sections/cart-template.liquid', 'value' => $newstr]]]);
                                }
                            } else {
                                Session::flash('error', 'Your Shortcode has been already pasted in the cart template page. If the datepicker section still does not appear, contact us for more support.');
                                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                            }
                        } else {
                            //if cart-template.liquid not available
                            $product_template = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json?asset[key]=templates/cart.liquid&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                            $old_str = $product_template->asset->value;
                            $is_exist = "{% include 'delivery-date' %}";
                            if (strpos($old_str, $is_exist) === false) {
                                $str_to_insert = " {% include 'delivery-date' %} ";
                                $find = "{{ cart.note }}";
                                $pos = strpos($old_str, $find) + 100;
                                $newstr = substr_replace($old_str, $str_to_insert, $pos, 0);
                                if (strpos($old_str, $is_exist) == '') {
                                    Session::flash('error', 'Someting went wrong, Please try manual process.');
                                    return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                                } else {
                                    //api call for creating snippets                 
                                    $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'templates/cart.liquid', 'value' => $newstr]]]);
                                }
                            } else {
                                Session::flash('error', 'Your Shortcode has been already pasted in the cart template page. If the datepicker section still does not appear, contact us for more support.');
                                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                            }
                        }
                    }
                }
            }
            Session::flash('success', 'Your shortcode has been added successfully in cart template page');
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,11);
            Session::flash('error', 'we are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Can you please try manual process.');
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please refresh the page or try after some time.";
            exit();
        }
    }

    /**
     * function fn_create_product_snippet Put shortcode directly in product snippet file
     * @param $request Illuminate\Http\Request
     * @return \Illuminate\Http\Response
     */
    public function fn_create_product_snippet(Request $request) {
        $shop = session('shop') ?? request()->get('shop');
        $this->error_info_array['shop'] = $shop;
        try {
            $obj_shop_detail = ShopModel::whereStoreName($shop)->first();
            $app_version = $obj_shop_detail->app_version;
            $this->error_info_array['shop_info'] = $obj_shop_detail;
            $is_exist = "{% include 'delivery-date' %}";
            $str_to_insert = " {% include 'delivery-date' %} ";
            ## For product page
            if ($app_version > 2 && isset($request->template_id) && $request->template_id == 2) {
                $is_exist = "{% include 'product-delivery-date' %}";
                $str_to_insert = " {% include 'product-delivery-date' %} ";
            }
            $sh = app('ShopifyAPI', ['API_KEY' => $this->app_settings->api_key, 'API_SECRET' => $this->app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $obj_shop_detail->access_token]);
            ## api call for get theme info
            $theme = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes.json?role=main', 'METHOD' => 'GET']);
            if ($theme->themes[0]->role == 'main') {
                $theme_id = $theme->themes[0]->id;
                $theme_data = $sh->call(['URL' => '/admin/themes/' . $theme_id . '/assets.json', 'METHOD' => 'GET']);
                $theme_two_flag = $product_form_flag = $main_product_flag = false;
                if(isset($theme_data->assets)){
                    foreach ($theme_data->assets as $key => $value) {
                        if($value->key == "templates/product.json"){
                            $theme_two_flag = true;
                        }
                        if($value->key == "sections/main-product.liquid"){
                            $main_product_flag = true;
                        }
                        if($value->key == "snippets/product-form.liquid"){
                            $product_form_flag = true;
                        }
                    }
                }
                
                if($theme_two_flag == false){
                    $product_template = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json?asset[key]=sections/product-template.liquid&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                    $old_str = $product_template->asset->value;
                }
                if($theme_two_flag) {
                    //if shopify 2.0
                    if($main_product_flag)
                        $liquid_name = 'sections/main-product.liquid';
                    if($product_form_flag)
                        $liquid_name = 'snippets/product-form.liquid';

                    $main_product = $sh->call(['URL' => '/admin/themes/' . $theme_id . '/assets.json?asset[key]='.$liquid_name.'&theme_id=' . $theme_id, 'METHOD' => 'GET']);
                    $old_str = $main_product->asset->value;
                    $str_to_insert = "{% render 'product-delivery-date' %}";
                    if (strpos($old_str, $str_to_insert) === false) {
                        if($main_product_flag)
                            $find = '<div class="product-form__buttons">';
                        if($product_form_flag)
                            $find = '{%- endform -%}';
                        $pos1 = strpos($old_str, $find) - 1;
                        $newstr = substr_replace($old_str, $str_to_insert, $pos1, 0);
                        $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => $liquid_name, 'value' => $newstr]]]);
                    } else {
                        Session::flash('error', 'Your Shortcode has been already pasted in the cart template page. If the datepicker section still does not appear, contact us for more support.');
                        return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                    }
                }elseif (strpos($old_str, $is_exist) === false) {
                    $find = "{{ product.title }}";
                    if (strpos($old_str, $find) !== false) {
                        //if find string available in liquide file                    
                        $pos = strpos($old_str, $find) + 30;
                        $newstr = substr_replace($old_str, $str_to_insert, $pos, 0);
                        $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'sections/product-template.liquid', 'value' => $newstr]]]);
                    } else {
                        //if find string NOT available in liquide file                    
                        $find1 = "{% if section.settings.product_quantity_enable %}";
                        $pos1 = strpos($old_str, $find1);
                        $newstr = substr_replace($old_str, $str_to_insert, $pos1, 0);
                        $call = $sh->call(['URL' => '/admin/api/'.$this->api_version.'/themes/' . $theme_id . '/assets.json', 'METHOD' => 'PUT', 'DATA' => ['asset' => ['key' => 'sections/product-template.liquid', 'value' => $newstr]]]);
                    }
                } else {
                    Session::flash('error', 'Your Shortcode has been already pasted in the product template page. If the datepicker section still does not appear, contact us for more support.');
                    return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
                }
            } else {
                Session::flash('error', 'Someting went wrong, Please try manual process.');
                return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
            }
            Session::flash('success', 'Your shortcode has been added successfully in product template page');
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
        } catch (Exception $e) {
            $this->fn_send_error_mail($e,10);
            Session::flash('error', 'we are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Can you please try manual process.');
            return redirect()->route('dashboard', ['shop' => $shop])->with(['shop'=>$shop]);
            echo "We are currently facing some technical issues, The technical is looking into it and we should get it fixed ASAP. Please try after some time.";
            exit();
        }
    }

    /**
     * function help For view help page
     * @param $request Illuminate\Http\Request
     * @return view blade file 
     */
    public function help(Request $request) {
        $shop = session('shop') ?? request()->get('shop');
        $obj_shop_detail = ShopModel::whereStoreName($shop)->first();
        $app_version = $obj_shop_detail->app_version;
        return view('help', ['active' => 'order', 'id' => $obj_shop_detail->id, 'app_version' => $app_version, 'shop' => $shop, 'active' => 'help']);
    }

    /**
     * function fn_get_shop_address
     * @param $shop_info
     * @return Return merged shop address
     */
    private function fn_get_shop_address($shop_info){
        try {
            $shop_address = "";
            if($shop_info->shop->address1 != '')
                $shop_address .= $shop_info->shop->address1.', ';

            if($shop_info->shop->city != '')
                $shop_address .= $shop_info->shop->city.', ';

            if($shop_info->shop->province != '')
                $shop_address .= $shop_info->shop->province.' - ';

            if($shop_info->shop->zip != '')
                $shop_address .= $shop_info->shop->zip;

            return $shop_address;   
        } catch (Exception $e) {
            if(isset($request['debug']) && $request['debug'] == true)
                return $e->getMessage();
            return "";
        }
    }

    /**
     * function fn_get_trial_days
     * @param $shop = Shop name
     * @return Trial days
     */
    private function fn_get_trial_days($shop){
        $get_trial_details = TrialInfo::whereStoreName($shop)->first();
        $trial_end_day = $get_trial_details->trial_ends_on;
        $current_date = date("Y-m-d");
        if (strtotime($current_date) < strtotime($trial_end_day)) {
            $date1 = date_create($trial_end_day);
            $date2 = date_create($current_date);
            $trial_remaining = date_diff($date2, $date1);
            return $trial_remaining->format("%a");
        }
        return 0;
    }

    /**
     * function fn_send_error_mail
     * @param $exception = Exception instance, $error_type = type of error like 1,2 etc..
     */
    private function fn_send_error_mail($exception,$error_type){
        $this->error_info_array['error_msg'] = $exception->getMessage();
        $this->error_info_array['error_line_no'] = $exception->getLine();
        $this->error_info_array['error_type'] = $error_type;
        $this->error_info_array['file_path'] = $exception->getFile();
        event(new ErrorOccurredEvent($this->error_info_array));
    }
}