<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App;
use Session;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\ShopModel;
use App\BlockConfig;
use App\FieldConfig;
use Response;
use App\AppSettings;
use Carbon\Carbon;

class OrderController1 extends Controller {
    /* get the orders from the order shopify api */

    public function index(Request $request) {
        // getting shop id

        $shop = session('shop');
        if (empty($shop)) {
            if (isset($_GET['shop'])) {
                $shop = $_GET['shop'];
            } else if (isset($_GET['store'])) {
                $shop = $_GET['store'];
            }
            session(['shop' => $shop]);
        }
        $orders_array = array();
        $todays_orders = 0;
        $weeks_orders = 0;
        $user_email = "";
        $full_name = "";
        $today_delivery_arr = array();
        $store_delivery_date_arr = array();
        $week_delivery_count = 0;
        $shop_details = ShopModel::where('store_name', $shop)->first();
        $app_settings = AppSettings::where('id', 1)->first();
        $shop_id = $shop_details->id;
        $app_version = $shop_details->app_version;
        $setting = [];
        $setting = BlockConfig::where('shop_id', $shop_id)->first();
        $current_date = date('d-m-Y');
        $current_date_format = $setting['date_format'];
        $store_format = $this->getStoreDateFormat($current_date_format);

        $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_details->access_token]);

        // For Calculating todays and this weeks orders
        $todays_date = date("d-m-Y");
        $orders = [];
        $orders = $sh->call(['URL' => 'orders.json?status=any&limit=250', 'METHOD' => 'GET']);
        $all_orders = $orders->orders;

        // to get the current week days     

        $monday = strtotime("last sunday");
        $monday = date('w', $monday) == date('w') ? $monday + 7 * 86400 : $monday;
        $sunday = strtotime(date("d-m-Y", $monday) . " +6 days");
        $this_week_sd = date("d-m-Y", $monday);
        $this_week_ed = date("d-m-Y", $sunday);
        $week_arr = array();
        for ($i = 0; $i < 7; $i++) {
            $week_arr[] = date("d-m-Y", strtotime($this_week_sd . '+' . $i . ' day'));
        }

        // End of this current week days

        foreach ($all_orders as $order) {
            if (!empty($order->note_attributes)) {
                foreach ($order->note_attributes as $atributes) {
                    $attr_arr = array("Shipping-Date", "date", "Delivery-Date");
                    if (in_array($atributes->name, $attr_arr)) {
                        if (strtotime($atributes->value) == '') {
                            $date_string = (string) $atributes->value;
                            $date_final = str_replace("/", "-", $date_string);
                            $delivery_date = $this->getFormatedDate($current_date_format, $date_final);
                        } else {
                            $date_final = $atributes->value;
                            $delivery_date = $this->getFormatedDate($current_date_format, $date_final);
                        }
                        $this->getDeliveryCounts($delivery_date, $this_week_sd, $this_week_ed, $todays_orders, $weeks_orders);
                        $todays_orders = $this->todays_orders;
                        $weeks_orders = $this->weeks_orders;
                        $store_delivery_date_arr[] = $delivery_date;
                    }
                }
            }
        }
        // Today's delivery date count
        $today_delivery_count = '';
        foreach ($store_delivery_date_arr as $store_delivery_date) {
            if ($current_date == $store_delivery_date) {
                $today_delivery_arr[] = $store_delivery_date;
            }
            if (in_array($store_delivery_date, $week_arr)) {
                $week_delivery_count++;
            }
        }

        $today_delivery_count = count($today_delivery_arr);
        // end of today's delivery date count
        //Api call for Order
        $orders = [];
        $count = $sh->call(['URL' => '/admin/orders/count.json?status=any', 'METHOD' => 'GET']);
        $orders_count = (array) $count;
        $order_count = $orders_count['count'];

        $orders = $sh->call(['URL' => 'orders.json?status=any&limit=' . $shop_details->records_per_page . '&page=1', 'METHOD' => 'GET']);
        $fiels_record = FieldConfig::where('shop_id', $shop_id)->first();
        if (count($fiels_record) > 0) {
            $field_data = json_decode($fiels_record->fields);
        } else {
            $field_data = ["0", "16"];
        }
        $this->formatWeekDates($current_date_format, $this_week_sd, $this_week_ed);

        $this_week_sd = $this->this_week_sd;
        $this_week_ed = $this->this_week_ed;

        $data = array(
            'orderlist' => $orders,
            'shop_id' => $shop_id,
            'shop' => $shop,
            'app_version' => $app_version,
            'settings' => $setting,
            'fields' => $field_data,
            'active' => 'order',
            'order_count' => $order_count,
            'page_number' => 1,
            'records_per_page' => $shop_details->records_per_page,
            'weeks_orders' => $weeks_orders,
            'todays_orders' => $todays_orders,
            'todays_date' => $todays_date,
            'start_of_week' => $this_week_sd,
            'end_of_week' => $this_week_ed,
            'today_delivery_count' => $today_delivery_count,
            'week_delivery_count' => $week_delivery_count,
            'store_format' => $store_format
        ); 

        return view('backend.order', $data);
    }

    /* all order export functionality and based on date filter order export csv */

    public function orderExport(Request $request) {

        $shop = session('shop');
        if (empty($shop)) {
            if (isset($_GET['shop'])) {
                $shop = $_GET['shop'];
            } else {
                $shop = $request->input('shop');
            }
            session(['shop' => $shop]);
        }

        $app_settings = AppSettings::where('id', 1)->first();
        $shop_details = ShopModel::where('store_name', $shop)->first();
        $shop_id = $shop_details->id;
        $settings = [];
        $settings = BlockConfig::where('shop_id', $shop_id)->first();

        $sh = App::make('ShopifyAPI', ['API_KEY' => $app_settings->api_key, 'API_SECRET' => $app_settings->shared_secret, 'SHOP_DOMAIN' => $shop, 'ACCESS_TOKEN' => $shop_details->access_token]);
        $orders = [];
        $orders = $sh->call(['URL' => 'orders.json?status=any&limit=250', 'METHOD' => 'GET']);
        $all_orders = $orders->orders;

        $orders_array = array();
        $delivery_time_enabled = $settings->admin_time_status;
        $timestamp_flag = 0;

        $start_date = $request->input('min');
        $end_date = $request->input('max');

        if (empty($start_date) || empty($end_date)) {
            $filename = "Orders.csv";
        } else {
            $filename = "Orders_from_" . $start_date . "_to_" . $end_date . ".csv ";
        }

        $old_order_no = 0;
        $new_order_no = 0;
        $user_email = "";
        $full_name = "";
        $financial_status = "";
        $total = "";

        if ($delivery_time_enabled) {
            $orders_header = array("Order", "Name", "Product Name(Quantity)", "Payment Status", "Total", "Delivery Date", "Delivery Time");
        } else {
            $orders_header = array("Order", "Name", "Product Name(Quantity)", "Payment Status", "Total", "Delivery Date");
        }

        foreach ($all_orders as $order) {
            $time_attribute = "";
            $financial_status = $order->financial_status;
            $total = $order->currency . ' ' . $order->total_price;
            if (is_array($order->note_attributes) && count($order->note_attributes) > 0) {
                foreach ($order->note_attributes as $atributes) {

                    $delivery_time = "-";
                    if ($atributes->name == "Delivery-Date") {

                        if (strtotime($atributes->value) == '') {
                            $date_string = (string) $atributes->value;
                            $date_final = str_replace("/", "-", $date_string);
                            $delivery_date = $this->getExportFormatedDate($request->input('current_format'), $date_final);
                        } else {
                            $date_final = $atributes->value;
                            if ($request->input('current_format') == 'd/m/Y') {
                                $delivery_date = str_replace("/", "-", $date_final);
                            }
                            if ($request->input('current_format') == 'm/d/Y') {
                                $temp_delivery_date = explode("/", $date_final);
                                $delivery_date = $temp_delivery_date[1] . '-' . $temp_delivery_date[0] . '-' . $temp_delivery_date[2];
                            }
                            if ($request->input('current_format') == 'Y/m/d') {
                                $delivery_date = date("d-m-Y", strtotime($date_final));
                            }
                        }
                    }
                    if ($atributes->name == "Delivery-Time") {
                        $time_attribute = $atributes->value;
                    }
                    if ($time_attribute != "" || !(empty($time_attribute))) {
                        $delivery_time = $time_attribute;
                    }
                }
                $full_name = "";
                $user_email = "";
                if (!empty($order->customer)) {
                    $full_name = $order->customer->first_name . " " . $order->customer->last_name;
                    $user_email = $order->email;
                }
                foreach ($order->line_items as $product_name) {
                    if (!$request->input('repeat')) {
                        $new_order_no = $order->order_number;
                        if ($new_order_no == $old_order_no) {
                            $full_name = "";
                            $user_email = "";
                        }
                    }

                    if ($start_date == "" || $end_date == "") {
                        $product_details = $product_name->title . "(" . $product_name->quantity . ")";
                        $order_row = array("#" . $order->order_number, $full_name, $product_details, $financial_status, $total, $delivery_date);
                        if ($delivery_time_enabled) {
                            array_push($order_row, $delivery_time);
                        }

                        array_push($orders_array, $order_row);
                    } else {
                        $this->getFormattedStartEndDates($request->input('current_format'), $start_date, $end_date);
                        $start_date = $this->start_date;
                        $end_date = $this->end_date;

                        $product_delivery_date = "-";
                        $product_delivery_time = "-";
                        foreach ($product_name->properties as $property) {
                            if ($property->name == "Delivery-Date") {
                                $product_delivery_date = $property->value;
                            }
                            if ($property->name == "Delivery-Time") {
                                $product_delivery_time = $property->value;
                            }
                        }

                        if ((strtotime($delivery_date) >= strtotime($start_date)) && (strtotime($delivery_date) <= strtotime($end_date))) {
                            $product_details = $product_name->title . "(" . $product_name->quantity . ")";
                            $order_row = array("#" . $order->order_number, $full_name, $product_details, $financial_status, $total, $delivery_date);
                            if ($delivery_time_enabled) {
                                array_push($order_row, $delivery_time);
                            }
                            array_push($orders_array, $order_row);
                        }
                    }
                    $old_order_no = $new_order_no;
                }
            } else {
                if ($start_date == "" || $end_date == "") {
                    if (empty($order->customer)) {
                        $full_name = "";
                        $user_email = "";
                    } else {
                        $full_name = $order->customer->first_name . " " . $order->customer->last_name;
                        $user_email = $order->email;
                    }
                    foreach ($order->line_items as $product_name) {
                        if (!$request->input('repeat')) {
                            $new_order_no = $order->order_number;
                            if ($new_order_no == $old_order_no) {
                                $full_name = "";
                                $user_email = "";
                            }
                        }
                        array_push($orders_array, array("#" . $order->order_number, $full_name, $product_name->title . "(" . $product_name->quantity . ")", $financial_status, $total, "-", "-"));
                        $old_order_no = $new_order_no;
                    }
                }
            }
        }

        $callback = function() use ($orders_array, $orders_header) {
            $fp = fopen('php://output', 'w');
            fputcsv($fp, $orders_header);
            foreach ($orders_array as $order_row) {
                fputcsv($fp, $order_row);
            }
            fclose($fp);
        };
        $headers = array(
            "Content-type" => "text/csv",
            "Content-Disposition" => "attachment; filename=$filename",
            "Pragma" => "no-cache",
            "Cache-Control" => "must-revalidate, post-check=0, pre-check=0",
            "Expires" => "0"
        );
        return Response::stream($callback, 200, $headers);
    }

    public function getFormatedDate($current_date_format, $date_final) {
        if ($current_date_format == 'dd/mm/yy') {
            $delivery_date = $date_final;
        }
        if ($current_date_format == 'mm/dd/yy') {
            $temp_delivery_date = explode("-", $date_final);
            $delivery_date = $temp_delivery_date[1] . "-" . $temp_delivery_date[0] . "-" . $temp_delivery_date[2];
        }
        if ($current_date_format == 'yy/mm/dd') {
            $delivery_date = date("d-m-Y", strtotime($date_final));
        }
        return $delivery_date;
    }

    public function getExportFormatedDate($current_date_format, $date_final) {

        if ($current_date_format == 'd/m/Y') {
            $delivery_date = $date_final;
        }
        if ($current_date_format == 'm/d/Y') {
            $temp_delivery_date = explode("-", $date_final);
            $delivery_date = $temp_delivery_date[1] . "-" . $temp_delivery_date[0] . "-" . $temp_delivery_date[2];
        }
        if ($current_date_format == 'Y/m/d') {
            $delivery_date = date("d-m-Y", strtotime($date_final));
        }
        return $delivery_date;
    }

    public function formatWeekDates($current_date_format, $this_week_sd, $this_week_ed) {
        $this_week_sd = strtotime($this_week_sd);
        $this_week_ed = strtotime($this_week_ed);
        if ($current_date_format == 'dd/mm/yy') {
            $this_week_sd = date("d/m/Y", $this_week_sd);
            $this_week_ed = date("d/m/Y", $this_week_ed);
        }
        if ($current_date_format == 'mm/dd/yy') {
            $this_week_sd = date("d/m/Y", $this_week_sd);
            $this_week_ed = date("d/m/Y", $this_week_ed);
        }
        if ($current_date_format == 'yy/mm/dd') {
            $this_week_sd = date("Y/m/d", $this_week_sd);
            $this_week_ed = date("Y/m/d", $this_week_ed);
        }
        $this->this_week_sd = $this_week_sd;
        $this->this_week_ed = $this_week_ed;
    }

    public function getFormattedStartEndDates($current_date_format, $start_date, $end_date) {
        if ($current_date_format == 'd/m/Y') {
            $start_date = str_replace("/", "-", $start_date);
            $end_date = str_replace("/", "-", $end_date);
        }
        if ($current_date_format == 'm/d/Y') {
            $temp_start_date = explode("/", $start_date);
            $temp_end_date = explode("/", $end_date);
            $start_date = $temp_start_date[1] . "-" . $temp_start_date[0] . "-" . $temp_start_date[2];
            $end_date = $temp_end_date[1] . "-" . $temp_end_date[0] . "-" . $temp_end_date[2];
        }
        if ($current_date_format == 'Y/m/d') {
            $start_date = date("d-m-Y", strtotime($start_date));
            $end_date = date("d-m-Y", strtotime($end_date));
        }
        $this->start_date = $start_date;
        $this->end_date = $end_date;
    }

    public function getDeliveryCounts($delivery_date, $this_week_sd, $this_week_ed, $todays_orders, $weeks_orders) {
        //get todays delivery count
        if (strtotime($delivery_date) == strtotime(date('d-m-Y'))) {
            ++$todays_orders;
        }
        //get this week delivery count
        if (strtotime($delivery_date) >= strtotime($this_week_sd) && strtotime($delivery_date) <= strtotime($this_week_ed)) {
            $weeks_orders++;
        }
        $this->todays_orders = $todays_orders;
        $this->weeks_orders = $weeks_orders;
    }

    public function getStoreDateFormat($date_format) {
        if ($date_format == "mm/dd/yy") {
            $store_format = "m/d/Y";
        } else if ($date_format == "yy/mm/dd") {
            $store_format = "Y/m/d";
        } else if ($date_format == "dd/mm/yy") {
            $store_format = "d/m/Y";
        }
        return $store_format;
    }

}
