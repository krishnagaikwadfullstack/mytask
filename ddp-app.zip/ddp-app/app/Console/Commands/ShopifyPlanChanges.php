<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App;
use DB;
use App\ShopModel;
use App\TrialInfo;
use App\AppSettings;
use App\StoreInformation;
use App\Events\WebhookProcessedEvent;
use App\Events\PlanChangeCronProcessedEvent;

class ShopifyPlanChanges extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'plan:day';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send email to store owner and support when store is live';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $api_version = getenv('API_VERSION');
        $sh = App::make('ShopifyAPI');
        $getAppSettings = AppSettings::where('id', 1)->first();

        $date = date_create(date('Y-m-d'));
        $lastday = date_sub($date,date_interval_create_from_date_string("1 days"));
        $lastday = $lastday->format('Y-m-d');
		$start = date('Y-m-d 01:31:00', strtotime($lastday));
        $end = date('Y-m-d 01:29:59');

        //$getStoreDetails = StoreInformation::where('store_plan_name', 'partner_test')->get();
		$getStoreDetails = StoreInformation::join('usersettings', 'store_information.shop_id', '=', 'usersettings.id')
    				   ->select('store_information.*','usersettings.*')
    				   ->whereBetween('plan_update_date', [$start, $end])
    				   // ->where('store_plan_name', 'affiliate')
    				   ->get();
        //for loop for fetching store plan
        $new_trial_days = '';
        try {
        	if(count($getStoreDetails) > 0){
		        foreach ($getStoreDetails as $key => $store_information) {

		        	$sh = App::make('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $store_information->store_name, 'ACCESS_TOKEN' => $store_information->access_token]);
		        	//gettin shop info using api
		        	$shopifyInfo = $sh->call(['URL' => '/admin/api/'.$api_version.'/shop.json', 'METHOD' => 'GET']);
		        	$shop_address = $this->getShopAddress($shopifyInfo);

		        	//checking trail days
	                $trialDays = getenv('TRIAL_DAYS');
	                $getTrialDetails = TrialInfo::where('store_name', $store_information->store_name)->first();

	                if (!is_null($getTrialDetails)) {
	                    $total_trial_days = $getTrialDetails->trial_days;
	                    $trial_activated_date = $getTrialDetails->activated_on;
	                    $trial_over_date = $getTrialDetails->trial_ends_on;
	                    $current_date = date("Y-m-d");
	                    if (strtotime($current_date) < strtotime($trial_over_date)) {
	                        $date1 = date_create($trial_over_date);
	                        $date2 = date_create($current_date);
	                        $trial_remain = date_diff($date2, $date1);
	                        $new_trial_days = $trial_remain->format("%a");
	                    } else {
	                        $new_trial_days = 0;
	                    }
	                }
	                //checking app price
	                if($store_information->app_version == 1){
	                	$price = 7.99;
	                }elseif ($store_information->app_version == 2) {
	                	$price = 10.99;
	                }elseif ($store_information->app_version == 3) {
	                	$price = 14.99;
	                }elseif ($store_information->app_version == 4) {
	                	$price = 15.99;
	                }
	                // dd($store_information,$price);
	                
	                //checking store is active... app is on trial period and app version advance
	                if (($shopifyInfo->shop->plan_name != 'affiliate' && $shopifyInfo->shop->plan_name != 'partner_test' && $shopifyInfo->shop->plan_name != 'Developer Preview')) {
	                	//update store information when store plan is change
		        			StoreInformation::where('id', $store_information->id)->update([
		                            'shop_id' => $store_information->id, 
		                            'store_information_id' => $shopifyInfo->shop->id, 
		                            'store_name' => $shopifyInfo->shop->name, 
		                            'store_email' => $shopifyInfo->shop->email, 
		                            'store_domain' => $shopifyInfo->shop->domain, 
		                            'store_address'=> $shop_address, 
		                            'store_phone'=> $shopifyInfo->shop->phone,
		                            'store_created'=> date('Y-m-d H:i:s', strtotime($shopifyInfo->shop->created_at)),
		                            'store_updated'=> date('Y-m-d H:i:s', strtotime($shopifyInfo->shop->updated_at)), 
		                            'store_country_name'=> $shopifyInfo->shop->country_name, 
		                            'store_currency'=> $shopifyInfo->shop->currency, 
		                            'store_owner' => $shopifyInfo->shop->shop_owner, 
		                            'store_plan_name'=> $shopifyInfo->shop->plan_name 
		                    ]);
		                    
		                    //creating the Recurring charge for app
		                    $url = 'https://' . $store_information->store_name . '/admin/recurring_application_charges.json';
		                    $charge = $sh->call([
			                    	        'URL' => $url,
			                    	        'METHOD' => 'POST',
			                    	        'DATA' => array(
			                    	            'recurring_application_charge' => array(
			                    	                'name' => 'Delivery Date Pro',
			                    	                'price' => $price,
			                    	                'return_url' => url('payment_success'),
			                    	                // "capped_amount" => 30,
			                    	                // "terms" => "Additional charges as per the plan",
			                    	                //'test' => true,
			                    	                'trial_days' => $new_trial_days
			                    	            )
			                    	        )
		                    	        ], false);
		                    //update charge data in usersetting table
		                    $updateShopData = array(
		                    	    'charge_id' => (string) $charge->recurring_application_charge->id,
		                    	    'api_client_id' => $charge->recurring_application_charge->api_client_id,
		                    	    'price' => $charge->recurring_application_charge->price,
		                    	    'status' => $charge->recurring_application_charge->status,
		                    	    'billing_on' => $charge->recurring_application_charge->billing_on,
		                    	    'payment_created_at' => $charge->recurring_application_charge->created_at,
		                    	    'activated_on' => $charge->recurring_application_charge->activated_on,
		                    	    'trial_ends_on' => $charge->recurring_application_charge->trial_ends_on,
		                    	    'cancelled_on' => $charge->recurring_application_charge->cancelled_on,
		                    	    'trial_days' => $charge->recurring_application_charge->trial_days,
		                    	    'decorated_return_url' => $charge->recurring_application_charge->decorated_return_url,
		                    	    'confirmation_url' => $charge->recurring_application_charge->confirmation_url,
		                    	    'domain' => $store_information->store_name
		                    	);
		                    ShopModel::where('store_name', $store_information->store_name)->update($updateShopData);
		                    $shop_info = ShopModel::where('store_name', $store_information->store_name)->first();
		                    //send email notification to store owner and support
		                   	event(new PlanChangeCronProcessedEvent($shop_info));
		                   	$this->info('Email send to the store owner and support team');
	                }
		        }
		    }	
        } catch (Exception $e) {
        	event(new WebhookProcessedEvent(['message'=>'Shopify plan change Cron run error occurred']));
        }
	    event(new WebhookProcessedEvent(['message'=>'Shopify plan change Cron run successfully']));
    }

    public function getShopAddress($shop_info){
        $shop_address = "";

        if($shop_info->shop->address1 != ''){
            $shop_address .= $shop_info->shop->address1.', ';
        }
        if($shop_info->shop->city != ''){
            $shop_address .= $shop_info->shop->city.', ';
        }
        if($shop_info->shop->province != ''){
            $shop_address .= $shop_info->shop->province.' - ';
        }
        if($shop_info->shop->city != ''){
            $shop_address .= $shop_info->shop->zip;
        }
        return $shop_address;
    }
}
