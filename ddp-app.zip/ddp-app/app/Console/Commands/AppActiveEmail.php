<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App;
use Carbon\Carbon;
use App\ShopModel;
use App\TrialInfo;
use App\AppSettings;
use App\StoreInformation;

class AppActiveEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'active:day';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send email to store owner if the plan is not active for our app';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->api_version = getenv('API_VERSION');
        $sh = App::make('ShopifyAPI');
        $getAppSettings = AppSettings::where('id', 1)->first();
        //get 7 days plan updated record
        $getStoreDetails = StoreInformation::whereDate('updated_at', Carbon::now()->subDays(6))->get();
        if(count($getStoreDetails) > 0){
            foreach ($getStoreDetails as $key => $store_information) {
                $getShopDetails = ShopModel::whereStoreName($store_information->store_domain)->first();
                //check store charges status if pending send email to store owner
                if($getShopDetails->status == 'pending'){

                    //send email notification to store owner and support
                    $headers = 'MIME-Version: 1.0' . "\r\n";
                    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                    $subject = "Plan Confirmation";
                    $sender = "support@zestard.com";
                    $sender_name = "Zestard Technologies";
                    $app_name = "Delivery Date Pro";
                    $logo = config('app.url') . 'public/image/zestard-logo.png';
                    $store_owner_msg = '<html>
                                        <head>
                                            <meta name="viewport" content="width=device-width, initial-scale=1">
                                            <style>
                                                @import url("https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i");
                                                @media only screen and (max-width:599px) {
                                                    table {
                                                        width: 100% !important;
                                                    }
                                                }
                                                @media only screen and (max-width:412px) {
                                                    h2 {
                                                        font-size: 20px;
                                                    }
                                                    p {
                                                        font-size: 13px;
                                                    }
                                                    .easy-donation-icon img {
                                                        width: 120px;
                                                    }
                                                }
                                            </style>
                                        </head>
                                        
                                        <body style="background: #f4f4f4; padding-top: 57px; padding-bottom: 57px;">
                                            <table class="main" border="0" cellspacing="0" cellpadding="0" width="600px" align="center" style="border: 1px solid #e6e6e6; background:#fff; ">
                                                <tbody>
                                                    <tr>
                                                        <td style="padding: 30px 30px 10px 30px;" class="review-content">
                                                            <p class="text-align:left;"><img src="' . $logo . '" alt=""></p>
                                                            <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px; line-height: 25px; margin-top: 0px;"><b>Hi ' . $store_information->store_owner . '</b>,</p>
                                                            <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">The '.$app_name.' plan is not active for our app.</p>
                                                            <p style="font-family: \'Helvetica\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 25px;margin-top: 0px;">Please pay the charges for further '.$app_name.' app uses.</p>
                                        
                                                        </td>
                                                    </tr>
                                        
                                                    <tr>
                                                        <td style="padding: 20px 30px 30px 30px;">
                                        
                                                            <br>
                                                            <p style="font-family: \'Open Sans\', sans-serif;font-size: 15px;color: dimgrey;margin-bottom: 13px;line-height: 26px; margin-bottom:0px;">Thank you,<br>Zestard Support</p>
                                                        </td>
                                                    </tr>
                                        
                                                </tbody>
                                            </table>
                                        </body>';
                    $receiver = $store_information->store_email;
                    mail('kamlesh.zestard@gmail.com', "Plan Confirmation", $store_owner_msg, $headers);
                    $this->info('Email send to the store owner');
                }
            }
        }
    }
}
