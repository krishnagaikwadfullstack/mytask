<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App;
use Carbon\Carbon;
use App\ShopModel;
use App\TrialInfo;
use App\AppSettings;
use App\StoreInformation;
use App\Events\FiveDayCronProcessedEvent;
use App\Events\WebhookProcessedEvent;

class FiveDayChargesConfirmationEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'five:day';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send email to store owner if the plan is not active for our app';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        try {
            //get 5 days plan updated record
            $getStoreDetails = StoreInformation::where('plan_update_date', '<=', Carbon::now()->subDays(5)->toDateTimeString())->whereHas('fn_shop_information',function($q){
                  $q->where('status','pending');
                })->get();
            if(count($getStoreDetails)){
                foreach ($getStoreDetails as $key => $store_information) {
                    $to = \Carbon\Carbon::createFromFormat('Y-m-d H:s:i', Carbon::now());
                    $from = \Carbon\Carbon::createFromFormat('Y-m-d H:s:i', $store_information->plan_update_date);
                    $diff_in_days = $to->diffInDays($from);
                    if($diff_in_days == 5){
                        event(new FiveDayCronProcessedEvent($store_information,1));
                    }else{
                        event(new FiveDayCronProcessedEvent($store_information,2));
                    }
                }
                $this->info('Email send to the store owner');
            }
        } catch (Exception $e) {
            dd($e);
            event(new WebhookProcessedEvent(['message'=>'Error occured in FiveDayChargesConfirmationEmail Command. File Path-'.$e->getFile().' Error-'.$e->getMessage().' At line-'.$e->getLine()]));
        }
    }
}
