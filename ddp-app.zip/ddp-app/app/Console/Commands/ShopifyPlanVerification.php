<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App;
use DB;
use Exception;
use App\ShopModel;
use App\TrialInfo;
use App\AppSettings;
use App\StoreInformation;
use App\Events\WebhookProcessedEvent;
use App\Events\PlanVerificationCronProcessedEvent;
use App\Events\TestChargeUpdateEvent;
use App\Events\TestPlanLiveStoreEvent;
use Carbon\Carbon;

class ShopifyPlanVerification extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'plan:verification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send email to support how many stores having test plan';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        try {
            $arrZestardStores = explode(',', env('SHOPIFY_STORE_NAME'));
            $arrDevlopmentPlans = ['partner_test','Developer Preview','affiliate'];

            ## Get all stores
            $arrAllStores = ShopModel::where(function($query) use($arrZestardStores){
                return $query
                ->where('charge_update_flag',1)
                ->whereNotIn('store_name',$arrZestardStores);
            })->get();

            ## Get how many stores moved from development plan to live plan.
            $arrDevlopmentToLiveStores = $arrAllStores->filter(function ($item) {
                return (!is_null($item->store_information) && !is_null($item->store_information->plan_update_date));
            });

            ## Get test plan all stores
            $arrTestPlanStores = $arrAllStores->filter(function ($item) use($arrDevlopmentPlans){
                // return ($item->price == '0.01');
                return (in_array($item->plan_name,$arrDevlopmentPlans));
            });

            ## Get how many live store having test charge plan.
            $arrTestPlanLiveStores = $arrAllStores->filter(function ($item) use($arrDevlopmentPlans){
                return ($item->price == '0.01' && $item->trial_ends_on < Carbon::now()->format('Y-m-d') && !in_array($item->plan_name,$arrDevlopmentPlans));
            });
        
            ## Send mail to admin how many store moved from demo to live & how many store has test plan
            if(count($arrDevlopmentToLiveStores) > 0 || count($arrTestPlanStores) > 0){
                event(new PlanVerificationCronProcessedEvent($arrTestPlanStores,$arrDevlopmentToLiveStores));
            }

        } catch (Exception $e) {
            event(new WebhookProcessedEvent(['message'=>'Shopify plan verification Cron run error occurred']));
        }

        try {
            $api_version = getenv('API_VERSION');
            $sh = App::make('ShopifyAPI');
            $getAppSettings = AppSettings::where('id', 1)->first();
            ## Send mail to admin and update test charge id.
            if(count($arrTestPlanLiveStores) > 0){
                event(new TestPlanLiveStoreEvent($arrTestPlanLiveStores));
            }
            ## Send email to client after for updating recurring charges as per current plan
            if(count($arrAllStores) > 0){
                foreach ($arrAllStores as $key => $objShopInfo) {
                    try{
                        $sh = App::make('ShopifyAPI', ['API_KEY' => $getAppSettings->api_key, 'API_SECRET' => $getAppSettings->shared_secret, 'SHOP_DOMAIN' => $objShopInfo->store_name, 'ACCESS_TOKEN' => $objShopInfo->access_token]);

                        ##Check already recurring application charges created using api
                        $url = 'admin/api/'.$api_version.'/recurring_application_charges/' . $objShopInfo->charge_id . '.json';
                        $charge = $sh->call(['URL' => $url, 'METHOD' => 'GET']);
                        $arrPrice = ['1' => 7.99, '2' => 10.99, '3' => 14.99, '4' => 15.99];

                        ## If current charge price as per current app version or test charge then skip
                        if(!empty($charge) && ($charge->recurring_application_charge->price == $arrPrice[$objShopInfo->app_version] /*|| is_null($charge->recurring_application_charge->test) || in_array($objShopInfo->plan_name, $arrDevlopmentPlans) */)){
                            continue;
                        }
                        $objShopInfo->update(['charge_update_flag' => 2]);
                        ##send email notification to store owner and support
                        event(new TestChargeUpdateEvent($objShopInfo));
                    } catch (Exception $e) {
                        continue;
                    }
                }
            }
            $this->info('Email send to the support team');
        } catch (Exception $e) {
            event(new WebhookProcessedEvent(['message'=>'Shopify plan verification Cron run update charge_update_flag update error occurred']));
        }
    }

    /**
     * Function getShopAddress
     */
    public function getShopAddress($shop_info){
        $shop_address = "";

        if($shop_info->shop->address1 != ''){
            $shop_address .= $shop_info->shop->address1.', ';
        }
        if($shop_info->shop->city != ''){
            $shop_address .= $shop_info->shop->city.', ';
        }
        if($shop_info->shop->province != ''){
            $shop_address .= $shop_info->shop->province.' - ';
        }
        if($shop_info->shop->city != ''){
            $shop_address .= $shop_info->shop->zip;
        }
        return $shop_address;
    }
}
