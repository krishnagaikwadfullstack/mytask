<?php
return [
	'arr_error_msg'=> [
		'1'	=>	'This is to notify that error occurred in index method while installing app.',
		'2'	=>	'This is to notify that error occurred in redirect method while storing store information.',
		'3'	=>	'This is to notify that error occurred in redirect method while calling webook.',
		'4'	=>	'This is to notify that error occurred in redirect method while creatig recurring charges for app.',
		'5'	=>	'This is to notify that error occurred in redirect method while saving store information.',
		'6'	=>	'This is to notify that error occurred in redirect method while installing app.',
		'7'	=>	'This is to notify that error occurred in payment_method method while making app payment.',
		'8'	=>	'This is to notify that error occurred in paymentComplete method while storing payment information.',
		'9'	=>	'This is to notify that error occurred in updatePlan method while updating app plan.',
		'10'	=>	'This is to notify that error occurred in SnippetCreateProduct method while adding product snippets.',
		'11'	=>	'This is to notify that error occurred in SnippetCreateCart method while adding cart snippets.',
		'12'	=>	'This is to notify that error occurred in upgrade_to_ultimate method while upgrading app plan.',
		'13'	=>	'This is to notify that error occurred in basic method while selecting basic app plan.',
		'14'	=>	'This is to notify that error occurred in index method while calling shopify api.',
		'15'	=>	'This is to notify that error occurred in index method while calling shopify charge api and updating shop data.',
		'16'	=>	'This is to notify that error occurred in updateCharge method while creating new recurring application charge.',
	]
];

?>