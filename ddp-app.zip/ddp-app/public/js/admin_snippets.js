//Global Variable Declarations
var base_path_delivery_date = "https://shopifydev.anujdalal.com/DeliveryDateProAppBridge/public/";
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var cutoff_hours, cutoff_minute, store_hour, store_minute, datepicker_default_date, deliverytime_global_status, app_version, type_of_app, cutoff_global_status, cutoff_status, cutoff_global_hours, cutoff_global_minute, start_from, is_time_required, is_date_required, time_array, time_count, deliverytime_response, cutoff_response, date_formate, add_delivery_information, order_note, locale, date_error_message, store_date, delivery_date_array, formatted_delivery_date, selected_delivery_date, datepicker_on_default, textarea_variable, original_start_from, time_error_message, disable_checkout;
var xhttp, data_length;
// var shop_name = Shopify.shop;
function calcTime(city, offset) {
    console.log(nd)
    console.log(nd.getHours());
    console.log(nd.getMinutes());
    // return time as a string
    return "The local time in " + city + " is " + nd.toLocaleString();
}
var store_timezone = 0;
var store_hour = ''
var store_minute = ''

//document.getElementsByName("checkout").disabled = true;
var $kanaoddp_custom_jq = "";
$kanaoddp_custom_jq = window.jQuery;
$kanaoddp_custom_jq.ajax({
    url: base_path_delivery_date + "getconfig",
    dataType: "json",
    async: false,
    data: {
        shop: shop_name
    },
    success: function(data) {
        locale = data[0].language_locale;
    }
});
if (locale == "en") {
    $kanaoddp_custom_jq = window.jQuery;
    //Calling Delivery Date Function
    // deliveryDatePro();
} else {
    var el = document.getElementById('datepicker_box'),
        elChild = document.createElement('div');
    elChild.id = 'datepicker_box_jquery';
    el.insertBefore(elChild, el.firstChild);
    jscript = document.createElement("script");
    jscript.src = base_path_delivery_date + "js/localjs/datepicker-" + locale + ".js";
    jscript.type = 'text/javascript';
    jscript.async = false;
    var el = document.getElementById('datepicker_box'),
        elChild = document.createElement('div');
    elChild.id = 'datepicker_locale_jquery';
    el.insertBefore(elChild, el.firstChild);
    el.appendChild(elChild);
    document.getElementById('datepicker_box_jquery').appendChild(jscript);
    jscript.onload = function() {
        $kanaoddp_custom_jq = window.jQuery;
        //Calling Delivery Date Function
        // deliveryDatePro();
    }
}


function deliveryDatePro() {
    store_timezone_offset = new Date().getTimezoneOffset();
    if(typeof store_timezone_offset !== 'undefined'){
        d = new Date();
        utc = d.getTime() + (d.getTimezoneOffset() * 60000);
        nd = new Date(utc + (3600000*store_timezone_offset));
        store_timezone = 1;
        store_hour = nd.getHours();
        store_minute = nd.getMinutes();
    }
    // $(".visible_datepicker").datepicker('destroy');
    // $("#delivery-date-pro").datepicker('destroy');
    // $kanaoddp_custom_jq(".visible_datepicker").remove();
// console.log(date_format,allowed_month,locale,datepicker_on_default,add_delivery_information,date_error_message,time_error_message,require_option,datepicker_label,show_datepicker_label)
    store_date = $kanaoddp_custom_jq("#ztpl-date-format-ddmmyy").val();
    $kanaoddp_custom_jq("#delivery-date-pro").val("");
    $kanaoddp_custom_jq.ajax({
        url: base_path_delivery_date + "get-type-and-version",
        async: false,
        data: { shop_name: shop_name },
        success: function(result) {
            data_length = result;
            if (data_length != 0) {
                app_version = result[0].app_version;
                type_of_app = result[0].type_of_app;
            } 
        }
    });
    var app_status = $('#checkboxID0').is(":visible") ? $('#checkboxID0').is(":checked") : data_length
    console.log($('#checkboxID0').is(":checked"),'app status',data_length,$('#checkboxID0').is(":visible"))
    if (app_status) {
        $('.additional-css').show();
        var unavailableDates = [];
        var unavailableDays = [];
        start_from = '';
        var allowed_month = '';
        date_formate = '';
        is_date_required = false;
        is_time_required = false;
        $kanaoddp_custom_jq.ajax({
            url: base_path_delivery_date + "getconfig",
            dataType: "json",
            async: false,
            data: {
                shop: shop_name
            },
            success: function(data) {
                app_status = data[0].app_status;
                locale = data[0].language_locale = ($('[name="language_locale"]').is(':visible') ? $('[name="language_locale"] option:selected').val() : data[0].language_locale);
                datepicker_on_default = data[0].datepicker_display_on = ($('#checkboxID8').is(":visible") ? ($('#checkboxID8').is(":checked") ? 1 : 0) : data[0].datepicker_display_on);
                datepicker_default_date = data[0].default_date_option = ($('#checkboxID9').is(":visible") ? ($('#checkboxID9').is(":checked") ? 1 : 0) : data[0].default_date_option);
                // datepicker_default_date = data[0].default_date_option;
                add_delivery_information = data[0].add_delivery_information = ($('#checkboxID10').is(":visible") ? ($('#checkboxID10').is(":checked") ? 1 : 0) : data[0].add_delivery_information);
                date_error_message = data[0].date_error_message =  $('#date_error_message').val();
                time_error_message = data[0].time_error_message = $('#time_error_message').val();

                if (app_status == "Deactive") {
                    $kanaoddp_custom_jq("input[name=checkout]").css('pointer-events', "auto");
                    $kanaoddp_custom_jq("button[name=checkout]").css('pointer-events', "auto");
                    $kanaoddp_custom_jq("#datepicker_box").remove();
                }
                var require_option = $('#checkboxID1').is(":checked") ? 1 : 0;
                if (require_option == 1) {
                    is_date_required = true;
                    $kanaoddp_custom_jq("#delivery-date-pro").attr("required", "true");
                    $kanaoddp_custom_jq("#delivery-date-pro").closest("form").removeAttr('novalidate');
                }

                var date_label = data[0].datepicker_label = ($('#datepicker_label').is(':visible') ? $('#datepicker_label').val() : data[0].datepicker_label);
                show_datepicker_label = data[0].show_datepicker_label = ($('#checkboxID6').is(":visible") ? ($('#checkboxID6').is(":checked") ? 1 : 0) : data[0].show_datepicker_label);
                
                if (show_datepicker_label == 1) {
                    $kanaoddp_custom_jq('.date-box label').text(date_label).show();
                } else {
                    $kanaoddp_custom_jq('.date-box label').hide();
                }
                //For dates
                var empty_block_date = false;
                var dates = data[0].block_date = ($('#checkboxID0').is(':visible') ? JSON.stringify($.map($('[name="blockdate[]"]').toArray().map(item => item.value), function( val, i ) {
                    if(val == ''){
                        empty_block_date = true;
                    }
                    var date_array = val.split("/");
                    // if(date_array[0].length == 4){
                    //     return date_array[2] +"-"+ date_array[1] + "-"+ date_array[0];
                    // }
                    if ($('[name="date_format"] option:selected').val() == "mm/dd/yy") {
                        return date_array[1] +"-"+ date_array[0] + "-"+ date_array[2];
                    }

                    if ($('[name="date_format"] option:selected').val() == "yy/mm/dd") {
                        return date_array[2] +"-"+ date_array[1] + "-"+ date_array[0];
                    }

                    if ($('[name="date_format"] option:selected').val() == "dd/mm/yy") {
                        return date_array[0] +"-"+ date_array[1] + "-"+ date_array[2];
                    }
                })): data[0].block_date);
                
                if(empty_block_date){
                    dates = JSON.stringify([]);
                }

                // For days
                var day = data[0].days = ($('[name="days[]"]').is(':visible') ? JSON.stringify($('[name="days[]"] option:selected').toArray().map(item => item.value)) : data[0].days);
                data[0].date_interval = ($('input[name=intervel]').is(':visible') ? $('input[name=intervel]').val() : data[0].date_interval);
                start_from = '+' + data[0].date_interval;
                
                data[0].alloved_month = ($('input[name=allowed_month]').is(':visible') ? $('input[name=allowed_month]').val() : data[0].alloved_month);
                allowed_month = '+' + data[0].alloved_month + 'M';
                unavailableDates = $kanaoddp_custom_jq.parseJSON(dates);
                unavailableDays = $kanaoddp_custom_jq.parseJSON(day);
                
                console.log('dates',dates,unavailableDates);
                data[0].date_format = ($('[name="date_format"]').is(':visible') ? $('[name="date_format"] option:selected').val() : data[0].date_format);
                date_formate = data[0].date_format;
                cutoff_status = data[0].cuttoff_status = ($('#checkboxID11').is(":visible") ? ($('#checkboxID11').is(":checked") ? 1 : 0) : data[0].cuttoff_status);
                cutoff_global_status = data[0].cutoff_global_status = ($('#global_cutoff_time').is(":visible") ? ($('#global_cutoff_time').is(":checked") ? 1 : 0) :data[0].cutoff_global_status);
                deliverytime_global_status = data[0].deliverytime_global_status = ($('#global_delivery_time').is(":visible") ? ($('#global_delivery_time').is(":checked") ? 1 : 0) : data[0].deliverytime_global_status);
                cutoff_global_hours = data[0].hours = ($('[name="hours"]').is(':visible') ? $('[name="hours"] option:selected').val() : data[0].hours);
                cutoff_global_minute = data[0].minute = ($('[name="minute"]').is(':visible') ? $('[name="minute"] option:selected').val() : data[0].minute);
                data[0].exclude_block_date_status = ($('#checkboxID12').is(":visible") ? ($('#checkboxID12').is(":checked") ? 1 : 0) : data[0].exclude_block_date_status);
                var current_date = $kanaoddp_custom_jq("#ztpl-current-date").val();
                if(store_hour == '' || isNaN(store_hour) ){
                    store_hour = $kanaoddp_custom_jq("#ztpl-store-hour").val();
                }
                if(store_minute == '' || isNaN(store_minute)){
                    store_minute = $kanaoddp_custom_jq("#ztpl-store-minute").val();
                }
                
                if (date_formate == "mm/dd/yy") {
                    var display_format = "(mm/dd/yyyy)";
                } else if (date_formate == "yy/mm/dd") {
                    var display_format = "(yyyy/mm/dd)";
                } else if (date_formate == "dd/mm/yy") {
                    var display_format = "(dd/mm/yyyy)";
                } else {
                    var display_format = "(mm/dd/yyyy)";
                }

                var show_date_format = data[0].show_date_format = ($('#checkboxID2').is(":visible") ? ($('#checkboxID2').is(":checked") ? 1 : 0) : data[0].show_date_format);
                if (show_date_format == 1) {
                    if (display_format != "") {
                        $kanaoddp_custom_jq("#selected_format").text(display_format);
                    } else {
                        $kanaoddp_custom_jq("#selected_format").text('mm/dd/yyyy');
                    }
                }else{
                    $kanaoddp_custom_jq("#selected_format").text('');
                }
                var admin_note_status = data[0].admin_note_status = ($('#checkboxID3').is(":visible") ? ($('#checkboxID3').is(":checked") ? 1 : 0) : data[0].admin_note_status);
                var notes_admin = data[0].admin_order_note = $('#admin_order_note').val();
                if (admin_note_status == 1) {
                    $kanaoddp_custom_jq("#admin_notes").html($kanaoddp_custom_jq.parseHTML(notes_admin)).show();
                }else{
                    $kanaoddp_custom_jq("#admin_notes").hide();
                }

                var admin_time_status = data[0].admin_time_status = ($('#checkboxID5').is(":visible") ? ($('#checkboxID5').is(":checked") ? 1 : 0) : data[0].admin_time_status);
                var time_lable = data[0].time_label = ($('input[name=time_label]').is(':visible') ? $('input[name=time_label]').val() : data[0].time_label);
                var default_option_label = data[0].time_default_option_label  = ($('input[name=time_default_option_label]').is(':visible') ? $('input[name=time_default_option_label]').val() : data[0].time_default_option_label);
                if (admin_time_status == 1) {
                    var time_in_text = data[0].delivery_time = ($('#delivery_time').is(':visible') ? $('#delivery_time').val() : data[0].delivery_time);
                    time_array = new Array();
                    time_array = time_in_text.split(",");
                    time_count = 0;
                    //$kanaoddp_custom_jq("#delivery-time").show();
                    $kanaoddp_custom_jq("#delivery-time").css('display', 'block');
                    //document.getElementById("delivery-time").style.display = "block";
                    $kanaoddp_custom_jq("#delivery-time").css('border', 'none');
                    $kanaoddp_custom_jq("#time_option_label").text(default_option_label);
                    $kanaoddp_custom_jq('#delivery-time option[value!=""]').remove();
                    if (app_version <= 2 && type_of_app <= 2) {
                        $kanaoddp_custom_jq(time_array).each(function() {
                            $kanaoddp_custom_jq('#delivery-time').append("<option value='" + time_array[time_count] + "'" + ">" + time_array[time_count] + "</option>");
                            time_count++;
                        });
                    }
                    $kanaoddp_custom_jq("#delivery-time-label").show();
                    $kanaoddp_custom_jq("#delivery-time-label").text(time_lable);
                    if (data[0].time_require_option == 1) {
                        is_time_required = true;
                        $kanaoddp_custom_jq("#delivery-time").attr("required", "true");
                        $kanaoddp_custom_jq("#delivery-date-pro").closest("form").removeAttr('novalidate');
                    }
                }else{
                    $kanaoddp_custom_jq('#delivery-time').hide();
                }
                var additional_css = data[0].additional_css = ($('input[name=additional_css').is(':visible') ? $('input[name=additional_css').val() : data[0].additional_css);
                // if (shop_name == "balance80.myshopify.com") {
                //     $kanaoddp_custom_jq('.datepicker_wrapper_box').css("cssText", "display: inline-block;background: #f5f5f5;padding: 20px 30px;color:black !important;font-weight:700;");
                // } else {
                    // $kanaoddp_custom_jq('#datepicker_box').after("<style>" + additional_css + "</style>");
                // }
                //Change Variable Name
                var str = parseInt(data[0].date_interval);
                if (parseInt(cutoff_status) == 0) {} else {
                    //Check App Version if it is 3(i.e Enterprise) or more then it will Exceute Following Code For Multiple Cut Off and Delivery Time  
                    if (app_version > 2 && type_of_app > 2) {
                        console.log('cutoff_global_status',cutoff_global_status)
                        if (cutoff_global_status == 1) {
                            cutoff_hours = cutoff_global_hours;
                            cutoff_minute = cutoff_global_minute;

                            if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                                if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                    str = parseInt(data[0].date_interval);
                                } else {
                                    if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                        str = parseInt(data[0].date_interval);
                                    } else {
                                        str = parseInt(data[0].date_interval) + 1;
                                    }
                                }
                            } else {
                                str = parseInt(data[0].date_interval) + 1;
                            }
                        } else {
                            var c_day = new Date().getDay();
                            $kanaoddp_custom_jq.ajax({
                                url: base_path_delivery_date + "get-cutoff-time",
                                data: { day: c_day, shop_name: shop_name },
                                async: false,
                                success: function(response) {
                                    var json_data = JSON.parse(response);
                                    cutoff_hours = $("[data-day='"+ c_day +"'].cutoff_hour").is(':visible') ? $("[data-day='"+ c_day +"'].cutoff_hour option:selected").val() : json_data['cutoff_hour'];
                                    cutoff_minute = $("[data-day='"+ c_day +"'].cutoff_minute").is(':visible') ? $("[data-day='"+ c_day +"'].cutoff_minute option:selected").val() : json_data['cutoff_minute'];
                                    console.log(json_data,c_day,cutoff_hours,cutoff_minute,store_hour,store_minute)
                                }
                            });
                            if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                                if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                    str = parseInt(data[0].date_interval);
                                } else {
                                    if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                        str = parseInt(data[0].date_interval);
                                    } else {
                                        str = parseInt(data[0].date_interval) + 1;
                                    }
                                }
                            } else {
                                str = parseInt(data[0].date_interval) + 1;
                            }
                        }
                    } else {
                        cutoff_hours = cutoff_global_hours;
                        cutoff_minute = cutoff_global_minute;
                        if (parseInt(store_hour) <= parseInt(cutoff_hours)) {
                            if (parseInt(store_hour) < parseInt(cutoff_hours)) {
                                str = parseInt(data[0].date_interval);
                            } else {
                                if (parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                    str = parseInt(data[0].date_interval);
                                } else {
                                    str = parseInt(data[0].date_interval) + 1;
                                }
                            }
                        } else {
                            str = parseInt(data[0].date_interval) + 1;
                        }
                    }
                }
                start_from = '+' + parseInt(str);
                original_start_from = start_from;

                function pad(n) {
                    return (n < 10) ? ("0" + n) : n;
                }
                var tempdate = new Date();
                tempdate.setDate(tempdate.getDate());
                var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                var block_date_array = JSON.parse(dates);
                var block_days_array = unavailableDays;
                var NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                var NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                var current_available_day = weekday[tempdate.getDay()];
                exit_flag = 0;
                temp_count = start_from;
                if (!block_days_array) {
                    block_days_array = new Array();
                }
                if (!block_date_array) {
                    block_date_array = new Array();
                }
                /* if (shop_name == "sunshine-milk-bread.myshopify.com" || shop_name == "greenox.myshopify.com" || shop_name == "petaljet.myshopify.com" || shop_name == "alacena-de-monica-prueba-12345.myshopify.com" || shop_name == "hello-cheese.myshopify.com" || shop_name == "sweetworthy.myshopify.com" || shop_name == "the-cornish-scone-company.myshopify.com" || shop_name == "the-cornish-scone-company.myshopify.com" || shop_name == "sgrocerie.myshopify.com" || shop_name == "maison-duffour.myshopify.com") //  */
                if (parseInt(data[0].exclude_block_date_status) == 0) {
                    tempdate.setDate(tempdate.getDate() + parseInt(start_from));
                    while (temp_count != -1) {
                        var date = tempdate.getDate();
                        var month = tempdate.getMonth() + 1;
                        var year = tempdate.getFullYear();
                        NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                        NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                        current_available_day = weekday[tempdate.getDay()];
                        if ($kanaoddp_custom_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                            index_of = block_date_array.indexOf(NextDayDMY);
                            block_date_array.splice(index_of, 1);
                            start_from = parseInt(start_from) + 1;
                            temp_count = start_from;
                        } else if ($kanaoddp_custom_jq.inArray(current_available_day, block_days_array) !== -1) {
                            index_of = block_days_array.indexOf(current_available_day);
                            start_from = parseInt(start_from) + 1;
                            temp_count = start_from;
                        } else {
                            temp_count = -1;
                        }
                        tempdate.setDate(tempdate.getDate() + 1);
                    }
                } else {
                    if (temp_count == 0) {
                        if (block_date_array.length > 0 || block_days_array.length > 0) {
                            while ((block_date_array.length > 0 || block_days_array.length > 0) && temp_count > -1) {
                                var date = tempdate.getDate();
                                var month = tempdate.getMonth() + 1;
                                var year = tempdate.getFullYear();
                                NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                                NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                                current_available_day = weekday[tempdate.getDay()];

                                if ($kanaoddp_custom_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                                    index_of = block_date_array.indexOf(NextDayDMY);
                                    block_date_array.splice(index_of, 1);
                                    start_from = parseInt(start_from) + 1;
                                    temp_count = start_from;
                                } else if ($kanaoddp_custom_jq.inArray(current_available_day, block_days_array) !== -1) {
                                    index_of = block_days_array.indexOf(current_available_day);
                                    //block_days_array.splice(index_of, 1);
                                    start_from = parseInt(start_from) + 1;
                                    temp_count = start_from;
                                } else {
                                    if (block_date_array.length <= 0 || block_days_array.length <= 0) {
                                        temp_count = -1;
                                    } else if (temp_count == 0) {
                                        temp_count = -1;
                                    } else {
                                        temp_count--;
                                    }
                                }
                                tempdate.setDate(tempdate.getDate() + 1);
                            }
                        }
                    } else {
                        while ((block_date_array.length > 0 || block_days_array.length > 0) && temp_count != -1) {
                            var date = tempdate.getDate();
                            var month = tempdate.getMonth() + 1;
                            var year = tempdate.getFullYear();
                            NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                            NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                            current_available_day = weekday[tempdate.getDay()];
                            if ($kanaoddp_custom_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                                temp_count = 0;
                                index_of = block_date_array.indexOf(NextDayDMY);
                                block_date_array.splice(index_of, 1);
                                start_from = parseInt(start_from) + 1;
                                temp_count = start_from;

                            } else if ($kanaoddp_custom_jq.inArray(current_available_day, block_days_array) !== -1) {
                                index_of = block_days_array.indexOf(current_available_day);
                                temp_count = 0;
                                //block_days_array.splice(index_of, 1);
                                start_from = parseInt(start_from) + 1;
                                temp_count = start_from;

                            } else {

                                /* 1 Aug 2018 */
                                var start_from_date = new Date();
                                start_from_date.setDate(start_from_date.getDate() + parseInt(original_start_from));
                                if (tempdate.getTime() >= start_from_date.getTime()) {
                                    temp_count = -1;
                                    block_days_array = [];
                                }

                            }
                            tempdate.setDate(tempdate.getDate() + 1);

                        }
                    }
                }
                if (parseInt(data[0].exclude_block_date_status) == 1) {
                    var block_date_array = JSON.parse(dates);
                    var block_days_array = JSON.parse(day);
                    var ddmmyy = $kanaoddp_custom_jq("#ztpl-date-format-ddmmyy").val();
                    var yymmdd = $kanaoddp_custom_jq("#ztpl-date-format-yymmdd").val();
                    var date_index = parseInt(0);
                    var reloop = function(ddmmyy, yymmdd) {
                        var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                        var current_day = new Date(yymmdd);
                        var current_available_day = weekday[current_day.getDay()];
                        //if(jQuery.inArray(ddmmyy,block_date_array) !== -1)                            
                        //Here ddmmyy
                        if ($kanaoddp_custom_jq.inArray(ddmmyy, block_date_array) != -1) {
                            start_from = parseInt(start_from) + 1;

                            //And Here yymmdd??
                            var NextDayData = new Date(new Date(yymmdd).getFullYear(), new Date(yymmdd).getMonth(), new Date(yymmdd).getDate() + 1);

                            var date = new Date(NextDayData).getDate();
                            var month = new Date(NextDayData).getMonth() + 1;
                            var year = new Date(NextDayData).getFullYear();

                            var NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                            var NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                            //alert(NextDayDMY+'=='+NextDayYMD);
                            return reloop(NextDayDMY, NextDayYMD);
                        } else if ($kanaoddp_custom_jq.inArray(current_available_day, block_days_array) != -1) {
                            start_from = parseInt(start_from) + 1;
                            //alert('days== '+start_from);
                            var NextDayData = new Date(new Date(yymmdd).getFullYear(), new Date(yymmdd).getMonth(), new Date(yymmdd).getDate() + 1);
                            var date = new Date(NextDayData).getDate();
                            var month = new Date(NextDayData).getMonth() + 1;
                            var year = new Date(NextDayData).getFullYear();
                            var NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                            var NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                            return reloop(NextDayDMY, NextDayYMD);
                        }
                    }
                    reloop(ddmmyy, yymmdd);
                    //alert('total== '+start_from);
                    function pad(n) {
                        return (n < 10) ? ("0" + n) : n;
                    }
                }
            }
        });
        setTimeout(function() {
            var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

            function unavailable(date) {
                // if (shop_name == "purpinkg.myshopify.com") {}
                ymd = date.getFullYear() + "/" + ("0" + (date.getMonth() + 1)).slice(-2) + "/" + ("0" + date.getDate()).slice(-2);
                ymd1 = ("0" + date.getDate()).slice(-2) + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + date.getFullYear();
                day = new Date(ymd).getDay();
                if ($kanaoddp_custom_jq.inArray(ymd1, unavailableDates) < 0 && $kanaoddp_custom_jq.inArray(days[day], unavailableDays) < 0) {
                    return [true, "enabled", "Book Now"];
                } else {
                    return [false, "disabled", "Booked Out"];
                }
            }
            setTimeout(function() {
                datepicker_var = undefined;
                //For keeping datepicker always open    
                if (datepicker_on_default == 1) {
                    if (locale == "en") {
                        $kanaoddp_custom_jq("#datepicker_box .date-box").append("<div class='visible_datepicker'></div>");
                        $kanaoddp_custom_jq("#delivery-date-pro").attr("type", "hidden");
                        console.log('date_formate561',date_formate)
                        datepicker_var = $(".visible_datepicker").datepicker('destroy').datepicker({
                            dateFormat: date_formate,
                            minDate: start_from,
                            maxDate: "'" + allowed_month + "'",
                            beforeShowDay: unavailable,
                            onSelect: function(dateText) {
                                disable_today_highlight();
                                console.log('deliverytime_global_status',deliverytime_global_status)
                                if (deliverytime_global_status == 0 && app_version > 2) {
                                    delivery_date_pro_div(dateText);
                                }
                            },
                            beforeShow: function() {
                                setTimeout(function() {
                                    $kanaoddp_custom_jq('.ui-datepicker').css('z-index', 99999999999999);
                                }, 0);
                            }
                        });
                        if (datepicker_default_date == 1) {
                            datepicker_var.datepicker("setDate", start_from);
                        }
                    } else {
                        $.getScript( base_path_delivery_date + "js/localjs/datepicker-" + locale + ".js", function( data, textStatus, jqxhr ) {
                            //$kanaoddp_custom_jq.datepicker.setDefaults($kanaoddp_custom_jq.datepicker.regional[locale]); 
                            $kanaoddp_custom_jq("#datepicker_box .date-box").append("<div class='visible_datepicker'></div>");
                            $('.visible_datepicker').addClass('notranslate');
                            $kanaoddp_custom_jq("#delivery-date-pro").attr("type", "hidden");
                            console.log('date_formate588',date_formate)
                            datepicker_var = $kanaoddp_custom_jq(".visible_datepicker").datepicker('destroy').datepicker({
                                dateFormat: date_formate,
                                minDate: start_from,
                                maxDate: "'" + allowed_month + "'",
                                beforeShowDay: unavailable,
                                defaultDate: null,
                                onSelect: function(dateText) {
                                    $kanaoddp_custom_jq.getScript( base_path_delivery_date + "js/localjs/datepicker-" + locale + ".js");
                                    console.log('deliverytime_global_status',deliverytime_global_status)
                                    if (deliverytime_global_status == 0 && app_version > 2) {
                                        delivery_date_pro_div(dateText);
                                    }
                                    disable_today_highlight();
                                },
                                beforeShow: function() {
                                    setTimeout(function() {
                                        $kanaoddp_custom_jq('.ui-datepicker').css('z-index', 99999999999999);
                                    }, 0);
                                }
                            });
                        });
                    }
                } else {
                    $('#delivery-date-pro').attr('type','text');
                    if (locale == "en") {
                        $kanaoddp_custom_jq.datepicker.setDefaults($kanaoddp_custom_jq.datepicker.regional[locale]);
                        console.log('date_formate614',date_formate)
                        datepicker_var = $kanaoddp_custom_jq("#delivery-date-pro").datepicker('destroy').datepicker({
                            dateFormat: date_formate,
                            minDate: start_from,
                            maxDate: "'" + allowed_month + "'",
                            onSelect: function(dateText) {
                                console.log('deliverytime_global_status',deliverytime_global_status)
                                if (deliverytime_global_status == 0 && app_version > 2) {
                                    delivery_date_pro_div(dateText);
                                }
                                disable_today_highlight();
                                //console.log($kanaoddp_custom_jq("#delivery-date-pro").val());
                            },
                            beforeShowDay: unavailable,
                            defaultDate: null,
                            beforeShow: function(input, inst) {
                                setTimeout(function() {
                                    $kanaoddp_custom_jq('.ui-datepicker').css('z-index', 99999999999999);
                                    inst.dpDiv.css({
                                        top: $("#delivery-date-pro").offset().top + 35,
                                        left: $("#delivery-date-pro").offset().left
                                    });
                                }, 0);
                            }
                        });
                    } else {
                        //$kanaoddp_custom_jq.datepicker.setDefaults($kanaoddp_custom_jq.datepicker.regional[locale]);
                        console.log('date_formate637',date_formate)
                        datepicker_var = $kanaoddp_custom_jq("#delivery-date-pro").datepicker('destroy').datepicker({
                            dateFormat: date_formate,
                            minDate: start_from,
                            maxDate: "'" + allowed_month + "'",
                            onSelect: function(dateText) {
                                console.log('deliverytime_global_status',deliverytime_global_status)
                                //$kanaoddp_custom_jq('#AddToCart').prop('disabled', false);
                                $kanaoddp_custom_jq('.zAddToCart').prop('disabled', false);
                                if (deliverytime_global_status == 0 && app_version > 2) {
                                    delivery_date_pro_div(dateText);
                                }

                                var userLang = navigator.language || navigator.userLanguage;
                                //console.log ("The language is: " + userLang);
                                disable_today_highlight();

                            },
                            beforeShowDay: unavailable,
                            beforeShow: function(input, inst) {
                                setTimeout(function() {
                                    $kanaoddp_custom_jq('.ui-datepicker').css('z-index', 99999999999999);
                                    inst.dpDiv.css({
                                        top: $("#delivery-date-pro").offset().top + 35,
                                        left: $("#delivery-date-pro").offset().left
                                    });
                                }, 0);
                            }
                        });
                    }
                }

                if (app_version == 1 && datepicker_on_default == 1) {
                    remove_default_date();
                }
                if (app_version > 1 && type_of_app > 1) {
                    if (datepicker_default_date == 1) {
                        $kanaoddp_custom_jq("#delivery-date-pro").datepicker("setDate", "today + start_from");
                    } else {
                        $kanaoddp_custom_jq('.visible_datepicker').datepicker('setDate', null);
                    }
                }
            }, 300)
            $kanaoddp_custom_jq("#delivery-date-pro").prop("disabled", false);
        }, 100);
        $kanaoddp_custom_jq("#delivery-date-pro").prop("disabled", false);
        //Check App Version if it is 3(i.e Enterprise) or more then it will Exceute Following Code For Multiple Cut Off and Delivery Time
        if (app_version > 2 && type_of_app > 2) {
            console.log('deliverytime_global_status',deliverytime_global_status)
            if (deliverytime_global_status == 0) {
                delivery_date_pro();
                var result = "";
                $kanaoddp_custom_jq.ajax({
                    url: base_path_delivery_date + "delivery-times",
                    data: { shop_name: shop_name, start_from: start_from, date_format: date_formate },
                    async: false,
                    success: function(response) {
                        var c_day = new Date().getDay();
                        response = $("[name='delivery_time_"+ c_day +"[]']").is(':visible') ? $("[name='delivery_time_"+ c_day +"[]']").toArray().map(item => item.value) : response;
                        if (response == 0) {
                            $kanaoddp_custom_jq("#delivery-time").html("");
                        } else {
                            $kanaoddp_custom_jq("#delivery-time").html("");
                            $kanaoddp_custom_jq("#delivery-time").append("<option value=''>Choose Time</option>");
                            for (var key in response) {
                                $kanaoddp_custom_jq("#delivery-time").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                            }
                        }
                    }
                });
            } else {
                $kanaoddp_custom_jq(time_array).each(function() {
                    $kanaoddp_custom_jq('#delivery-time').append("<option value='" + time_array[time_count] + "'" + ">" + time_array[time_count] + "</option>");
                    time_count++;
                });
            }
        }

        setTimeout(function() {         
            textarea_variable = $kanaoddp_custom_jq('textarea[name=note]');
            old_order_note = textarea_variable.val();
            if (old_order_note) {
                open_index = old_order_note.indexOf("(Delivery Date:");
                if (open_index > -1) {
                    textarea_variable.html(old_order_note.substring(0, open_index - 1));
                }
            }
        }, 500);
        if(datepicker_default_date != 1){
            setTimeout(function () {
                $kanaoddp_custom_jq(".ui-state-highlight").removeClass('ui-state-highlight');
                $kanaoddp_custom_jq(".ui-state-hover").removeClass('ui-state-hover');
                remove_default_date();
            }, 2000);
        }
    }else{
        $('.additional-css').hide();
    }
    $kanaoddp_custom_jq('#CartSpecialInstructions').val(order_note);
}
//Following Function is for Showing Delivery Time Dynamically Based on Days
function delivery_date_pro_div(dateText) {
    var result = "";
    if (date_formate == "mm/dd/yy") {
        var date_array = dateText.split("/");
        dateText = date_array[2] +"-"+ date_array[0] + "-"+ date_array[1];
    }

    if (date_formate == "yy/mm/dd") {
        var date_array = dateText.split("/");
        dateText = date_array[0] +"-"+ date_array[1] + "-"+ date_array[2];
    }

    if (date_formate == "dd/mm/yy") {
        var date_array = dateText.split("/");
        dateText = date_array[2] +"-"+ date_array[1] + "-"+ date_array[0];
    }
    day = new Date(dateText).getDay();
    console.log('day',day,'dateText',dateText)
    $kanaoddp_custom_jq.ajax({
        url: base_path_delivery_date + "delivery-times",
        data: { todays_date: dateText, date_format: date_formate, shop_name: shop_name },
        async: false,
        success: function(response) {
            response = $("[name='delivery_time_"+ day +"[]']").is(':visible') ? $("[name='delivery_time_"+ day +"[]']").toArray().map(item => item.value) : response;
            if (response == 0) {
                $kanaoddp_custom_jq("#delivery-time").html("");
                if (is_time_required == true) {
                    alert('Sorry No Time Slots Available For ' + dateText + ' Please Select Other Date');
                    $kanaoddp_custom_jq("#delivery-date-pro").val("");
                    $kanaoddp_custom_jq("#delivery-date-pro").focus();
                }
            } else {
                $kanaoddp_custom_jq("#delivery-time").html("");
                $kanaoddp_custom_jq("#delivery-time").append("<option value=''>Choose Time</option>");
                for (var key in response) {
                    $kanaoddp_custom_jq("#delivery-time").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                }
            }
        }
    });
}

function delivery_date_pro() {
    var day;
    $kanaoddp_custom_jq("#delivery-date-pro").change(function(dateText) {
        $kanaoddp_custom_jq(".ui-state-active, .ui-widget-content .ui-state-active, .ui-widget-header .ui-state-active").css("cssText", "background:#000 !important;color:#fff !important;font-weight:700 !important;");
        var result = "";
        day = new Date(this.value).getDay();
        $kanaoddp_custom_jq.ajax({
            url: base_path_delivery_date + "delivery-times",
            data: { todays_date: this.value, date_format: date_formate, shop_name: shop_name },
            async: false,
            success: function(response) {
                if (response == 0) {
                    $kanaoddp_custom_jq("#delivery-time").html("");
                    if (is_time_required == true) {
                        alert('Sorry No Time Slots Available For ' + $kanaoddp_custom_jq("#delivery-date-pro").val() + ' Please Select Other Date');
                        $kanaoddp_custom_jq("#delivery-date-pro").val("");
                        $kanaoddp_custom_jq("#delivery-date-pro").focus();
                    }
                } else {
                    $kanaoddp_custom_jq("#delivery-time").html("");
                    $kanaoddp_custom_jq("#delivery-time").append("<option value=''>Choose Time</option>");
                    for (var key in response) {
                        $kanaoddp_custom_jq("#delivery-time").append("<option value='" + response[key] + "'> " + response[key] + " </option>");
                    }
                }
            }
        });
    });
}
// For remove default date as selected
function remove_default_date(){
    $kanaoddp_custom_jq(".visible_datepicker").val("");
    $kanaoddp_custom_jq(".visible_datepicker").find(".ui-state-active").removeClass("ui-state-active");
    $kanaoddp_custom_jq(".visible_datepicker").find(".ui-state-hover").removeClass("ui-state-hover");

}
// For remove todays date as selected
function disable_today_highlight(){
    setTimeout(function () {
        $kanaoddp_custom_jq(".ui-datepicker-today").find('a.ui-state-highlight').removeClass('ui-state-highlight');
        $kanaoddp_custom_jq(".ui-datepicker-today").find('a.ui-state-hover').removeClass('ui-state-hover');
    }, 10);
}