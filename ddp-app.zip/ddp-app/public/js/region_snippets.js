//Global Variable Declarations
var base_path_delivery_date = "https://zestardshop.com/shopifyapp/DeliveryDatePro/public/";
var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
var cutoff_hours, cutoff_minute, store_hour, store_minute, datepicker_default_date, deliverytime_global_status, app_version, type_of_app, cutoff_global_status, cutoff_status, cutoff_global_hours, cutoff_global_minute, start_from, is_time_required, is_date_required, time_array, time_count, deliverytime_response, cutoff_response, date_formate, add_delivery_information, order_note, locale, date_error_message, store_date, delivery_date_array, formatted_delivery_date, selected_delivery_date, datepicker_on_default, textarea_variable, original_start_from, time_error_message, disable_checkout;
var xhttp, data_length;
var shop_name = Shopify.shop;
//document.getElementsByName("checkout").disabled = true;
var $zestard_jq = "";
//Check if Jquery is Undefined or Not available.

(function() {
    // Load Jquery, If undefined
    var jscript = document.createElement("script");
    jscript.src = base_path_delivery_date + "js/zestard_jquery_3.3.1.js";
    jscript.type = 'text/javascript';
    jscript.async = false;

    var el = document.getElementById('datepicker_box');
    if (el == '' || el == 'undefined' || el == null) {
        el = document.createElement('div');
        el.id = "datepicker_box";
        elChild = document.createElement('div');
        elChild.id = 'datepicker_box_jquery';
    } else {
        elChild = document.createElement('div');
        elChild.id = 'datepicker_box_jquery';
        el.insertBefore(elChild, el.firstChild);
        document.getElementById('datepicker_box_jquery').appendChild(jscript);
    }

    jscript.onload = function() {
        //Assigning Jquery Object to Zestard_jq
        $zestard_jq = window.jQuery;
        $zestard_jq.ajax({
            url: base_path_delivery_date + "getconfig",
            dataType: "json",
            async: false,
            data: {
                shop: shop_name
            },
            success: function(data) {
                if (data == 0) {
                    data_length = data;
                } else {
                    locale = data[0].language_locale;
                }
            }
        });
        if (data_length != 0) {
            // Load Jquery UI, If undefined
            script = document.createElement('script');
            script.type = "text/javascript";
            script.src = base_path_delivery_date + 'js/jquery-ui.js';
            document.getElementById('datepicker_box_jquery').appendChild(script);
            script.onload = function() {

                // Check If jQuery UI Object is Undefined
                //Send Email that jQuery is Still not Working
                if (typeof jQuery.ui == 'undefined') {
                    //If undefined then send email
                    if (shop_name != "purpinkg.myshopify.com") {
                        xhttp = new XMLHttpRequest();
                        xhttp.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {

                            }
                        };
                        xhttp.open("GET", base_path_delivery_date + "acknowledge?shop_name=" + shop_name + "&type=2", true);
                        xhttp.send();
                    }
                } else {
                    if (locale == "en") {
                        $zestard_jq = window.jQuery;
                        //Calling Delivery Date Function
                        deliveryDatePro();
                    } else {
                        jscript = document.createElement("script");
                        jscript.src = base_path_delivery_date + "js/localjs/datepicker-" + locale + ".js";
                        jscript.type = 'text/javascript';
                        jscript.async = false;
                        var el = document.getElementById('datepicker_box'),
                            elChild = document.createElement('div');
                        elChild.id = 'datepicker_locale_jquery';
                        el.insertBefore(elChild, el.firstChild);
                        el.appendChild(elChild);
                        document.getElementById('datepicker_box_jquery').appendChild(jscript);
                        jscript.onload = function() {
                            $zestard_jq = window.jQuery;
                            //Calling Delivery Date Function
                            deliveryDatePro();
                        }
                    }
                }
            }
        } else {
            // App is inactive
            $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
            $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
            $("#datepicker_box").remove();
        }
    };
})();
function deliveryDatePro() {
    store_date = $zestard_jq("#ztpl-date-format-ddmmyy").val();
    $zestard_jq("#delivery-date-pro").val("");
    $zestard_jq.ajax({
        url: base_path_delivery_date + "get-type-and-version",
        async: false,
        data: { shop_name: shop_name },
        success: function(result) {
            data_length = result;
            if (data_length != 0) {
                app_version = result[0].app_version;
                type_of_app = result[0].type_of_app;
            } else {
                $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
                $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
                $("#datepicker_box").remove();
            }
        }
    });
    /* get region data */
    var region = [];
    $zestard_jq.ajax({
        url: base_path_delivery_date + "region",
        crossDomain: true,
        async: false,
        data: {
            shop_name: shop_name
        },
        success: function(response) {
            $zestard_jq("#region_id").append("<option value=''>Select Region</option>");
            for (var i = 0; i < response.length; i++) {
                $zestard_jq("#region_id").append("<option value='" + response[i]['region'] + "' data-id='" + response[i]['id'] + "'>" + response[i]['region'] + "</option>");
                region.push(response[i]['id']);
            }
            $zestard_jq('.regions').css('display', 'block');
        }
    });
    /* region end */

    if (data_length != 0) {
        var unavailableDates = [];
        var unavailableDays = [];
        start_from = '';
        var allowed_month = '';
        date_formate = '';
        var check_out_form = $zestard_jq("#delivery-date-pro").closest("form").attr('class');

        if (check_out_form) {
            var check_out_class_array = check_out_form.split(' ');
            if ($zestard_jq.inArray("cart-form", check_out_class_array) < 0) {
                $zestard_jq("#delivery-date-pro").closest("form").addClass("cart-form");
            }
        } else {
                $zestard_jq("#delivery-date-pro").closest("form").addClass("cart-form");
        }
        is_date_required = false;
        is_time_required = false;
        $zestard_jq.ajax({
            url: base_path_delivery_date + "getconfig",
            dataType: "json",
            async: false,
            data: {
                shop: shop_name
            },
            success: function(data) {
                app_status = data[0].app_status;
                locale = data[0].language_locale;
                datepicker_on_default = data[0].datepicker_display_on;
                datepicker_default_date = data[0].default_date_option;
                add_delivery_information = data[0].add_delivery_information;
                date_error_message = data[0].date_error_message;
                time_error_message = data[0].time_error_message;
                if (app_status == "Deactive") {
                    $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
                    $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
                    $zestard_jq("#datepicker_box").remove();
                }

                if (data[0].require_option == 1) {
                    is_date_required = true;
                    $zestard_jq("#delivery-date-pro").attr("required", "true");
                    $zestard_jq("#delivery-date-pro").closest("form").removeAttr('novalidate');
                }
                var date_label = data[0].datepicker_label;

                show_datepicker_label = data[0].show_datepicker_label;
                if (show_datepicker_label == 1) {
                    $zestard_jq('.date-box label').text(date_label);
                    if (shop_name == "mitcham-central-flowers.myshopify.com") {

                        setTimeout(function() {
                            $zestard_jq('.date-box label').text(date_label);
                        }, 3000);
                    }
                } else {
                    $zestard_jq('.date-box label').hide();
                }
                var dates = data[0].block_date;
                var day = data[0].days;
                start_from = '+' + data[0].date_interval;
                allowed_month = '+' + data[0].alloved_month + 'M';
                unavailableDates = $zestard_jq.parseJSON(dates);
                unavailableDays = $zestard_jq.parseJSON(day);
                date_formate = data[0].date_format;
                cutoff_status = data[0].cuttoff_status;
                cutoff_global_status = data[0].cutoff_global_status;
                deliverytime_global_status = data[0].deliverytime_global_status;

                cutoff_global_hours = data[0].hours;
                cutoff_global_minute = data[0].minute;

                // Get current Date, Hours
                var current_date = $zestard_jq("#ztpl-current-date").val();

                store_hour = $zestard_jq("#ztpl-store-hour").val();

                store_minute = $zestard_jq("#ztpl-store-minute").val();

                if (date_formate == "mm/dd/yy") {
                    var display_format = "(mm/dd/yyyy)";
                } else if (date_formate == "yy/mm/dd") {
                    var display_format = "(yyyy/mm/dd)";
                } else if (date_formate == "dd/mm/yy") {
                    var display_format = "(dd/mm/yyyy)";
                } else {
                    var display_format = "(mm/dd/yyyy)";
                }

                var show_date_format = data[0].show_date_format;
                if (show_date_format == 1) {
                    if (display_format != "") {
                        $zestard_jq("#selected_format").text(display_format);
                    } else {
                        $zestard_jq("#selected_format").text('mm/dd/yyyy');
                    }
                }
                var admin_note_status = data[0].admin_note_status;
                var notes_admin = data[0].admin_order_note;
                if (admin_note_status == 1) {
                    $zestard_jq("#admin_notes").html($zestard_jq.parseHTML(notes_admin));
                }

                var admin_time_status = data[0].admin_time_status;
                var time_lable = data[0].time_label;
                var default_option_label = data[0].time_default_option_label;
                if (admin_time_status == 1) {
                    var time_in_text = data[0].delivery_time;
                    time_array = new Array();
                    time_array = time_in_text.split(",");
                    time_count = 0;
                    //$zestard_jq("#delivery-time").show();
                    $zestard_jq("#delivery-time").css('display', 'block');
                    $zestard_jq("#delivery-time").css('border', 'none');
                    $zestard_jq("#time_option_label").text(default_option_label);
                    $zestard_jq("#delivery-time-label").show();
                    $zestard_jq("#delivery-time-label").text(time_lable);

                    if (data[0].time_require_option == 1) {
                        is_time_required = true;
                        $zestard_jq("#delivery-time").attr("required", "true");
                        $zestard_jq("#delivery-date-pro").closest("form").removeAttr('novalidate');
                    }
                }
                var additional_css = data[0].additional_css;
                $zestard_jq('#datepicker_box').after("<style>" + additional_css + "</style>");

                //Change Variable Name
                var str = parseInt(data[0].date_interval);

                if (parseInt(cutoff_status) == 0) {} else {

                    //Check App Version if it is 3(i.e Enterprise) or more then it will Exceute Following Code For Multiple Cut Off and Delivery Time
                    if (app_version > 2 && type_of_app > 2) {
                        // Check if global is enabled in Cuttoff settings
                        if (cutoff_global_status == 1) {
                            cutoff_hours = cutoff_global_hours;
                            cutoff_minute = cutoff_global_minute;
                            if (parseInt(store_hour) <= parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)) {
                                str = parseInt(data[0].date_interval);
                            } else {
                                str = parseInt(data[0].date_interval) + 1;
                            }
                        } else {
                            var region_name;
                            var region_array = ["Abu Dhabi", "Dubai", "Al Ain", "Sharjah", "Ajman", "Ras Al Khaimah", "Fujairah"];
                            var region_id = region[0];
                            var c_day = new Date().getDay();
                            region_change();
                        }
                    }
                }

                function region_change() {
                    $zestard_jq("#region_id").change(function() {
                        $zestard_jq('.main-box').css('display', 'block');
                        var flag = 0;
                        var region_id = $zestard_jq('#region_id option:selected').attr('data-id');

                        // Get day number
                        var c_day = new Date().getDay();
                        $zestard_jq.ajax({
                            url: base_path_delivery_date + "get-region-cutoff",
                            data: { day: c_day, shop_name: shop_name, region_id: region_id },
                            async: false,
                            success: function(response) {
                                debugger;
                                var json_data = JSON.parse(response);
                                if (json_data.length > 0) {
                                    var previous_hours = 0;
                                    for (var value in json_data) {
                                        if (value != 0) {
                                            previous_hours = json_data[value - 1]['cutoff_hour'];
                                        }
                                        region_name = json_data[value]['regions']['region'];
                                        date_interval = json_data[value]['date_interval'];
                                        cutoff_hours = json_data[value]['cutoff_hour'];
                                        cutoff_minute = json_data[value]['cutoff_minute'];
                                        delivery_time_slot = json_data[value]['region_delivery_time'];
                                        delivery_time_slot = JSON.parse(delivery_time_slot);
                                        var html = '';
                                        // Set Time based on the Region Cuttoff settings
                                        if ((parseInt(store_hour) <= parseInt(cutoff_hours)) && parseInt(store_hour) >= previous_hours && c_day != 5) {
                                            for (var key in delivery_time_slot) {
                                                $zestard_jq('.custom_delivery').show();
                                                $zestard_jq('.delivery-date-pro').css('display', 'block');
                                                $zestard_jq('#delivery-time-label').css('display', 'block');
                                                $zestard_jq('.error_note').hide();
                                                html += '<label><i class="fa fa-truck truck-icon"></i><input type="radio" name="delivery-time" value="' + delivery_time_slot[key] + '" /><i class="fa fa-check fa-2x"></i><span>' + delivery_time_slot[key] + '</span></label>';
                                            }
                                            $zestard_jq('.custom_delivery').html(html);
                                        } else {
                                            //**Need to check
                                            for (var key in delivery_time_slot) {
                                                $zestard_jq('.custom_delivery').show();
                                                $zestard_jq('.delivery-date-pro').css('display', 'block');
                                                $zestard_jq('#delivery-time-label').css('display', 'block');
                                                $zestard_jq('.error_note').hide();
                                                html += '<label><i class="fa fa-truck truck-icon"></i><input type="radio" name="delivery-time" value="' + delivery_time_slot[key] + '"/><i class="fa fa-check fa-2x"></i><span>' + delivery_time_slot[key] + '</span></label>';
                                            }
                                            $zestard_jq('.custom_delivery').html(html);
                                        }
                                        // Set Date based on Day Interval
                                        if ($zestard_jq.inArray(region_name, region_array) > -1) {
                                            // If store time is between cutoff time(Hours) defined in admin
                                            if ((parseInt(store_hour) < parseInt(cutoff_hours) ) && parseInt(store_hour) > previous_hours) {
                                                str = parseInt(date_interval);
                                                flag = 1;
                                            } else {
                                                // If store time is between cutoff time(Hrs-minutes) defined in admin
                                                if(parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) > parseInt(cutoff_minute)){
                                                    var index = parseInt(value)
                                                    if(typeof json_data[index + 1] !== "undefined"){

                                                        delivery_time_slot = json_data[index + 1]['region_delivery_time'];
                                                        delivery_time_slot = JSON.parse(delivery_time_slot);
                                                        html = '';
                                                        for (var key in delivery_time_slot) {

                                                            $zestard_jq('.custom_delivery').show();
                                                            $zestard_jq('.delivery-date-pro').css('display', 'block');
                                                            $zestard_jq('#delivery-time-label').css('display', 'block');
                                                            $zestard_jq('.error_note').hide();
                                                            html += '<label><i class="fa fa-truck truck-icon"></i><input type="radio" name="delivery-time" value="' + delivery_time_slot[key] + '"/><i class="fa fa-check fa-2x"></i><span>' + delivery_time_slot[key] + '</span></label>';
                                                        }
                                                        $zestard_jq('.custom_delivery').html(html);
                                                        date_interval = json_data[index+1]['date_interval'];
                                                    }
                                                    str = parseInt(date_interval);
                                                    flag = 1;
                                                }else if(parseInt(store_hour) == parseInt(cutoff_hours) && parseInt(store_minute) <= parseInt(cutoff_minute)){
                                                    str = parseInt(date_interval);
                                                    flag = 1;
                                                }else{
                                                    str = parseInt(date_interval);
                                                    flag = 0;
                                                }
                                            }
                                        }

                                        var date_flag =true;
                                        var formatted_delivery_date = ''
                                        while(date_flag){
                                            var current_date = new Date();
                                             formatted_delivery_date = current_date.setDate(current_date.getDate() + str);
                                             formatted_delivery_date = ("0" + current_date.getDate()).slice(-2) + "-" + ("0" + (current_date.getMonth() + 1)).slice(-2) + "-" + current_date.getFullYear();
                                            if($zestard_jq.inArray(formatted_delivery_date, unavailableDates) > -1){
                                                str = str+1
                                            }else{
                                                date_flag = false
                                            }
                                        }
                                        // Code end for block dates // venkatesh

                                        var current_date = new Date();
                                        var formatted_delivery_date = current_date.setDate(current_date.getDate() + str);

                                        if (date_formate == "dd/mm/yy") {
                                            formatted_delivery_date = ("0" + current_date.getDate()).slice(-2) + "/" + ("0" + (current_date.getMonth() + 1)).slice(-2) + "/" + current_date.getFullYear();
                                        }
                                        if (date_formate == "mm/dd/yy") {
                                            formatted_delivery_date = ("0" + (current_date.getMonth() + 1)).slice(-2) + "/" + ("0" + current_date.getDate()).slice(-2) + "/" + current_date.getFullYear();
                                        }
                                        if (date_formate == "yy/mm/dd") {
                                            formatted_delivery_date = current_date.getFullYear() + "/" + ("0" + (current_date.getMonth() + 1)).slice(-2) + "/" + ("0" + current_date.getDate()).slice(-2);
                                        }
                                        $zestard_jq(".title-label").html(date_label + ' :-');

                                        $zestard_jq(".delivery-date-pro").html(formatted_delivery_date);

                                        if (flag == 1) break;
                                    }
                                } else {
                                    if ($zestard_jq("#region_id").val() == '' || $zestard_jq("#region_id").val() == undefined) {
                                        $zestard_jq('.main-box').css('display', 'none');
                                        return false;
                                    }
                                    $zestard_jq('.error_note').show();
                                    $zestard_jq(".error_note").html("Sorry, we don't deliver to your location yet. We're working on it!");
                                    $zestard_jq('.custom_delivery').hide();
                                    $zestard_jq('.delivery-date-pro').css('display', 'none');
                                    $zestard_jq('#delivery-time-label').css('display', 'none');
                                }
                            }
                        });
                        $zestard_jq('input:radio[name=delivery-time]').on('change', function() {
                            if ($zestard_jq(this).prop('checked', true)) {
                                $zestard_jq('.truck-icon').show();
                                $zestard_jq(this).siblings('.truck-icon').hide();
                            }
                        });
                    });
                }

                //** Need to check */
                $zestard_jq('input:radio[name=delivery-time]').on('change', function() {
                    if ($zestard_jq(this).prop('checked', true)) {
                        $zestard_jq('.truck-icon').show();
                        $zestard_jq(this).siblings('.truck-icon').hide();
                    }
                });
                start_from = '+' + parseInt(str);
                original_start_from = start_from;

                function pad(n) {
                    return (n < 10) ? ("0" + n) : n;
                }
                var tempdate = new Date();
                tempdate.setDate(tempdate.getDate());
                var weekday = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                var block_date_array = JSON.parse(dates);
                var block_days_array = unavailableDays;
                var NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                var NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                var current_available_day = weekday[tempdate.getDay()];
                exit_flag = 0;
                temp_count = start_from;
                if (!block_days_array) {
                    block_days_array = new Array();
                }
                if (!block_date_array) {
                    block_date_array = new Array();
                }

                if (parseInt(data[0].exclude_block_date_status) == 0) {
                    tempdate.setDate(tempdate.getDate() + parseInt(start_from));
                    while (temp_count != -1) {
                        var date = tempdate.getDate();
                        var month = tempdate.getMonth() + 1;
                        var year = tempdate.getFullYear();
                        NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                        NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                        current_available_day = weekday[tempdate.getDay()];
                        if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                            index_of = block_date_array.indexOf(NextDayDMY);
                            block_date_array.splice(index_of, 1);
                            start_from = parseInt(start_from) + 1;
                            temp_count = start_from;
                        } else if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                            index_of = block_days_array.indexOf(current_available_day);
                            start_from = parseInt(start_from) + 1;
                            temp_count = start_from;
                        } else {
                            temp_count = -1;
                        }
                        tempdate.setDate(tempdate.getDate() + 1);
                    }
                } else {
                    if (temp_count == 0) {
                        if (block_date_array.length > 0 || block_days_array.length > 0) {
                            while ((block_date_array.length > 0 || block_days_array.length > 0) && temp_count > -1) {
                                var date = tempdate.getDate();
                                var month = tempdate.getMonth() + 1;
                                var year = tempdate.getFullYear();
                                NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                                NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                                current_available_day = weekday[tempdate.getDay()];

                                if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                                    index_of = block_date_array.indexOf(NextDayDMY);
                                    block_date_array.splice(index_of, 1);
                                    start_from = parseInt(start_from) + 1;
                                    temp_count = start_from;
                                } else if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                                    index_of = block_days_array.indexOf(current_available_day);
                                    //block_days_array.splice(index_of, 1);
                                    start_from = parseInt(start_from) + 1;
                                    temp_count = start_from;
                                } else {
                                    if (block_date_array.length <= 0 || block_days_array.length <= 0) {
                                        temp_count = -1;
                                    } else if (temp_count == 0) {
                                        temp_count = -1;
                                    } else {
                                        temp_count--;
                                    }
                                }
                                tempdate.setDate(tempdate.getDate() + 1);
                            }
                        }
                    } else {
                        while ((block_date_array.length > 0 || block_days_array.length > 0) && temp_count != -1) {
                            var date = tempdate.getDate();
                            var month = tempdate.getMonth() + 1;
                            var year = tempdate.getFullYear();
                            NextDayDMY = pad(date) + '-' + pad(month) + '-' + year;
                            NextDayYMD = year + '-' + pad(month) + '-' + pad(date);
                            current_available_day = weekday[tempdate.getDay()];
                            if ($zestard_jq.inArray(NextDayDMY, block_date_array) !== -1) {
                                temp_count = 0;
                                index_of = block_date_array.indexOf(NextDayDMY);
                                block_date_array.splice(index_of, 1);
                                start_from = parseInt(start_from) + 1;
                                temp_count = start_from;

                            } else if ($zestard_jq.inArray(current_available_day, block_days_array) !== -1) {
                                index_of = block_days_array.indexOf(current_available_day);
                                temp_count = 0;
                                //block_days_array.splice(index_of, 1);
                                start_from = parseInt(start_from) + 1;
                                temp_count = start_from;

                            } else {

                                /* 1 Aug 2018 */
                                var start_from_date = new Date();
                                start_from_date.setDate(start_from_date.getDate() + parseInt(original_start_from));
                                if (tempdate.getTime() >= start_from_date.getTime()) {
                                    temp_count = -1;
                                    block_days_array = [];
                                }

                            }
                            tempdate.setDate(tempdate.getDate() + 1);

                        }
                    }
                }

            }
        });
        setTimeout(function() {
            var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

            function unavailable(date) {
                if (shop_name == "purpinkg.myshopify.com") {}
                ymd = date.getFullYear() + "/" + ("0" + (date.getMonth() + 1)).slice(-2) + "/" + ("0" + date.getDate()).slice(-2);
                ymd1 = ("0" + date.getDate()).slice(-2) + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + date.getFullYear();
                day = new Date(ymd).getDay();
                if ($zestard_jq.inArray(ymd1, unavailableDates) < 0 && $zestard_jq.inArray(days[day], unavailableDays) < 0) {
                    return [true, "enabled", "Book Now"];
                } else {
                    return [false, "disabled", "Booked Out"];
                }
            }
            setTimeout(function() {

                datepicker_var = undefined;

                $zestard_jq("#delivery-date-pro").val("");
                // Check If Datepicker Object is Undefined
                /* if (app_version == 1 && type_of_app == 1) {
                 {
                 $zestard_jq("#delivery-date-pro").datepicker("setDate", "today - 1");
                 }
                 } */
                if (app_version > 1 && type_of_app > 1) {
                    if (datepicker_default_date == 1) {
                        $zestard_jq("#delivery-date-pro").datepicker("setDate", "today + start_from");
                    } else {
                        $zestard_jq('.visible_datepicker').datepicker('setDate', null);
                    }
                }
                if (typeof datepicker_var === 'undefined') {
                    if (shop_name != "purpinkg.myshopify.com") {
                        //If Undefined, Then send email
                        $zestard_jq.ajax({
                            url: base_path_delivery_date + "acknowledge",
                            async: false,
                            data: { shop_name: shop_name, type: 3 },
                            success: function(result) {}
                        });
                    }
                }
            }, 300)
            if (shop_name == "purpinkg.myshopify.com" || shop_name == "virginiamaryflorist.myshopify.com") {
                setTimeout(function() {
                    $(".visible_datepicker").find(".ui-state-active").css("border", "1px solid #c3c3c3");
                    $(".visible_datepicker").find(".ui-state-active").removeClass("ui-state-active");
                }, 2000);
            }
            $zestard_jq("#delivery-date-pro").prop("disabled", false);
        }, 100);

        $zestard_jq("#delivery-date-pro").prop("disabled", false);
        setTimeout(function() {
            /* $zestard_jq("input[name=checkout]").removeAttr('disabled');
             $zestard_jq("button[name=checkout]").removeAttr('disabled'); */
            $zestard_jq("input[name=checkout]").css('pointer-events', "auto");
            $zestard_jq("button[name=checkout]").css('pointer-events', "auto");
            //$zestard_jq("#datepicker_box").show();
        }, 3000);


        setTimeout(function() {
            textarea_variable = $zestard_jq('textarea[name=note]');
            old_order_note = textarea_variable.val();
            if (old_order_note) {
                open_index = old_order_note.indexOf("(Delivery Date:");
                if (open_index > -1) {
                    textarea_variable.html(old_order_note.substring(0, open_index - 1));
                }
            }
        }, 500);

        setTimeout(function() {
            $zestard_jq('input[name=checkout], button[name=checkout], .googlepay, .paypal-button').on('click', function(event) {

                var date = $zestard_jq('.delivery-date-pro').text();
                var time = $("input[name='delivery-time']:checked").val();
                var region_id = $zestard_jq('#region_id').val();

                $zestard_jq('.checked_time').attr('value', time);
                $zestard_jq('.delivery-date-pro-date').attr('value', date);

                if (region_id == '' || region_id == undefined) {
                    event.preventDefault();
                    alert('Please Select region');
                    return false;
                }

                order_note = '';
                old_order_note = '';
                if (app_status == 'Active') {
                    // if (is_date_required == true && ((typeof $zestard_jq('#delivery-date-pro').val() == 'undefined') || ($zestard_jq('#delivery-date-pro').val() == ''))) {
                    //     {
                    //         alert(date_error_message);

                    //     }
                    //     $zestard_jq('#delivery-date-pro').focus();
                    //     return false;
                    //     event.preventDefault();
                    // }
                    if (is_time_required == true) {
                        if (time == undefined || time == null || time == '') {
                            alert(time_error_message);
                            return false;
                        }

                    }

                    if (add_delivery_information == 1) {
                        order_note = textarea_variable.val();
                        old_order_note = textarea_variable.val();
                    }
                    //Check Blocked Days and Dates

                    if ($zestard_jq('#delivery-date-pro').val() != '') {
                        selected_delivery_date = $zestard_jq('#delivery-date-pro').val();
                        //if(shop_name == "debut-shopify.myshopify.com")
                        {
                            if (date_formate == "dd/mm/yy") {
                                formatted_delivery_date = selected_delivery_date;
                            }
                            if (date_formate == "mm/dd/yy") {
                                delivery_date_array = selected_delivery_date.split('/');
                                formatted_delivery_date = delivery_date_array[1] + '/' + delivery_date_array[0] + '/' + delivery_date_array[2];
                            }
                            if (date_formate == "yy/mm/dd") {

                                delivery_date_array = selected_delivery_date.split('/');
                                formatted_delivery_date = delivery_date_array[2] + '/' + delivery_date_array[1] + '/' + delivery_date_array[0];
                            }
                        }
                        var blocked_status, json_response, blocked_date_status;
                        var todays_date = $zestard_jq('#delivery-date-pro').val();
                        var today = new Date(todays_date).getDay();
                        $zestard_jq.ajax({
                            url: base_path_delivery_date + "check-blocked-day",
                            data: { todays_date: todays_date, date_format: date_formate, shop_name: shop_name },
                            async: false,
                            success: function(result) {
                                json_response = $zestard_jq.parseJSON(result);
                            }
                        });
                        blocked_status = json_response.result;

                        $zestard_jq.ajax({
                            url: base_path_delivery_date + "check-blocked-date",
                            data: { delivery_date: todays_date, date_format: date_formate, shop_name: shop_name },
                            async: false,
                            success: function(response) {
                                blocked_date_status = response;
                            }
                        });

                        if (blocked_status == 0) {
                            alert('Sorry Delivery is Not Possible for ' + json_response.today + ' . Please Select Other Day');
                            event.preventDefault();
                        }
                        if (blocked_date_status == 0) {
                            alert('Sorry, The Delivery Date You Selected is Blocked. Please Select Other Delivery Date');
                            event.preventDefault();
                        }
                        if (blocked_date_status == 1 && blocked_status == 1) {
                            $zestard_jq.ajax({
                                url: base_path_delivery_date + "check-cuttoff",
                                data: { start_from: start_from, date_format: date_formate, delivery_date: formatted_delivery_date, store_hour: store_hour, store_minute: store_minute, shop_name: shop_name, store_date: store_date },
                                async: false,
                                success: function(result) {
                                    cutoff_response = result;
                                }
                            });


                            if (add_delivery_information == 1) {
                                old_order_note = textarea_variable.val();
                                if (old_order_note) {
                                    open_index = old_order_note.indexOf("(Delivery Date:");
                                    if (open_index > -1) {
                                        textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                    }
                                }
                                order_note = old_order_note;
                                if (order_note == "" || typeof order_note === "undefined") {
                                    order_note = " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val() + ")";
                                } else {
                                    order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val();
                                }
                                if (time != '' || time != undefined) {
                                    order_note = order_note + ", Delivery Time: " + $zestard_jq('#delivery-time').val() + ")";
                                }


                            }
                            if (cutoff_response == 1) {
                                if (time == "" || typeof $zestard_jq('#delivery-date-pro').val() === 'undefined' || time != undefined) {
                                    if (is_time_required == true) {
                                        alert("Please Select Delivery Time");
                                        event.preventDefault();
                                    } else {
                                        if (add_delivery_information == 1) {

                                            old_order_note = textarea_variable.val();
                                            if (old_order_note) {
                                                open_index = old_order_note.indexOf("(Delivery Date:");
                                                if (open_index > -1) {
                                                    textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                                }
                                            }
                                            order_note = old_order_note;
                                            if (order_note == "" || typeof order_note === "undefined") {
                                                order_note = " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val() + ")";
                                            } else {
                                                order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val();
                                            }
                                            if (time != '' || time != undefined) {
                                                order_note = order_note + ", Delivery Time: " + $zestard_jq('#delivery-time').val() + ")";
                                            }
                                            textarea_variable.val(order_note);
                                        }
                                    }
                                } else {

                                    if (add_delivery_information == 1) {

                                        old_order_note = textarea_variable.val();
                                        if (old_order_note) {
                                            open_index = old_order_note.indexOf("(Delivery Date:");
                                            if (open_index > -1) {
                                                textarea_variable.html(old_order_note.substring(0, open_index - 1));
                                            }
                                        }
                                        order_note = old_order_note;
                                        if (order_note == "" || typeof order_note === "undefined") {
                                            order_note = " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val() + ")";
                                        } else {
                                            order_note = order_note + " (Delivery Date: " + $zestard_jq('#delivery-date-pro').val();
                                        }
                                        if (time != undefined || time != '') {
                                            order_note = order_note + ", Delivery Time: " + $zestard_jq('#delivery-time').val() + ")";
                                        }
                                        textarea_variable.val(order_note);
                                    }
                                    if (deliverytime_global_status == 0) {

                                        $zestard_jq.ajax({
                                            url: base_path_delivery_date + "check-delivery-time",
                                            data: { delivery_time: $zestard_jq("#delivery-time").val(), date_format: date_formate, delivery_date: formatted_delivery_date, shop_name: shop_name },
                                            async: false,
                                            success: function(result) {

                                                deliverytime_response = result;
                                            }
                                        });
                                        if (deliverytime_response == 1) {

                                        } else {
                                            alert("Selected Delivery Time Slot is Full. Plese Select Other Delivery Time");
                                            event.preventDefault();
                                        }
                                    } else {}
                                }
                            }
                        }
                    }
                }
            });
        });
    }
    $zestard_jq('#cartSpecialInstructions').val(order_note);
}