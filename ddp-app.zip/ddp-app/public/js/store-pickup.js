import React, { useEffect, useState } from 'react';
import CalenderInline from '../common_component/CalenderInline';
import { htmlspecialchars_decode, ODD_fetchData, tConvert24To12 } from '../helper/common';
import { useSelector, useDispatch } from 'react-redux';
import GoogleMapContainer from './GoogleMapContainer';
import jqueryODD from 'jquery';
import Paginations from './SpPagination';
import { getdatePicker } from '../redux/redux_slice/changeClass';
import { getPageindex, getlocationIndex } from '../redux/redux_slice/storePickupData';
const locationSvg = require('../asset/constants/commonCalenderSvg.json');

function StorePickup({ storePickupApiResponse, storePickup }) {
    const [latLong, setLatLong] = useState([]);
    const generalSettings = useSelector(state => state.generalSettingsSlice.generalSettings);
    const activeAddon = useSelector(state => state.generalSettingsSlice.activeAddon);
    const dispatch = useDispatch();
    const [calenderSetting, setCalenderSetting] = useState({});
    const [locationId, setlocationId] = useState(0);
    const [openPopUp, setPopup] = useState();
    const [locationRegion, setlocationRegion] = useState();
    const [locationDetails, setlocationDetails] = useState();
    const [locationInfo, setlocationInfo] = useState();
    const [pageOffset, setpageOffset] = useState();
    const [locationIdIndex, setlocationIdIndex] = useState();
    const [regionFilter, setregionFilter] = useState([]);
    const [isShow, setisShow] = useState(false);
    const [Region, setRegion] = useState();
    const page_offset = useSelector(state => state.pageOffsetData);
    useEffect(() => {
        if (storePickupApiResponse?.location_ids) {
            setCalenderDetail();
            mapLatitude();
            dispatch(getdatePicker(true));
        }
    }, [storePickupApiResponse]);

    const setCalenderDetail = (id, location) => {
        const location_ids = location?.length > 0 ? location : storePickupApiResponse?.location_ids;
        const index = id && id !== 'region' ? id : 0;
        const address = `${storePickupApiResponse[location_ids[index]]?.address1} ${storePickupApiResponse[location_ids[index]]?.address2} ${storePickupApiResponse[location_ids[index]]?.city} ${storePickupApiResponse[location_ids[index]]?.province_name} ${storePickupApiResponse[location_ids[index]]?.country_name}`;
        window.ODD_CONFIG.checkout_address = {
            address1: storePickupApiResponse[location_ids[index]]?.address1,
            address2: storePickupApiResponse[location_ids[index]]?.address2,
            city: storePickupApiResponse[location_ids[index]]?.city,
            zip: storePickupApiResponse[location_ids[index]]?.zip,
            country: storePickupApiResponse[location_ids[index]]?.country_name,
            province: storePickupApiResponse[location_ids[index]]?.province_name
        }
        if (location_ids.length) {
            setCalenderSetting({
                firstDayCalender: storePickupApiResponse[
                    location_ids[index]
                ]?.sp_date_settings?.first_day_calender,
                min_date: storePickupApiResponse[location_ids[index]]?.sp_date_settings?.min_date,
                max_date: storePickupApiResponse[location_ids[index]]?.sp_date_settings?.max_date,
                disable_date: storePickupApiResponse[
                    location_ids[index]
                ]?.sp_date_settings?.disable_date,
                avilable_days: storePickupApiResponse[
                    location_ids[index]
                ]?.sp_date_settings?.available_days,
                cutoff_time: storePickupApiResponse[
                    location_ids[index]
                ]?.sp_date_settings?.cutoff_final,
                isShowSlots: {
                    is_show_hide_slot:
                        storePickupApiResponse[location_ids[index]]?.sp_date_settings
                            ?.is_sp_show_hide_slot,
                    hide_slots_settings:
                        storePickupApiResponse[location_ids[index]]?.sp_date_settings
                            ?.sp_hide_slots_settings
                },
                padding_time_status: storePickupApiResponse[
                    location_ids[index]
                ]?.sp_date_settings?.padding_time_status,
                padding_time: storePickupApiResponse[
                    location_ids[index]
                ]?.sp_date_settings?.padding_time_final,
                padding_time_min_status: storePickupApiResponse[
                    location_ids[index]
                ]?.sp_date_settings?.padding_time_min_status,
                min_interval_time: storePickupApiResponse[
                    location_ids[index]
                ]?.sp_date_settings?.min_interval_time,
                cal_inline_text: storePickup?.store_pickup_cal_inline_text,
                delivery_time: storePickupApiResponse[location_ids[index]]?.delivery_time,
                time_zone: storePickupApiResponse[location_ids[index]]?.sp_date_settings?.time_zone,
                timerHeading: storePickup?.store_pickup_timer_heading,
                require_holiday_interval: storePickup?.sp_required_holiday_interval,
                extraInfo: {
                    'Order Type': 'Store Pickup',
                    'Location Id': location_ids[index] || '',
                    'Location Address': htmlspecialchars_decode(address) || '',
                    'Location Name': htmlspecialchars_decode(storePickupApiResponse[location_ids[index]]?.location_name || ''),
                    'calendar_type': ''
                }
            });
        }
    };

    function mapLatitude(id) {
        let lat_lng = [];
        let location_ids = storePickupApiResponse?.location_ids;
        let i = location_ids.length;
        while (i--) {
            let id = location_ids[i];
            if (storePickupApiResponse[id]?.lat_lng !== undefined) {
                lat_lng[id] = storePickupApiResponse[id]?.lat_lng;
            }
            setLatLong(lat_lng)
        }
    }

    function showCalender(id, i) {
        document.getElementsByClassName('deliverytimeValue')[0].value = '';
        document.getElementsByClassName('deliveryDateValue')[0].value = '';
        mapLatitude(i);
        dispatch(getdatePicker(true));
        dispatch(getlocationIndex(i));
        setCalenderDetail(id, page_offset?.locationId);
    }

    function showRegion(id, province) {
        document.getElementsByClassName('deliverytimeValue')[0].value = '';
        document.getElementsByClassName('deliveryDateValue')[0].value = '';
        dispatch(getdatePicker(true));
        setlocationRegion(id);
        const locationids = storePickupApiResponse?.location_ids;
        const regionArray = [];
        const spPageLimit = storePickupApiResponse?.sp_page_limit;
        let i = locationids.length;
        while (i--) {
            if (province.target[province.target.selectedIndex].id === (storePickupApiResponse[locationids[i]].province_name) || (!id && regionArray?.length < spPageLimit)) {
                regionArray.push(locationids[i]);
            }
        }
        setCalenderDetail(0, regionArray);
        setlocationId(id);
        mapLatitude(regionArray[0]);
        dispatch(getPageindex(true));
        if (!id) {
            dispatch(getlocationIndex(locationids[0]));
            setRegion(locationids);
        } else {
            dispatch(getlocationIndex(regionArray[0]));
            setRegion(regionArray);
        }
        setisShow(true);
    }

    function moreInformation(id) {
        if (id) {
            setPopup('block');
            document.body.classList.add('popup_open');
            const location_ids = storePickupApiResponse[id];
            const location_name = location_ids?.location_name || '';
            const address = `${location_ids?.address1 || ''} ${location_ids?.address2 || ''} ${location_ids?.city || ''} ${location_ids?.province_name || ''} ${location_ids?.country_name || ''} ${location_ids?.zip || ''}`;
            setlocationDetails({
                location_name, address
            });
            const time_format = location_ids?.delivery_time?.time_format;
            const dayName = generalSettings?.delivey_days_text;
            const invalidDay = location_ids?.sp_date_settings?.available_days;
            const Days = ['0', '1', '2', '3', '4', '5', '6'];
            const DayName = [];
            for (let i = 0; i < invalidDay.length; i++) {
                if (invalidDay[i] !== Days[i]) {
                    DayName.push(dayName[invalidDay[i]]);
                }
            }
            let timeFormatHtml = '';
            if (time_format == '0') {
                const delivery_time = location_ids?.delivery_time?.time_24;
                let daysList = '<tr>';
                let timeList = '<tr>';
                const timeFormatValuearr = [];
                let x = 0;
                while (x < 24) {
                    if (delivery_time[x] !== undefined) {
                        timeFormatValuearr.push(delivery_time[x]);
                    }
                    x++;
                }
                const time = timeFormatValuearr.join('<br>');
                let i = 0;
                let len = DayName.length;
                while (i < len) {
                    daysList += `<td>${DayName[i]}</td>`;
                    timeList += `<td>${time}</td>`;
                    i++;
                }
                daysList += '</tr>';
                timeList += '</tr>';
                timeFormatHtml = daysList + timeList;
            } else if (time_format == '1') {
                const delivery_time = location_ids?.delivery_time?.time;
                let i = 0;
                let len = DayName.length;
                while (i < len) {
                    timeFormatHtml += '<tr>';
                    timeFormatHtml += `<td>${DayName[i]}</td>`;
                    for (let x = 0; x < delivery_time?.length; x++) {
                        timeFormatHtml += `<td>${delivery_time[x]}</td>`;
                    }
                    timeFormatHtml += '</tr>';
                    i++;
                }
            } else if (time_format == '2') {
                const delivery_time = location_ids?.delivery_time;
                const timeValue = ['sunday_time_value', 'monday_time_value', 'tuesday_time_value', 'wednesday_time_value', 'thursday_time_value', 'friday_time_value', 'saturday_time_value'];
                const timeValues = [];
                let i = invalidDay.length;
                let length = 0;
                while (length < i) {
                    timeValues.push(timeValue[invalidDay[length]]);
                    length++;
                }
                let index = 0;
                let len = timeValues.length;
                while (index < len) {
                    const dayArray = timeValues[index];
                    const timeFormatValues = delivery_time[dayArray];
                    const timeFormatValuesLength = timeFormatValues.length;
                    if (DayName[index]) {
                        timeFormatHtml += '<tr>';
                        timeFormatHtml += `<td>${DayName[index]}</td>`;
                        for (let a = 0; a < timeFormatValuesLength; a++) {
                            if (a == 0) {
                                timeFormatHtml += `<td>${timeFormatValues[a]}</td></tr>`;
                            } else {
                                timeFormatHtml += '<tr><td></td>';
                                timeFormatHtml += `<td>${timeFormatValues[a]}</td>`;
                                timeFormatHtml += '</tr>';
                            }
                        }
                    }
                    index++;
                }
            } else {
                const delivery_time = location_ids?.delivery_time;
                let a = 0;
                let len = DayName.length;
                while (a < len) {
                    timeFormatHtml += '<tr>';
                    timeFormatHtml += `<td>${DayName[a]}</td>`;
                    const timeFormatValueLength = Object.keys(delivery_time[invalidDay[a]]?.start_time).length;
                    let index = 0;
                    let x = timeFormatValueLength;
                    while (index < x) {
                        let startTime = delivery_time[invalidDay[a]]['start_time'][index]
                        let endTime = delivery_time[invalidDay[a]]['end_time'][index];
                        if (delivery_time.time_format_hour == 12) {
                            startTime = tConvert24To12(delivery_time[invalidDay[a]]['start_time'][index]);
                            endTime = tConvert24To12(delivery_time[invalidDay[a]]['end_time'][index]);
                        }
                        if (index == 0) {
                            timeFormatHtml += `<td>${startTime}-${endTime}</td></tr>`;
                        } else {
                            timeFormatHtml += '<tr><td></td>';
                            timeFormatHtml += `<td>${startTime}-${endTime}</td>`;
                            timeFormatHtml += '</tr>';
                        }
                        index++;
                    }
                    a++;
                }
            }
            setlocationInfo(timeFormatHtml);
        } else {
            setPopup('none');
            document.body.classList.remove('popup_open');
        }
    }

    useEffect(() => {
        const locationids = storePickupApiResponse?.location_ids;
        const regionArray = [];
        let i = locationids?.length;
        while (i--) {
            if (regionArray.indexOf(storePickupApiResponse[locationids[i]]?.province_name) === -1) {
                regionArray.push(storePickupApiResponse[locationids[i]]?.province_name);
            }
        }
        setregionFilter(regionArray);
    }, [storePickupApiResponse]);

    /** auto select on change of location and radio button */
    useEffect(() => {
        if (generalSettings?.auto_select_date === '0') {
            jqueryODD('.uiDeliveryCalendar').datepicker('setDate', null);
            jqueryODD('.uiDeliveryCalendar')
                .find('.ui-datepicker-current-day a')
                .removeClass('ui-state-active')
                .removeClass('ui-state-hover');
            jqueryODD('.uiDeliveryCalendar')
                .find('.ui-datepicker-current-day')
                .removeClass('ui-datepicker-current-day')
                .removeClass('ui-datepicker-days-cell-over');
            jqueryODD('.uiDeliveryCalendar .ui-datepicker').addClass('notranslate');
            jqueryODD('#ui-datepicker-div').addClass('notranslate');
        }
    }, [calenderSetting]);

    useEffect(() => {
        setpageOffset(page_offset?.locationId);
        setlocationIdIndex(page_offset?.locationIndex);
    }, [page_offset]);

    return (
        <>
            <style>
                .store_dv{'{'}
                background: {storePickup?.sp_tab_bg_color} !important; box-shadow :
                inset 0 1px 0 0 {storePickup?.sp_tab_bg_color}, 0 0 0 0 transparent
                !important; border-color: {storePickup?.sp_tab_bg_color} !important;
                {'}'}
                .store_dv svg path {'{'}
                stroke: {storePickup?.sp_tab_sel_icon_color} !important;
                {'}'}
                .store_dv svg.calendar-svg {'{'}
                fill: {storePickup?.sp_tab_sel_icon_color} !important;
                {'}'}
                .pagination > .active > a, .pagination > .active > span, .pagination > .active > a:hover, .pagination > .active > span:hover, .pagination > .active > a:focus, .pagination > .active > span:focus {'{'}
                background-color : {storePickup?.sp_tab_bg_color} !important;
                border: 1px solid #dadada !important;
                color : {storePickup?.sp_tab_sel_icon_color} !important;
                {'}'}
                .pagination > li > a, .pagination > li > span {'{'}
                background: {storePickup?.store_pkp_tab_bg_color};
                color: {storePickup?.sp_tab_icon_color} !important;
                {'}'}
                .identixweb-pagination li:not(.disabled) a:hover:not(.active){'{'}
                background-color : {storePickup?.sp_tab_bg_color} !important;
                border-color: {storePickup?.sp_tab_bg_color} !important;
                color : {storePickup?.sp_tab_sel_icon_color} !important;
                {'}'}
            </style>
            <div className="identixweb-order-delivery-date-main">
                {storePickupApiResponse?.status === 2 ? <p className="identixweb-order-delivery-date-deliveryRequired odd_notrequired" style={{ display: 'block' }}>{storePickup?.store_pickup_product_availability_text && htmlspecialchars_decode(storePickup.store_pickup_product_availability_text) || 'Sorry product not available in store locations.'}</p> : storePickupApiResponse ? <div className="identixweb-order-delivery-date-store-pickup1">
                    <input type="hidden" className="deliveryDateValue uiDeliveryDateVal" />
                    <input type="hidden" className="deliveryDayValue" />
                    {storePickupApiResponse?.google_map_status === '1' && (
                        <>
                            <div className="identixweb-order-delivery-date-uiHeading main_heading odd_calender_heading" dangerouslySetInnerHTML={{__html: htmlspecialchars_decode(storePickup?.store_pickup_subheading)}}>
                            </div>
                            <div className="identixweb-map">
                                <GoogleMapContainer google_map_key={storePickupApiResponse?.google_map_key} mapLatitude={latLong} location={locationIdIndex} />
                            </div>
                        </>
                    )}
                    <p className="identixweb-order-delivery-date-uiHeading identixweb-order-delivery-date-subHeading odd_calender_heading">
                        {storePickup?.store_pickup_location_heading &&
                            htmlspecialchars_decode(
                                storePickup.store_pickup_location_heading
                            )}
                    </p>
                    <div className="region-replace">
                        <div className="odd-sp-right-location">
                            {storePickupApiResponse?.region_status === '1' ? (
                                <div className="region-filter">
                                    <select
                                        className="region_filter"
                                        aria-invalid="false"
                                        onChange={(e) => shaowRegion(e.target.value, e)}
                                    >
                                        <option value=''>Select Region Value</option>
                                        {regionFilter?.map((province_name, i) => {
                                            return (<option
                                                key={province_name}
                                                value={i}
                                                id={province_name}
                                            >
                                                {htmlspecialchars_decode(province_name || 'Select Province')}
                                            </option>
                                            );
                                        })}
                                    </select>
                                </div>
                            ) : ''}
                            <div>
                                <div className="identixweb-locations">
                                    {pageOffset?.map((id, i) => {
                                        if ((storePickupApiResponse[id]?.status === 1) && (locationRegion || !locationRegion)) {
                                            return (
                                                <div className="identixweb-store" key={i}>
                                                    <input
                                                        type="radio"
                                                        name="location_id"
                                                        className="identixweb-locationRadio"
                                                        value={`${id}`}
                                                        onChange={() => showCalender(i, id)}
                                                        checked={!locationIdIndex ? i === 0 : locationIdIndex === id} />
                                                    <span className="identixweb-storr-span">
                                                        <strong>
                                                            {storePickupApiResponse[id]?.location_name &&
                                                                htmlspecialchars_decode(
                                                                    storePickupApiResponse[id].location_name
                                                                )}
                                                        </strong>
                                                        <span dangerouslySetInnerHTML={{__html: htmlspecialchars_decode(`${storePickupApiResponse[id]?.address1} ${storePickupApiResponse[id]?.address2} ${storePickupApiResponse[id]?.province_name} ${storePickupApiResponse[id]?.country_name}`)}}>
                                                        </span>
                                                        {storePickupApiResponse[id]?.delivery_time
                                                            ?.timer_status === 1 ? (
                                                            <>
                                                                <input type="hidden" className="deliverytimeValue uiDeliveryTimeVal" />
                                                                <a href={null} className="identixweb-popup" onClick={() => moreInformation(id)} dangerouslySetInnerHTML={{__html: htmlspecialchars_decode(storePickup?.store_pickup_more_information_text || 'More information')}}>
                                                                </a>
                                                            </>
                                                        ) : ''}
                                                    </span>
                                                    <span
                                                        className="odd-location-map"
                                                        title="View on map"
                                                        dangerouslySetInnerHTML={{
                                                            __html: locationSvg.common.LOCATION_MAP
                                                        }}
                                                    ></span>
                                                </div>
                                            );
                                        }
                                    })}
                                    <div id="myModalidentixweb" className="identixweb-order-delivery-date-spmodel identixweb-modal" style={{ display: openPopUp ? openPopUp : 'none' }} >
                                        <div className="identixweb-modal-content">
                                            <span className="closeidentixweb" onClick={() => moreInformation('')} >  × </span>
                                            <div className="identixweb-modal-detail">
                                                <strong className="model-heading-identixweb heading-identixweb">
                                                    {htmlspecialchars_decode(locationDetails?.location_name)}
                                                </strong>
                                                <span className="model-heading-identixweb-address">
                                                    {htmlspecialchars_decode(locationDetails?.address)}
                                                </span>
                                                <div className="identixweb-openingHours">
                                                    <div className="identixweb-openingHours-time">
                                                        <h2>{storePickup?.store_pickup_opening_hours_text && htmlspecialchars_decode(storePickup.store_pickup_opening_hours_text) || 'Opening hours'}</h2>
                                                        <table className="identixweb-table-moreinformation-data">
                                                            <tbody dangerouslySetInnerHTML={{ __html: locationInfo }}>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="identixweb-order-delivery-date-store-pickup-delivery">
                        <div className="identixweb-order-delivery-date-store-pickup-delivery-uiHeading identixweb-order-delivery-date-uiHeading">{storePickup?.store_pickup_calender_heading && htmlspecialchars_decode(storePickup.store_pickup_calender_heading)}</div>
                            <p className="identixweb-order-delivery-date-store-pickup-delivery-deliveryRequired deliveryRequired">{storePickup?.store_pickup_cart_required_message && htmlspecialchars_decode(storePickup.store_pickup_cart_required_message)}</p>
                            <div className={`iw-calendar ${calenderSetting?.delivery_time?.timer_status == 1 ? 'iw-calander-active' : 'iw-calander-diactive'}`}>
                                {calenderSetting?.firstDayCalender ?
                                    <CalenderInline
                                        generalSetting={generalSettings}
                                        active_addon={activeAddon}
                                        calender_setting={calenderSetting}
                                    /> : ''}
                            </div>
                            <div className="note_div">
                                <p className="identixweb-order-delivery-deliveryNote" dangerouslySetInnerHTML={{__html: htmlspecialchars_decode(storePickup?.store_pickup_calendar_note)}}>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="identixweb-pagination">
                        <Paginations spPageLimit={storePickupApiResponse?.sp_page_limit} pageOffset={isShow ? Region : storePickupApiResponse?.location_ids} locationId={locationId} />
                    </div>
                </div> : ''}
            </div>
        </>
    );
}

export default React.memo(StorePickup);