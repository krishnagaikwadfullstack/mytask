function copy_text() {
    $(this).CopyToClipboard();
    alert('Shortcode Copied');
}

function copy_script() {
    var script = document.getElementById('script_code').value;
    var script = prompt("Copy this code", script);

}

function copy_script_product(short_code) {
    var script = prompt("Copy this code", short_code);
}

function copy_popup() {
    var script = document.getElementById('popup_code').value;
    var script = prompt("Copy this code", script);

}